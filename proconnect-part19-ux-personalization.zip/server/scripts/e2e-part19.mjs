// Part 19 end-to-end run against a real server process and a throw-away database file: preferences, the personalized Home data,
// sign-out and a server restart. No job source or news source is contacted.
// Usage: npm run e2e:part19   (does not touch your own data folder)
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'proconnect-e2e19-'));
const PORT = String(5300 + Math.floor(Math.random() * 400));
const dbFile = path.join(tmp, 'e2e.db');
const env = { ...process.env, JOBS_SYNC: 'off', NEWS_SYNC: 'off', PORT, PROCONNECT_DB: dbFile, PROCONNECT_UPLOADS: path.join(tmp, 'uploads') };
const base = `http://127.0.0.1:${PORT}`;
const PASSWORD = 'ProConnect123!';

const seed = spawnSync(process.execPath, ['--disable-warning=ExperimentalWarning', 'src/db/seed.js', '--reset'], { cwd: ROOT, env });
if (seed.status !== 0) { console.error(seed.stderr.toString()); process.exit(1); }

let server;
const start = async () => {
  server = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', 'src/index.js'], { cwd: ROOT, env, stdio: 'ignore' });
  for (let i = 0; i < 80; i++) { try { if ((await fetch(`${base}/api/health`)).ok) return; } catch { /* not up yet */ } await new Promise((r) => setTimeout(r, 100)); }
  throw new Error('The server did not start');
};
const stop = async () => { server.kill(); await new Promise((r) => setTimeout(r, 400)); };

const person = () => {
  let cookie = '';
  const call = async (method, route, body) => {
    const headers = cookie ? { Cookie: cookie } : {};
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    const res = await fetch(base + route, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
    const set = res.headers.getSetCookie().map((c) => c.split(';')[0]).find((c) => c.startsWith('pc_token='));
    if (set) cookie = set === 'pc_token=' ? '' : set;
    return { status: res.status, body: await res.json() };
  };
  return { get: (r) => call('GET', r), post: (r, b) => call('POST', r, b ?? {}), put: (r, b) => call('PUT', r, b) };
};
const login = async (email) => { const p = person(); const r = await p.post('/api/auth/login', { email, password: PASSWORD }); if (r.status !== 200) throw new Error(`login ${email}: ${r.status}`); return p; };
const results = [];
const ok = (name, cond, detail = '') => { results.push(cond); console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail ? `  (${detail})` : ''}`); };
const count = (sql) => { const d = new DatabaseSync(dbFile); const r = d.prepare(sql).get().n; d.close(); return r; };

try {
  const t = new Date(Date.now() - 86_400_000).toISOString();
  const raw = new DatabaseSync(dbFile);
  raw.prepare(`INSERT INTO jobs (source, external_id, url, url_key, title, company, location, work_mode, category, tags, summary, published_at, first_seen_at, last_seen_at) VALUES ('arbeitnow', 'p19-1', 'https://www.arbeitnow.com/jobs/p19-1', 'arbeitnow.com/jobs/p19-1', 'P19 Remote Engineer', 'Example GmbH', 'Berlin', 'remote', 'it-software', '[]', 's', ?, ?, ?)`).run(t, t, t);
  raw.close();
  const before = { users: count('SELECT COUNT(*) AS n FROM users'), memberships: count('SELECT COUNT(*) AS n FROM memberships'), posts: count('SELECT COUNT(*) AS n FROM posts'), jobs: count('SELECT COUNT(*) AS n FROM jobs'), prefs: count('SELECT COUNT(*) AS n FROM user_preferences') };

  await start();
  const alex = await login('alex.morgan@example.com');
  const sara = await login('sara.kim@example.com');

  ok('a member without saved preferences gets the defaults', (await alex.get('/api/preferences')).body.preferences.persisted === false);
  ok('signing in created no preference row', count('SELECT COUNT(*) AS n FROM user_preferences') === 0);
  ok('saving preferences works over HTTP', (await alex.put('/api/preferences', { theme: 'dark', newsDefaultTab: 'for-you', jobCategory: 'it-software', jobWorkMode: 'remote', homeSections: { registrations: false } })).status === 200);
  ok('invalid and unknown values are refused with the usual error shape', (await alex.put('/api/preferences', { theme: 'neon' })).body.error?.code === 'validation_error' && (await alex.put('/api/preferences', { isAdmin: true })).status === 400);
  ok('another member is not affected', (await sara.get('/api/preferences')).body.preferences.theme === 'light');

  const home = (await alex.get('/api/home')).body;
  ok('GET /api/home keeps its earlier fields and adds `personal`', Array.isArray(home.trending) && Array.isArray(home.courses) && Array.isArray(home.popularCommunities) && !!home.personal);
  ok('Jobs for You follows the saved preferences', home.personal.jobsForYou.items.some((j) => j.title === 'P19 Remote Engineer') && home.personal.jobsForYou.items.every((j) => j.category.key === 'it-software' && j.workMode === 'remote'));
  ok('the hidden Home section is saved as hidden', (await alex.get('/api/preferences')).body.preferences.homeSections.registrations === false);

  await stop();
  await start();
  const alex2 = await login('alex.morgan@example.com');
  const stored = (await alex2.get('/api/preferences')).body.preferences;
  ok('after a server restart the preferences are still there', stored.persisted === true && stored.theme === 'dark' && stored.newsDefaultTab === 'for-you' && stored.jobCategory === 'it-software' && stored.jobWorkMode === 'remote' && stored.homeSections.registrations === false);

  const out = await alex2.post('/api/auth/logout');
  ok('logout answers 200', out.status === 200);
  ok('after logout the session is gone', (await alex2.get('/api/preferences')).status === 401 && (await alex2.get('/api/home')).status === 401 && (await alex2.get('/api/auth/me')).body.user === null);
  ok('a visitor cannot read or save preferences', (await person().get('/api/preferences')).status === 401 && (await person().put('/api/preferences', { theme: 'dark' })).status === 401);
  ok('signing in again restores the same preferences', (await (await login('alex.morgan@example.com')).get('/api/preferences')).body.preferences.theme === 'dark');

  const after = { users: count('SELECT COUNT(*) AS n FROM users'), memberships: count('SELECT COUNT(*) AS n FROM memberships'), posts: count('SELECT COUNT(*) AS n FROM posts'), jobs: count('SELECT COUNT(*) AS n FROM jobs'), prefs: count('SELECT COUNT(*) AS n FROM user_preferences') };
  ok('no user, membership, post or job was created or removed', after.users === before.users && after.memberships === before.memberships && after.posts === before.posts && after.jobs === before.jobs);
  ok('exactly one preference row exists (Alex), never more than one per member', after.prefs === 1, `rows: ${after.prefs}`);
} catch (err) {
  console.error('FAIL  unexpected error:', err);
  results.push(false);
} finally {
  await stop();
  fs.rmSync(tmp, { recursive: true, force: true });
}
const passed = results.filter(Boolean).length;
console.log(`\n${passed}/${results.length} checks passed`);
process.exit(passed === results.length ? 0 : 1);
