// Makes a verified copy of the whole data folder (database + uploads) BEFORE you upgrade or run anything that opens your database.
// Usage:  npm run backup            (copies server/data to server/data-backups/data-<UTC time>/)
//         node scripts/backup-data.mjs <data folder> [backup root]
// Stop the server first so the database file is not being written while it is copied.
// Every copied file is compared with the original by size and SHA-256; the script exits with an error if anything differs.
// It never deletes or changes the original, and it never overwrites an earlier backup.
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const source = path.resolve(process.argv[2] || path.join(here, '..', 'data'));
const root = path.resolve(process.argv[3] || path.join(here, '..', 'data-backups'));

if (!fs.existsSync(source)) {
  console.log(`Nothing to back up: ${source} does not exist yet (no database has been created here).`);
  process.exit(0);
}
if (root === source || root.startsWith(source + path.sep)) { console.error('The backup folder must be outside the data folder.'); process.exit(1); }

const files = (dir) => fs.readdirSync(dir, { withFileTypes: true }).flatMap((e) => (e.isDirectory() ? files(path.join(dir, e.name)) : e.isFile() ? [path.join(dir, e.name)] : []));
const sha = (file) => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');

const stamp = new Date().toISOString().replace(/[:.]/g, '-');
const target = path.join(root, `data-${stamp}`);
if (fs.existsSync(target)) { console.error(`${target} already exists; not overwriting it.`); process.exit(1); }
const wal = files(source).filter((f) => /-wal$|-shm$/.test(f));
if (wal.length) console.warn('Warning: SQLite -wal/-shm files exist. Is the server still running? Stop it and run this again for a consistent copy.');

fs.mkdirSync(root, { recursive: true });
fs.cpSync(source, target, { recursive: true, errorOnExist: true, force: false });

let bad = 0;
const list = files(source);
for (const file of list) {
  const copy = path.join(target, path.relative(source, file));
  const same = fs.existsSync(copy) && fs.statSync(copy).size === fs.statSync(file).size && sha(copy) === sha(file);
  if (!same) { bad += 1; console.error(`MISMATCH  ${path.relative(source, file)}`); }
}
const copied = files(target).length;
if (bad || copied !== list.length) { console.error(`Backup NOT verified: ${bad} mismatch(es), ${copied} of ${list.length} files present.`); process.exit(1); }
console.log(`Backup verified: ${list.length} file(s), sizes and SHA-256 match.\n  from ${source}\n  to   ${target}`);
