// Part 18 end-to-end run against a real server process and a throw-away database file: Saved Jobs and My Applications over HTTP,
// including a server restart. Listings are inserted straight into the throw-away database (no job source is contacted).
// Usage: npm run e2e:part18   (does not touch your own data folder)
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'proconnect-e2e18-'));
const PORT = String(4800 + Math.floor(Math.random() * 400));
const dbFile = path.join(tmp, 'e2e.db');
const env = { ...process.env, JOBS_SYNC: 'off', NEWS_SYNC: 'off', PORT, PROCONNECT_DB: dbFile, PROCONNECT_UPLOADS: path.join(tmp, 'uploads') };
const base = `http://127.0.0.1:${PORT}`;
const PASSWORD = 'ProConnect123!';

const seed = spawnSync(process.execPath, ['--disable-warning=ExperimentalWarning', 'src/db/seed.js', '--reset'], { cwd: ROOT, env });
if (seed.status !== 0) { console.error(seed.stderr.toString()); process.exit(1); }

let server;
const start = async () => {
  server = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', 'src/index.js'], { cwd: ROOT, env, stdio: 'ignore' });
  for (let i = 0; i < 80; i++) { try { if ((await fetch(`${base}/api/health`)).ok) return; } catch { /* not up yet */ } await new Promise((r) => setTimeout(r, 100)); }
  throw new Error('The server did not start');
};
const stop = async () => { server.kill(); await new Promise((r) => setTimeout(r, 400)); };

const person = () => {
  let cookie = '';
  const call = async (method, route, body) => {
    const headers = cookie ? { Cookie: cookie } : {};
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    const res = await fetch(base + route, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined });
    const set = res.headers.getSetCookie().map((c) => c.split(';')[0]).find((c) => c.startsWith('pc_token='));
    if (set) cookie = set === 'pc_token=' ? '' : set;
    return { status: res.status, body: await res.json() };
  };
  return { get: (r) => call('GET', r), post: (r, b) => call('POST', r, b ?? {}), put: (r, b) => call('PUT', r, b), del: (r) => call('DELETE', r) };
};
const login = async (email) => { const p = person(); const r = await p.post('/api/auth/login', { email, password: PASSWORD }); if (r.status !== 200) throw new Error(`login ${email}: ${r.status}`); return p; };
const results = [];
const ok = (name, cond, detail = '') => { results.push(cond); console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail ? `  (${detail})` : ''}`); };
const today = new Date().toISOString().slice(0, 10);

try {
  // listings: inserted into the throw-away file before the server starts
  const raw = new DatabaseSync(dbFile);
  const t = new Date(Date.now() - 86_400_000).toISOString();
  const add = raw.prepare(`INSERT INTO jobs (source, external_id, url, url_key, title, company, location, category, tags, summary, published_at, first_seen_at, last_seen_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, '[]', ?, ?, ?, ?)`);
  add.run('arbeitnow', 'e2e-1', 'https://www.arbeitnow.com/jobs/e2e-1', 'arbeitnow.com/jobs/e2e-1', 'E2E Backend Engineer', 'Example GmbH', 'Berlin', 'it-software', 'Backend work', t, t, t);
  add.run('muse', '9001', 'https://www.themuse.com/jobs/example/e2e-2', 'themuse.com/jobs/example/e2e-2', 'E2E Nurse', 'CareCo', 'Austin, TX', 'healthcare', 'Care work', t, t, t);
  raw.close();
  const usersBefore = (() => { const d = new DatabaseSync(dbFile); const r = d.prepare('SELECT COUNT(*) AS n FROM users').get().n; d.close(); return r; })();

  await start();
  const alex = await login('alex.morgan@example.com');
  const sara = await login('sara.kim@example.com');
  const jobs = (await alex.get('/api/jobs?pageSize=24')).body.jobs;
  const backend = jobs.find((j) => j.title === 'E2E Backend Engineer');
  const nurse = jobs.find((j) => j.title === 'E2E Nurse');
  console.log('\nSaved Jobs');
  ok('a visitor cannot use saved jobs or applications (401)', (await Promise.all(['/api/saved-jobs', '/api/job-applications'].map((r) => person().get(r)))).every((r) => r.status === 401));
  const s1 = await alex.post('/api/saved-jobs', { jobId: backend.id });
  ok('a member saves a job (201)', s1.status === 201 && s1.body.savedJob.availability === 'available');
  ok('saving it again is refused as a duplicate (409 already_saved)', (await alex.post('/api/saved-jobs', { jobId: backend.id })).body.error?.code === 'already_saved');
  ok('the job list marks it as saved for this member only', (await alex.get('/api/jobs?pageSize=24')).body.jobs.find((j) => j.id === backend.id).savedId === s1.body.savedJob.id && (await sara.get('/api/jobs?pageSize=24')).body.jobs.find((j) => j.id === backend.id).savedId === null);
  ok("another member sees none of it and cannot remove it (404)", (await sara.get('/api/saved-jobs')).body.total === 0 && (await sara.del(`/api/saved-jobs/${s1.body.savedJob.id}`)).status === 404);
  await alex.post('/api/saved-jobs', { jobId: nurse.id });
  ok('logout, then login: the saved jobs are still there', (await alex.post('/api/auth/logout')).status === 200 && (await alex.get('/api/saved-jobs')).status === 401);
  const alex2 = await login('alex.morgan@example.com');
  ok('after login both saved jobs are listed, newest first', (await alex2.get('/api/saved-jobs')).body.savedJobs.map((s) => s.job.title).join('|') === 'E2E Nurse|E2E Backend Engineer');

  console.log('\nThe listing disappears');
  const d = new DatabaseSync(dbFile);
  d.prepare("DELETE FROM jobs WHERE external_id = '9001'").run();
  d.close();
  const afterGone = (await alex2.get('/api/saved-jobs')).body;
  const goneItem = afterGone.savedJobs.find((s) => s.job.title === 'E2E Nurse');
  ok('the saved job is kept, marked unavailable, with its snapshot and no apply link', goneItem.availability === 'unavailable' && goneItem.job.company === 'CareCo' && goneItem.job.applyUrl === null && afterGone.total === 2);
  ok('saving a listing that no longer exists answers job_not_found (404)', (await alex2.post('/api/saved-jobs', { jobId: nurse.id })).body.error?.code === 'job_not_found');

  console.log('\nMy Applications');
  const manual = await alex2.post('/api/job-applications', { title: 'Data Analyst', company: 'Globex', url: 'https://careers.globex.example/42', appliedOn: today, status: 'applied', notes: 'Applied on the website' });
  ok('a member adds an external application by hand (201)', manual.status === 201 && manual.body.application.tracking.submittedViaProConnect === false && manual.body.application.job === null);
  const linked = await alex2.post('/api/job-applications', { jobId: backend.id, appliedOn: today, status: 'reviewing' });
  ok('and one linked to a stored listing, which supplies its title and link', linked.status === 201 && linked.body.application.title === 'E2E Backend Engineer' && linked.body.application.url === 'https://www.arbeitnow.com/jobs/e2e-1');
  ok('a duplicate is refused (409), another position at the same company is accepted', (await alex2.post('/api/job-applications', { title: 'Some other title', company: 'Other name', url: 'https://careers.globex.example/42/', appliedOn: today, status: 'applied' })).status === 409 && (await alex2.post('/api/job-applications', { title: 'Data Engineer', company: 'Globex', url: 'https://careers.globex.example/43', appliedOn: today, status: 'applied' })).status === 201);
  ok('invalid input is rejected with field errors (400)', (await alex2.post('/api/job-applications', { title: '', company: '', appliedOn: 'x', status: 'nope', url: 'javascript:1' })).body.error.fields.url !== undefined);
  const upd = await alex2.put(`/api/job-applications/${manual.body.application.id}`, { status: 'interview', notes: 'Call on Tuesday' });
  ok('status and notes can be updated', upd.status === 200 && upd.body.application.status === 'interview' && upd.body.application.notes === 'Call on Tuesday');
  ok('another member cannot read, edit or delete it (404 each)', [(await sara.get(`/api/job-applications/${manual.body.application.id}`)).status, (await sara.put(`/api/job-applications/${manual.body.application.id}`, { status: 'rejected' })).status, (await sara.del(`/api/job-applications/${manual.body.application.id}`)).status].every((s) => s === 404));
  ok('the counts match the records', JSON.stringify((await alex2.get('/api/job-applications')).body.summary) === JSON.stringify({ total: 3, applied: 1, reviewing: 1, interview: 1, rejected: 0, accepted: 0, withdrawn: 0 }));

  console.log('\nRestart');
  await stop();
  await start();
  const alex3 = await login('alex.morgan@example.com');
  ok('after a server restart saved jobs and applications are unchanged', (await alex3.get('/api/saved-jobs')).body.total === 2 && (await alex3.get('/api/job-applications')).body.summary.total === 3);
  const del = await alex3.del(`/api/job-applications/${manual.body.application.id}`);
  ok('a member deletes their own application; the counts follow', del.status === 200 && del.body.summary.total === 2 && del.body.summary.interview === 0);
  const raw2 = new DatabaseSync(dbFile);
  ok('no user was created or removed by any of this', raw2.prepare('SELECT COUNT(*) AS n FROM users').get().n === usersBefore);
  raw2.close();
} catch (err) {
  console.error('E2E run aborted:', err);
  results.push(false);
} finally {
  if (server) await stop();
  fs.rmSync(tmp, { recursive: true, force: true });
}
const passed = results.filter(Boolean).length;
console.log(`\n${passed}/${results.length} checks passed`);
process.exit(passed === results.length ? 0 : 1);
