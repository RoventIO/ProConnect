import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

process.env.PROCONNECT_DB = ':memory:';
process.env.PROCONNECT_UPLOADS = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-uploads-'));

import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';

const { createApp } = await import('../src/app.js');
const { seedDatabase, DEMO_PASSWORD } = await import('../src/db/seed.js');
const { getDb } = await import('../src/db/index.js');

let server;
let base;

before(async () => {
  seedDatabase();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server.close());

/** A tiny browser: keeps the session cookie between requests. */
function browser() {
  let cookie = '';
  return {
    cookie: () => cookie,
    async request(method, path, body) {
      const res = await fetch(base + path, {
        method,
        headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) },
        body: body ? JSON.stringify(body) : undefined,
      });
      const set = res.headers.getSetCookie().map((c) => c.split(';')[0]).find((c) => c.startsWith('pc_token='));
      if (set) cookie = set === 'pc_token=' ? '' : set;
      return { status: res.status, body: await res.json(), setCookie: res.headers.getSetCookie().join('; ') };
    },
  };
}
const as = (b) => ({ get: (p) => b.request('GET', p), post: (p, d) => b.request('POST', p, d), put: (p, d) => b.request('PUT', p, d), request: (m, p, d) => b.request(m, p, d), cookie: () => b.cookie() });

const newBrowser = () => as(browser());
async function signedInAsAlex() {
  const b = newBrowser();
  const r = await b.post('/api/auth/login', { email: 'alex.morgan@example.com', password: DEMO_PASSWORD });
  assert.equal(r.status, 200);
  return b;
}

test('health reports a connected database', async () => {
  const { status, body } = await newBrowser().get('/api/health');
  assert.equal(status, 200);
  assert.equal(body.database, 'connected');
});

test('visitors get 401 on internal content', async () => {
  const v = newBrowser();
  for (const p of ['/api/communities', '/api/communities/1', '/api/courses']) {
    const r = await v.get(p);
    assert.equal(r.status, 401, p);
    assert.equal(r.body.error.code, 'unauthenticated');
  }
});

test('/auth/me returns null user for visitors', async () => {
  const r = await newBrowser().get('/api/auth/me');
  assert.equal(r.status, 200);
  assert.equal(r.body.user, null);
});

test('registration validates fields and rejects duplicate emails', async () => {
  const b = newBrowser();
  const bad = await b.post('/api/auth/register', { name: 'A', email: 'nope', password: 'short' });
  assert.equal(bad.status, 400);
  assert.deepEqual(Object.keys(bad.body.error.fields).sort(), ['email', 'name', 'password']);

  const dup = await b.post('/api/auth/register', { name: 'Someone Else', email: 'ALEX.MORGAN@example.com', password: 'longenough1' });
  assert.equal(dup.status, 409);
  assert.equal(dup.body.error.code, 'email_taken');
});

test('full journey: register, onboarding gate, profile, access, logout', async () => {
  const b = newBrowser();
  const reg = await b.post('/api/auth/register', { name: 'Nina Park', email: 'nina@example.com', password: 'correct-horse-9' });
  assert.equal(reg.status, 201);
  assert.equal(reg.body.user.profileCompleted, false);
  assert.ok(!('password_hash' in reg.body.user) && !('passwordHash' in reg.body.user));
  assert.match(reg.setCookie, /HttpOnly/i);

  // Password is stored hashed, never in plain text.
  const stored = getDb().prepare("SELECT password_hash FROM users WHERE email = 'nina@example.com'").get();
  assert.notEqual(stored.password_hash, 'correct-horse-9');
  assert.match(stored.password_hash, /^\$2[aby]\$/);

  // Signed in but without a profile: content is still locked.
  const locked = await b.get('/api/communities');
  assert.equal(locked.status, 403);
  assert.equal(locked.body.error.code, 'profile_incomplete');

  // Incomplete profile is rejected with field messages.
  const incomplete = await b.put('/api/profile', { profession: 'Nurse', bio: 'short', skills: '' });
  assert.equal(incomplete.status, 400);
  assert.deepEqual(Object.keys(incomplete.body.error.fields).sort(), ['bio', 'skills']);

  const ok = await b.put('/api/profile', {
    profession: 'Nurse',
    bio: 'Emergency nurse interested in clinical informatics.',
    skills: 'Triage, Patient care, triage',
    yearsExperience: '5',
  });
  assert.equal(ok.status, 200);
  assert.equal(ok.body.user.profileCompleted, true);
  assert.deepEqual(ok.body.user.skills, ['Triage', 'Patient care']);

  const open = await b.get('/api/communities');
  assert.equal(open.status, 200);

  const out = await b.post('/api/auth/logout');
  assert.equal(out.status, 200);
  assert.equal((await b.get('/api/communities')).status, 401);
});

test('login fails with a generic message for wrong password and unknown email', async () => {
  const b = newBrowser();
  const wrong = await b.post('/api/auth/login', { email: 'alex.morgan@example.com', password: 'wrong-password' });
  const unknown = await b.post('/api/auth/login', { email: 'ghost@example.com', password: 'whatever123' });
  assert.equal(wrong.status, 401);
  assert.equal(unknown.status, 401);
  assert.equal(wrong.body.error.message, unknown.body.error.message);
});

test('a tampered session cookie is treated as signed out', async () => {
  const res = await fetch(base + '/api/auth/me', { headers: { Cookie: 'pc_token=not.a.real.token' } });
  assert.equal((await res.json()).user, null);
});

test('communities list contains top-level communities with subcommunities', async () => {
  const b = await signedInAsAlex();
  const { body } = await b.get('/api/communities');
  assert.equal(body.communities.length, 6);
  const sd = body.communities.find((c) => c.name === 'Software Development');
  assert.deepEqual(sd.subcommunities.map((s) => s.name), ['Backend', 'DevOps', 'Frontend']);
});

test('community detail, filters and errors', async () => {
  const b = await signedInAsAlex();
  const design = (await b.get('/api/communities?category=Design')).body.communities;
  assert.deepEqual(design.map((c) => c.name), ['Design & UX']);
  const sd = (await b.get('/api/communities')).body.communities.find((c) => c.name === 'Software Development');
  const detail = await b.get(`/api/communities/${sd.id}`);
  assert.ok(detail.body.recentPosts.some((p) => p.title.startsWith('How do you structure code reviews')));
  assert.equal((await b.get('/api/communities/9999')).status, 404);
  assert.equal((await b.get('/api/communities/abc')).body.error.code, 'invalid_id');
});

test('courses expose free/paid labels and filters', async () => {
  const b = await signedInAsAlex();
  const all = (await b.get('/api/courses')).body.courses;
  assert.equal(all.length, 6);
  assert.ok(all.every((c) => c.priceLabel === 'Free' || c.priceLabel === 'Paid'));
  assert.equal((await b.get('/api/courses?price=free&type=webinar')).body.courses.length, 3);
  assert.equal((await b.get('/api/courses?type=bogus')).status, 400);
});

test('unknown routes return JSON 404', async () => {
  const r = await newBrowser().get('/api/nope');
  assert.equal(r.status, 404);
  assert.equal(r.body.error.code, 'not_found');
});

test('schema rejects orphan posts', () => {
  assert.throws(() => getDb().prepare("INSERT INTO posts (author_id, community_id, title, content) VALUES (9999, 9999, 't', 'c')").run());
});

test('public stats expose aggregate numbers only', async () => {
  const r = await newBrowser().get('/api/stats');
  assert.equal(r.status, 200);
  assert.equal(r.body.totals.communities, 6);
  assert.equal(r.body.totals.professionals, 7); // 6 seeded accounts (incl. admin) + Nina from the earlier journey test
  assert.equal(r.body.week.discussions.points.length, 7);
  assert.ok(!JSON.stringify(r.body).includes('@'));
});

test('home data is for members only and contains real content', async () => {
  assert.equal((await newBrowser().get('/api/home')).status, 401);
  const b = await signedInAsAlex();
  const { body } = await b.get('/api/home');
  assert.equal(body.trending.length, 4);
  assert.equal(body.trending[0].replyCount, 2);
  assert.ok(body.courses.length > 0 && body.courses.every((c) => c.isSample));
  assert.equal(body.popularCommunities.length, 3);
});

test('my profile returns details, communities, posts and stats', async () => {
  const b = await signedInAsAlex();
  const { status, body } = await b.get('/api/profile');
  assert.equal(status, 200);
  assert.equal(body.user.email, 'alex.morgan@example.com');
  assert.equal(body.items.experience.length, 2);
  assert.equal(body.items.education.length, 2);
  assert.equal(body.items.projects.length, 2);
  assert.equal(body.stats.communities, 3);
  assert.ok(body.stats.discussions >= 2);
  assert.ok(body.recentPosts.length >= 2);
});

test('other members see permitted information only', async () => {
  const b = await signedInAsAlex();
  const sara = getDb().prepare("SELECT id FROM users WHERE email = 'sara.kim@example.com'").get();
  const { status, body } = await b.get(`/api/users/${sara.id}`);
  assert.equal(status, 200);
  assert.equal(body.user.name, 'Sara Kim');
  assert.ok(!('email' in body.user) && !('role' in body.user));
  assert.equal((await b.get('/api/users/9999')).status, 404);
  assert.equal((await newBrowser().get(`/api/users/${sara.id}`)).status, 401);
});

test('profile items: add, edit, delete, validation and ownership', async () => {
  const alex = await signedInAsAlex();
  const bad = await alex.post('/api/profile/items', { kind: 'project', title: '', url: 'javascript:alert(1)' });
  assert.equal(bad.status, 400);
  assert.deepEqual(Object.keys(bad.body.error.fields).sort(), ['title', 'url']);
  assert.equal((await alex.post('/api/profile/items', { kind: 'nonsense', title: 'x' })).status, 400);

  const created = await alex.post('/api/profile/items', { kind: 'project', title: 'Open source icons', subtitle: 'GitHub', url: 'https://github.com/example/icons' });
  assert.equal(created.status, 201);
  const id = created.body.item.id;

  const edited = await alex.put(`/api/profile/items/${id}`, { title: 'Open source icon set', url: 'https://github.com/example/icons' });
  assert.equal(edited.body.item.title, 'Open source icon set');
  assert.equal(edited.body.item.kind, 'project'); // kind cannot be changed

  // Another member cannot edit or delete Alex's entry.
  const other = newBrowser();
  await other.post('/api/auth/login', { email: 'sara.kim@example.com', password: DEMO_PASSWORD });
  assert.equal((await other.put(`/api/profile/items/${id}`, { title: 'Hijacked' })).status, 404);
  assert.equal((await other.request('DELETE', `/api/profile/items/${id}`)).status, 404);

  assert.equal((await alex.request('DELETE', `/api/profile/items/${id}`)).status, 200);
  assert.equal((await alex.request('DELETE', `/api/profile/items/${id}`)).status, 404);
});

test('editing basic profile fields persists and keeps validation', async () => {
  const b = await signedInAsAlex();
  const bad = await b.put('/api/profile', { profession: 'Designer', bio: 'too short', skills: 'A', yearsExperience: '-3' });
  assert.deepEqual(Object.keys(bad.body.error.fields).sort(), ['bio', 'yearsExperience']);
  const ok = await b.put('/api/profile', { profession: 'Product Designer', headline: 'Lead Designer', bio: 'Designer who mentors early-career colleagues.', skills: ['Design Systems', 'Mentoring'], yearsExperience: 10, location: 'London' });
  assert.equal(ok.body.user.headline, 'Lead Designer');
  assert.equal((await b.get('/api/profile')).body.user.yearsExperience, 10);
});

// ---- Image uploads ----
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');
const upload = (b, bytes, name = 'photo.png', type = 'image/png') => {
  const fd = new FormData();
  fd.append('avatar', new Blob([bytes], { type }), name);
  return fetch(base + '/api/profile/avatar', { method: 'POST', headers: { Cookie: b.cookie() }, body: fd });
};

test('profile photo: upload, serve to members only, replace and remove', async () => {
  const alex = await signedInAsAlex();
  const res = await upload(alex, PNG);
  assert.equal(res.status, 200);
  const { user } = await res.json();
  assert.match(user.avatarUrl, /^\/api\/uploads\/[a-f0-9]{32}\.png$/);

  const img = await fetch(base + user.avatarUrl, { headers: { Cookie: alex.cookie() } });
  assert.equal(img.status, 200);
  assert.equal(img.headers.get('content-type'), 'image/png');
  assert.equal(img.headers.get('x-content-type-options'), 'nosniff');
  assert.equal((await fetch(base + user.avatarUrl)).status, 401); // visitors cannot fetch it

  // Other members see the photo on Alex's profile.
  const sara = newBrowser();
  await sara.post('/api/auth/login', { email: 'sara.kim@example.com', password: DEMO_PASSWORD });
  const alexRow = getDb().prepare("SELECT id FROM users WHERE email = 'alex.morgan@example.com'").get();
  assert.equal((await sara.get(`/api/users/${alexRow.id}`)).body.user.avatarUrl, user.avatarUrl);

  // Replacing deletes the old file from disk.
  const oldFile = user.avatarUrl.split('/').pop();
  const second = await (await upload(alex, PNG)).json();
  assert.notEqual(second.user.avatarUrl, user.avatarUrl);
  assert.equal(fs.existsSync(path.join(process.env.PROCONNECT_UPLOADS, oldFile)), false);

  const removed = await alex.request('DELETE', '/api/profile/avatar');
  assert.equal(removed.body.user.avatarUrl, null);
  assert.equal(fs.readdirSync(process.env.PROCONNECT_UPLOADS).length, 0);
});

test('profile photo: rejects fake images, oversized files and unsafe file names', async () => {
  const alex = await signedInAsAlex();
  const fake = await upload(alex, Buffer.from('<script>alert(1)</script> not an image at all'), 'evil.png', 'image/png');
  assert.equal(fake.status, 400);
  assert.equal((await fake.json()).error.code, 'unsupported_type');

  const svg = await upload(alex, Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"></svg>'), 'x.svg', 'image/svg+xml');
  assert.equal(svg.status, 400);

  const big = Buffer.concat([PNG, Buffer.alloc(2 * 1024 * 1024 + 10)]);
  const tooBig = await upload(alex, big);
  assert.equal(tooBig.status, 413);
  assert.equal((await tooBig.json()).error.code, 'file_too_large');

  assert.equal((await fetch(base + '/api/uploads/..%2F..%2Fetc%2Fpasswd', { headers: { Cookie: alex.cookie() } })).status, 404);
  assert.equal((await fetch(base + '/api/uploads/notours.png', { headers: { Cookie: alex.cookie() } })).status, 404);
  assert.equal((await fetch(base + '/api/profile/avatar', { method: 'POST', headers: { Cookie: alex.cookie() } })).status, 400);
});

// ---- Communities: joining and administration ----
const { setAdmin } = await import('../src/db/makeAdmin.js');
const loginAs = async (email) => {
  const b = newBrowser();
  const r = await b.post('/api/auth/login', { email, password: DEMO_PASSWORD });
  assert.equal(r.status, 200);
  return b;
};
const communityByName = async (b, name) => (await b.get('/api/communities')).body.communities.find((c) => c.name === name);

test('members can join and leave main communities; joining is idempotent', async () => {
  const thomas = await loginAs('thomas.nguyen@example.com');
  const fin = await communityByName(thomas, 'Finance & Accounting');
  assert.equal(fin.isMember, false);
  assert.equal(fin.memberCount, 0);

  const joined = await thomas.post(`/api/communities/${fin.id}/join`);
  assert.equal(joined.body.community.isMember, true);
  assert.equal(joined.body.community.memberCount, 1);
  const again = await thomas.post(`/api/communities/${fin.id}/join`);
  assert.equal(again.body.community.memberCount, 1); // no duplicate membership

  assert.equal((await communityByName(thomas, 'Finance & Accounting')).isMember, true);
  assert.equal((await thomas.get(`/api/communities/${fin.id}`)).body.community.isMember, true);
  assert.ok((await thomas.get('/api/profile')).body.communities.some((c) => c.name === 'Finance & Accounting'));

  const left = await thomas.request('DELETE', `/api/communities/${fin.id}/join`);
  assert.equal(left.body.community.isMember, false);
  assert.equal(left.body.community.memberCount, 0);
  assert.equal((await thomas.request('DELETE', `/api/communities/${fin.id}/join`)).status, 200); // leaving twice is harmless
});

test('subcommunities cannot be joined directly but follow their parent', async () => {
  const alex = await signedInAsAlex();
  const sd = await communityByName(alex, 'Software Development');
  const backend = sd.subcommunities.find((s) => s.name === 'Backend');
  const r = await alex.post(`/api/communities/${backend.id}/join`);
  assert.equal(r.status, 400);
  assert.equal(r.body.error.code, 'not_joinable');
  const detail = (await alex.get(`/api/communities/${backend.id}`)).body.community;
  assert.equal(detail.canJoin, false);
  assert.equal(detail.isMember, true); // Alex joined Software Development
  assert.equal(detail.parent.name, 'Software Development');
});

test('visitors cannot join and unknown communities return 404', async () => {
  assert.equal((await newBrowser().post('/api/communities/1/join')).status, 401);
  const alex = await signedInAsAlex();
  assert.equal((await alex.post('/api/communities/9999/join')).status, 404);
});

test('only administrators can create or delete communities', async () => {
  const alex = await signedInAsAlex();
  const body = { name: 'Legal Professionals', category: 'Legal', description: 'Contracts, compliance and courtroom practice.' };
  assert.equal((await alex.post('/api/communities', body)).status, 403);
  assert.equal((await alex.request('DELETE', '/api/communities/1')).status, 403);
  assert.equal((await newBrowser().post('/api/communities', body)).status, 401);
});

test('the seeded admin can create, validate, nest and delete communities', async () => {
  const admin = await loginAs('admin@proconnect.example');
  assert.equal((await admin.get('/api/auth/me')).body.user.isAdmin, true);

  const bad = await admin.post('/api/communities', { name: 'X', description: 'short', category: '' });
  assert.deepEqual(Object.keys(bad.body.error.fields).sort(), ['category', 'description', 'name']);

  const created = await admin.post('/api/communities', { name: 'Legal Professionals', category: 'Legal', description: 'Contracts, compliance and courtroom practice.' });
  assert.equal(created.status, 201);
  assert.equal(created.body.community.slug, 'legal-professionals');
  const legalId = created.body.community.id;

  const dup = await admin.post('/api/communities', { name: 'legal professionals', category: 'Legal', description: 'Duplicate name in a different case.' });
  assert.equal(dup.status, 409);

  assert.equal((await admin.post('/api/communities', { name: 'Sub', description: 'Parent that does not exist.', parentId: 9999 })).status, 400);
  const sub = await admin.post('/api/communities', { name: 'Contract Law', category: 'ignored', description: 'Drafting and negotiating contracts.', parentId: legalId });
  assert.equal(sub.status, 201);
  assert.equal(sub.body.community.category, 'Legal'); // inherited from the parent
  assert.equal(sub.body.community.parentId, legalId);

  const list = (await admin.get('/api/communities')).body;
  assert.ok(list.categories.includes('Legal'));
  assert.deepEqual(list.communities.find((c) => c.id === legalId).subcommunities.map((s) => s.name), ['Contract Law']);

  // Deleting a main community that still has subcommunities needs an explicit confirmation, then removes them too.
  const refused = await admin.request('DELETE', `/api/communities/${legalId}`);
  assert.equal(refused.status, 409);
  assert.deepEqual([refused.body.error.code, refused.body.error.details.impact.subcommunities], ['needs_confirmation', 1]);
  assert.equal((await admin.get(`/api/communities/${legalId}`)).status, 200); // still there
  assert.equal((await admin.request('DELETE', `/api/communities/${legalId}?confirm=true`)).status, 200);
  assert.equal((await admin.get(`/api/communities/${sub.body.community.id}`)).status, 404);
  assert.equal((await admin.request('DELETE', `/api/communities/${legalId}`)).status, 404);
});

test('make-admin promotes an existing account and can demote it again', async () => {
  const email = 'thomas.nguyen@example.com';
  assert.ok(setAdmin(email, true));
  const b = await loginAs(email);
  assert.equal((await b.get('/api/auth/me')).body.user.role, 'admin');
  assert.ok(setAdmin(email, false));
  assert.equal((await b.get('/api/auth/me')).body.user.role, 'member');
  assert.equal(setAdmin('nobody@example.com'), null);
});

// ---- Discussions: posts, comments, images, GIFs, voice messages, emoji ----
const GIF = Buffer.concat([Buffer.from('GIF89a'), Buffer.alloc(40)]);
const WEBM = Buffer.concat([Buffer.from([0x1a, 0x45, 0xdf, 0xa3]), Buffer.alloc(200, 7)]);
const uploadsCount = () => fs.readdirSync(process.env.PROCONNECT_UPLOADS).length;

/** Sends multipart form data with the member's session cookie. */
async function form(b, method, route, fields = {}, files = []) {
  const fd = new FormData();
  for (const [k, v] of Object.entries(fields)) fd.append(k, v);
  for (const [name, buf, filename, type] of files) fd.append(name, new Blob([buf], { type }), filename);
  const res = await fetch(base + route, { method, headers: { Cookie: b.cookie() }, body: fd });
  return { status: res.status, body: await res.json() };
}
const communityId = async (b, name) => (await communityByName(b, name)).id;

test('only community members can start discussions', async () => {
  const thomas = await loginAs('thomas.nguyen@example.com'); // member of Product Management only
  const sd = await communityId(thomas, 'Software Development');
  const denied = await thomas.post(`/api/communities/${sd}/posts`, { title: 'Hello world', content: 'Not a member' });
  assert.equal(denied.status, 403);
  assert.equal(denied.body.error.code, 'not_member');
  assert.equal((await newBrowser().post(`/api/communities/${sd}/posts`, { title: 'Hello', content: 'x' })).status, 401);
  assert.equal((await thomas.post('/api/communities/9999/posts', { title: 'Hello', content: 'x' })).status, 404);
});

test('discussion text is validated and emoji are stored intact', async () => {
  const alex = await signedInAsAlex();
  const pm = await communityId(alex, 'Product Management');
  const bad = await alex.post(`/api/communities/${pm}/posts`, { title: 'Hi', content: '' });
  assert.equal(bad.status, 400);
  assert.deepEqual(Object.keys(bad.body.error.fields).sort(), ['content', 'title']);

  const ok = await alex.post(`/api/communities/${pm}/posts`, { title: 'Roadmap tips 🚀', content: 'Great question 👍🎉 — here are my thoughts.' });
  assert.equal(ok.status, 201);
  assert.equal(ok.body.post.title, 'Roadmap tips 🚀');
  const read = await alex.get(`/api/posts/${ok.body.post.id}`);
  assert.equal(read.body.post.content, 'Great question 👍🎉 — here are my thoughts.');
  assert.equal(read.body.post.canEdit, true);
  await alex.request('DELETE', `/api/posts/${ok.body.post.id}`);
});

test('a discussion can carry images, a GIF and a voice message that members can open', async () => {
  const alex = await signedInAsAlex();
  const ux = await communityId(alex, 'Design & UX');
  const before = uploadsCount();
  const res = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Design critique day', content: 'See the attached', voiceDuration: '12' }, [
    ['images', PNG, 'one.png', 'image/png'],
    ['images', GIF, 'move.gif', 'image/gif'],
    ['voice', WEBM, 'voice.webm', 'audio/webm'],
  ]);
  assert.equal(res.status, 201);
  assert.equal(uploadsCount(), before + 3);
  const { attachments } = res.body.post;
  assert.deepEqual(attachments.map((a) => a.kind), ['image', 'image', 'audio']);
  assert.equal(attachments[2].durationSec, 12);

  const gif = await fetch(base + attachments[1].url, { headers: { Cookie: alex.cookie() } });
  assert.equal(gif.headers.get('content-type'), 'image/gif');
  const voice = await fetch(base + attachments[2].url, { headers: { Cookie: alex.cookie(), Range: 'bytes=0-9' } });
  assert.equal(voice.status, 206); // seeking in the voice player works
  assert.equal(voice.headers.get('content-type'), 'audio/webm');
  assert.equal((await fetch(base + attachments[0].url)).status, 401); // visitors cannot open attachments

  // Listing shows a summary.
  const detail = await alex.get(`/api/communities/${ux}`);
  const listed = detail.body.recentPosts.find((p) => p.id === res.body.post.id);
  assert.equal(listed.imageCount, 2);
  assert.equal(listed.hasVoice, true);
  assert.equal(listed.excerpt, 'See the attached');

  await alex.request('DELETE', `/api/posts/${res.body.post.id}`);
  assert.equal(uploadsCount(), before); // files removed with the post
});

test('an image-only discussion is allowed, fake files are rejected without leaving anything behind', async () => {
  const alex = await signedInAsAlex();
  const ux = await communityId(alex, 'Design & UX');
  const before = uploadsCount();
  const postsBefore = getDb().prepare('SELECT COUNT(*) AS n FROM posts').get().n;

  const imageOnly = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Just a picture' }, [['images', PNG, 'a.png', 'image/png']]);
  assert.equal(imageOnly.status, 201);
  await alex.request('DELETE', `/api/posts/${imageOnly.body.post.id}`);

  // The second file is not an image: the whole post must be rejected and the first file removed again.
  const mixed = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Broken upload', content: 'x' }, [
    ['images', PNG, 'ok.png', 'image/png'],
    ['images', Buffer.from('<script>alert(1)</script> definitely not an image'), 'bad.png', 'image/png'],
  ]);
  assert.equal(mixed.status, 400);
  assert.equal(mixed.body.error.code, 'unsupported_type');
  assert.equal(uploadsCount(), before);
  assert.equal(getDb().prepare('SELECT COUNT(*) AS n FROM posts').get().n, postsBefore);

  const badVoice = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Bad voice', content: 'x' }, [['voice', Buffer.from('not audio at all, just text'), 'v.webm', 'audio/webm']]);
  assert.equal(badVoice.status, 400);

  const five = Array.from({ length: 5 }, (_, i) => ['images', PNG, `${i}.png`, 'image/png']);
  const tooMany = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Too many pictures', content: 'x' }, five);
  assert.equal(tooMany.status, 400);
  assert.equal(uploadsCount(), before);
});

test('replies: members only, text, image, GIF or voice, listed in order', async () => {
  const alex = await signedInAsAlex();
  const sd = await communityId(alex, 'Software Development');
  const post = (await alex.post(`/api/communities/${sd}/posts`, { title: 'Reply test thread', content: 'Say something' })).body.post;

  const thomas = await loginAs('thomas.nguyen@example.com'); // not a member of Software Development
  const denied = await thomas.post(`/api/posts/${post.id}/comments`, { content: 'Let me in' });
  assert.equal(denied.status, 403);
  assert.equal((await thomas.get(`/api/posts/${post.id}`)).body.post.canComment, false);

  assert.equal((await alex.post(`/api/posts/${post.id}/comments`, { content: '   ' })).status, 400);
  assert.equal((await alex.post(`/api/posts/${post.id}/comments`, { content: 'First reply 😀' })).status, 201);
  assert.equal((await form(alex, 'POST', `/api/posts/${post.id}/comments`, {}, [['images', GIF, 'party.gif', 'image/gif']])).status, 201);
  assert.equal((await form(alex, 'POST', `/api/posts/${post.id}/comments`, { voiceDuration: '5' }, [['voice', WEBM, 'v.webm', 'audio/webm']])).status, 201);

  const { comments } = (await alex.get(`/api/posts/${post.id}`)).body;
  assert.equal(comments.length, 3);
  assert.equal(comments[0].content, 'First reply 😀');
  assert.equal(comments[1].attachments[0].kind, 'image');
  assert.equal(comments[2].attachments[0].kind, 'audio');
  assert.ok(comments.every((c) => c.canEdit && c.canDelete));
  await alex.request('DELETE', `/api/posts/${post.id}`);
});

test('editing and deleting: authors edit, authors and admins delete, others are refused', async () => {
  const alex = await signedInAsAlex();
  const sara = await loginAs('sara.kim@example.com'); // member of Software Development
  const admin = await loginAs('admin@proconnect.example');
  const sd = await communityId(alex, 'Software Development');
  const before = uploadsCount();

  const post = (await form(sara, 'POST', `/api/communities/${sd}/posts`, { title: 'Original title', content: 'Original text' }, [['images', PNG, 'p.png', 'image/png']])).body.post;
  const reply = await form(sara, 'POST', `/api/posts/${post.id}/comments`, { content: 'My reply' }, [['images', PNG, 'c.png', 'image/png']]);
  assert.equal(reply.status, 201);
  assert.equal(uploadsCount(), before + 2);

  // Alex is a member but not the author.
  assert.equal((await alex.put(`/api/posts/${post.id}`, { title: 'Hijacked', content: 'x' })).status, 403);
  assert.equal((await alex.put(`/api/comments/${reply.body.comment.id}`, { content: 'Hijacked' })).status, 403);
  assert.equal((await alex.request('DELETE', `/api/posts/${post.id}`)).status, 403);
  assert.equal((await alex.request('DELETE', `/api/comments/${reply.body.comment.id}`)).status, 403);

  const edited = await sara.put(`/api/posts/${post.id}`, { title: 'Better title', content: 'Better text 🙂' });
  assert.equal(edited.status, 200);
  assert.equal(edited.body.post.edited, true);
  assert.equal(edited.body.post.attachments.length, 1);
  assert.equal((await sara.put(`/api/posts/${post.id}`, { title: 'x', content: '' })).status, 400);
  assert.equal((await sara.put(`/api/comments/${reply.body.comment.id}`, { content: 'Edited reply' })).status, 200);
  assert.equal((await sara.get(`/api/posts/${post.id}`)).body.comments[0].edited, true);

  // An administrator can moderate: deleting the post removes the reply and every file.
  const adminView = (await admin.get(`/api/posts/${post.id}`)).body;
  assert.equal(adminView.post.canDelete, true);
  assert.equal(adminView.post.canEdit, false);
  assert.equal((await admin.request('DELETE', `/api/posts/${post.id}`)).status, 200);
  assert.equal(uploadsCount(), before);
  assert.equal((await sara.get(`/api/posts/${post.id}`)).status, 404);
});

test('deleting a community removes its discussions and their uploaded files', async () => {
  const admin = await loginAs('admin@proconnect.example');
  const before = uploadsCount();
  const made = await admin.post('/api/communities', { name: 'Temporary Lab', category: 'Testing', description: 'A community created only for a test.' });
  const id = made.body.community.id;
  await admin.post(`/api/communities/${id}/join`);
  const post = (await form(admin, 'POST', `/api/communities/${id}/posts`, { title: 'Lab post', content: 'with a file' }, [['images', PNG, 'l.png', 'image/png']])).body.post;
  await form(admin, 'POST', `/api/posts/${post.id}/comments`, { content: 'and a reply' }, [['voice', WEBM, 'v.webm', 'audio/webm']]);
  assert.equal(uploadsCount(), before + 2);
  assert.equal((await admin.request('DELETE', `/api/communities/${id}`)).status, 409); // has a discussion and a member: needs confirmation
  assert.equal(uploadsCount(), before + 2); // nothing was removed by the refused request
  assert.equal((await admin.request('DELETE', `/api/communities/${id}?confirm=true`)).status, 200);
  assert.equal(uploadsCount(), before);
  assert.equal((await admin.get(`/api/posts/${post.id}`)).status, 404);
});

// ---- Search and filters ----
const searchFor = async (b, params) => (await b.get(`/api/search?${new URLSearchParams(params)}`)).body;

test('courses are ordered upcoming, then undated, then past, and past events are flagged', async () => {
  const alex = await signedInAsAlex();
  const db = getDb();
  const insert = db.prepare("INSERT INTO courses (title, type, is_free, starts_at, approval_status) VALUES (?, 'webinar', 1, ?, 'approved')");
  const day = 86400000;
  const past = insert.run('ZZ past webinar', new Date(Date.now() - 10 * day).toISOString()).lastInsertRowid;
  const upcoming = insert.run('ZZ upcoming webinar', new Date(Date.now() + 10 * day).toISOString()).lastInsertRowid;
  const undated = insert.run('ZZ undated webinar', null).lastInsertRowid;
  try {
    const { courses } = (await alex.get('/api/courses?q=ZZ')).body;
    assert.deepEqual(courses.map((c) => c.title), ['ZZ upcoming webinar', 'ZZ undated webinar', 'ZZ past webinar']);
    assert.deepEqual(courses.map((c) => c.isPast), [false, false, true]);
  } finally {
    for (const id of [past, upcoming, undated]) db.prepare('DELETE FROM courses WHERE id = ?').run(id);
  }
});

test('"My Communities" data is per signed-in user, stored in the database and survives a new sign-in', async () => {
  const joinedNames = async (b) => (await b.get('/api/communities')).body.communities.filter((c) => c.isMember).map((c) => c.name).sort();
  const alex = await signedInAsAlex();
  const sara = await loginAs('sara.kim@example.com');
  assert.deepEqual(await joinedNames(alex), ['Design & UX', 'Product Management', 'Software Development']);
  assert.deepEqual(await joinedNames(sara), ['Software Development']); // a different user sees a different list

  const edu = await communityId(sara, 'Teachers & Educators');
  await sara.post(`/api/communities/${edu}/join`);
  assert.deepEqual(await joinedNames(sara), ['Software Development', 'Teachers & Educators']);
  assert.deepEqual(await joinedNames(alex), ['Design & UX', 'Product Management', 'Software Development']); // Alex unaffected

  // The membership is a database row, so a brand-new session (like a later sign-in) sees it too.
  const saraAgain = await loginAs('sara.kim@example.com');
  assert.deepEqual(await joinedNames(saraAgain), ['Software Development', 'Teachers & Educators']);
  const sarasId = getDb().prepare("SELECT id FROM users WHERE email = 'sara.kim@example.com'").get().id;
  assert.equal(getDb().prepare('SELECT COUNT(*) AS n FROM memberships WHERE user_id = ? AND community_id = ?').get(sarasId, edu).n, 1);

  await saraAgain.request('DELETE', `/api/communities/${edu}/join`);
  assert.deepEqual(await joinedNames(await loginAs('sara.kim@example.com')), ['Software Development']);
});

test('list filters on communities and courses are case-insensitive too', async () => {
  const alex = await signedInAsAlex();
  assert.ok((await alex.get('/api/communities?q=DESIGN')).body.communities.some((c) => c.name === 'Design & UX'));
  assert.ok((await alex.get('/api/courses?q=ACCESSIBLE')).body.courses.some((c) => c.title === 'Designing Accessible Interfaces'));
});

test('upload problems explain the real limit of the place they happened in', async () => {
  const alex = await signedInAsAlex();
  const ux = await communityId(alex, 'Design & UX');
  const before = uploadsCount();

  const five = Array.from({ length: 5 }, (_, i) => ['images', PNG, `${i}.png`, 'image/png']);
  const many = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Too many images', content: 'x' }, five);
  assert.equal(many.status, 400);
  assert.equal(many.body.error.code, 'too_many_files');
  assert.equal(many.body.error.message, 'You can attach up to 4 images.');

  const twoVoices = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Two voices', content: 'x' }, [['voice', WEBM, 'a.webm', 'audio/webm'], ['voice', WEBM, 'b.webm', 'audio/webm']]);
  assert.equal(twoVoices.body.error.message, 'You can attach only one voice message.');

  const sixMb = Buffer.concat([PNG, Buffer.alloc(5 * 1024 * 1024 + 10)]);
  const bigImage = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Huge image', content: 'x' }, [['images', sixMb, 'big.png', 'image/png']]);
  assert.equal(bigImage.status, 413);
  assert.equal(bigImage.body.error.message, 'Each image can be up to 5 MB.'); // the post limit, not the 2 MB profile-photo limit

  const bigVoice = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Huge voice', content: 'x' }, [['voice', Buffer.concat([WEBM, Buffer.alloc(5 * 1024 * 1024 + 10)]), 'big.webm', 'audio/webm']]);
  assert.equal(bigVoice.body.error.message, 'The voice message is too large. The maximum size is 5 MB.');

  const threeMb = Buffer.concat([PNG, Buffer.alloc(3 * 1024 * 1024)]);
  const okPost = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'A 3 MB image is fine in a post', content: 'x' }, [['images', threeMb, 'ok.png', 'image/png']]);
  assert.equal(okPost.status, 201); // 3 MB is allowed for posts
  await alex.request('DELETE', `/api/posts/${okPost.body.post.id}`);
  const avatar = await upload(alex, threeMb); // but not for a profile photo
  assert.equal(avatar.status, 413);
  assert.equal((await avatar.json()).error.message, 'The profile photo can be up to 2 MB.');
  assert.equal(uploadsCount(), before); // nothing was left behind
});

// ---- Part 1: roles and permissions ----
const perms = await import('../src/utils/permissions.js');
const { requireOrganizer } = await import('../src/middleware/auth.js');
const userRow = (email) => getDb().prepare('SELECT * FROM users WHERE email = ?').get(email);

/** Registers and onboards a throwaway member. */
async function newMember(email) {
  const b = newBrowser();
  assert.equal((await b.post('/api/auth/register', { name: 'Test Member', email, password: 'correct-horse-9' })).status, 201);
  assert.equal((await b.put('/api/profile', { profession: 'Tester', bio: 'Checks permissions carefully.', skills: 'Testing' })).status, 200);
  return b;
}

test('Student and Beginner are self-selected; Professional and unknown values are refused', async () => {
  const m = await newMember('status.member@example.com');
  assert.equal((await m.get('/api/auth/me')).body.user.status, 'beginner');
  const s = await m.put('/api/profile/status', { status: 'student' });
  assert.equal(s.status, 200);
  assert.equal(s.body.user.status, 'student');
  assert.equal((await m.put('/api/profile/status', { status: 'Beginner' })).body.user.status, 'beginner');

  const pro = await m.put('/api/profile/status', { status: 'professional' });
  assert.equal(pro.status, 403);
  assert.equal(pro.body.error.code, 'professional_requires_admin');
  for (const bad of ['admin', 'community_leader', 'organizer', '', undefined]) {
    assert.equal((await m.put('/api/profile/status', { status: bad })).status, 400, String(bad));
  }
  assert.equal((await m.get('/api/auth/me')).body.user.status, 'beginner');
  assert.equal((await newBrowser().put('/api/profile/status', { status: 'student' })).status, 401);

  // An approved Professional cannot quietly drop the status through the ordinary route.
  const sara = await loginAs('sara.kim@example.com');
  assert.equal((await sara.put('/api/profile/status', { status: 'student' })).status, 403);
  assert.equal(userRow('sara.kim@example.com').status, 'professional');
});

test('ordinary profile and sign-up requests cannot set role, status or organizer permission', async () => {
  const evil = { role: 'admin', status: 'professional', isOrganizer: true, is_organizer: 1, isAdmin: true, communityLeader: true };
  const b = newBrowser();
  const refused = await b.post('/api/auth/register', { name: 'Sneaky One', email: 'sneaky@example.com', password: 'correct-horse-9', ...evil });
  assert.equal(refused.status, 400); // status 'professional' is not a choice at sign-up
  assert.ok(refused.body.error.fields.status);
  assert.equal(userRow('sneaky@example.com'), undefined);
  const { status: _s, ...evilWithoutStatus } = evil; // eslint-disable-line no-unused-vars
  const reg = await b.post('/api/auth/register', { name: 'Sneaky One', email: 'sneaky@example.com', password: 'correct-horse-9', ...evilWithoutStatus });
  assert.equal(reg.status, 201);
  const upd = await b.put('/api/profile', { profession: 'Tester', bio: 'Tries to promote themselves.', skills: 'Testing', ...evil });
  assert.equal(upd.status, 200);
  const row = userRow('sneaky@example.com');
  assert.equal(row.role, 'member');
  assert.equal(row.status, 'beginner');
  assert.equal(row.is_organizer, 0);
  const me = (await b.get('/api/auth/me')).body.user;
  assert.deepEqual([me.isAdmin, me.isOrganizer, me.status], [false, false, 'beginner']);

  // Profile items and the member view never carry privileged fields.
  const other = (await b.get(`/api/users/${userRow('sara.kim@example.com').id}`)).body.user;
  assert.ok(!('role' in other) && !('isOrganizer' in other) && !('email' in other));
});

test('administrative endpoints reject visitors, members, leaders and organizers', async () => {
  const target = userRow('laura.bennett@example.com').id;
  const community = getDb().prepare("SELECT id FROM communities WHERE name = 'Design & UX'").get().id;
  const calls = [
    ['PUT', `/api/admin/users/${target}/organizer`, { granted: true }],
    ['PUT', `/api/admin/users/${target}/professional`, { granted: true }],
    ['PUT', `/api/admin/communities/${community}/leaders/${target}`],
    ['DELETE', `/api/admin/communities/${community}/leaders/${target}`],
  ];
  for (const [method, path, body] of calls) {
    assert.equal((await newBrowser().request(method, path, body)).status, 401, `visitor ${path}`);
    for (const email of ['laura.bennett@example.com', 'alex.morgan@example.com', 'sara.kim@example.com']) { // member, community leader, organizer
      const r = await (await loginAs(email)).request(method, path, body);
      assert.equal(r.status, 403, `${email} ${method} ${path}`);
      assert.equal(r.body.error.code, 'forbidden');
    }
  }
  const row = userRow('laura.bennett@example.com');
  assert.deepEqual([row.is_organizer, row.status], [0, 'professional']); // nothing changed
});

test('an Admin grants and revokes Authorized Organizer and Professional status', async () => {
  await newMember('grantee@example.com');
  const id = userRow('grantee@example.com').id;
  const admin = await loginAs('admin@proconnect.example');
  assert.equal((await admin.put(`/api/admin/users/${id}/organizer`, { granted: 'yes' })).status, 400);
  assert.equal((await admin.put('/api/admin/users/9999/organizer', { granted: true })).status, 404);

  assert.equal(userRow('grantee@example.com').is_organizer, 0);
  assert.equal((await admin.put(`/api/admin/users/${id}/organizer`, { granted: true })).status, 200);
  assert.equal(userRow('grantee@example.com').is_organizer, 1);
  assert.equal(perms.canPublishListings(userRow('grantee@example.com')), true);
  assert.equal((await admin.put(`/api/admin/users/${id}/organizer`, { granted: false })).status, 200);
  assert.equal(perms.canPublishListings(userRow('grantee@example.com')), false);

  assert.equal((await admin.put(`/api/admin/users/${id}/professional`, { granted: true })).body.user.status, 'professional');
  assert.equal(userRow('grantee@example.com').status, 'professional');
  assert.equal((await admin.put(`/api/admin/users/${id}/professional`, { granted: false })).body.user.status, 'beginner');
});

test('Community Leader authority is limited to the communities they lead', async () => {
  const db = getDb();
  const idOf = (name) => db.prepare('SELECT id FROM communities WHERE name = ?').get(name).id;
  const alexRow = userRow('alex.morgan@example.com'); // leads Design & UX in the demo data
  const design = idOf('Design & UX');
  const uxResearch = idOf('UX Research'); // a subcommunity of Design & UX
  const software = idOf('Software Development');

  assert.equal(perms.isLeaderOf(alexRow, design), true);
  assert.equal(perms.isLeaderOf(alexRow, uxResearch), true); // a parent's leader also leads its subcommunities
  assert.equal(perms.isLeaderOf(alexRow, software), false);
  assert.equal(perms.isLeaderOf(alexRow, idOf('Backend')), false);
  assert.equal(perms.isLeaderOf(userRow('admin@proconnect.example'), design), false); // Admin is not implicitly a leader

  const alex = await loginAs('alex.morgan@example.com');
  const sub = { name: 'Interaction Design', description: 'Motion, micro-interactions and flows.' };
  assert.equal((await alex.post('/api/communities', { ...sub, parentId: software })).status, 403); // someone else's parent
  assert.equal((await alex.post('/api/communities', { ...sub, category: 'Design' })).status, 403); // top-level stays Admin-only
  assert.equal((await alex.post('/api/communities', { ...sub, parentId: uxResearch })).status, 403); // a subcommunity is not a parent they lead
  const made = await alex.post('/api/communities', { ...sub, parentId: design });
  assert.equal(made.status, 201);
  assert.equal(made.body.community.parentId, design);
  assert.equal((await alex.request('DELETE', `/api/communities/${made.body.community.id}`)).status, 403);

  // A leader gets no organizer permission and no admin rights.
  assert.equal(perms.canPublishListings(alexRow), false);
  assert.equal((await alex.get('/api/auth/me')).body.user.isAdmin, false);

  // The Admin assigns and removes leaders; removal ends the authority immediately.
  const admin = await loginAs('admin@proconnect.example');
  const laura = userRow('laura.bennett@example.com');
  assert.equal((await admin.put(`/api/admin/communities/${software}/leaders/${laura.id}`)).status, 200);
  assert.equal((await admin.put(`/api/admin/communities/${software}/leaders/${laura.id}`)).status, 200); // repeatable
  const lauraB = await loginAs('laura.bennett@example.com');
  assert.equal((await lauraB.post('/api/communities', { ...sub, name: 'Platform Engineering', parentId: software })).status, 201);
  assert.equal((await lauraB.post('/api/communities', { ...sub, name: 'Other Design', parentId: design })).status, 403);
  assert.equal((await admin.request('DELETE', `/api/admin/communities/${software}/leaders/${laura.id}`)).status, 200);
  assert.equal((await lauraB.post('/api/communities', { ...sub, name: 'Late Attempt', parentId: software })).status, 403);
  assert.equal((await admin.request('DELETE', `/api/admin/communities/${software}/leaders/${laura.id}`)).status, 404);
  assert.equal((await admin.put(`/api/admin/communities/9999/leaders/${laura.id}`)).status, 404);
});

test('only Authorized Organizers pass the publishing check; Leaders, Professionals and Admins do not get it implicitly', () => {
  const check = (email) => requireOrganizer({ user: userRow(email) }, {}, () => {});
  assert.doesNotThrow(() => check('sara.kim@example.com')); // organizer in the demo data
  for (const email of ['alex.morgan@example.com', 'admin@proconnect.example', 'daniel.reyes@example.com']) {
    assert.throws(() => check(email), (e) => e.status === 403 && e.code === 'forbidden', email); // leader, admin, plain professional
  }
  assert.throws(() => requireOrganizer({ user: null }, {}, () => {}), (e) => e.status === 403);
});

test('Admin accounts are not counted or listed as ordinary community participants', async () => {
  const admin = await loginAs('admin@proconnect.example');
  const design = getDb().prepare("SELECT id FROM communities WHERE name = 'Design & UX'").get().id;
  const before = (await admin.get(`/api/communities/${design}`)).body.community.memberCount;
  assert.equal((await admin.post(`/api/communities/${design}/join`)).status, 200);
  assert.equal((await admin.get(`/api/communities/${design}`)).body.community.memberCount, before);
  const people = (await admin.get('/api/search?q=Administrator&type=people')).body;
  assert.ok(!JSON.stringify(people).includes('admin@proconnect.example'));
  assert.ok(!(people.results?.people?.items || []).some((p) => p.name === 'ProConnect Admin'));
});

test('make-admin --password creates or repairs an admin account without touching other data', async () => {
  const { ensureAdmin } = await import('../src/db/makeAdmin.js');
  const users = () => getDb().prepare('SELECT COUNT(*) AS n FROM users').get().n;
  const before = users();
  assert.deepEqual(ensureAdmin('recovered.admin@example.com', 'Recovered123'), { created: true });
  const b = newBrowser();
  const r = await b.post('/api/auth/login', { email: 'recovered.admin@example.com', password: 'Recovered123' });
  assert.equal(r.status, 200);
  assert.equal(r.body.user.isAdmin, true);
  assert.equal((await b.get('/api/communities')).status, 200); // already onboarded
  assert.deepEqual(ensureAdmin('recovered.admin@example.com', 'Changed12345'), { created: false });
  assert.equal((await newBrowser().post('/api/auth/login', { email: 'recovered.admin@example.com', password: 'Recovered123' })).status, 401);
  assert.equal(users(), before + 1);
});

// ---- Part 9: status at sign-up, demo accounts, repeatable demo seed ----
test('sign-up saves Student or Beginner, defaults to Beginner and refuses anything else', async () => {
  for (const [email, sent, saved] of [['su1@example.com', 'student', 'student'], ['su2@example.com', 'beginner', 'beginner'], ['su3@example.com', undefined, 'beginner']]) {
    const r = await newBrowser().post('/api/auth/register', { name: 'Sign Up Test', email, password: 'correct-horse-9', ...(sent ? { status: sent } : {}) });
    assert.equal(r.status, 201, email);
    assert.equal(r.body.user.status, saved);
    assert.equal(userRow(email).status, saved);
  }
  for (const bad of ['professional', 'admin', 'Community Leader', '']) {
    const r = await newBrowser().post('/api/auth/register', { name: 'Sign Up Test', email: 'bad@example.com', password: 'correct-horse-9', status: bad });
    assert.equal(r.status, 400, String(bad));
    assert.ok(r.body.error.fields.status);
  }
  assert.equal(userRow('bad@example.com'), undefined);
});

test('bots: a broad IT directory with labelled, unprivileged, non-login bot participants, created repeatably', async () => {
  const demo = await import('../src/db/demoData.js');
  const db = getDb();
  const count = (sql) => db.prepare(sql).get().n;
  const sizes = () => ['users', 'communities', 'memberships', 'posts', 'comments'].map((t) => count(`SELECT COUNT(*) AS n FROM ${t}`));
  const realBefore = count("SELECT COUNT(*) AS n FROM users WHERE is_bot = 0");

  const first = demo.ensureDemoData();
  assert.equal(first.bots, 40);
  assert.equal(first.subcommunities, 72);
  assert.ok(first.communities >= 11); // 12 main areas; Software Development already existed in the sample data
  const afterFirst = sizes();
  assert.deepEqual(Object.values(demo.ensureDemoData()), [0, 0, 0, 0, 0, 0, 0]); // second run creates nothing
  assert.deepEqual(sizes(), afterFirst);
  assert.equal(count("SELECT COUNT(*) AS n FROM users WHERE is_bot = 0"), realBefore + 1); // only the owner administrator is new

  // Every directory community has several discussions with replies from different bots, on topic.
  const dirs = (await import('../src/db/botContent.js')).DIRECTORY;
  const slugify = (x) => x.toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  for (const d of dirs) {
    for (const e of [d.top, ...d.subs]) {
      const c = db.prepare('SELECT id FROM communities WHERE slug = ?').get(e === d.top ? slugify(e.name) : `${slugify(d.top.name)}-${slugify(e.name)}`);
      assert.ok(c, e.name);
      assert.ok(count(`SELECT COUNT(*) AS n FROM posts WHERE community_id = ${c.id}`) >= 3, `${e.name} has discussions`);
      assert.ok(count(`SELECT COUNT(DISTINCT cm.author_id) AS n FROM comments cm JOIN posts p ON p.id = cm.post_id WHERE p.community_id = ${c.id}`) >= 3, `${e.name} has replies from several bots`);
    }
  }
  assert.ok(count('SELECT COUNT(*) AS n FROM communities WHERE parent_id IS NULL') >= 12);

  // Bots are labelled, cannot sign in and carry no privileges.
  const bots = db.prepare('SELECT * FROM users WHERE is_bot = 1').all();
  assert.ok(bots.length >= 40);
  for (const b of bots) {
    assert.equal(b.role, 'member');
    assert.equal(b.is_organizer, 0);
    assert.ok(/bot/i.test(b.headline) && /bot/i.test(b.bio), b.name);
    assert.equal(db.prepare('SELECT COUNT(*) AS n FROM community_leaders WHERE user_id = ?').get(b.id).n, 0);
  }
  const bot = bots.find((b) => b.email.endsWith('@bots.proconnect.example'));
  assert.equal((await newBrowser().post('/api/auth/login', { email: bot.email, password: 'anything' })).status, 401);
  assert.equal((await newBrowser().post('/api/auth/login', { email: bot.email, password: '!bot-account-cannot-sign-in' })).status, 401);

  // The API tells the interface who is a bot.
  const viewer = await loginAs('sara.kim@example.com');
  const community = db.prepare("SELECT id FROM communities WHERE name = 'Kubernetes'").get().id;
  const list = (await viewer.get(`/api/communities/${community}`)).body;
  assert.ok(JSON.stringify(list).includes('"isBot":true'));
  const profile = (await viewer.get(`/api/users/${bot.id}`)).body.user;
  assert.equal(profile.isBot, true);
  assert.ok(!('email' in profile) && !('role' in profile));
});

test('the owner administrator signs in; cleanup removes the old demo accounts but never real users or their content', async () => {
  const demo = await import('../src/db/demoData.js');
  const db = getDb();
  const owner = await newBrowser();
  const r = await owner.post('/api/auth/login', { email: demo.OWNER_ADMIN.email, password: demo.OWNER_ADMIN.password });
  assert.equal(r.status, 200);
  assert.equal(r.body.user.isAdmin, true);
  assert.equal((await owner.put('/api/admin/users/1/organizer', { granted: false })).status, 200);

  // Re-create two of the old demo accounts plus a real member's reply under one of their posts.
  const hash = userRow('sara.kim@example.com').password_hash.length ? (await import('bcryptjs')).default.hashSync('ProConnect123!', 4) : '';
  const add = db.prepare("INSERT INTO users (name, email, password_hash, profile_completed, role, status) VALUES (?, ?, ?, 1, 'member', 'student')");
  add.run('Old Student', 'student@proconnect.example', hash);
  add.run('Old Leader', 'leader@proconnect.example', hash);
  const legacy = userRow('student@proconnect.example').id;
  const community = db.prepare("SELECT id FROM communities WHERE name = 'Python'").get().id;
  const post = Number(db.prepare('INSERT INTO posts (author_id, community_id, title, content) VALUES (?, ?, ?, ?)').run(legacy, community, 'Old demo discussion', 'Kept for the replies below.').lastInsertRowid);
  db.prepare('INSERT INTO comments (post_id, author_id, content) VALUES (?, ?, ?)').run(post, userRow('sara.kim@example.com').id, 'A real member replied here.');
  const users = () => db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  const before = users();

  // admin@ still has the demo password and another administrator exists, so it goes too; a changed password keeps it.
  const report = demo.removeLegacyDemoAccounts();
  assert.deepEqual(report.removed.sort(), ['admin@proconnect.example', 'leader@proconnect.example', 'student@proconnect.example']);
  assert.equal(users(), before - 3 + 1); // three accounts removed, one bot-labelled archive account added
  assert.equal(userRow('student@proconnect.example'), undefined);
  assert.ok(userRow('sara.kim@example.com') && userRow('alex.morgan@example.com') && userRow(demo.OWNER_ADMIN.email));
  const kept = db.prepare("SELECT p.title, u.is_bot FROM posts p JOIN users u ON u.id = p.author_id WHERE p.id = ?").get(post);
  assert.deepEqual([kept.title, kept.is_bot], ['Old demo discussion', 1]);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM comments WHERE post_id = ?').get(post).n, 1);
  assert.deepEqual(demo.removeLegacyDemoAccounts().removed, []); // repeatable
});

test('a changed-password admin@ account and a sole administrator are never removed', async () => {
  const demo = await import('../src/db/demoData.js');
  const db = getDb();
  const bcryptjs = (await import('bcryptjs')).default;
  db.prepare("INSERT INTO users (name, email, password_hash, profile_completed, role) VALUES ('Real Admin', 'admin@proconnect.example', ?, 1, 'admin')").run(bcryptjs.hashSync('My-own-password-1', 4));
  const r = demo.removeLegacyDemoAccounts();
  assert.deepEqual(r.removed, []);
  assert.ok(r.keptAdmin.includes('password was changed'));
  assert.ok(userRow('admin@proconnect.example'));
});

// ---- Part 2: notifications ----
const notif = await import('../src/utils/notifications.js');
const countNotifs = (email) => getDb().prepare('SELECT COUNT(*) AS n FROM notifications WHERE recipient_id = ?').get(userRow(email).id).n;
const countReplies = (email) => getDb().prepare("SELECT COUNT(*) AS n FROM notifications WHERE recipient_id = ? AND type = 'comment_reply'").get(userRow(email).id).n;
const topCommunityId = (name) => getDb().prepare('SELECT id FROM communities WHERE name = ? AND parent_id IS NULL').get(name).id;

async function memberOf(email, communityName) {
  const b = await newMember(email);
  if (communityName) assert.equal((await b.post(`/api/communities/${topCommunityId(communityName)}/join`)).status, 200);
  return b;
}
async function startDiscussion(b, id, title) {
  const r = await b.post(`/api/communities/${id}/posts`, { title, content: 'Body text for the notification test.' });
  assert.equal(r.status, 201, JSON.stringify(r.body));
  return r.body.post.id;
}

test('notifications: a new discussion notifies joined members only, never its author or bots', async () => {
  const design = topCommunityId('Design & UX');
  const author = await memberOf('n.author@example.com', 'Design & UX');
  const member = await memberOf('n.member@example.com', 'Design & UX');
  await memberOf('n.outsider@example.com', null); // joined nothing
  const other = await memberOf('n.other@example.com', 'Software Development'); // a different community
  const botId = getDb().prepare("SELECT id FROM users WHERE is_bot = 1 LIMIT 1").get()?.id;
  if (botId) getDb().prepare('INSERT OR IGNORE INTO memberships (user_id, community_id) VALUES (?, ?)').run(botId, design);
  const botBefore = botId ? getDb().prepare('SELECT COUNT(*) AS n FROM notifications WHERE recipient_id = ?').get(botId).n : 0;

  const postId = await startDiscussion(author, design, 'Notification test: first discussion');
  assert.equal(countNotifs('n.member@example.com'), 1);
  assert.equal(countNotifs('n.author@example.com'), 0); // not about their own discussion
  assert.equal(countNotifs('n.outsider@example.com'), 0);
  assert.equal(countNotifs('n.other@example.com'), 0);
  if (botId) assert.equal(getDb().prepare('SELECT COUNT(*) AS n FROM notifications WHERE recipient_id = ?').get(botId).n, botBefore);

  const list = (await member.get('/api/notifications')).body;
  assert.equal(list.unreadCount, 1);
  const n = list.notifications[0];
  assert.deepEqual([n.type, n.read, n.post.id, n.post.title, n.community.name, n.actor.name, n.link, n.commentId], ['new_discussion', false, postId, 'Notification test: first discussion', 'Design & UX', 'Test Member', `/posts/${postId}`, null]);
  assert.equal((await other.get('/api/notifications')).body.notifications.length, 0);

  // The same event can never be recorded twice for the same recipient.
  const row = getDb().prepare('SELECT * FROM posts WHERE id = ?').get(postId);
  assert.equal(notif.notifyNewDiscussion(row), 0);
  assert.equal(countNotifs('n.member@example.com'), 1);
});

test('notifications: a discussion in a subcommunity notifies members of its main community', async () => {
  const sub = getDb().prepare("SELECT id, parent_id FROM communities WHERE parent_id IS NOT NULL LIMIT 1").get();
  const parentName = getDb().prepare('SELECT name FROM communities WHERE id = ?').get(sub.parent_id).name;
  const writer = await memberOf('n.sub.writer@example.com', parentName);
  await memberOf('n.sub.reader@example.com', parentName);
  await memberOf('n.sub.away@example.com', null);
  const postId = await startDiscussion(writer, sub.id, 'Notification test: in a subcommunity');
  assert.equal(countNotifs('n.sub.reader@example.com'), 1);
  assert.equal(countNotifs('n.sub.away@example.com'), 0);
  const n = (await (await loginAs('n.sub.reader@example.com').catch(() => null))?.get?.('/api/notifications')) || null;
  void n;
  assert.equal(getDb().prepare('SELECT community_id FROM notifications WHERE post_id = ?').get(postId).community_id, sub.id);
});

test('notifications: replying to a comment notifies its author, not the replier, with a link to that reply', async () => {
  const design = topCommunityId('Design & UX');
  const owner = await memberOf('n.owner@example.com', 'Design & UX');
  const replier = await memberOf('n.replier@example.com', 'Design & UX');
  const postId = await startDiscussion(owner, design, 'Notification test: replies');
  const first = (await replier.post(`/api/posts/${postId}/comments`, { content: 'A comment by the replier.' })).body.comment.id;
  assert.equal(countReplies('n.owner@example.com'), 0); // a plain comment on a post is not a notification

  // The post author answers the replier's comment: the replier is notified.
  const answer = await owner.post(`/api/posts/${postId}/comments`, { content: 'Answering you directly.', parentId: first });
  assert.equal(answer.status, 201);
  assert.equal(answer.body.comment.parentId, first);
  assert.equal(countReplies('n.replier@example.com'), 1);
  assert.equal(countReplies('n.owner@example.com'), 0);
  const n = (await replier.get('/api/notifications')).body.notifications[0];
  assert.deepEqual([n.type, n.post.id, n.commentId, n.link, n.actor.name], ['comment_reply', postId, answer.body.comment.id, `/posts/${postId}#comment-${answer.body.comment.id}`, 'Test Member']);

  // Replying to your own comment, or posting without parentId, notifies nobody.
  await replier.post(`/api/posts/${postId}/comments`, { content: 'Replying to myself.', parentId: first });
  await replier.post(`/api/posts/${postId}/comments`, { content: 'Another plain comment.' });
  assert.equal(countReplies('n.replier@example.com'), 1);
  assert.equal(countReplies('n.owner@example.com'), 0);

  // The thread comes back with who is answering whom.
  const comments = (await owner.get(`/api/posts/${postId}`)).body.comments;
  const shown = comments.find((c) => c.id === answer.body.comment.id);
  assert.equal(shown.parentId, first);
  assert.equal(shown.replyTo.id, first);

  // Duplicates are impossible, and bad parents are refused.
  assert.equal(notif.notifyCommentReply({ id: answer.body.comment.id, post_id: postId, author_id: userRow('n.owner@example.com').id }, { author_id: userRow('n.replier@example.com').id }), 0);
  assert.equal(countReplies('n.replier@example.com'), 1);
  const otherPost = await startDiscussion(owner, design, 'Notification test: another discussion');
  assert.equal((await owner.post(`/api/posts/${otherPost}/comments`, { content: 'Wrong thread.', parentId: first })).status, 400);
  assert.equal((await owner.post(`/api/posts/${postId}/comments`, { content: 'Missing parent.', parentId: 999999 })).status, 400);
  assert.equal((await owner.post(`/api/posts/${postId}/comments`, { content: 'Bad parent.', parentId: 'abc' })).status, 400);
});

test('notifications: read state and unread counts, and members only ever reach their own', async () => {
  const design = topCommunityId('Design & UX');
  const a = await memberOf('n.a@example.com', 'Design & UX');
  const b = await memberOf('n.b@example.com', 'Design & UX');
  const c = await memberOf('n.c@example.com', 'Design & UX');
  await startDiscussion(c, design, 'Notification test: counts one');
  await startDiscussion(c, design, 'Notification test: counts two');
  const listA = (await a.get('/api/notifications')).body;
  assert.equal(listA.unreadCount, 2);
  assert.equal((await a.get('/api/notifications/unread-count')).body.unreadCount, 2);
  assert.equal((await a.get('/api/notifications?unread=1&limit=1')).body.notifications.length, 1);
  const [first, second] = listA.notifications;
  assert.ok(first.createdAt >= second.createdAt); // newest first

  // Someone else's notification looks like a missing one and stays untouched.
  const foreign = await b.post(`/api/notifications/${first.id}/read`);
  assert.equal(foreign.status, 404);
  assert.equal((await a.get('/api/notifications/unread-count')).body.unreadCount, 2);
  assert.ok(!JSON.stringify((await b.get('/api/notifications')).body).includes(`"id":${first.id},`) || (await b.get('/api/notifications')).body.notifications.every((n) => n.id !== first.id));

  const read = await a.post(`/api/notifications/${first.id}/read`);
  assert.equal(read.status, 200);
  assert.equal(read.body.unreadCount, 1);
  assert.equal((await a.post(`/api/notifications/${first.id}/read`)).body.unreadCount, 1); // repeating changes nothing
  const after = (await a.get('/api/notifications')).body.notifications.find((n) => n.id === first.id);
  assert.equal(after.read, true);

  // "Mark all as read" only touches the caller.
  assert.equal((await b.get('/api/notifications/unread-count')).body.unreadCount, 2);
  assert.equal((await a.post('/api/notifications/read-all')).body.unreadCount, 0);
  assert.equal((await b.get('/api/notifications/unread-count')).body.unreadCount, 2);

  // Invalid and unauthenticated requests.
  assert.equal((await a.post('/api/notifications/abc/read')).status, 400);
  assert.equal((await a.post('/api/notifications/999999/read')).status, 404);
  for (const [method, path] of [['GET', '/api/notifications'], ['GET', '/api/notifications/unread-count'], ['POST', '/api/notifications/read-all'], ['POST', `/api/notifications/${first.id}/read`]]) {
    assert.equal((await newBrowser().request(method, path)).status, 401, path);
  }
});

test('notifications: deleted content disappears safely and demo seeding creates none', async () => {
  const design = topCommunityId('Design & UX');
  const writer = await memberOf('n.del.writer@example.com', 'Design & UX');
  const reader = await memberOf('n.del.reader@example.com', 'Design & UX');
  const postId = await startDiscussion(writer, design, 'Notification test: to be deleted');
  const mine = (await reader.post(`/api/posts/${postId}/comments`, { content: 'My comment.' })).body.comment.id;
  await writer.post(`/api/posts/${postId}/comments`, { content: 'Reply to you.', parentId: mine });
  assert.equal(countNotifs('n.del.reader@example.com'), 2);
  assert.equal((await writer.request('DELETE', `/api/posts/${postId}`)).status, 200);
  assert.equal(countNotifs('n.del.reader@example.com'), 0);
  assert.equal((await reader.get('/api/notifications')).status, 200);

  // Deleting only the reply removes only its notification; deleting a parent keeps the reply as a normal comment.
  const p2 = await startDiscussion(writer, design, 'Notification test: delete a reply');
  const c1 = (await reader.post(`/api/posts/${p2}/comments`, { content: 'Parent comment.' })).body.comment.id;
  const c2 = (await writer.post(`/api/posts/${p2}/comments`, { content: 'Child reply.', parentId: c1 })).body.comment.id;
  assert.equal((await reader.request('DELETE', `/api/comments/${c1}`)).status, 200);
  const child = (await writer.get(`/api/posts/${p2}`)).body.comments.find((c) => c.id === c2);
  assert.deepEqual([child.parentId, child.replyTo], [null, null]);
  assert.equal((await writer.request('DELETE', `/api/comments/${c2}`)).status, 200);
  assert.equal((await reader.get('/api/notifications')).status, 200);

  // Seeding demo content writes posts and comments directly and never creates notifications.
  const demo = await import('../src/db/demoData.js');
  const before = getDb().prepare('SELECT COUNT(*) AS n FROM notifications').get().n;
  getDb().prepare("DELETE FROM posts WHERE title IN ('Do I really need Kubernetes for a small project?', 'Is DevOps a job title or a way of working?')").run();
  demo.ensureDemoData(); // recreates what was just removed
  assert.equal(getDb().prepare('SELECT COUNT(*) AS n FROM notifications').get().n, before);
});

// ---- Part 3: search and discovery, and the five test accounts ----
const testers = await import('../src/db/testAccounts.js');
const crypto3 = await import('node:crypto');
const TESTER_PASSWORDS = Object.fromEntries(testers.TEST_ACCOUNTS.map((a) => [a.email, `T3st-${crypto3.randomBytes(8).toString('hex')}-Pw`]));
const tester = (key) => testers.TEST_ACCOUNTS.find((a) => a.key === key);
const find = (b, params) => searchFor(b, params);
const names = (r) => r.items.map((i) => i.name);

test('five test accounts: created in the database, repeatable, non-destructive, and able to sign in', async () => {
  const db = getDb();
  const before = db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  const first = testers.ensureTestAccounts(TESTER_PASSWORDS);
  assert.equal(first.created.length, 5);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM users').get().n, before + 5);
  const second = testers.ensureTestAccounts(TESTER_PASSWORDS);
  assert.deepEqual([second.created.length, second.updated.length, second.unchanged.length], [0, 0, 5]);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM users').get().n, before + 5);

  for (const a of testers.TEST_ACCOUNTS) {
    const row = userRow(a.email);
    assert.ok(row.password_hash.startsWith('$2'), 'stored as a bcrypt hash'); // never plaintext
    assert.ok(!row.password_hash.includes(TESTER_PASSWORDS[a.email]));
    const b = newBrowser();
    const login = await b.post('/api/auth/login', { email: a.email, password: TESTER_PASSWORDS[a.email] });
    assert.equal(login.status, 200, a.email);
    const me = (await b.get('/api/auth/me')).body.user;
    assert.deepEqual([me.name, me.profession, me.status, me.isAdmin, me.isBot, me.isOrganizer], [a.name, a.profession, a.status, false, false, false]);
    assert.ok(me.skills.length >= 4 && me.bio.length > 40, 'profile is filled in');
    assert.equal((await b.get('/api/communities')).status, 200); // onboarded
  }
  assert.equal(new Set(testers.TEST_ACCOUNTS.map((a) => a.profession)).size, 5); // five different specialties

  // A rerun refreshes demo text only; an existing password, status and role are never touched.
  db.prepare("UPDATE users SET headline = 'edited by hand', status = 'professional' WHERE email = ?").run(tester('frontend').email);
  const third = testers.ensureTestAccounts({ ...TESTER_PASSWORDS, [tester('frontend').email]: 'a-different-password-1' });
  assert.deepEqual(third.updated, [tester('frontend').email]);
  assert.equal(userRow(tester('frontend').email).headline, tester('frontend').headline);
  assert.equal(userRow(tester('frontend').email).status, 'professional'); // left alone
  assert.equal((await newBrowser().post('/api/auth/login', { email: tester('frontend').email, password: TESTER_PASSWORDS[tester('frontend').email] })).status, 200);
  db.prepare("UPDATE users SET status = 'student' WHERE email = ?").run(tester('frontend').email);

  const demo = await import('../src/db/demoData.js');
  demo.ensureDemoData(); // communities for memberships and the leader assignment
  const again = testers.ensureTestAccounts(TESTER_PASSWORDS);
  assert.deepEqual([again.memberships, again.leaders], [0, 0]); // already added by the first run above, nothing doubled
  const maya = userRow(tester('frontend').email).id;
  assert.ok(db.prepare("SELECT COUNT(*) AS n FROM memberships m JOIN communities c ON c.id = m.community_id WHERE m.user_id = ? AND c.name = 'Web Development'").get(maya).n === 1);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM community_leaders WHERE user_id = ?').get(userRow(tester('security').email).id).n, 1);
});

test('search: members only, discovery without a query, and every error is explained', async () => {
  for (const path of ['/api/search', '/api/search?q=maya', '/api/search/options']) assert.equal((await newBrowser().get(path)).status, 401, path);
  const maya = await loginAs(tester('frontend').email).catch(() => null);
  const b = maya || (await signedInAsAlex());
  const empty = await find(b, {});
  assert.ok(empty.results.people.total > 0 && empty.results.communities.total > 0); // discovery, not an error
  assert.ok(empty.results.people.items.length <= 20 && empty.results.communities.items.length <= 20);
  assert.deepEqual(Object.keys(empty.results).sort(), ['communities', 'people']); // no discussions or courses
  const none = await find(b, { q: 'qqzzxx-nothing-matches' });
  assert.deepEqual([none.results.people.total, none.results.communities.total, none.results.people.items.length], [0, 0, 0]);
  for (const q of ['%', '_', '\\']) {
    const r = await find(b, { q });
    assert.equal(r.results.people.total + r.results.communities.total, 0, `literal ${q}`);
  }
  for (const [params, label] of [[{ q: 'x'.repeat(101) }, 'long query'], [{ status: 'admin' }, 'status'], [{ sort: 'oldest' }, 'sort'], [{ limit: '0' }, 'limit 0'], [{ limit: '101' }, 'limit 101'], [{ limit: 'abc' }, 'limit abc'], [{ profession: 'x'.repeat(81) }, 'profession']]) {
    const r = await b.get(`/api/search?${new URLSearchParams(params)}`);
    assert.equal(r.status, 400, label);
    assert.ok(r.body.error.message.length > 5);
  }
  assert.equal((await find(b, { limit: '2' })).results.people.items.length, 2);
});

test('people search: by name, specialty and skill, case-insensitively, with private data kept out', async () => {
  const alex = await signedInAsAlex();
  assert.deepEqual(names((await find(alex, { q: 'maya chen' })).results.people), ['Maya Chen']);
  assert.deepEqual(names((await find(alex, { q: 'MAYA' })).results.people), ['Maya Chen']);
  assert.deepEqual(names((await find(alex, { q: 'pytorch' })).results.people).includes('Priya Nair'), true); // skill
  assert.ok(names((await find(alex, { q: 'cybersecurity analyst' })).results.people).includes('Lukas Brandt')); // specialty
  assert.ok(names((await find(alex, { profession: 'DevOps Engineer' })).results.people).includes('Sofia Alvarez')); // specialty filter
  assert.deepEqual(names((await find(alex, { q: 'docker', profession: 'Backend Developer' })).results.people), ['Daniel Okoro']); // combined
  assert.ok((await alex.get('/api/search/options')).body.professions.includes('Machine Learning Engineer'));

  // Every script is case-insensitive: Armenian, Cyrillic and Greek specialties.
  const members = [['search.hy@example.com', 'Ծրագրավորող'], ['search.ru@example.com', 'Разработчик'], ['search.el@example.com', 'Μηχανικός']];
  for (const [email, profession] of members) {
    const b = await newMember(email);
    assert.equal((await b.put('/api/profile', { profession, bio: 'Profession written in another script.', skills: 'Testing' })).status, 200);
  }
  assert.deepEqual(names((await find(alex, { q: 'ԾՐԱԳՐԱՎՈՐՈՂ' })).results.people).length, 1);
  assert.equal((await find(alex, { q: 'разраб' })).results.people.total, 1);
  assert.equal((await find(alex, { q: 'ΜΗΧΑΝΙΚΌΣ' })).results.people.total, 1);

  // No private data, no incomplete profiles, no administrators.
  const raw = JSON.stringify(await find(alex, { q: 'a' }));
  assert.ok(!raw.includes('@proconnect.example') && !raw.includes('@example.com') && !/password|hash|email/i.test(raw));
  const incomplete = newBrowser();
  await incomplete.post('/api/auth/register', { name: 'Hidden Zelda', email: 'zelda.hidden@example.com', password: 'longenough1' });
  assert.equal((await find(alex, { q: 'zelda' })).results.people.total, 0);
  assert.equal((await find(alex, { q: 'Site Owner' })).results.people.total, 0);
  for (const person of (await find(alex, { limit: '100' })).results.people.items) {
    assert.deepEqual(Object.keys(person).sort(), ['avatarUrl', 'bioExcerpt', 'headline', 'id', 'isBot', 'isLeader', 'location', 'name', 'profession', 'skills', 'status', 'updatedAt']);
  }
});

test('people search: status filters (Student, Beginner, Professional, Community Leader) match the role model', async () => {
  const alex = await signedInAsAlex();
  const list = async (status) => names((await find(alex, { status, limit: '100' })).results.people);
  const students = await list('student');
  assert.ok(students.includes('Sofia Alvarez') && students.includes('Maya Chen') && !students.includes('Priya Nair'));
  const beginners = await list('beginner');
  assert.ok(beginners.includes('Daniel Okoro') && !beginners.includes('Maya Chen'));
  const pros = await list('professional');
  assert.ok(pros.includes('Priya Nair') && pros.includes('Lukas Brandt') && !pros.includes('Daniel Okoro'));
  assert.deepEqual(await list('leader'), [...(await list('leader'))].filter(Boolean)); // leaders only
  assert.ok((await list('leader')).includes('Lukas Brandt') && !(await list('leader')).includes('Priya Nair'));
  // Bots never appear under a status filter, and a bot is labelled when it does appear.
  for (const status of ['student', 'beginner', 'professional', 'leader']) {
    assert.ok((await find(alex, { status, limit: '100' })).results.people.items.every((p) => !p.isBot), status);
  }
  const bot = (await find(alex, { q: 'bots', limit: '100' })).results.people.items.find((p) => p.isBot);
  if (bot) assert.equal(bot.isBot, true);
  const shown = (await find(alex, { q: 'lukas' })).results.people.items[0];
  assert.deepEqual([shown.status, shown.isLeader], ['professional', true]);
  // Filters combine with a keyword.
  assert.deepEqual(names((await find(alex, { q: 'docker', status: 'student' })).results.people), ['Sofia Alvarez']);
});

test('people open the real profile, and the sort order is the last profile update', async () => {
  const alex = await signedInAsAlex();
  const priya = (await find(alex, { q: 'priya nair' })).results.people.items[0];
  const profile = (await alex.get(`/api/users/${priya.id}`)).body.user;
  assert.deepEqual([profile.id, profile.name, profile.profession], [priya.id, 'Priya Nair', 'Machine Learning Engineer']);
  assert.ok(!('email' in profile) && !('password_hash' in profile));
  assert.equal((await alex.get('/api/users/99999999')).status, 404);

  const people = (await find(alex, { limit: '100' })).results.people.items;
  for (let i = 1; i < people.length; i++) assert.ok(people[i - 1].updatedAt >= people[i].updatedAt, 'newest update first');
  // Editing a profile moves it to the top.
  const sofia = await loginAs(tester('devops').email).catch(() => null);
  const login = newBrowser();
  await login.post('/api/auth/login', { email: tester('devops').email, password: TESTER_PASSWORDS[tester('devops').email] });
  await new Promise((r) => setTimeout(r, 15));
  assert.equal((await login.put('/api/profile', { profession: 'DevOps Engineer', bio: 'Updated biography so the profile becomes the most recent one.', skills: 'Linux, Docker, CI/CD, Kubernetes' })).status, 200);
  assert.equal((await find(alex, {})).results.people.items[0].name, 'Sofia Alvarez');
  void sofia;
  const relevance = (await find(alex, { q: 'maya', sort: 'relevance' })).results.people.items;
  assert.equal(relevance[0].name, 'Maya Chen');
});

test('community search: name, description and specialty; subcommunities are found and labelled; newest first', async () => {
  const alex = await signedInAsAlex();
  const kube = (await find(alex, { q: 'kubernetes' })).results.communities.items;
  const sub = kube.find((c) => c.name === 'Kubernetes' && c.isSubcommunity);
  assert.ok(sub, 'the Kubernetes subcommunity is found');
  assert.deepEqual([sub.parent.name, sub.category, sub.joinTargetId === sub.parent.id], ['Cloud and DevOps', 'Cloud and DevOps', true]);
  assert.ok(sub.description.length > 20 && Number.isInteger(sub.memberCount) && Number.isInteger(sub.postCount));

  const main = (await find(alex, { q: 'cloud and devops' })).results.communities.items.find((c) => c.name === 'Cloud and DevOps');
  assert.deepEqual([main.isSubcommunity, main.parent, main.joinTargetId === main.id], [false, null, true]);
  assert.ok((await find(alex, { q: 'running software reliably' })).results.communities.items.some((c) => c.name === 'Cloud and DevOps')); // description text
  assert.ok((await find(alex, { q: 'KUBERNETES' })).results.communities.items.some((c) => c.id === sub.id)); // case

  const options = (await alex.get('/api/search/options')).body;
  assert.ok(options.categories.includes('Cloud and DevOps') && options.statuses.length === 4);
  const byCategory = (await find(alex, { category: 'Cloud and DevOps', limit: '100' })).results.communities.items;
  assert.ok(byCategory.length >= 10 && byCategory.every((c) => c.category === 'Cloud and DevOps'));
  assert.ok(byCategory.some((c) => c.isSubcommunity) && byCategory.some((c) => !c.isSubcommunity));
  assert.deepEqual(names((await find(alex, { q: 'docker', category: 'Cloud and DevOps' })).results.communities).includes('Docker and Containers'), true);
  assert.equal((await find(alex, { category: 'No Such Specialty' })).results.communities.total, 0);

  // Newest first by creation time; a new community goes to the top.
  const all = (await find(alex, { limit: '100' })).results.communities.items;
  for (let i = 1; i < all.length; i++) assert.ok(all[i - 1].createdAt >= all[i].createdAt);
  const admin = newBrowser();
  await admin.post('/api/auth/login', { email: 'owner.admin@proconnect.example', password: (await import('../src/db/demoData.js')).OWNER_ADMIN.password });
  const made = await admin.post('/api/communities', { name: 'Search Order Test Community', description: 'Created to prove newest-first order.', category: 'Testing' });
  assert.equal(made.status, 201, JSON.stringify(made.body));
  assert.equal((await find(alex, {})).results.communities.items[0].name, 'Search Order Test Community');
  assert.equal((await find(alex, { q: 'order test', category: 'Testing' })).results.communities.total, 1);
});

test('joining from a community result persists in the database and follows the existing rules', async () => {
  const db = getDb();
  const daniel = newBrowser();
  await daniel.post('/api/auth/login', { email: tester('backend').email, password: TESTER_PASSWORDS[tester('backend').email] });
  const target = db.prepare("SELECT id FROM communities WHERE name = 'Agile and Scrum'").get();
  const parent = db.prepare("SELECT id, name FROM communities WHERE name = 'Product and Project Management' AND parent_id IS NULL").get();
  const uid = userRow(tester('backend').email).id;
  const rowCount = () => db.prepare('SELECT COUNT(*) AS n FROM memberships WHERE user_id = ? AND community_id = ?').get(uid, parent.id).n;
  assert.equal(rowCount(), 0);

  const result = (await find(daniel, { q: 'agile and scrum' })).results.communities.items.find((c) => c.id === target.id);
  assert.deepEqual([result.isSubcommunity, result.isMember, result.joinTargetId], [true, false, parent.id]);
  // A subcommunity cannot be joined directly: the member joins its main community (existing rule).
  assert.equal((await daniel.post(`/api/communities/${target.id}/join`)).status, 400);
  assert.equal(rowCount(), 0);

  const before = result.memberCount;
  const joined = await daniel.post(`/api/communities/${result.joinTargetId}/join`);
  assert.equal(joined.status, 200);
  assert.equal(joined.body.community.isMember, true);
  assert.equal(rowCount(), 1); // persisted in the database
  assert.equal((await daniel.post(`/api/communities/${result.joinTargetId}/join`)).status, 200); // repeating is harmless
  assert.equal(rowCount(), 1);
  const after = (await find(daniel, { q: 'agile and scrum' })).results.communities.items.find((c) => c.id === target.id);
  assert.deepEqual([after.isMember, after.memberCount], [true, before + 1]);
  assert.equal((await daniel.get(`/api/communities/${target.id}`)).status, 200); // the real detail page opens
  assert.equal((await daniel.get(`/api/communities/${result.joinTargetId}`)).body.community.name, parent.name);

  // Joining does not grant management rights.
  assert.equal((await daniel.post('/api/communities', { name: 'Not Allowed Community', description: 'Should be refused for a plain member.', category: 'X', parentId: parent.id })).status, 403);
  assert.equal((await daniel.put('/api/admin/users/1/organizer', { granted: true })).status, 403);
  await daniel.request('DELETE', `/api/communities/${result.joinTargetId}/join`);
  assert.equal(rowCount(), 0);
});

// ---- Part 7: community and subcommunity management, membership ----
const ownerAdmin = async () => {
  const b = newBrowser();
  const { OWNER_ADMIN } = await import('../src/db/demoData.js');
  assert.equal((await b.post('/api/auth/login', { email: OWNER_ADMIN.email, password: OWNER_ADMIN.password })).status, 200);
  return b;
};
const row = (sql, ...p) => getDb().prepare(sql).get(...p);
const commByName = (name, parentId = null) => row('SELECT * FROM communities WHERE name = ? COLLATE NOCASE AND parent_id IS ?', name, parentId);

test('admin: creates, edits and deletes a main community; subcommunities follow the category; nothing unrelated is touched', async () => {
  const admin = await ownerAdmin();
  const usersBefore = row('SELECT COUNT(*) AS n FROM users').n;
  const communitiesBefore = row('SELECT COUNT(*) AS n FROM communities').n;
  const made = await admin.post('/api/communities', { name: 'Zeta Management Test', description: 'A main community created by the management test.', category: 'Testing' });
  assert.equal(made.status, 201, JSON.stringify(made.body));
  const id = made.body.community.id;
  assert.equal((await admin.post('/api/communities', { name: 'zeta management test', description: 'Same name, different case.', category: 'Testing' })).status, 409); // no duplicates
  const sub = await admin.post('/api/communities', { name: 'Zeta Sub One', description: 'First subcommunity of the test community.', parentId: id });
  assert.equal(sub.status, 201);
  assert.equal(sub.body.community.category, 'Testing'); // inherited, whatever the request says
  assert.equal(commByName('Zeta Sub One', id).parent_id, id);

  // Edit: name, description and category (administrators); the slug and parent never change.
  const slugBefore = row('SELECT slug FROM communities WHERE id = ?', id).slug;
  const edit = await admin.put(`/api/communities/${id}`, { name: 'Zeta Management Renamed', description: 'A clearer description of the management test community.', category: 'Testing Two' });
  assert.equal(edit.status, 200, JSON.stringify(edit.body));
  assert.deepEqual([edit.body.community.name, edit.body.community.category], ['Zeta Management Renamed', 'Testing Two']);
  assert.equal(row('SELECT slug FROM communities WHERE id = ?', id).slug, slugBefore);
  assert.equal(row('SELECT category FROM communities WHERE id = ?', sub.body.community.id).category, 'Testing Two'); // subcommunities follow
  assert.equal((await admin.put(`/api/communities/${id}`, { name: 'x' })).status, 400); // validation
  assert.equal((await admin.put(`/api/communities/${id}`, { description: 'short' })).status, 400);
  assert.equal((await admin.put(`/api/communities/${id}`, { parentId: commByName('Software Development').id })).status, 400); // no re-parenting
  assert.equal((await admin.put(`/api/communities/${sub.body.community.id}`, { parentId: null })).status, 400); // no promoting either
  assert.equal((await admin.put('/api/communities/999999', { name: 'Nothing here' })).status, 404);
  assert.equal(commByName('Software Development').name, 'Software Development');

  // The detail page tells the interface what the administrator may do.
  const detail = (await admin.get(`/api/communities/${id}`)).body.community;
  assert.deepEqual(detail.permissions, { canEdit: true, canEditCategory: true, canCreateSubcommunity: true, canDelete: true, canViewMembers: true, isLeader: false });
  assert.equal(detail.subcommunities.length, 1);

  // Deleting something with content needs an explicit confirmation that names what is lost.
  const member = await newMember('mgmt.member@example.com');
  assert.equal((await member.post(`/api/communities/${id}/join`)).status, 200);
  await startDiscussion(member, sub.body.community.id, 'Discussion inside the doomed subcommunity');
  const refused = await admin.request('DELETE', `/api/communities/${id}`);
  assert.equal(refused.status, 409);
  assert.deepEqual(refused.body.error.details.impact, { subcommunities: 1, discussions: 1, members: 1 });
  assert.ok(commByName('Zeta Management Renamed'));
  assert.equal((await admin.request('DELETE', `/api/communities/${id}?confirm=true`)).status, 200);
  assert.equal(commByName('Zeta Management Renamed'), undefined);
  assert.equal(commByName('Zeta Sub One', id), undefined);
  assert.equal(row('SELECT COUNT(*) AS n FROM posts WHERE title = ?', 'Discussion inside the doomed subcommunity').n, 0);
  assert.equal(row('SELECT COUNT(*) AS n FROM users').n, usersBefore + 1); // only the member created here; no account was deleted
  assert.equal(row('SELECT COUNT(*) AS n FROM communities').n, communitiesBefore);
  assert.ok(userRow('mgmt.member@example.com'));
  // An empty community needs no confirmation.
  const empty = await admin.post('/api/communities', { name: 'Zeta Empty', description: 'Nothing in here yet, so deleting is immediate.', category: 'Testing' });
  assert.equal((await admin.request('DELETE', `/api/communities/${empty.body.community.id}`)).status, 200);
});

test('ordinary members and visitors cannot create, edit or delete communities, nor read member lists they should not see', async () => {
  const user = await memberOf('mgmt.plain@example.com', null);
  const design = commByName('Design & UX');
  const attempts = [
    ['POST', '/api/communities', { name: 'Sneaky Main', description: 'A member trying to create a main community.', category: 'Sneaky' }],
    ['POST', '/api/communities', { name: 'Sneaky Sub', description: 'A member trying to create a subcommunity.', parentId: design.id }],
    ['PUT', `/api/communities/${design.id}`, { name: 'Renamed By A Member' }],
    ['DELETE', `/api/communities/${design.id}?confirm=true`],
  ];
  for (const [method, path, body] of attempts) {
    assert.equal((await user.request(method, path, body)).status, 403, `${method} ${path}`);
    assert.equal((await newBrowser().request(method, path, body)).status, 401, `visitor ${method} ${path}`);
  }
  assert.equal(commByName('Design & UX').name, 'Design & UX');
  assert.equal(commByName('Sneaky Main'), undefined);
  assert.equal((await user.get(`/api/communities/${design.id}/members`)).status, 403); // not a member: sees the count only
  assert.equal((await newBrowser().get(`/api/communities/${design.id}/members`)).status, 401);
  assert.equal((await user.get(`/api/communities/${design.id}`)).body.community.permissions.canEdit, false);
});

test('a Community Leader manages only their own community and its subcommunities', async () => {
  const admin = await ownerAdmin();
  const alex = await loginAs('alex.morgan@example.com'); // leads Design & UX in the sample data
  const design = commByName('Design & UX');
  const software = commByName('Software Development');
  const designSub = row('SELECT * FROM communities WHERE parent_id = ? LIMIT 1', design.id);
  const softwareSub = row('SELECT * FROM communities WHERE parent_id = ? LIMIT 1', software.id);

  const perms = (await alex.get(`/api/communities/${design.id}`)).body.community.permissions;
  assert.deepEqual(perms, { canEdit: true, canEditCategory: false, canCreateSubcommunity: true, canDelete: false, canViewMembers: true, isLeader: true });
  const subPerms = (await alex.get(`/api/communities/${designSub.id}`)).body.community.permissions;
  assert.deepEqual([subPerms.canEdit, subPerms.canCreateSubcommunity, subPerms.canDelete], [true, false, false]);

  // Own community: edit name and description, but not the category.
  const description = 'Updated by the leader of this community in a management test.';
  assert.equal((await alex.put(`/api/communities/${design.id}`, { description })).status, 200);
  assert.equal(row('SELECT description FROM communities WHERE id = ?', design.id).description, description);
  assert.equal((await alex.put(`/api/communities/${design.id}`, { category: 'Something Else' })).status, 403);
  assert.equal((await alex.put(`/api/communities/${design.id}`, { parentId: software.id })).status, 400);
  // Own subcommunities: create and edit; a repeated create does not duplicate.
  const created = await alex.post('/api/communities', { name: 'Leader Made Sub', description: 'A subcommunity made by its parent community leader.', parentId: design.id });
  assert.equal(created.status, 201, JSON.stringify(created.body));
  assert.equal((await alex.post('/api/communities', { name: 'Leader Made Sub', description: 'A subcommunity made by its parent community leader.', parentId: design.id })).status, 409);
  assert.equal(row('SELECT COUNT(*) AS n FROM communities WHERE name = ? AND parent_id = ?', 'Leader Made Sub', design.id).n, 1);
  assert.equal((await alex.put(`/api/communities/${created.body.community.id}`, { name: 'Leader Renamed Sub' })).status, 200);
  assert.equal((await alex.put(`/api/communities/${designSub.id}`, { description: 'A leader may refine the descriptions of their subcommunities.' })).status, 200);
  assert.equal((await alex.get(`/api/communities/${design.id}/members`)).status, 200);

  // Someone else's community: nothing at all.
  assert.equal((await alex.put(`/api/communities/${software.id}`, { name: 'Taken Over' })).status, 403);
  assert.equal((await alex.put(`/api/communities/${softwareSub.id}`, { name: 'Taken Over Sub' })).status, 403);
  assert.equal((await alex.post('/api/communities', { name: 'Intruder Sub', description: 'A subcommunity under another leader.', parentId: software.id })).status, 403);
  assert.equal(commByName('Software Development').name, 'Software Development');
  assert.equal(commByName('Intruder Sub', software.id), undefined);
  // A parent supplied by the browser is verified: a subcommunity is not a valid parent, nor is a missing one.
  assert.equal((await alex.post('/api/communities', { name: 'Nested Too Deep', description: 'Subcommunities cannot contain subcommunities.', parentId: designSub.id })).status, 403);
  assert.equal((await admin.post('/api/communities', { name: 'Nested Too Deep', description: 'Subcommunities cannot contain subcommunities.', parentId: designSub.id })).status, 400);
  assert.equal((await admin.post('/api/communities', { name: 'Orphan Sub', description: 'The parent does not exist at all.', parentId: 999999 })).status, 400);
  assert.equal((await admin.post('/api/communities', { name: 'Orphan Sub', description: 'The parent is not a number.', parentId: 'abc' })).status, 400);

  // Top-level and platform actions stay with administrators.
  assert.equal((await alex.post('/api/communities', { name: 'Leader Main', description: 'A leader may not create a main community.', category: 'X' })).status, 403);
  assert.equal((await alex.request('DELETE', `/api/communities/${created.body.community.id}?confirm=true`)).status, 403);
  assert.equal((await alex.request('DELETE', `/api/communities/${design.id}?confirm=true`)).status, 403);
  const target = userRow('laura.bennett@example.com').id;
  assert.equal((await alex.put(`/api/admin/communities/${software.id}/leaders/${target}`)).status, 403); // cannot assign leaders
  assert.equal((await alex.put(`/api/admin/users/${userRow('alex.morgan@example.com').id}/organizer`, { granted: true })).status, 403);
  assert.equal(userRow('alex.morgan@example.com').role, 'member');

  // A second leader, appointed by the administrator, is limited in the same way and cannot touch Design & UX.
  assert.equal((await admin.put(`/api/admin/communities/${software.id}/leaders/${target}`)).status, 200);
  const laura = await loginAs('laura.bennett@example.com');
  assert.equal((await laura.put(`/api/communities/${software.id}`, { description: 'Updated by the leader of Software Development.' })).status, 200);
  assert.equal((await laura.put(`/api/communities/${design.id}`, { name: 'Not Mine' })).status, 403);
  assert.equal((await laura.put(`/api/communities/${designSub.id}`, { name: 'Not Mine Either' })).status, 403);
  assert.equal((await alex.put(`/api/communities/${softwareSub.id}`, { name: 'Still Not Alex' })).status, 403);
  await admin.request('DELETE', `/api/admin/communities/${software.id}/leaders/${target}`);
  assert.equal((await laura.put(`/api/communities/${software.id}`, { name: 'Revoked Leader' })).status, 403); // authority ends immediately
});

test('membership: join, leave, no duplicates, honest counts, only approved communities, member lists follow the rules', async () => {
  const db = getDb();
  const admin = await ownerAdmin();
  const main = commByName('Cybersecurity');
  const sub = row('SELECT * FROM communities WHERE parent_id = ? LIMIT 1', main.id);
  const user = await memberOf('mgmt.join@example.com', null);
  const uid = userRow('mgmt.join@example.com').id;
  const rows = (id = main.id) => row('SELECT COUNT(*) AS n FROM memberships WHERE user_id = ? AND community_id = ?', uid, id).n;
  const count = async () => (await user.get(`/api/communities/${main.id}`)).body.community.memberCount;

  const before = await count();
  assert.equal((await user.post(`/api/communities/${sub.id}/join`)).status, 400); // a subcommunity opens with its parent
  assert.equal(rows(sub.id), 0);
  assert.equal((await user.post(`/api/communities/${main.id}/join`)).status, 200);
  assert.equal((await user.post(`/api/communities/${main.id}/join`)).status, 200); // repeating is harmless
  assert.equal(rows(), 1); // one row, never two
  assert.equal(await count(), before + 1);
  const real = row("SELECT COUNT(DISTINCT m.user_id) AS n FROM memberships m JOIN users u ON u.id = m.user_id WHERE u.role <> 'admin' AND (m.community_id = ? OR m.community_id IN (SELECT id FROM communities WHERE parent_id = ?))", main.id, main.id).n;
  assert.equal(await count(), real); // the number is the number of membership records
  assert.ok((await user.get('/api/communities/mine')).body.communities?.some?.((c) => c.id === main.id) ?? (await user.get('/api/communities')).body.communities.find((c) => c.id === main.id).isMember);

  // Members see the list (and the subcommunity shows its parent's members); administrators are never listed.
  const list = (await user.get(`/api/communities/${main.id}/members`)).body;
  assert.ok(list.members.some((m) => m.name === 'Test Member') && list.total >= 1);
  assert.equal((await user.get(`/api/communities/${sub.id}/members`)).status, 200);
  assert.ok(!JSON.stringify(list).includes('@') && !/password|hash|email/i.test(JSON.stringify(list)));
  assert.equal((await user.get(`/api/communities/${main.id}/members?limit=0`)).status, 400);
  assert.equal((await user.get(`/api/communities/${main.id}/members?limit=201`)).status, 400);
  assert.equal((await admin.get(`/api/communities/${main.id}/members`)).status, 200);
  assert.equal((await admin.post(`/api/communities/${main.id}/join`)).status, 200);
  assert.ok(!(await admin.get(`/api/communities/${main.id}/members`)).body.members.some((m) => m.name === 'Site Owner')); // administrators are not participants

  // Leaving removes the row, updates the count and closes the list.
  assert.equal((await user.request('DELETE', `/api/communities/${main.id}/join`)).status, 200);
  assert.equal((await user.request('DELETE', `/api/communities/${main.id}/join`)).status, 200); // leaving twice is harmless
  assert.equal(rows(), 0);
  assert.equal(await count(), before);
  assert.equal((await user.get(`/api/communities/${main.id}/members`)).status, 403);

  // A community that is not approved cannot be joined by manipulating the request.
  const pending = db.prepare("INSERT INTO communities (name, slug, description, category, status) VALUES ('Pending Test Community', 'pending-test-community', 'Waiting for approval, so it cannot be joined.', 'Testing', 'pending')").run().lastInsertRowid;
  assert.equal((await user.post(`/api/communities/${pending}/join`)).status, 404);
  assert.equal(row('SELECT COUNT(*) AS n FROM memberships WHERE community_id = ?', pending).n, 0);
  assert.equal((await newBrowser().post(`/api/communities/${main.id}/join`)).status, 401);
});

test('discussions stay attached to their own community or subcommunity, and comments and replies still work', async () => {
  const main = commByName('Web Development');
  const sub = row('SELECT * FROM communities WHERE parent_id = ? LIMIT 1', main.id);
  const author = await memberOf('mgmt.author@example.com', 'Web Development');
  const replier = await memberOf('mgmt.replier@example.com', 'Web Development');
  const outsider = await memberOf('mgmt.outsider@example.com', null);

  const inSub = await startDiscussion(author, sub.id, 'Management test: a discussion in a subcommunity');
  const inMain = await startDiscussion(author, main.id, 'Management test: a discussion in the main community');
  assert.equal(row('SELECT community_id FROM posts WHERE id = ?', inSub).community_id, sub.id);
  assert.equal(row('SELECT community_id FROM posts WHERE id = ?', inMain).community_id, main.id);
  const subPage = (await author.get(`/api/communities/${sub.id}`)).body;
  assert.ok(subPage.recentPosts.some((p) => p.id === inSub) && !subPage.recentPosts.some((p) => p.id === inMain));
  assert.equal(subPage.community.parent.id, main.id); // the page names its main community
  const mainPage = (await author.get(`/api/communities/${main.id}`)).body;
  assert.ok(mainPage.recentPosts.some((p) => p.id === inMain) && mainPage.recentPosts.some((p) => p.id === inSub)); // the main page also lists its subcommunities' discussions
  assert.ok(mainPage.community.subcommunities.some((s) => s.id === sub.id && s.description.length > 10));

  assert.equal((await outsider.post(`/api/communities/${sub.id}/posts`, { title: 'Not a member', content: 'This should be refused for a non-member.' })).status, 403);
  const comment = (await replier.post(`/api/posts/${inSub}/comments`, { content: 'A comment from the replier.' })).body.comment.id;
  const reply = await author.post(`/api/posts/${inSub}/comments`, { content: 'A reply to that comment.', parentId: comment });
  assert.equal(reply.status, 201);
  const thread = (await author.get(`/api/posts/${inSub}`)).body.comments;
  assert.equal(thread.find((c) => c.id === reply.body.comment.id).parentId, comment);
});

test('the five test accounts and the bots are untouched by community management', async () => {
  const testers = await import('../src/db/testAccounts.js');
  const passwords = Object.fromEntries(testers.TEST_ACCOUNTS.map((a) => [a.email, `Mgmt-${a.key}-Pw-12345`]));
  testers.ensureTestAccounts(passwords); // creates them in this test database (a no-op where they exist)
  const hashes = testers.TEST_ACCOUNTS.map((a) => userRow(a.email).password_hash);
  const report = testers.ensureTestAccounts(passwords);
  assert.deepEqual([report.created.length, report.updated.length, report.unchanged.length], [0, 0, 5]); // none duplicated or changed
  assert.deepEqual(testers.TEST_ACCOUNTS.map((a) => userRow(a.email).password_hash), hashes);
  assert.equal(row("SELECT COUNT(*) AS n FROM users WHERE email IN (" + testers.TEST_ACCOUNTS.map(() => '?').join(',') + ')', ...testers.TEST_ACCOUNTS.map((a) => a.email)).n, 5);
  assert.ok(row('SELECT COUNT(*) AS n FROM users WHERE is_bot = 1').n >= 40); // the bots are all still there
});
