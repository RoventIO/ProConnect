// Part 4 tests. Every external source is MOCKED here (no internet is needed); time and timers are controlled by the tests.
// Real-source behaviour is checked separately with `npm run news:smoke` (see README).
import fs from 'node:fs';
import http from 'node:http';
import os from 'node:os';
import path from 'node:path';
import zlib from 'node:zlib';

process.env.PROCONNECT_DB = ':memory:';
process.env.JOBS_SYNC = 'off'; // tests never contact the real job sources
process.env.PROCONNECT_UPLOADS = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-news-uploads-'));
process.env.PROCONNECT_TEST_ACCOUNTS_FILE = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'pc-news-accts-')), 'accounts.json');

import test, { before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { atomFeed, BROKEN_XML, devtoResponse, DOCTYPE_XML, HTML_PAGE, hnResponse, rssFeed } from './news-fixtures.js';

const { createApp } = await import('../src/app.js');
const { startServer } = await import('../src/server.js');
const { seedDatabase, DEMO_PASSWORD } = await import('../src/db/seed.js');
const { getDb } = await import('../src/db/index.js');
const { ensureTestAccounts, TEST_ACCOUNTS } = await import('../src/db/testAccounts.js');
const { configureNewsService, getNewsService } = await import('../src/news/index.js');
const { BUILTIN_SOURCES } = await import('../src/news/sources.js');
const { NewsError, canonicalUrl, isPrivateAddress, parseFeedUrl, validateFeedUrl } = await import('../src/news/urls.js');
const { safeGet } = await import('../src/news/http.js');
const { parseFeed, parseHackerNews, parseDevTo } = await import('../src/news/parsers.js');
const { normalizeCandidate } = await import('../src/news/normalize.js');
const { DEFAULT_NEWS_IMAGE } = await import('../src/news/defaultImage.js');
const { classify, categoriesForText } = await import('../src/news/categories.js');

const H = 3_600_000;
const NOW = Date.parse('2026-10-27T12:00:00.000Z');
const ago = (hours) => NOW - hours * H;
let clock = NOW;

// ---------- mocked world: sources, DNS, timers, logger ----------
const routes = new Map(); // address -> () => response text (may be async or throw)
const fetchLog = [];
const logs = [];
const logger = { info: (m) => logs.push(`I ${m}`), warn: (m) => logs.push(`W ${m}`), error: (m) => logs.push(`E ${m}`) };
const fakeFetch = async (url) => {
  fetchLog.push(url);
  const handler = routes.get(url);
  if (!handler) throw new NewsError('network', 'The source could not be reached.');
  return { text: await handler() };
};
const HOSTS = { 'internal.example.org': ['10.0.0.5'], 'nxdomain.example.org': null };
const fakeResolve = async (host) => {
  if (host in HOSTS) {
    if (HOSTS[host] === null) throw new Error('ENOTFOUND');
    return HOSTS[host];
  }
  return ['93.184.216.34'];
};
let captured = null; // the repeating job the scheduler registered
const timers = { setIntervalFn: (fn, ms) => { captured = { fn, ms }; return { unref() {} }; }, clearIntervalFn: () => { captured = null; }, now: () => clock };
const until = async (cond, ms = 3000) => {
  const t = Date.now();
  while (!cond()) {
    if (Date.now() - t > ms) throw new Error('condition not reached in time');
    await new Promise((r) => setTimeout(r, 5));
  }
};

const U = { tc: BUILTIN_SOURCES[0].url, ars: BUILTIN_SOURCES[1].url, hn: BUILTIN_SOURCES[2].url, dev: BUILTIN_SOURCES[3].url };
const TC_ITEMS = () => [
  { id: 'https://techcrunch.com/?p=101', title: 'OpenAI ships a new reasoning model', link: 'https://techcrunch.com/2026/10/27/openai-ships-model/', at: ago(2), tags: ['AI'], image: 'https://techcrunch.com/wp-content/uploads/a.jpg', creator: 'Ann', html: '<p>Hello <b>world</b> &amp; friends.</p><p>The post <a href="https://x.example/">T</a> appeared first on TechCrunch.</p>' },
  { id: 'https://techcrunch.com/?p=102', title: 'Hackers steal customer data in major breach', link: 'https://techcrunch.com/2026/10/27/breach/', at: ago(5), tags: ['Security'] },
  { id: 'https://techcrunch.com/?p=103', title: 'Acme raises $20 million Series A to build robots', link: 'https://techcrunch.com/2026/10/26/acme/', at: ago(30), tags: ['Startups'] },
];
function standardRoutes() {
  routes.clear();
  routes.set(U.tc, () => rssFeed('TechCrunch', TC_ITEMS()));
  routes.set(U.ars, () => rssFeed('Ars Technica', [
    { id: 'https://arstechnica.com/?p=201', title: 'Rust 2.0 lands with a new compiler for developers', link: 'https://arstechnica.com/gadgets/2026/10/rust/', at: ago(8), tags: ['Technology Lab'], html: '<p>x</p><img src="https://cdn.arstechnica.net/wp-content/uploads/2026/10/rust.jpg" width="640">' },
    { id: 'https://arstechnica.com/?p=202', title: 'A new phone, reviewed', link: 'https://arstechnica.com/gadgets/2026/10/phone/', at: ago(20), tags: ['Gadgets'] },
  ]));
  routes.set(U.hn, () => hnResponse([
    { id: 9001, title: 'Show HN: A tiny database in Rust', url: 'https://www.example.com/tiny-db?utm_source=hn', at: ago(1) },
    { id: 9002, title: 'Ask HN: How do you stay focused?', url: null, at: ago(3), story_text: '<p>Long text &amp; thoughts</p>' },
    { id: 9003, title: 'Old story from last week', url: 'https://old.example.net/x', at: ago(100) },
  ]));
  routes.set(U.dev, () => devtoResponse([
    { id: 7001, title: 'Getting started with TypeScript generics', url: 'https://dev.to/jane/ts-generics-abc', at: ago(4), tags: ['typescript', 'webdev'], cover: 'https://media2.dev.to/cover1.png' },
    { id: 7002, title: 'Why I moved my blog', url: 'https://dev.to/jane/moved-xyz', canonical: 'https://jane.example.dev/moved', at: ago(6), tags: ['career'] },
  ]));
}

// ---------- tiny browser ----------
let base;
let server;
function browser(baseUrl = () => base) {
  let cookie = '';
  const request = async (method, p, body) => {
    const res = await fetch(baseUrl() + p, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
    const set = res.headers.getSetCookie().map((c) => c.split(';')[0]).find((c) => c.startsWith('pc_token='));
    if (set) cookie = set === 'pc_token=' ? '' : set;
    return { status: res.status, body: await res.json() };
  };
  return { get: (p) => request('GET', p), post: (p, d) => request('POST', p, d), put: (p, d) => request('PUT', p, d), del: (p) => request('DELETE', p), request };
}
async function signIn(email, baseUrl) {
  const b = browser(baseUrl);
  const r = await b.post('/api/auth/login', { email, password: DEMO_PASSWORD });
  assert.equal(r.status, 200, `sign in as ${email}`);
  return b;
}
const asAdmin = (baseUrl) => signIn('admin@proconnect.example', baseUrl);
const asMember = (baseUrl) => signIn('alex.morgan@example.com', baseUrl);

const db = () => getDb();
const articleCount = () => db().prepare('SELECT COUNT(*) AS n FROM news_articles').get().n;
const titles = () => db().prepare('SELECT title FROM news_articles ORDER BY retention_at DESC, id DESC').all().map((r) => r.title);
const sourceId = (key) => db().prepare('SELECT id FROM news_sources WHERE key = ?').get(key).id;

function insertArticle({ key = 'techcrunch', ext, url, title = 'Stored article', publishedAt = null, ingestedAt = new Date(clock).toISOString() }) {
  const sid = sourceId(key);
  return Number(db().prepare(
    `INSERT INTO news_articles (source_id, external_id, url, url_key, title, categories, published_at, ingested_at, retention_at)
     VALUES (?, ?, ?, ?, ?, '["ai"]', ?, ?, ?)`
  ).run(sid, ext, url, canonicalUrl(url), title, publishedAt, ingestedAt, publishedAt ?? ingestedAt).lastInsertRowid);
}

let service;
before(async () => {
  seedDatabase();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server.close());
beforeEach(() => {
  clock = NOW;
  logs.length = 0;
  fetchLog.length = 0;
  captured = null;
  db().exec('DELETE FROM news_articles');
  db().exec("DELETE FROM news_sources WHERE is_builtin = 0");
  db().exec("UPDATE news_sources SET enabled = 1, last_sync_at = NULL, last_status = NULL, last_message = NULL, last_fetched = NULL, last_inserted = NULL");
  db().exec('DELETE FROM news_interests');
  standardRoutes();
  service = configureNewsService({ fetchText: fakeFetch, now: () => clock, logger, resolveHost: fakeResolve });
});

// =====================================================================================
// 1. Parsing and normalization of each source format
// =====================================================================================
test('RSS (TechCrunch/Ars style): fields are extracted and cleaned', () => {
  const items = parseFeed(rssFeed('TechCrunch', TC_ITEMS()), { publisher: 'TechCrunch' });
  assert.equal(items.length, 3);
  const n = normalizeCandidate(items[0], { nowMs: NOW, retentionMs: 72 * H });
  assert.ok(n.ok);
  const a = n.article;
  assert.equal(a.title, 'OpenAI ships a new reasoning model');
  assert.equal(a.url, 'https://techcrunch.com/2026/10/27/openai-ships-model/');
  assert.equal(a.externalId, 'https://techcrunch.com/?p=101');
  assert.equal(a.publisher, 'TechCrunch');
  assert.equal(a.publishedAt, new Date(ago(2)).toISOString());
  assert.equal(a.retentionAt, a.publishedAt);
  assert.equal(a.imageUrl, 'https://techcrunch.com/wp-content/uploads/a.jpg');
  assert.ok(a.summary.startsWith('Hello world & friends.'));
  assert.ok(!/[<>]/.test(a.summary));
  assert.deepEqual(a.tags, ['AI']);
  assert.deepEqual(a.categories, ['ai']);
});

test('RSS: image falls back to the first <img> in the description; Atom entries are supported', () => {
  const [ars] = parseFeed(rssFeed('Ars', [{ id: 'g1', title: 'Rust compiler news', link: 'https://arstechnica.com/a/', at: ago(1), html: '<p>x</p><img src="https://cdn.example.net/p.jpg" width="640"><img src="https://t.example.net/px.gif" width="1" height="1">' }]), { publisher: 'Ars' });
  assert.equal(ars.imageUrl, 'https://cdn.example.net/p.jpg');
  const atom = parseFeed(atomFeed([{ id: 'tag:example.org,2026:1', title: 'Atom & friends', link: 'https://example.org/atom-1', at: ago(2), tag: 'security' }]), { publisher: 'Example' });
  assert.equal(atom.length, 1);
  assert.equal(atom[0].url, 'https://example.org/atom-1'); // rel="alternate", not rel="self"
  assert.deepEqual(atom[0].tags, ['security']);
  const n = normalizeCandidate(atom[0], { nowMs: NOW, retentionMs: 72 * H });
  assert.ok(n.ok);
  assert.equal(n.article.title, 'Atom & friends');
});

test('Hacker News (Algolia): link, publisher and a factual summary; Ask HN falls back to the discussion link', () => {
  const items = parseHackerNews(hnResponse([{ id: 1, title: 'Show HN: Thing', url: 'https://www.example.com/thing', at: ago(1), points: 321, comments: 45 }, { id: 2, title: 'Ask HN: Why?', url: null, at: ago(2) }]));
  const a = normalizeCandidate(items[0], { nowMs: NOW, retentionMs: 72 * H }).article;
  assert.equal(a.publisher, 'example.com');
  assert.equal(a.summary, '321 points · 45 comments on Hacker News');
  assert.equal(a.externalId, '1');
  const b = normalizeCandidate(items[1], { nowMs: NOW, retentionMs: 72 * H }).article;
  assert.equal(b.url, 'https://news.ycombinator.com/item?id=2');
  assert.equal(b.publisher, 'Hacker News');
});

test('DEV.to: canonical URL, publisher, tags and cover image', () => {
  const items = parseDevTo(devtoResponse([{ id: 5, title: 'Cross-posted article', url: 'https://dev.to/a/x', canonical: 'https://blog.example.dev/x', at: ago(1), tags: ['webdev', 'javascript'], cover: 'https://media2.dev.to/c.png' }, { id: 6, title: 'Native article', url: 'https://dev.to/a/y', at: ago(1) }]));
  const a = normalizeCandidate(items[0], { nowMs: NOW, retentionMs: 72 * H }).article;
  assert.equal(a.url, 'https://blog.example.dev/x');
  assert.equal(a.publisher, 'blog.example.dev');
  assert.deepEqual(a.tags, ['webdev', 'javascript']);
  assert.equal(a.imageUrl, 'https://media2.dev.to/c.png');
  assert.equal(normalizeCandidate(items[1], { nowMs: NOW, retentionMs: 72 * H }).article.publisher, 'DEV Community');
});

test('malformed responses are rejected with a clear parse error', () => {
  assert.throws(() => parseFeed(HTML_PAGE, { publisher: 'x' }), /web page/);
  assert.throws(() => parseFeed(BROKEN_XML, { publisher: 'x' }), (e) => e instanceof NewsError && e.kind === 'parse');
  assert.throws(() => parseFeed(DOCTYPE_XML, { publisher: 'x' }), /document type/);
  assert.throws(() => parseFeed('{"not":"xml"}', { publisher: 'x' }), (e) => e.kind === 'parse');
  assert.throws(() => parseHackerNews('<html>'), (e) => e.kind === 'parse');
  assert.throws(() => parseHackerNews('{"hits":"nope"}'), (e) => e.kind === 'parse');
  assert.throws(() => parseDevTo('{"error":"rate limited"}'), (e) => e.kind === 'parse');
});

test('normalization: invalid entries, unsafe links, unreliable dates, expired articles', () => {
  const ctx = { nowMs: NOW, retentionMs: 72 * H };
  const base = { externalId: 'a', url: 'https://example.com/a', title: 'A valid title', summaryHtml: '', tags: [], publishedAt: new Date(ago(1)).toISOString() };
  assert.equal(normalizeCandidate({ ...base, title: '  ' }, ctx).ok, false);
  assert.equal(normalizeCandidate({ ...base, url: 'javascript:alert(1)' }, ctx).ok, false);
  assert.equal(normalizeCandidate({ ...base, url: null }, ctx).ok, false);
  assert.equal(normalizeCandidate({ ...base, url: 'https://user:pw@example.com/a' }, ctx).ok, false);
  const future = normalizeCandidate({ ...base, publishedAt: new Date(NOW + 48 * H).toISOString() }, ctx).article;
  assert.equal(future.publishedAt, null, 'a date in the future is not reliable');
  assert.equal(future.retentionAt, future.ingestedAt, 'ingestion time is used instead');
  assert.equal(normalizeCandidate({ ...base, publishedAt: 'not a date' }, ctx).article.publishedAt, null);
  const old = normalizeCandidate({ ...base, publishedAt: new Date(ago(73)).toISOString() }, ctx);
  assert.deepEqual([old.ok, old.reason], [false, 'expired']);
  assert.equal(normalizeCandidate({ ...base, imageUrl: 'http://example.com/i.jpg' }, ctx).article.imageUrl, DEFAULT_NEWS_IMAGE, 'plain-http images cannot be shown, so the local default is used');
  assert.equal(normalizeCandidate({ ...base, title: '<b>Bold</b> &amp; plain' }, ctx).article.title, 'Bold & plain');
});

test('categories: source tags, title keywords and transparent reasons; no category on weak evidence', () => {
  assert.deepEqual(classify({ title: 'OpenAI ships a new model' }).categories, ['ai']);
  assert.match(classify({ title: 'OpenAI ships a new model' }).basis.ai, /OpenAI/);
  assert.deepEqual(classify({ title: 'Quarterly results', tags: ['Security'] }).categories, ['cybersecurity']);
  assert.deepEqual(classify({ title: 'Local bakery opens', summary: 'Fresh bread every day.' }).categories, []);
  assert.deepEqual(classify({ title: 'Weekend plans', summary: 'A nice AI-powered toaster.' }).categories, [], 'a single summary keyword is not enough');
  assert.deepEqual(categoriesForText('Cybersecurity'), ['cybersecurity']);
  assert.deepEqual(categoriesForText('Web Development'), ['programming']);
});

// =====================================================================================
// 2. Address safety (SSRF) and the guarded HTTP client
// =====================================================================================
test('unsafe or invalid feed addresses are rejected before any request is made', async () => {
  for (const bad of [
    'file:///etc/passwd', 'ftp://example.com/feed', 'javascript:alert(1)', 'data:text/xml,<rss/>', 'not a url', '',
    'http://localhost/feed', 'http://127.0.0.1/feed', 'http://127.1/feed', 'http://2130706433/feed', 'http://0x7f.0.0.1/feed',
    'http://10.0.0.1/rss', 'http://172.16.5.4/rss', 'http://192.168.1.1/rss', 'http://169.254.169.254/latest/meta-data/',
    'http://100.64.0.1/x', 'http://[::1]/feed', 'http://[::ffff:127.0.0.1]/feed', 'http://[fd00::1]/feed', 'http://[fe80::1]/feed',
    'https://user:secret@example.com/feed', 'https://example.com:8443/feed', 'http://intranet/feed', 'https://printer.local/feed', 'https://db.internal/feed',
  ]) {
    assert.throws(() => parseFeedUrl(bad), (e) => e instanceof NewsError, `should reject ${bad}`);
  }
  assert.equal(parseFeedUrl('https://example.com/feed.xml').hostname, 'example.com');
  assert.equal(isPrivateAddress('93.184.216.34'), false);
  assert.equal(isPrivateAddress('2606:2800:220:1:248:1893:25c8:1946'), false);
  assert.equal(isPrivateAddress('::ffff:10.0.0.1'), true);
  assert.equal(isPrivateAddress('64:ff9b::7f00:1'), true);
  await assert.rejects(() => validateFeedUrl('https://internal.example.org/feed', { resolve: fakeResolve }), (e) => e.kind === 'blocked', 'a public-looking name that resolves to a private address');
  await assert.rejects(() => validateFeedUrl('https://nxdomain.example.org/feed', { resolve: fakeResolve }), (e) => e.kind === 'invalid_url');
  assert.equal(await validateFeedUrl('https://feeds.example.org/rss#frag', { resolve: fakeResolve }), 'https://feeds.example.org/rss');
});

test('canonical URLs ignore tracking parameters, www, fragments and trailing slashes', () => {
  const k = canonicalUrl('https://www.Example.com/a/b/?utm_source=x&id=2&fbclid=z#top');
  assert.equal(k, 'example.com/a/b?id=2');
  assert.equal(canonicalUrl('http://example.com/a/b?id=2'), k);
  assert.notEqual(canonicalUrl('https://example.com/a/c?id=2'), k);
});

test('safeGet: success, gzip, HTTP errors, timeout, size limit, redirects, and local addresses blocked by default', async () => {
  const srv = http.createServer((req, res) => {
    if (req.url === '/ok') return res.end('hello');
    if (req.url === '/gz') { res.setHeader('Content-Encoding', 'gzip'); return res.end(zlib.gzipSync('zipped hello')); }
    if (req.url === '/404') { res.statusCode = 404; return res.end('no'); }
    if (req.url === '/slow') return undefined; // never answers
    if (req.url === '/big') return res.end(Buffer.alloc(3 * 1024 * 1024, 97));
    if (req.url === '/r') { res.statusCode = 302; res.setHeader('Location', '/ok'); return res.end(); }
    if (req.url.startsWith('/loop')) { res.statusCode = 302; res.setHeader('Location', `/loop${Number(req.url.slice(5)) + 1}`); return res.end(); }
    return res.end('?');
  });
  await new Promise((r) => srv.listen(0, '127.0.0.1', r));
  const root = `http://127.0.0.1:${srv.address().port}`;
  const opt = { allowPrivate: true, timeoutMs: 400, maxBytes: 1024 * 1024 };
  try {
    assert.equal((await safeGet(`${root}/ok`, opt)).text, 'hello');
    assert.equal((await safeGet(`${root}/gz`, opt)).text, 'zipped hello');
    assert.equal((await safeGet(`${root}/r`, opt)).text, 'hello');
    await assert.rejects(() => safeGet(`${root}/404`, opt), (e) => e.kind === 'http' && /404/.test(e.message));
    await assert.rejects(() => safeGet(`${root}/slow`, opt), (e) => e.kind === 'timeout');
    await assert.rejects(() => safeGet(`${root}/big`, opt), (e) => e.kind === 'too_large');
    await assert.rejects(() => safeGet(`${root}/loop0`, opt), /redirects/);
    await assert.rejects(() => safeGet(`${root}/ok`, { timeoutMs: 400 }), (e) => e.kind === 'blocked', 'private/local targets are refused unless a test opts in');
    await assert.rejects(() => safeGet('http://127.0.0.1:1/x', { allowPrivate: true, timeoutMs: 400 }), (e) => e.kind === 'network');
  } finally {
    srv.closeAllConnections?.();
    srv.close();
  }
});

// =====================================================================================
// 3. Synchronization: storage, normalization, duplicates
// =====================================================================================
test('a synchronization stores normalized articles from every source and the News API returns them', async () => {
  const summary = await service.run('test');
  assert.equal(summary.sources.length, 4);
  assert.ok(summary.sources.every((s) => s.status === 'ok'), JSON.stringify(summary.sources));
  assert.equal(articleCount(), 9);
  assert.equal(summary.totals.inserted, 9);
  assert.equal(summary.totals.skipped, 1, 'the 100-hour-old Hacker News story is not stored');
  assert.ok(!titles().includes('Old story from last week'));

  const row = db().prepare("SELECT a.*, s.name AS source FROM news_articles a JOIN news_sources s ON s.id = a.source_id WHERE a.external_id = 'https://techcrunch.com/?p=101'").get();
  assert.equal(row.source, 'TechCrunch');
  assert.equal(row.publisher, 'TechCrunch');
  assert.equal(row.ingested_at, new Date(NOW).toISOString());
  assert.equal(row.published_at, new Date(ago(2)).toISOString());
  assert.equal(row.summary.includes('<'), false);
  assert.ok(row.url.startsWith('https://techcrunch.com/'));

  const member = await asMember();
  const r = await member.get('/api/news?limit=50');
  assert.equal(r.status, 200);
  assert.equal(r.body.total, 9);
  assert.equal(r.body.articles.length, 9);
  assert.equal(r.body.retentionHours, 72);
  const newest = r.body.articles[0];
  assert.equal(newest.title, 'Show HN: A tiny database in Rust', 'newest first');
  assert.equal(newest.source.name, 'Hacker News');
  assert.equal(newest.publisher, 'example.com');
  assert.equal(newest.url, 'https://www.example.com/tiny-db?utm_source=hn', 'the link points at the original article');
  const dev = r.body.articles.find((a) => a.title === 'Why I moved my blog');
  assert.equal(dev.publisher, 'jane.example.dev');
  assert.equal(dev.url, 'https://jane.example.dev/moved');
  const ai = r.body.articles.find((a) => a.title.startsWith('OpenAI'));
  assert.equal(ai.imageUrl, 'https://techcrunch.com/wp-content/uploads/a.jpg');
  assert.deepEqual(ai.categories.map((c) => c.key), ['ai']);
  assert.match(ai.categories[0].basis, /source tag "ai"/);
  assert.ok(r.body.sync.lastSyncAt && r.body.sync.failedSources.length === 0);
  const noExtras = Object.keys(ai).sort().join();
  assert.ok(!/password|email/i.test(JSON.stringify(r.body)), 'no private data in the feed');
  assert.ok(noExtras.includes('publishedAt'));
});

test('repeated synchronization never inserts duplicates; changed metadata is refreshed without touching dates', async () => {
  await service.run('first');
  const before = db().prepare('SELECT id, published_at, ingested_at, url FROM news_articles ORDER BY id').all();
  const again = await service.run('second');
  assert.equal(again.totals.inserted, 0);
  assert.equal(articleCount(), 9);

  clock += 2 * H;
  const items = TC_ITEMS();
  items[0].title = 'OpenAI ships a new reasoning model (updated)';
  routes.set(U.tc, () => rssFeed('TechCrunch', items));
  const third = await service.run('third');
  assert.equal(third.totals.inserted, 0);
  assert.equal(third.totals.updated, 1);
  assert.equal(articleCount(), 9);
  const row = db().prepare("SELECT title, published_at, ingested_at, url FROM news_articles WHERE external_id = 'https://techcrunch.com/?p=101'").get();
  assert.equal(row.title, 'OpenAI ships a new reasoning model (updated)');
  const old = before.find((b) => b.url === row.url);
  assert.equal(row.published_at, old.published_at);
  assert.equal(row.ingested_at, old.ingested_at);
});

test('the same article reached through two sources is stored once; similar titles alone are not duplicates', async () => {
  routes.set(U.hn, () => hnResponse([
    { id: 1, title: 'OpenAI ships a new reasoning model', url: 'https://www.techcrunch.com/2026/10/27/openai-ships-model/?utm_source=hn#comments', at: ago(1) }, // same article as TechCrunch #101
    { id: 2, title: 'Hackers steal customer data in major breach', url: 'https://other.example.net/different-story', at: ago(1) }, // same title, different article
  ]));
  const s = await service.run('dupes');
  assert.equal(articleCount(), 3 + 2 + 1 + 2, 'TechCrunch 3 + Ars 2 + HN 1 (the other is a duplicate URL) + DEV 2');
  assert.equal(titles().filter((t) => t === 'Hackers steal customer data in major breach').length, 2);
  assert.equal(s.sources.find((x) => x.name === 'Hacker News').inserted, 1);
});

test('the database itself refuses duplicates (unique constraints)', async () => {
  await service.run('x');
  const tc = sourceId('techcrunch');
  assert.throws(() => insertArticle({ ext: 'https://techcrunch.com/?p=101', url: 'https://techcrunch.com/other-url/' }), /UNIQUE/);
  assert.throws(() => insertArticle({ key: 'devto', ext: 'brand-new-id', url: 'https://techcrunch.com/2026/10/27/breach/?utm_campaign=z' }), /UNIQUE/);
  assert.ok(tc > 0);
});

test('invalid entries are skipped, valid ones in the same feed are still stored', async () => {
  routes.set(U.tc, () => rssFeed('TechCrunch', [...TC_ITEMS().slice(0, 1), { id: 'bad1', title: 'No link here', link: '', at: ago(1) }, { id: 'bad2', title: '', link: 'https://techcrunch.com/x/', at: ago(1) }]));
  const s = await service.run('partial');
  const tc = s.sources.find((x) => x.name === 'TechCrunch');
  assert.equal(tc.status, 'ok');
  assert.equal(tc.inserted, 1);
  assert.equal(tc.invalid, 2);
});

// =====================================================================================
// 4. Failures of external sources
// =====================================================================================
test('one failing source does not stop the others, and its failure is recorded', async () => {
  routes.set(U.tc, () => { throw new NewsError('timeout', 'No complete answer within 10 s.'); });
  const s = await service.run('one-fails');
  const byName = Object.fromEntries(s.sources.map((x) => [x.name, x]));
  assert.equal(byName.TechCrunch.status, 'error');
  assert.equal(byName['Ars Technica'].status, 'ok');
  assert.equal(byName['Hacker News'].status, 'ok');
  assert.equal(byName['DEV Community'].status, 'ok');
  assert.equal(articleCount(), 6);
  const row = db().prepare("SELECT last_status, last_message FROM news_sources WHERE key = 'techcrunch'").get();
  assert.equal(row.last_status, 'error');
  assert.match(row.last_message, /No complete answer/);
  assert.ok(logs.some((l) => l.startsWith('W source "TechCrunch": FAILED')));
  assert.ok(logs.some((l) => /source "Ars Technica": ok, fetched=2 inserted=2/.test(l)));
  const r = await (await asMember()).get('/api/news');
  assert.deepEqual(r.body.sync.failedSources, ['TechCrunch']);
  assert.equal(r.body.total, 6);
});

test('an unexpected exception inside one source is contained too', async () => {
  routes.set(U.ars, () => { throw new TypeError('boom with /secret/path'); });
  const s = await service.run('exception');
  assert.equal(s.sources.find((x) => x.name === 'Ars Technica').status, 'error');
  assert.ok(!JSON.stringify(s).includes('/secret/path'), 'internal details are not stored or returned');
  assert.equal(articleCount(), 7);
});

test('wrong content types and malformed bodies are handled as source failures', async () => {
  routes.set(U.tc, () => HTML_PAGE);
  routes.set(U.ars, () => BROKEN_XML);
  routes.set(U.hn, () => HTML_PAGE);
  routes.set(U.dev, () => '{"error":"rate limited"}');
  const s = await service.run('malformed');
  assert.ok(s.sources.every((x) => x.status === 'error'));
  assert.equal(articleCount(), 0);
  assert.equal(s.finishedAt !== null, true);
});

test('cleanup still runs and stored articles stay available when every external source fails', async () => {
  insertArticle({ ext: 'old', url: 'https://example.net/old', title: 'Too old', publishedAt: new Date(ago(80)).toISOString() });
  insertArticle({ ext: 'fresh', url: 'https://example.net/fresh', title: 'Still fresh', publishedAt: new Date(ago(10)).toISOString() });
  routes.clear(); // every request fails with a network error
  const s = await service.run('offline');
  assert.ok(s.sources.every((x) => x.status === 'error') && s.sources.length === 4);
  assert.equal(s.deleted, 1);
  assert.deepEqual(titles(), ['Still fresh']);
  const r = await (await asMember()).get('/api/news');
  assert.deepEqual(r.body.articles.map((a) => a.title), ['Still fresh']);
  assert.equal(r.body.sync.failedSources.length, 4);
});

// =====================================================================================
// 5. 72-hour retention
// =====================================================================================
test('articles older than 72 hours are deleted; newer ones and unrelated data remain', () => {
  const before = { users: db().prepare('SELECT COUNT(*) AS n FROM users').get().n, communities: db().prepare('SELECT COUNT(*) AS n FROM communities').get().n, posts: db().prepare('SELECT COUNT(*) AS n FROM posts').get().n, comments: db().prepare('SELECT COUNT(*) AS n FROM comments').get().n };
  const iso = (h) => new Date(ago(h)).toISOString();
  insertArticle({ ext: 'a', url: 'https://e.example/a', title: '10 h', publishedAt: iso(10) });
  insertArticle({ ext: 'b', url: 'https://e.example/b', title: '71.9 h', publishedAt: iso(71.9) });
  insertArticle({ ext: 'c', url: 'https://e.example/c', title: 'exactly 72 h', publishedAt: iso(72) });
  insertArticle({ ext: 'd', url: 'https://e.example/d', title: '72.1 h', publishedAt: iso(72.1) });
  insertArticle({ ext: 'e', url: 'https://e.example/e', title: '200 h', publishedAt: iso(200) });
  const result = service.cleanup();
  assert.equal(result.deleted, 2);
  assert.deepEqual(titles().sort(), ['10 h', '71.9 h', 'exactly 72 h'].sort());
  const after = { users: db().prepare('SELECT COUNT(*) AS n FROM users').get().n, communities: db().prepare('SELECT COUNT(*) AS n FROM communities').get().n, posts: db().prepare('SELECT COUNT(*) AS n FROM posts').get().n, comments: db().prepare('SELECT COUNT(*) AS n FROM comments').get().n };
  assert.deepEqual(after, before);
});

test('without a publication date the ingestion time decides, and the cutoff moves with the clock', () => {
  insertArticle({ ext: 'u', url: 'https://e.example/u', title: 'Undated', publishedAt: null, ingestedAt: new Date(NOW).toISOString() });
  clock = NOW + 71 * H;
  assert.equal(service.cleanup().deleted, 0);
  clock = NOW + 73 * H;
  assert.equal(service.cleanup().deleted, 1);
  assert.equal(articleCount(), 0);
});

test('the feed hides expired articles even before the next cleanup runs', async () => {
  insertArticle({ ext: 'x', url: 'https://e.example/x', title: 'Fresh', publishedAt: new Date(ago(1)).toISOString() });
  clock = NOW + 72.5 * H; // Fresh is now 73.5 h old but cleanup has not run yet
  const r = await (await asMember()).get('/api/news');
  assert.equal(r.body.total, 0);
  assert.equal(articleCount(), 1, 'still physically stored until cleanup runs');
});

// =====================================================================================
// 6. Startup, scheduler, overlap, restart
// =====================================================================================
test('starting the server runs cleanup and an immediate synchronization without waiting for the sources', async () => {
  insertArticle({ ext: 'old', url: 'https://e.example/old', title: 'Expired before start', publishedAt: new Date(ago(90)).toISOString() });
  let release;
  const gate = new Promise((r) => { release = r; });
  routes.set(U.tc, async () => { await gate; return rssFeed('TechCrunch', TC_ITEMS()); }); // a slow source
  const started = await startServer({ port: 0, news: { timers } });
  const url = () => `http://127.0.0.1:${started.server.address().port}`;
  try {
    // the API already answers while the first synchronization is still waiting on a source
    const health = await fetch(`${url()}/api/health`);
    assert.equal(health.status, 200);
    await until(() => fetchLog.includes(U.tc));
    assert.equal(started.scheduler.status().running, true);
    assert.deepEqual(titles(), [], 'expired-news cleanup ran first, at startup');
    release();
    await started.scheduler.initialRun;

    assert.equal(captured.ms, 120 * 60_000, 'a repeating job every 120 minutes is registered');
    assert.equal(started.scheduler.status().nextRunAt, new Date(NOW + 120 * 60_000).toISOString());
    assert.equal(articleCount(), 9);
    const cleanupAt = logs.findIndex((l) => l.includes('cleanup: deleted 1'));
    const firstSource = logs.findIndex((l) => l.includes('source "TechCrunch"'));
    assert.ok(logs.some((l) => l.includes('scheduler registered: every 120 minutes')));
    assert.ok(logs.some((l) => l.includes('sync started (reason: startup)')));
    assert.ok(cleanupAt >= 0 && cleanupAt < firstSource, 'cleanup is logged before any source is processed');
    assert.ok(logs.some((l) => /sync finished \(startup\): sources ok=4 failed=0, fetched=9 inserted=9 skipped=1 deleted=1/.test(l)));

    // the Admin can see that the job is registered
    const admin = await asAdmin(url);
    const st = await admin.get('/api/admin/news/status');
    assert.equal(st.status, 200);
    assert.equal(st.body.scheduler.registered, true);
    assert.equal(st.body.scheduler.intervalMinutes, 120);
    assert.equal(st.body.lastRun.reason, 'startup');
    assert.equal(st.body.retentionHours, 72);
  } finally {
    release();
    started.scheduler.stop();
    await new Promise((r) => started.server.close(r));
  }
});

test('the 120-minute job runs a full synchronization with cleanup and reschedules itself 120 minutes later', async () => {
  const started = await startServer({ port: 0, news: { timers } });
  try {
    await started.scheduler.initialRun;
    assert.equal(articleCount(), 9);
    insertArticle({ ext: 'ages', url: 'https://e.example/ages', title: 'About to expire', publishedAt: new Date(ago(70.5)).toISOString() });
    const newItems = [...TC_ITEMS(), { id: 'https://techcrunch.com/?p=104', title: 'Brand new startup funding round announced', link: 'https://techcrunch.com/2026/10/27/new/', at: NOW + 119 * 60_000, tags: ['Startups'] }];
    routes.set(U.tc, () => rssFeed('TechCrunch', newItems));

    clock = NOW + 120 * 60_000; // two hours later
    captured.fn(); // the timer fires
    await until(() => service.lastRun()?.reason === 'scheduled' && !service.isRunning());
    assert.equal(started.scheduler.status().nextRunAt, new Date(NOW + 240 * 60_000).toISOString());
    assert.ok(titles().includes('Brand new startup funding round announced'), 'new article inserted');
    assert.ok(!titles().includes('About to expire'), 'it is now 72 h old: deleted by the scheduled cleanup');
    assert.equal(service.lastRun().deleted >= 1, true);

    clock = NOW + 240 * 60_000;
    captured.fn();
    await until(() => service.lastRun().startedAt === new Date(clock).toISOString() && !service.isRunning());
    assert.equal(started.scheduler.status().nextRunAt, new Date(NOW + 360 * 60_000).toISOString());
  } finally {
    started.scheduler.stop();
    await new Promise((r) => started.server.close(r));
  }
});

test('scheduled runs never overlap: a tick during a running synchronization starts nothing', async () => {
  let release;
  const gate = new Promise((r) => { release = r; });
  routes.set(U.tc, async () => { await gate; return rssFeed('TechCrunch', TC_ITEMS()); });
  const started = await startServer({ port: 0, news: { timers } });
  try {
    await until(() => fetchLog.includes(U.tc));
    captured.fn(); // timer fires while the startup run is still waiting
    captured.fn();
    await new Promise((r) => setTimeout(r, 30));
    assert.equal(fetchLog.filter((u) => u === U.tc).length, 1, 'only one request was made');
    assert.equal(logs.filter((l) => l.includes('skipped: the previous synchronization is still running')).length, 2);
    release();
    await started.scheduler.initialRun;
    assert.equal(articleCount(), 9);
    assert.equal(fetchLog.filter((u) => u === U.dev).length, 1);
  } finally {
    release();
    started.scheduler.stop();
    await new Promise((r) => started.server.close(r));
  }
});

test('restarting after downtime synchronizes and cleans up again, without replaying missed runs', async () => {
  const first = await startServer({ port: 0, news: { timers } });
  await first.scheduler.initialRun;
  assert.equal(articleCount(), 9);
  first.scheduler.stop();
  await new Promise((r) => first.server.close(r));

  // the server stays off for 11 hours (five missed two-hour slots); meanwhile the feeds moved on
  clock = NOW + 11 * H;
  fetchLog.length = 0;
  logs.length = 0;
  const items = [{ id: 'https://techcrunch.com/?p=900', title: 'Fresh AI funding story after downtime', link: 'https://techcrunch.com/2026/10/27/fresh/', at: clock - 1 * H, tags: ['AI'] }];
  routes.set(U.tc, () => rssFeed('TechCrunch', items));
  insertArticle({ ext: 'wasfresh', url: 'https://e.example/wasfresh', title: 'Aged during downtime', publishedAt: new Date(NOW - 65 * H).toISOString() }); // 76 h old at restart

  const second = await startServer({ port: 0, news: { timers } });
  try {
    await second.scheduler.initialRun;
    assert.equal(logs.filter((l) => l.includes('sync started')).length, 1, 'exactly one synchronization, not five');
    assert.equal(fetchLog.filter((u) => u === U.tc).length, 1);
    assert.ok(titles().includes('Fresh AI funding story after downtime'));
    assert.ok(!titles().includes('Aged during downtime'), 'cleanup ran again at startup');
    assert.equal(second.scheduler.status().nextRunAt, new Date(clock + 120 * 60_000).toISOString(), 'the normal schedule resumes from the restart');
  } finally {
    second.scheduler.stop();
    await new Promise((r) => second.server.close(r));
  }
});

// =====================================================================================
// 7. News API: access, categories, personalization, pagination, disabled sources
// =====================================================================================
test('the News API needs a signed-in member; visitors get 401', async () => {
  assert.equal((await browser().get('/api/news')).status, 401);
  assert.equal((await browser().get('/api/news/interests')).status, 401);
});

test('category tabs filter articles; unknown categories are rejected; pagination works', async () => {
  await service.run('tabs');
  const m = await asMember();
  const ai = await m.get('/api/news?category=ai');
  assert.deepEqual(ai.body.articles.map((a) => a.title), ['OpenAI ships a new reasoning model']);
  const sec = await m.get('/api/news?category=cybersecurity');
  assert.deepEqual(sec.body.articles.map((a) => a.title), ['Hackers steal customer data in major breach']);
  const startups = await m.get('/api/news?category=startups');
  assert.deepEqual(startups.body.articles.map((a) => a.title), ['Acme raises $20 million Series A to build robots']);
  const prog = await m.get('/api/news?category=programming');
  assert.ok(prog.body.articles.length >= 3 && prog.body.articles.every((a) => a.categories.some((c) => c.key === 'programming')));
  assert.equal((await m.get('/api/news?category=nonsense')).status, 400);
  const p1 = await m.get('/api/news?limit=4&offset=0');
  const p2 = await m.get('/api/news?limit=4&offset=4');
  assert.equal(p1.body.hasMore, true);
  assert.equal(p1.body.articles.length, 4);
  assert.equal(new Set([...p1.body.articles, ...p2.body.articles].map((a) => a.id)).size, 8);
  const p3 = await m.get('/api/news?limit=4&offset=8');
  assert.equal(p3.body.articles.length, 1);
  assert.equal(p3.body.hasMore, false);
});

test('"For you" uses the member\'s joined communities and chosen topics, and only their own data', async () => {
  await service.run('foryou');
  const m = await asMember();
  const me = db().prepare("SELECT id FROM users WHERE email = 'alex.morgan@example.com'").get().id;
  db().prepare('DELETE FROM memberships WHERE user_id = ?').run(me);
  let r = await m.get('/api/news?category=for-you');
  assert.equal(r.body.total, 0);
  assert.deepEqual(r.body.recommendation.categories, []);

  const sd = db().prepare("SELECT id FROM communities WHERE name = 'Software Development'").get().id;
  db().prepare('INSERT OR IGNORE INTO memberships (user_id, community_id) VALUES (?, ?)').run(me, sd);
  r = await m.get('/api/news?category=for-you');
  assert.deepEqual(r.body.recommendation.categories, ['programming']);
  assert.deepEqual(r.body.recommendation.fromCommunities, [{ category: 'programming', label: 'Programming', communities: ['Software Development'] }]);
  assert.ok(r.body.total >= 3 && r.body.articles.every((a) => a.categories.some((c) => c.key === 'programming')));

  const put = await m.put('/api/news/interests', { interests: ['cybersecurity', 'cybersecurity'] });
  assert.equal(put.status, 200);
  assert.deepEqual(put.body.interests, ['cybersecurity']);
  r = await m.get('/api/news?category=for-you');
  assert.deepEqual(r.body.recommendation.categories, ['programming', 'cybersecurity']);
  assert.equal((await m.put('/api/news/interests', { interests: ['gossip'] })).status, 400);
  assert.equal((await m.put('/api/news/interests', { interests: 'ai' })).status, 400);
  const other = await signIn('sara.kim@example.com');
  assert.deepEqual((await other.get('/api/news/interests')).body.interests, [], 'another member does not see these choices');
});

// =====================================================================================
// 8. Admin management of trusted sources
// =====================================================================================
test('only an Admin can use the source-management API (visitor 401, member 403) and nothing changes', async () => {
  const visitor = browser();
  const member = await asMember();
  const calls = [['get', '/api/admin/news/sources'], ['get', '/api/admin/news/status'], ['post', '/api/admin/news/sources', { name: 'X', url: 'https://feeds.example.org/x.xml' }], ['put', '/api/admin/news/sources/1', { enabled: false }], ['del', '/api/admin/news/sources/1']];
  for (const [m, p, body] of calls) {
    assert.equal((await visitor[m](p, body)).status, 401, `visitor ${m} ${p}`);
    assert.equal((await member[m](p, body)).status, 403, `member ${m} ${p}`);
  }
  assert.equal(db().prepare('SELECT COUNT(*) AS n FROM news_sources').get().n, 4);
  assert.equal(db().prepare('SELECT COUNT(*) AS n FROM news_sources WHERE enabled = 1').get().n, 4);
});

test('an Admin sees the four configured sources with their status', async () => {
  await service.run('admin-list');
  const admin = await asAdmin();
  const r = await admin.get('/api/admin/news/sources');
  assert.equal(r.status, 200);
  assert.deepEqual(r.body.sources.map((s) => s.name), ['TechCrunch', 'Ars Technica', 'Hacker News', 'DEV Community']);
  const tc = r.body.sources[0];
  assert.deepEqual([tc.enabled, tc.builtin, tc.urlEditable, tc.lastStatus, tc.articleCount], [true, true, true, 'ok', 3]);
  assert.equal(r.body.sources[2].urlEditable, false);
  assert.ok(tc.lastSyncAt);
});

test('adding a feed validates the address, fetches it once to prove it works, and rejects duplicates', async () => {
  routes.set('https://feeds.example.org/rss.xml', () => rssFeed('Example Feed', [{ id: 'ex-1', title: 'Cloud security update for developers', link: 'https://feeds.example.org/posts/1', at: ago(1), tags: ['Security'] }]));
  const admin = await asAdmin();
  const created = await admin.post('/api/admin/news/sources', { name: 'Example Feed', url: 'https://feeds.example.org/rss.xml' });
  assert.equal(created.status, 201);
  assert.equal(created.body.check.status, 'ok');
  assert.equal(created.body.source.lastStatus, 'ok');
  assert.equal(created.body.source.articleCount, 1);
  assert.equal(created.body.source.builtin, false);
  const dup = await admin.post('/api/admin/news/sources', { name: 'Again', url: 'https://www.feeds.example.org/rss.xml?utm_source=x' });
  assert.equal(dup.status, 409);
  assert.equal((await admin.post('/api/admin/news/sources', { name: '', url: 'https://feeds.example.org/z.xml' })).status, 400);
  // a broken feed is saved but shows the failure
  routes.set('https://feeds.example.org/broken.xml', () => HTML_PAGE);
  const broken = await admin.post('/api/admin/news/sources', { name: 'Broken', url: 'https://feeds.example.org/broken.xml' });
  assert.equal(broken.status, 201);
  assert.equal(broken.body.check.status, 'error');
  assert.match(broken.body.source.lastMessage, /web page/);
});

test('unsafe and invalid feed addresses are rejected by the API and never requested', async () => {
  const admin = await asAdmin();
  const unsafe = ['file:///etc/passwd', 'ftp://example.com/feed', 'http://localhost/feed', 'http://127.0.0.1/feed', 'http://169.254.169.254/latest/meta-data/', 'http://10.0.0.1/rss', 'http://[::1]/feed', 'https://user:pw@example.com/feed', 'https://example.com:8080/feed', 'https://internal.example.org/feed', 'https://nxdomain.example.org/feed', 'javascript:alert(1)', 'not a url', ''];
  for (const url of unsafe) {
    const r = await admin.post('/api/admin/news/sources', { name: 'Evil', url });
    assert.equal(r.status, 400, `should reject ${url}`);
    assert.ok(r.body.error.fields?.url, `field error for ${url}`);
  }
  assert.equal(db().prepare('SELECT COUNT(*) AS n FROM news_sources').get().n, 4);
  assert.deepEqual(fetchLog, [], 'no request was made for any rejected address');
  const tc = (await admin.get('/api/admin/news/sources')).body.sources[0];
  const edit = await admin.put(`/api/admin/news/sources/${tc.id}`, { url: 'http://192.168.0.10/feed.xml' });
  assert.equal(edit.status, 400);
  assert.equal(db().prepare('SELECT url FROM news_sources WHERE id = ?').get(tc.id).url, U.tc, 'the stored address is unchanged');
});

test('enable/disable, edit and remove behave safely', async () => {
  await service.run('before-admin');
  const admin = await asAdmin();
  const member = await asMember();
  const list = (await admin.get('/api/admin/news/sources')).body.sources;
  const ars = list.find((s) => s.name === 'Ars Technica');
  const hn = list.find((s) => s.name === 'Hacker News');

  const off = await admin.put(`/api/admin/news/sources/${ars.id}`, { enabled: false });
  assert.equal(off.body.source.enabled, false);
  const feedAfterOff = await member.get('/api/news?limit=50');
  assert.ok(!feedAfterOff.body.articles.some((a) => a.source.name === 'Ars Technica'), 'articles of a disabled source are hidden');
  fetchLog.length = 0;
  await service.run('after-disable');
  assert.ok(!fetchLog.includes(U.ars), 'a disabled source is not fetched');
  assert.equal(db().prepare('SELECT COUNT(*) AS n FROM news_articles WHERE source_id = ?').get(ars.id).n, 2, 'its stored articles are kept until they expire');
  await admin.put(`/api/admin/news/sources/${ars.id}`, { enabled: true });
  assert.ok((await member.get('/api/news?limit=50')).body.articles.some((a) => a.source.name === 'Ars Technica'));

  assert.equal((await admin.put(`/api/admin/news/sources/${hn.id}`, { url: 'https://example.com/other.json' })).status, 400, 'API sources have a fixed address');
  assert.equal((await admin.put(`/api/admin/news/sources/${ars.id}`, { enabled: 'yes' })).status, 400);
  assert.equal((await admin.put('/api/admin/news/sources/99999', { enabled: false })).status, 404);
  assert.equal((await admin.put(`/api/admin/news/sources/${ars.id}`, {})).status, 400);

  routes.set('https://feeds.example.org/new-ars.xml', () => rssFeed('Ars', [{ id: 'n1', title: 'Linux kernel developers ship a release', link: 'https://arstechnica.com/new/1', at: ago(1) }]));
  const moved = await admin.put(`/api/admin/news/sources/${ars.id}`, { url: 'https://feeds.example.org/new-ars.xml' });
  assert.equal(moved.status, 200);
  assert.equal(moved.body.check.status, 'ok');

  assert.equal((await admin.del(`/api/admin/news/sources/${ars.id}`)).status, 400, 'built-in sources can only be disabled');

  routes.set('https://feeds.example.org/custom.xml', () => rssFeed('Custom', [{ id: 'c1', title: 'Custom feed security story', link: 'https://feeds.example.org/p/1', at: ago(1), tags: ['security'] }]));
  const custom = (await admin.post('/api/admin/news/sources', { name: 'Custom', url: 'https://feeds.example.org/custom.xml' })).body.source;
  const total = articleCount();
  const del = await admin.del(`/api/admin/news/sources/${custom.id}`);
  assert.deepEqual([del.status, del.body.removedArticles], [200, 1]);
  assert.equal(articleCount(), total - 1, 'only that source\'s articles were removed');
  assert.equal(db().prepare('SELECT COUNT(*) AS n FROM news_sources').get().n, 4);
});

// =====================================================================================
// 9. Parts 1-3 stay intact
// =====================================================================================
test('the five Part 3 test accounts are untouched by startup, synchronization and cleanup', async () => {
  const first = ensureTestAccounts();
  assert.equal(first.created.length, 5);
  const snapshot = () => db().prepare(`SELECT id, email, password_hash, status, role, profession FROM users WHERE email IN (${TEST_ACCOUNTS.map(() => '?').join(',')}) ORDER BY email`).all(...TEST_ACCOUNTS.map((a) => a.email));
  const before = snapshot();
  assert.equal(before.length, 5);

  const started = await startServer({ port: 0, news: { timers } });
  await started.scheduler.initialRun;
  clock = NOW + 120 * 60_000;
  captured.fn();
  await until(() => service.lastRun()?.reason === 'scheduled' && !service.isRunning());
  started.scheduler.stop();
  await new Promise((r) => started.server.close(r));

  assert.deepEqual(snapshot(), before);
  const again = ensureTestAccounts();
  assert.equal(again.created.length, 0, 'no duplicates are created');
  assert.equal(again.unchanged.length + again.updated.length, 5);
  assert.equal(db().prepare('SELECT COUNT(*) AS n FROM users WHERE email LIKE ?').get('%@proconnect.example').n >= 5, true);
});

test('old news-free databases gain the news tables and built-in sources without losing data', () => {
  const tables = db().prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name LIKE 'news_%' ORDER BY name").all().map((r) => r.name);
  assert.deepEqual(tables, ['news_articles', 'news_interests', 'news_sources']);
  assert.equal(db().prepare('SELECT COUNT(*) AS n FROM news_sources WHERE is_builtin = 1').get().n, 4);
});

// ---------- Part 7: missing-image fallback ----------
test('the default news image is a local, well-formed ProConnect SVG that needs no external service', () => {
  assert.equal(DEFAULT_NEWS_IMAGE, '/news/proconnect-news-default.svg');
  const file = path.join(path.dirname(new URL(import.meta.url).pathname), '..', '..', 'client', 'public', DEFAULT_NEWS_IMAGE);
  const svg = fs.readFileSync(file, 'utf8');
  assert.match(svg, /^<svg[^>]+viewBox="0 0 640 360"/); // 16:9, like the News card thumbnails
  assert.ok(!/(href|src)="https?:/i.test(svg) && !/url\(https?:/i.test(svg), 'no external references');
  for (const colour of ['#BDF07A', '#6F8461', '#1C1F1A']) assert.ok(svg.includes(colour), colour); // lime, sage, dark from the brand palette
  assert.ok(svg.length < 12_000, 'small enough to load instantly');
});

test('an article with a valid original image keeps it; one without gets the local default', () => {
  const ctx = { nowMs: NOW, retentionMs: 72 * H };
  const base = { externalId: 'a', url: 'https://example.com/a', title: 'A valid title', summaryHtml: '', tags: [], publishedAt: new Date(ago(1)).toISOString() };
  const original = 'https://cdn.example.com/pictures/original.jpg?w=800';
  assert.equal(normalizeCandidate({ ...base, imageUrl: original }, ctx).article.imageUrl, original);
  for (const missing of [undefined, null, '', '   ', 'not a url', 'javascript:alert(1)', 'ftp://example.com/x.jpg']) {
    assert.equal(normalizeCandidate({ ...base, imageUrl: missing }, ctx).article.imageUrl, DEFAULT_NEWS_IMAGE, String(missing));
  }
});

test('stored articles with a missing image are answered with the default; originals are untouched', async () => {
  await service.run('test');
  const d = db();
  const withImage = d.prepare("SELECT id, image_url FROM news_articles WHERE image_url LIKE 'https://%' LIMIT 1").get();
  assert.ok(withImage, 'the mocked feeds include an article with an image');
  // Simulate old data: an article stored before the default existed, and one with an empty string.
  const victims = d.prepare("SELECT id FROM news_articles WHERE image_url = ? OR image_url IS NULL LIMIT 2").all(DEFAULT_NEWS_IMAGE);
  for (const [i, v] of victims.entries()) d.prepare('UPDATE news_articles SET image_url = ? WHERE id = ?').run(i === 0 ? null : '', v.id);
  const member = await asMember();
  const r = await member.get('/api/news?limit=50');
  assert.equal(r.status, 200);
  for (const a of r.body.articles) assert.ok(a.imageUrl && a.imageUrl.length > 1, a.title); // never empty
  for (const v of victims) assert.equal(r.body.articles.find((a) => a.id === v.id).imageUrl, DEFAULT_NEWS_IMAGE);
  const original = r.body.articles.find((a) => a.id === withImage.id);
  assert.equal(original.imageUrl, withImage.image_url);
  assert.equal(original.hasOriginalImage, true);
  assert.deepEqual(victims.map((v) => r.body.articles.find((a) => a.id === v.id).hasOriginalImage), victims.map(() => false));
});

test('after a synchronization every stored article has an image value, and repeating it adds no duplicates', async () => {
  await service.run('test');
  const count = () => db().prepare('SELECT COUNT(*) AS n FROM news_articles').get().n;
  const before = count();
  const again = await service.run('test');
  assert.equal(again.totals.inserted, 0);
  assert.equal(count(), before);
  const rows = db().prepare('SELECT image_url FROM news_articles').all();
  assert.ok(rows.length > 0 && rows.every((r) => r.image_url && r.image_url.length > 1));
  // The scheduler, 72-hour cleanup and deduplication have their own tests above; they still pass with the default image in place.
});
