// Part 18 tests: Saved Jobs and Job Application Management (API level, throw-away in-memory database, no network at all).
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

process.env.PROCONNECT_DB = ':memory:';
process.env.JOBS_SYNC = 'off';
process.env.NEWS_SYNC = 'off';
process.env.PROCONNECT_UPLOADS = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-p18-uploads-'));

import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';

const { createApp } = await import('../src/app.js');
const { seedDatabase, DEMO_PASSWORD } = await import('../src/db/seed.js');
const { getDb } = await import('../src/db/index.js');

const here = path.dirname(fileURLToPath(import.meta.url));
let server;
let base;
before(async () => {
  seedDatabase();
  const d = getDb();
  const add = d.prepare(
    `INSERT INTO jobs (source, external_id, url, url_key, title, company, location, work_mode, category, employment_type, tags, summary, description_text, published_at, first_seen_at, last_seen_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '[]', ?, ?, ?, ?, ?)`
  );
  const t = '2026-10-30T10:00:00.000Z';
  add.run('arbeitnow', 'dev-1', 'https://www.arbeitnow.com/jobs/dev-1', 'arbeitnow.com/jobs/dev-1', 'Backend Developer', 'Acme GmbH', 'Berlin', 'remote', 'it-software', 'full_time', 'Build APIs', 'Build APIs all day', t, t, t);
  add.run('arbeitnow', 'dev-2', 'https://www.arbeitnow.com/jobs/dev-2', 'arbeitnow.com/jobs/dev-2', 'Frontend Developer', 'Acme GmbH', 'Berlin', null, 'it-software', null, null, null, t, t, t);
  add.run('muse', '4711', 'https://www.themuse.com/jobs/care/nurse', 'themuse.com/jobs/care/nurse', 'Registered Nurse', 'CareCo', 'Austin, TX', null, 'healthcare', null, 'Care for people', null, t, t, t);
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server.close());

function browser() {
  let cookie = '';
  const call = async (method, p, body) => {
    const res = await fetch(base + p, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) }, body: body !== undefined ? JSON.stringify(body) : undefined });
    const set = res.headers.getSetCookie().map((c) => c.split(';')[0]).find((c) => c.startsWith('pc_token='));
    if (set) cookie = set === 'pc_token=' ? '' : set;
    return { status: res.status, body: await res.json() };
  };
  return { get: (p) => call('GET', p), post: (p, b) => call('POST', p, b ?? {}), put: (p, b) => call('PUT', p, b), del: (p) => call('DELETE', p) };
}
const loginAs = async (email) => {
  const b = browser();
  assert.equal((await b.post('/api/auth/login', { email, password: DEMO_PASSWORD })).status, 200);
  return b;
};
const jobId = (external) => getDb().prepare('SELECT id FROM jobs WHERE external_id = ?').get(external).id;
const clean = () => getDb().exec('DELETE FROM saved_jobs; DELETE FROM job_applications;');
const today = () => new Date().toISOString().slice(0, 10);
const code = (r) => r.body.error?.code;

// ===================== Saved Jobs =====================

test('saved-jobs and job-applications endpoints need a signed-in member (401)', async () => {
  const v = browser();
  for (const [m, p] of [['get', '/api/saved-jobs'], ['post', '/api/saved-jobs'], ['del', '/api/saved-jobs/1'], ['get', '/api/job-applications'], ['post', '/api/job-applications'], ['get', '/api/job-applications/1'], ['put', '/api/job-applications/1'], ['del', '/api/job-applications/1']]) {
    const r = await v[m](p, m === 'put' ? {} : undefined);
    assert.equal(r.status, 401, `${m} ${p}`);
  }
});

test('a member can save a job; it appears with a snapshot, a save date and available status', async () => {
  clean();
  const alex = await loginAs('alex.morgan@example.com');
  const r = await alex.post('/api/saved-jobs', { jobId: jobId('dev-1') });
  assert.equal(r.status, 201);
  assert.equal(r.body.savedJob.job.title, 'Backend Developer');
  assert.equal(r.body.savedJob.availability, 'available');
  assert.ok(r.body.savedJob.savedAt);
  const list = (await alex.get('/api/saved-jobs')).body;
  assert.equal(list.total, 1);
  assert.equal(list.savedJobs[0].job.company, 'Acme GmbH');
  assert.equal(list.savedJobs[0].job.applyUrl, 'https://www.arbeitnow.com/jobs/dev-1');
  assert.equal(list.savedJobs[0].job.source.name, 'Arbeitnow');
  // the job list and the job details tell the card whether it is saved
  const listed = (await alex.get('/api/jobs?pageSize=24')).body.jobs.find((j) => j.title === 'Backend Developer');
  assert.equal(listed.savedId, r.body.savedJob.id);
  assert.equal((await alex.get(`/api/jobs/${jobId('dev-1')}`)).body.job.savedId, r.body.savedJob.id);
  assert.equal((await alex.get('/api/jobs?pageSize=24')).body.jobs.find((j) => j.title === 'Frontend Developer').savedId, null);
});

test('saving the same job twice is refused with already_saved and creates no second record', async () => {
  clean();
  const alex = await loginAs('alex.morgan@example.com');
  const first = await alex.post('/api/saved-jobs', { jobId: jobId('dev-1') });
  const again = await alex.post('/api/saved-jobs', { jobId: jobId('dev-1') });
  assert.equal(again.status, 409);
  assert.equal(code(again), 'already_saved');
  assert.equal(again.body.error.details.savedId, first.body.savedJob.id);
  assert.equal(getDb().prepare('SELECT COUNT(*) AS n FROM saved_jobs').get().n, 1);
  // two parallel clicks still leave exactly one record
  clean();
  const results = await Promise.all([alex.post('/api/saved-jobs', { jobId: jobId('dev-2') }), alex.post('/api/saved-jobs', { jobId: jobId('dev-2') })]);
  assert.deepEqual(results.map((r) => r.status).sort(), [201, 409]);
  assert.equal(getDb().prepare('SELECT COUNT(*) AS n FROM saved_jobs').get().n, 1);
});

test('saving validates its input and answers job_not_found for a listing that does not exist', async () => {
  const alex = await loginAs('alex.morgan@example.com');
  for (const bad of [{}, { jobId: 'abc' }, { jobId: -1 }, { jobId: 1.5 }, { jobId: null }]) {
    const r = await alex.post('/api/saved-jobs', bad);
    assert.equal(r.status, 400, JSON.stringify(bad));
    assert.equal(code(r), 'validation_error');
  }
  const gone = await alex.post('/api/saved-jobs', { jobId: 999999 });
  assert.equal(gone.status, 404);
  assert.equal(code(gone), 'job_not_found');
});

test('a member can remove a saved job; removing it again says not_found; the listing itself is untouched', async () => {
  clean();
  const alex = await loginAs('alex.morgan@example.com');
  const id = (await alex.post('/api/saved-jobs', { jobId: jobId('dev-1') })).body.savedJob.id;
  assert.equal((await alex.del(`/api/saved-jobs/${id}`)).status, 200);
  assert.equal((await alex.get('/api/saved-jobs')).body.total, 0);
  const again = await alex.del(`/api/saved-jobs/${id}`);
  assert.equal(again.status, 404);
  assert.equal((await alex.del('/api/saved-jobs/abc')).status, 400);
  assert.equal(getDb().prepare('SELECT COUNT(*) AS n FROM jobs').get().n, 3);
  // it can be saved again afterwards
  assert.equal((await alex.post('/api/saved-jobs', { jobId: jobId('dev-1') })).status, 201);
});

test('saved jobs persist after logout and login', async () => {
  clean();
  const first = await loginAs('alex.morgan@example.com');
  await first.post('/api/saved-jobs', { jobId: jobId('dev-1') });
  assert.equal((await first.post('/api/auth/logout')).status, 200);
  assert.equal((await first.get('/api/saved-jobs')).status, 401);
  const second = await loginAs('alex.morgan@example.com');
  const list = (await second.get('/api/saved-jobs')).body;
  assert.deepEqual(list.savedJobs.map((s) => s.job.title), ['Backend Developer']);
});

test('one member cannot see or remove another member\'s saved jobs; the user id in the request is ignored', async () => {
  clean();
  const alex = await loginAs('alex.morgan@example.com');
  const sara = await loginAs('sara.kim@example.com');
  const alexId = (await alex.post('/api/saved-jobs', { jobId: jobId('dev-1') })).body.savedJob.id;
  assert.equal((await sara.get('/api/saved-jobs')).body.total, 0);
  const del = await sara.del(`/api/saved-jobs/${alexId}`);
  assert.equal(del.status, 404);
  assert.equal((await alex.get('/api/saved-jobs')).body.total, 1);
  // a forged user id changes nothing
  const alexUser = getDb().prepare("SELECT id FROM users WHERE email = 'alex.morgan@example.com'").get().id;
  const forged = await sara.post('/api/saved-jobs', { jobId: jobId('dev-2'), userId: alexUser, user_id: alexUser });
  assert.equal(forged.status, 201);
  assert.equal(getDb().prepare('SELECT user_id FROM saved_jobs WHERE id = ?').get(forged.body.savedJob.id).user_id, getDb().prepare("SELECT id FROM users WHERE email = 'sara.kim@example.com'").get().id);
  assert.equal((await alex.get('/api/saved-jobs')).body.total, 1);
  // sara's flag on the job list is her own
  assert.equal((await alex.get('/api/jobs?pageSize=24')).body.jobs.find((j) => j.title === 'Frontend Developer').savedId, null);
});

test('a saved job whose listing disappeared stays saved, shows as unavailable and offers no apply link', async () => {
  clean();
  const alex = await loginAs('alex.morgan@example.com');
  await alex.post('/api/saved-jobs', { jobId: jobId('4711') });
  const d = getDb();
  const row = d.prepare('SELECT * FROM jobs WHERE external_id = ?').get('4711');
  d.prepare('DELETE FROM jobs WHERE id = ?').run(row.id); // the retention cleanup, or the source removing it
  const list = (await alex.get('/api/saved-jobs')).body;
  assert.equal(list.total, 1);
  const s = list.savedJobs[0];
  assert.equal(s.availability, 'unavailable');
  assert.equal(s.job.title, 'Registered Nurse');
  assert.equal(s.job.company, 'CareCo');
  assert.equal(s.job.id, null);
  assert.equal(s.job.applyUrl, null);
  assert.equal(s.job.lastKnownUrl, 'https://www.themuse.com/jobs/care/nurse'); // what was stored, never rebuilt
  assert.equal(list.unavailable, 1);
  assert.equal((await alex.get('/api/saved-jobs?availability=unavailable')).body.total, 1);
  assert.equal((await alex.get('/api/saved-jobs?availability=available')).body.total, 0);
  // the member can still remove it
  assert.equal((await alex.del(`/api/saved-jobs/${s.id}`)).status, 200);
  // and a job that is not stored any more cannot be saved
  assert.equal(code(await alex.post('/api/saved-jobs', { jobId: row.id })), 'job_not_found');
  // restore for the other tests (and prove the same listing re-appearing under a NEW row id is recognised again)
  d.prepare(`INSERT INTO jobs (source, external_id, url, url_key, title, company, location, category, tags, published_at, first_seen_at, last_seen_at)
             VALUES ('muse', '4711', 'https://www.themuse.com/jobs/care/nurse', 'themuse.com/jobs/care/nurse', 'Registered Nurse', 'CareCo', 'Austin, TX', 'healthcare', '[]', ?, ?, ?)`).run(row.published_at, row.first_seen_at, row.last_seen_at);
});

test('a temporary source failure never removes saved jobs, and a listing that comes back becomes available again', async () => {
  clean();
  const alex = await loginAs('alex.morgan@example.com');
  await alex.post('/api/saved-jobs', { jobId: jobId('dev-1') });
  const d = getDb();
  // a failed fetch records an error and deletes nothing
  d.prepare("INSERT OR REPLACE INTO job_sources (key, last_sync_at, last_status, last_message) VALUES ('arbeitnow', ?, 'error', 'The source could not be reached.')").run(new Date().toISOString());
  assert.equal((await alex.get('/api/saved-jobs')).body.savedJobs[0].availability, 'available');
  assert.equal(d.prepare('SELECT COUNT(*) AS n FROM saved_jobs').get().n, 1);
  // retention removes the listing, then a later fetch stores it again under a new id
  const old = d.prepare("SELECT * FROM jobs WHERE external_id = 'dev-1'").get();
  d.prepare('DELETE FROM jobs WHERE id = ?').run(old.id);
  assert.equal((await alex.get('/api/saved-jobs')).body.savedJobs[0].availability, 'unavailable');
  d.prepare(`INSERT INTO jobs (source, external_id, url, url_key, title, company, location, category, tags, published_at, first_seen_at, last_seen_at)
             VALUES ('arbeitnow', 'dev-1', ?, ?, 'Backend Developer', 'Acme GmbH', 'Berlin', 'it-software', '[]', ?, ?, ?)`).run(old.url, old.url_key, old.published_at, old.first_seen_at, old.last_seen_at);
  const back = (await alex.get('/api/saved-jobs')).body.savedJobs[0];
  assert.equal(back.availability, 'available');
  assert.equal(back.job.applyUrl, 'https://www.arbeitnow.com/jobs/dev-1');
  d.exec("DELETE FROM job_sources WHERE key = 'arbeitnow'");
});

test('the saved-jobs list searches by title and company, filters by category and availability, and sorts', async () => {
  clean();
  const alex = await loginAs('alex.morgan@example.com');
  const d = getDb();
  for (const [ext, at] of [['dev-1', '2026-11-01T10:00:00.000Z'], ['dev-2', '2026-11-02T08:00:00.000Z'], ['4711', '2026-10-31T09:00:00.000Z']]) {
    const id = (await alex.post('/api/saved-jobs', { jobId: jobId(ext) })).body.savedJob.id;
    d.prepare('UPDATE saved_jobs SET saved_at = ? WHERE id = ?').run(at, id);
  }
  const titles = async (q = '') => (await alex.get(`/api/saved-jobs${q}`)).body.savedJobs.map((s) => s.job.title);
  assert.deepEqual(await titles(), ['Frontend Developer', 'Backend Developer', 'Registered Nurse']); // most recently saved first
  assert.deepEqual(await titles('?sort=oldest'), ['Registered Nurse', 'Backend Developer', 'Frontend Developer']);
  assert.deepEqual(await titles('?sort=title'), ['Backend Developer', 'Frontend Developer', 'Registered Nurse']);
  assert.deepEqual(await titles('?q=nurse'), ['Registered Nurse']);
  assert.deepEqual(await titles('?q=CAREco'), ['Registered Nurse']); // company, any letter case
  assert.deepEqual((await titles('?q=acme')).sort(), ['Backend Developer', 'Frontend Developer']);
  assert.deepEqual(await titles('?category=healthcare'), ['Registered Nurse']);
  assert.deepEqual(await titles('?category=it-software&q=front'), ['Frontend Developer']);
  assert.deepEqual(await titles('?q=zzz'), []);
  const body = (await alex.get('/api/saved-jobs?q=nurse')).body;
  assert.equal(body.totalSaved, 3); // the unfiltered total
  assert.deepEqual(body.facets.categories.map((c) => [c.key, c.count]), [['it-software', 2], ['healthcare', 1]]);
  for (const bad of ['?sort=random', '?category=nope', '?availability=maybe']) assert.equal((await alex.get(`/api/saved-jobs${bad}`)).status, 400, bad);
});

// ===================== My Applications =====================

const manual = (over = {}) => ({ title: 'Data Analyst', company: 'Globex', url: 'https://careers.globex.example/jobs/42', appliedOn: today(), status: 'applied', notes: 'Sent the CV by the website.', ...over });

test('a member can add an application by hand: required fields are validated and nothing is defaulted', async () => {
  clean();
  const alex = await loginAs('alex.morgan@example.com');
  const bad = await alex.post('/api/job-applications', {});
  assert.equal(bad.status, 400);
  assert.equal(code(bad), 'validation_error');
  assert.deepEqual(Object.keys(bad.body.error.fields).sort(), ['appliedOn', 'company', 'status', 'title']);
  for (const [over, field] of [
    [{ title: ' ' }, 'title'], [{ title: 'x'.repeat(201) }, 'title'], [{ company: '' }, 'company'], [{ company: 'c'.repeat(121) }, 'company'],
    [{ url: 'javascript:alert(1)' }, 'url'], [{ url: 'ftp://x.example/a' }, 'url'], [{ url: 'https://user:pw@x.example/a' }, 'url'], [{ url: 'not a url' }, 'url'], [{ url: `https://x.example/${'a'.repeat(500)}` }, 'url'],
    [{ appliedOn: '2026-13-40' }, 'appliedOn'], [{ appliedOn: 'yesterday' }, 'appliedOn'], [{ appliedOn: '2999-01-01' }, 'appliedOn'], [{ appliedOn: '' }, 'appliedOn'],
    [{ status: 'done' }, 'status'], [{ status: undefined }, 'status'], [{ notes: 'n'.repeat(2001) }, 'notes'], [{ title: 5 }, 'title'],
  ]) {
    const r = await alex.post('/api/job-applications', manual(over));
    assert.equal(r.status, 400, JSON.stringify(over).slice(0, 60));
    assert.ok(r.body.error.fields?.[field], `${field} for ${JSON.stringify(over).slice(0, 60)}`);
  }
  assert.equal(getDb().prepare('SELECT COUNT(*) AS n FROM job_applications').get().n, 0);
  const ok = await alex.post('/api/job-applications', manual());
  assert.equal(ok.status, 201);
  const a = ok.body.application;
  assert.deepEqual([a.title, a.company, a.url, a.status, a.notes, a.appliedOn], ['Data Analyst', 'Globex', 'https://careers.globex.example/jobs/42', 'applied', 'Sent the CV by the website.', today()]);
  assert.equal(a.job, null);
  assert.deepEqual(a.tracking, { origin: 'self_reported', submittedViaProConnect: false });
  assert.ok(a.createdAt && a.updatedAt);
  assert.equal(ok.body.summary.total, 1);
  // title and company are enough: the link and the notes are optional
  assert.equal((await alex.post('/api/job-applications', manual({ title: 'Nurse', url: undefined, notes: undefined }))).status, 201);
});

test('a member can add an application linked to an existing job; the listing supplies title, company and link', async () => {
  clean();
  const alex = await loginAs('alex.morgan@example.com');
  const r = await alex.post('/api/job-applications', { jobId: jobId('dev-1'), title: 'Hacked title', company: 'Hacked', url: 'https://evil.example/', appliedOn: today(), status: 'reviewing', notes: 'Applied on the Acme site' });
  assert.equal(r.status, 201);
  const a = r.body.application;
  assert.deepEqual([a.title, a.company, a.url, a.status], ['Backend Developer', 'Acme GmbH', 'https://www.arbeitnow.com/jobs/dev-1', 'reviewing']);
  assert.deepEqual([a.job.available, a.job.source.name], [true, 'Arbeitnow']);
  // the job card now knows it is tracked
  assert.equal((await alex.get(`/api/jobs/${jobId('dev-1')}`)).body.job.applicationId, a.id);
  // a missing listing is refused with an explanation, nothing is invented
  const gone = await alex.post('/api/job-applications', { jobId: 999999, appliedOn: today(), status: 'applied' });
  assert.equal(gone.status, 404);
  assert.equal(code(gone), 'job_not_found');
  // the snapshot keeps the record readable after the listing disappears
  getDb().prepare("DELETE FROM jobs WHERE external_id = 'dev-1'").run();
  const after = (await alex.get(`/api/job-applications/${a.id}`)).body.application;
  assert.deepEqual([after.title, after.company, after.url, after.job.available], ['Backend Developer', 'Acme GmbH', 'https://www.arbeitnow.com/jobs/dev-1', false]);
  getDb().prepare(`INSERT INTO jobs (source, external_id, url, url_key, title, company, location, work_mode, category, employment_type, tags, summary, description_text, published_at, first_seen_at, last_seen_at)
    VALUES ('arbeitnow', 'dev-1', 'https://www.arbeitnow.com/jobs/dev-1', 'arbeitnow.com/jobs/dev-1', 'Backend Developer', 'Acme GmbH', 'Berlin', 'remote', 'it-software', 'full_time', '[]', 'Build APIs', 'Build APIs all day', '2026-10-30T10:00:00.000Z', '2026-10-30T10:00:00.000Z', '2026-10-30T10:00:00.000Z')`).run();
});

test('duplicates are prevented per member and per position, while other positions at the same company are allowed', async () => {
  clean();
  const alex = await loginAs('alex.morgan@example.com');
  const sara = await loginAs('sara.kim@example.com');
  assert.equal((await alex.post('/api/job-applications', manual())).status, 201);
  const dupUrl = await alex.post('/api/job-applications', manual({ title: 'Totally different title', url: 'https://careers.globex.example/jobs/42/?utm_source=x#top' }));
  assert.equal(dupUrl.status, 409);
  assert.equal(code(dupUrl), 'duplicate_application');
  // another position at the same company is fine
  assert.equal((await alex.post('/api/job-applications', manual({ title: 'Data Engineer', url: 'https://careers.globex.example/jobs/43' }))).status, 201);
  assert.equal((await alex.post('/api/job-applications', manual({ title: 'Data Engineer', url: undefined }))).status, 201);
  // without a link, the same title and company is the same position
  assert.equal(code(await alex.post('/api/job-applications', manual({ title: ' data  engineer ', company: 'GLOBEX', url: undefined }))), 'duplicate_application');
  // the same listing twice
  assert.equal((await alex.post('/api/job-applications', { jobId: jobId('dev-2'), appliedOn: today(), status: 'applied' })).status, 201);
  assert.equal(code(await alex.post('/api/job-applications', { jobId: jobId('dev-2'), appliedOn: today(), status: 'applied' })), 'duplicate_application');
  // typing the link of a listing that is already tracked is the same application
  assert.equal(code(await alex.post('/api/job-applications', manual({ title: 'x1', url: 'https://www.arbeitnow.com/jobs/dev-2' }))), 'duplicate_application');
  // another member may track the very same position
  assert.equal((await sara.post('/api/job-applications', manual())).status, 201);
  // an edit cannot create a duplicate either
  const list = (await alex.get('/api/job-applications')).body.applications;
  const other = list.find((a) => a.url === 'https://careers.globex.example/jobs/43');
  assert.equal(code(await alex.put(`/api/job-applications/${other.id}`, { url: 'https://careers.globex.example/jobs/42' })), 'duplicate_application');
});

test('a member can change the status and edit the notes, and last-updated moves forward', async () => {
  clean();
  const alex = await loginAs('alex.morgan@example.com');
  const a = (await alex.post('/api/job-applications', manual())).body.application;
  getDb().prepare("UPDATE job_applications SET updated_at = '2026-01-01T00:00:00.000Z' WHERE id = ?").run(a.id);
  for (const status of ['reviewing', 'interview', 'accepted', 'rejected', 'withdrawn', 'applied']) {
    const r = await alex.put(`/api/job-applications/${a.id}`, { status });
    assert.equal(r.status, 200);
    assert.equal(r.body.application.status, status);
  }
  const edited = await alex.put(`/api/job-applications/${a.id}`, { notes: 'Phone screen on Tuesday', title: 'Senior Data Analyst', appliedOn: '2026-10-01' });
  assert.deepEqual([edited.body.application.notes, edited.body.application.title, edited.body.application.appliedOn, edited.body.application.company], ['Phone screen on Tuesday', 'Senior Data Analyst', '2026-10-01', 'Globex']);
  assert.ok(edited.body.application.updatedAt > '2026-01-01T00:00:00.000Z');
  assert.equal((await alex.put(`/api/job-applications/${a.id}`, { notes: '' })).body.application.notes, null);
  assert.equal((await alex.put(`/api/job-applications/${a.id}`, { url: null })).body.application.url, null);
  assert.equal(code(await alex.put(`/api/job-applications/${a.id}`, { status: 'hired' })), 'validation_error');
  assert.equal(code(await alex.put(`/api/job-applications/${a.id}`, { title: '' })), 'validation_error');
  assert.equal(code(await alex.put(`/api/job-applications/${a.id}`, {})), 'nothing_to_update');
  assert.equal((await alex.get(`/api/job-applications/${a.id}`)).body.application.title, 'Senior Data Analyst');
});

test('a member can delete their own application; deleting twice says not_found', async () => {
  clean();
  const alex = await loginAs('alex.morgan@example.com');
  const a = (await alex.post('/api/job-applications', manual())).body.application;
  const del = await alex.del(`/api/job-applications/${a.id}`);
  assert.equal(del.status, 200);
  assert.equal(del.body.summary.total, 0);
  assert.equal((await alex.del(`/api/job-applications/${a.id}`)).status, 404);
  assert.equal((await alex.get(`/api/job-applications/${a.id}`)).status, 404);
  assert.equal((await alex.get('/api/job-applications/abc')).status, 400);
});

test('one member cannot read, edit or delete another member\'s applications', async () => {
  clean();
  const alex = await loginAs('alex.morgan@example.com');
  const sara = await loginAs('sara.kim@example.com');
  const admin = await loginAs('admin@proconnect.example');
  const a = (await alex.post('/api/job-applications', manual())).body.application;
  for (const who of [sara, admin]) {
    assert.equal((await who.get('/api/job-applications')).body.total, 0);
    assert.equal((await who.get(`/api/job-applications/${a.id}`)).status, 404);
    assert.equal((await who.put(`/api/job-applications/${a.id}`, { status: 'rejected', notes: 'hijacked' })).status, 404);
    assert.equal((await who.del(`/api/job-applications/${a.id}`)).status, 404);
  }
  const mine = (await alex.get(`/api/job-applications/${a.id}`)).body.application;
  assert.deepEqual([mine.status, mine.notes], ['applied', 'Sent the CV by the website.']);
  // a user id in the body is ignored
  const alexUser = getDb().prepare("SELECT id FROM users WHERE email = 'alex.morgan@example.com'").get().id;
  const sent = await sara.post('/api/job-applications', { ...manual({ title: 'Sara role' }), userId: alexUser, user_id: alexUser });
  assert.equal(sent.status, 201);
  assert.equal((await alex.get('/api/job-applications')).body.total, 1);
  assert.equal((await sara.get('/api/job-applications')).body.total, 1);
});

test('the dashboard counts come from the member\'s real records, whatever filter is used; filters and sorting work', async () => {
  clean();
  const alex = await loginAs('alex.morgan@example.com');
  const sara = await loginAs('sara.kim@example.com');
  await sara.post('/api/job-applications', manual({ title: 'Sara only' }));
  const rows = [['A1', 'applied', '2026-10-01'], ['A2', 'applied', '2026-10-05'], ['R1', 'reviewing', '2026-10-03'], ['I1', 'interview', '2026-10-09'], ['X1', 'rejected', '2026-09-20'], ['C1', 'accepted', '2026-10-02'], ['W1', 'withdrawn', '2026-10-04']];
  const ids = {};
  for (const [title, status, appliedOn] of rows) ids[title] = (await alex.post('/api/job-applications', manual({ title, url: `https://x.example/${title}`, status, appliedOn }))).body.application.id;
  const empty = (await browser().get('/api/job-applications')).status;
  assert.equal(empty, 401);
  const all = (await alex.get('/api/job-applications')).body;
  assert.deepEqual(all.summary, { total: 7, applied: 2, reviewing: 1, interview: 1, rejected: 1, accepted: 1, withdrawn: 1 });
  assert.equal(all.applications.length, 7);
  const titles = async (q = '') => (await alex.get(`/api/job-applications${q}`)).body.applications.map((a) => a.title);
  assert.deepEqual(await titles(), ['I1', 'A2', 'W1', 'R1', 'C1', 'A1', 'X1']); // newest application date first
  assert.deepEqual(await titles('?sort=applied&dir=asc'), ['X1', 'A1', 'C1', 'R1', 'W1', 'A2', 'I1']);
  assert.deepEqual(await titles('?status=applied&sort=applied&dir=asc'), ['A1', 'A2']);
  assert.deepEqual(await titles('?status=interview'), ['I1']);
  const filtered = (await alex.get('/api/job-applications?status=rejected')).body;
  assert.equal(filtered.total, 1);
  assert.equal(filtered.summary.total, 7); // the overview does not shrink when a filter is on
  // last updated sorting
  getDb().prepare("UPDATE job_applications SET updated_at = '2099-01-01T00:00:00.000Z' WHERE id = ?").run(ids.X1);
  assert.equal((await titles('?sort=updated'))[0], 'X1');
  assert.equal((await titles('?sort=updated&dir=asc')).at(-1), 'X1');
  assert.deepEqual(await titles('?q=a1'), ['A1']);
  // after a status change and a delete the numbers follow the records
  await alex.put(`/api/job-applications/${ids.A1}`, { status: 'interview' });
  await alex.del(`/api/job-applications/${ids.X1}`);
  assert.deepEqual((await alex.get('/api/job-applications')).body.summary, { total: 6, applied: 1, reviewing: 1, interview: 2, rejected: 0, accepted: 1, withdrawn: 1 });
  assert.deepEqual((await sara.get('/api/job-applications')).body.summary, { total: 1, applied: 1, reviewing: 0, interview: 0, rejected: 0, accepted: 0, withdrawn: 0 });
  for (const bad of ['?status=hired', '?sort=name', '?dir=up']) assert.equal((await alex.get(`/api/job-applications${bad}`)).status, 400, bad);
});

test('clicking Apply never creates an application: listing, detail and apply links are read-only and the application list stays empty', async () => {
  clean();
  const alex = await loginAs('alex.morgan@example.com');
  const list = (await alex.get('/api/jobs?pageSize=24')).body;
  const job = list.jobs.find((j) => j.title === 'Backend Developer');
  assert.equal(job.applyUrl, 'https://www.arbeitnow.com/jobs/dev-1'); // the original page, unchanged: opening it is a plain link with no ProConnect call
  await alex.get(`/api/jobs/${job.id}`);
  assert.equal(job.applicationId, null);
  assert.equal((await alex.get('/api/job-applications')).body.total, 0);
  assert.equal(getDb().prepare('SELECT COUNT(*) AS n FROM job_applications').get().n, 0);
  // saving a job is not applying for it either
  await alex.post('/api/saved-jobs', { jobId: job.id });
  assert.equal(getDb().prepare('SELECT COUNT(*) AS n FROM job_applications').get().n, 0);
  // there is no endpoint that submits to an employer
  assert.equal((await alex.post(`/api/jobs/${job.id}/apply`)).status, 404);
  assert.equal((await alex.post('/api/job-applications/submit', {})).status, 404);
});

test('the job details endpoint answers for stored listings and says job_not_found otherwise', async () => {
  const alex = await loginAs('alex.morgan@example.com');
  const r = await alex.get(`/api/jobs/${jobId('dev-1')}`);
  assert.equal(r.status, 200);
  assert.deepEqual([r.body.job.title, r.body.job.description, r.body.job.applyUrl], ['Backend Developer', 'Build APIs all day', 'https://www.arbeitnow.com/jobs/dev-1']);
  const gone = await alex.get('/api/jobs/999999');
  assert.deepEqual([gone.status, code(gone)], [404, 'job_not_found']);
  assert.equal((await alex.get('/api/jobs/abc')).status, 400);
  assert.equal((await browser().get(`/api/jobs/${jobId('dev-1')}`)).status, 401);
});

test('users removed from the system take their saved jobs and applications with them (foreign keys), nothing else', async () => {
  clean();
  const d = getDb();
  d.prepare("INSERT INTO users (name, email, password_hash, profile_completed) VALUES ('Temp Person', 'temp.person@example.com', 'x', 1)").run();
  const uid = d.prepare("SELECT id FROM users WHERE email = 'temp.person@example.com'").get().id;
  d.prepare("INSERT INTO saved_jobs (user_id, source, external_id, title, company) VALUES (?, 'arbeitnow', 'dev-1', 't', 'c')").run(uid);
  d.prepare("INSERT INTO job_applications (user_id, job_title, company, dup_key, applied_on, status) VALUES (?, 't', 'c', 'text:t|c', '2026-10-01', 'applied')").run(uid);
  d.prepare('DELETE FROM users WHERE id = ?').run(uid);
  assert.equal(d.prepare('SELECT COUNT(*) AS n FROM saved_jobs').get().n, 0);
  assert.equal(d.prepare('SELECT COUNT(*) AS n FROM job_applications').get().n, 0);
  assert.equal(d.prepare('SELECT COUNT(*) AS n FROM jobs').get().n, 3);
});

// ===================== Migration on an existing database =====================

test('opening a Part 17 database adds the new tables and keeps every existing record', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-p18-migrate-'));
  const dbFile = path.join(dir, 'old.db');
  const schema = fs.readFileSync(path.join(here, '..', 'src', 'db', 'schema.sql'), 'utf8');
  const marker = schema.indexOf('-- Saved Jobs (Part 18)');
  assert.ok(marker > 0);
  const part17 = schema.slice(0, marker); // exactly the schema before this part
  const script = `
    import { DatabaseSync } from 'node:sqlite';
    import fs from 'node:fs';
    const old = new DatabaseSync(${JSON.stringify(dbFile)});
    old.exec(fs.readFileSync(${JSON.stringify(path.join(dir, 'part17.sql'))}, 'utf8'));
    old.prepare("INSERT INTO users (name, email, password_hash, profile_completed) VALUES ('Old User', 'old@example.com', 'hash', 1)").run();
    old.prepare("INSERT INTO jobs (source, external_id, url, url_key, title, company, category, tags, first_seen_at, last_seen_at) VALUES ('muse', '1', 'https://www.themuse.com/jobs/a/b', 'themuse.com/jobs/a/b', 'Old job', 'Old Co', 'other', '[]', 't', 't')").run();
    old.close();
    const { getDb } = await import(${JSON.stringify(path.join(here, '..', 'src', 'db', 'index.js'))});
    const db = getDb();
    const tables = db.prepare("SELECT name FROM sqlite_master WHERE type = 'table'").all().map((r) => r.name);
    console.log(JSON.stringify({
      tables: ['saved_jobs', 'job_applications'].map((t) => tables.includes(t)),
      users: db.prepare('SELECT COUNT(*) AS n FROM users').get().n,
      email: db.prepare('SELECT email FROM users').get().email,
      jobs: db.prepare('SELECT title FROM jobs').all().map((j) => j.title),
    }));`;
  fs.writeFileSync(path.join(dir, 'part17.sql'), part17);
  fs.writeFileSync(path.join(dir, 'run.mjs'), script);
  const r = spawnSync(process.execPath, ['--disable-warning=ExperimentalWarning', path.join(dir, 'run.mjs')], { env: { ...process.env, PROCONNECT_DB: dbFile, JOBS_SYNC: 'off' }, encoding: 'utf8' });
  assert.equal(r.status, 0, r.stderr);
  assert.deepEqual(JSON.parse(r.stdout.trim().split('\n').pop()), { tables: [true, true], users: 1, email: 'old@example.com', jobs: ['Old job'] });
});
