// Part 5 backend tests: LinkedIn/GitHub profile links and the My Work portfolio. These are API/database tests (no browser).
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { DatabaseSync } from 'node:sqlite';

process.env.PROCONNECT_DB = ':memory:';
process.env.PROCONNECT_UPLOADS = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-profile-uploads-'));
process.env.PROCONNECT_TEST_ACCOUNTS_FILE = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'pc-profile-accts-')), 'accounts.json');

import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';

const { createApp } = await import('../src/app.js');
const { seedDatabase, DEMO_PASSWORD } = await import('../src/db/seed.js');
const { getDb } = await import('../src/db/index.js');
const { ensureTestAccounts, loadPasswords, TEST_ACCOUNTS } = await import('../src/db/testAccounts.js');
const { checkGithubProfile, checkGithubRepo, checkLinkedIn } = await import('../src/utils/links.js');

let server;
let base;
const passwords = loadPasswords();
const [MAYA, DANIEL, PRIYA, LUKAS, SOFIA] = TEST_ACCOUNTS.map((a) => a.email);

function browser() {
  let cookie = '';
  const request = async (method, p, body, raw) => {
    const res = await fetch(base + p, { method, headers: { ...(raw ? {} : { 'Content-Type': 'application/json' }), ...(cookie ? { Cookie: cookie } : {}) }, body: raw ? body : body ? JSON.stringify(body) : undefined });
    const set = res.headers.getSetCookie().map((c) => c.split(';')[0]).find((c) => c.startsWith('pc_token='));
    if (set) cookie = set === 'pc_token=' ? '' : set;
    const type = res.headers.get('content-type') || '';
    return { status: res.status, body: type.includes('json') ? await res.json() : null };
  };
  return { get: (p) => request('GET', p), post: (p, d) => request('POST', p, d), put: (p, d) => request('PUT', p, d), del: (p) => request('DELETE', p), upload: (p, form) => request('POST', p, form, true) };
}
async function signIn(email, password = passwords[email]) {
  const b = browser();
  const r = await b.post('/api/auth/login', { email, password });
  assert.equal(r.status, 200, `sign in as ${email}`);
  return b;
}
const db = () => getDb();
const row = (email) => db().prepare('SELECT * FROM users WHERE email = ?').get(email);

// 1x1 PNG
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mP8z8BQDwAEhQGAhKmMIQAAAABJRU5ErkJggg==', 'base64');
const png = (name = 'thumb.png') => { const f = new FormData(); f.append('image', new Blob([PNG], { type: 'image/png' }), name); return f; };

const profileBody = (user, extra = {}) => ({ profession: user.profession, headline: user.headline, bio: user.bio, skills: user.skills, location: user.location, yearsExperience: user.yearsExperience, ...extra });

let before5; // snapshot of the five accounts before any test touched them
before(async () => {
  seedDatabase();
  const created = ensureTestAccounts();
  assert.equal(created.created.length, 5);
  before5 = db().prepare(`SELECT id, email, password_hash, status, role FROM users WHERE email IN (${TEST_ACCOUNTS.map(() => '?').join(',')}) ORDER BY email`).all(...TEST_ACCOUNTS.map((a) => a.email)).map((r) => ({ ...r }));
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server.close());

// ====================================================================================
// LinkedIn and GitHub profile links
// ====================================================================================
test('link validators accept the right profile addresses and nothing else', () => {
  assert.deepEqual(checkLinkedIn('https://www.linkedin.com/in/jane-doe/'), { ok: true, value: 'https://www.linkedin.com/in/jane-doe' });
  assert.equal(checkLinkedIn('https://de.linkedin.com/in/jane').ok, true, 'legitimate subdomains');
  for (const bad of ['http://www.linkedin.com/in/jane', 'https://linkedin.com.evil.com/in/jane', 'https://evil.com/linkedin.com/in/jane', 'https://notlinkedin.com/in/jane', 'javascript:alert(1)', 'https://www.linkedin.com/company/acme', 'https://u:p@www.linkedin.com/in/jane', 'https://www.linkedin.com:8443/in/jane', 'linkedin.com/in/jane', 'https://www.linkedin.com/in/', 'ftp://www.linkedin.com/in/jane', 'data:text/html,hi', '']) {
    assert.equal(checkLinkedIn(bad).ok, false, `LinkedIn should reject ${bad}`);
  }
  assert.deepEqual(checkGithubProfile('https://github.com/octocat/'), { ok: true, value: 'https://github.com/octocat' });
  assert.equal(checkGithubProfile('https://www.github.com/octocat').ok, true);
  for (const bad of ['http://github.com/octocat', 'https://github.com/octocat/hello', 'https://github.com/settings', 'https://github.io/octocat', 'https://gist.github.com/octocat', 'https://github.com.evil.com/octocat', 'https://evil.com/github.com/octocat', 'javascript:alert(1)', 'https://github.com/-bad', 'https://github.com/']) {
    assert.equal(checkGithubProfile(bad).ok, false, `GitHub should reject ${bad}`);
  }
  assert.deepEqual(checkGithubRepo('https://github.com/octocat/Hello-World.git'), { ok: true, value: 'https://github.com/octocat/Hello-World' });
  for (const bad of ['https://github.com/octocat', 'https://github.com/octocat/hello/tree/main', 'https://gitlab.com/a/b', 'https://github.com/orgs/foo', 'http://github.com/a/b', 'javascript:alert(1)', 'https://github.com/a/..', 'https://github.com/a/b c']) {
    assert.equal(checkGithubRepo(bad).ok, false, `repository should reject ${bad}`);
  }
});

test('a member can save valid LinkedIn and GitHub links; they persist in the database and across sign-ins', async () => {
  const maya = await signIn(MAYA);
  const me = (await maya.get('/api/profile')).body.user;
  assert.equal(me.linkedinUrl, null, 'no link is invented for an existing account');
  assert.equal(me.githubUrl, null);

  const saved = await maya.put('/api/profile', profileBody(me, { linkedinUrl: 'https://www.linkedin.com/in/maya-chen/', githubUrl: 'https://github.com/maya-chen/' }));
  assert.equal(saved.status, 200);
  assert.equal(saved.body.user.linkedinUrl, 'https://www.linkedin.com/in/maya-chen');
  assert.equal(saved.body.user.githubUrl, 'https://github.com/maya-chen', 'normalized: no trailing slash');
  assert.equal(row(MAYA).linkedin_url, 'https://www.linkedin.com/in/maya-chen');
  assert.equal(row(MAYA).github_url, 'https://github.com/maya-chen');

  const again = await signIn(MAYA); // a brand-new session
  const profile = (await again.get('/api/profile')).body.user;
  assert.deepEqual([profile.linkedinUrl, profile.githubUrl], ['https://www.linkedin.com/in/maya-chen', 'https://github.com/maya-chen']);
  assert.equal((await again.get('/api/auth/me')).body.user.githubUrl, 'https://github.com/maya-chen');
});

test('invalid social links are rejected with a message and nothing is changed', async () => {
  const maya = await signIn(MAYA);
  const me = (await maya.get('/api/profile')).body.user;
  const bad = [
    ['linkedinUrl', 'javascript:alert(1)'], ['linkedinUrl', 'https://evil.com/in/maya'], ['linkedinUrl', 'http://www.linkedin.com/in/maya'], ['linkedinUrl', 'not a url'], ['linkedinUrl', 'https://github.com/maya-chen'],
    ['githubUrl', 'javascript:alert(1)'], ['githubUrl', 'https://gitlab.com/maya'], ['githubUrl', 'http://github.com/maya'], ['githubUrl', 'https://github.com/maya/repo'], ['githubUrl', 'https://www.linkedin.com/in/maya'], ['githubUrl', 'maya-chen'], ['githubUrl', 42],
  ];
  for (const [field, value] of bad) {
    const r = await maya.put('/api/profile', profileBody(me, { [field]: value }));
    assert.equal(r.status, 400, `${field}=${value}`);
    assert.ok(r.body.error.fields[field], `a message for ${field}`);
  }
  assert.match((await maya.put('/api/profile', profileBody(me, { githubUrl: 'https://gitlab.com/x' }))).body.error.fields.githubUrl, /github\.com\/your-username/);
  assert.equal(row(MAYA).github_url, 'https://github.com/maya-chen', 'the stored link is unchanged after rejected attempts');
  assert.equal(row(MAYA).linkedin_url, 'https://www.linkedin.com/in/maya-chen');
});

test('omitted keys keep the links, empty values remove them, and both are optional', async () => {
  const maya = await signIn(MAYA);
  const me = (await maya.get('/api/profile')).body.user;
  assert.equal((await maya.put('/api/profile', profileBody(me))).status, 200, 'saving without social keys (older clients, onboarding)');
  assert.equal(row(MAYA).github_url, 'https://github.com/maya-chen');
  const r = await maya.put('/api/profile', profileBody(me, { linkedinUrl: '   ', githubUrl: '' }));
  assert.equal(r.status, 200);
  assert.deepEqual([r.body.user.linkedinUrl, r.body.user.githubUrl], [null, null]);
  assert.deepEqual([row(MAYA).linkedin_url, row(MAYA).github_url], [null, null], 'NULL in the database, not an empty string');
  await maya.put('/api/profile', profileBody(me, { githubUrl: 'https://github.com/maya-chen', linkedinUrl: null }));
  assert.equal(row(MAYA).github_url, 'https://github.com/maya-chen');
  assert.equal(row(MAYA).linkedin_url, null);
});

test('another member sees the links on the profile (never the email); links can only be changed by their owner', async () => {
  const maya = await signIn(MAYA);
  const me = (await maya.get('/api/profile')).body.user;
  await maya.put('/api/profile', profileBody(me, { linkedinUrl: 'https://www.linkedin.com/in/maya-chen/' }));
  const daniel = await signIn(DANIEL);
  const view = await daniel.get(`/api/users/${me.id}`);
  assert.equal(view.body.user.linkedinUrl, 'https://www.linkedin.com/in/maya-chen');
  assert.equal(view.body.user.githubUrl, 'https://github.com/maya-chen');
  assert.ok(!('email' in view.body.user));
  const none = await daniel.get(`/api/users/${row(PRIYA).id}`);
  assert.deepEqual([none.body.user.linkedinUrl, none.body.user.githubUrl], [null, null], 'a member without links has none (nothing invented)');
  assert.equal((await browser().get(`/api/users/${me.id}`)).status, 401, 'visitors cannot read member profiles');

  // Daniel cannot reach Maya's profile through any parameter or payload
  const before = { ...row(MAYA) };
  const dp = (await daniel.get('/api/profile')).body.user;
  for (const extra of [{ id: me.id }, { userId: me.id }, { email: MAYA }, { user_id: me.id }]) {
    assert.equal((await daniel.put('/api/profile', profileBody(dp, { ...extra, githubUrl: 'https://github.com/daniel-hacks' }))).status, 200);
  }
  const mayaAfter = row(MAYA);
  assert.deepEqual([mayaAfter.github_url, mayaAfter.linkedin_url, mayaAfter.bio, mayaAfter.profession], [before.github_url, before.linkedin_url, before.bio, before.profession]);
  assert.equal(row(DANIEL).github_url, 'https://github.com/daniel-hacks', 'only his own row changed');
  assert.equal((await daniel.put(`/api/users/${me.id}`, { githubUrl: 'https://github.com/x' })).status, 404, 'there is no endpoint to edit another member');
  assert.equal((await daniel.put(`/api/profile/${me.id}`, { githubUrl: 'https://github.com/x' })).status, 404);
});

test('profile editing cannot grant roles, permissions or a Professional status; the status rules still hold', async () => {
  const sofia = await signIn(SOFIA);
  const me = (await sofia.get('/api/profile')).body.user;
  const r = await sofia.put('/api/profile', profileBody(me, { role: 'admin', isAdmin: true, status: 'professional', isOrganizer: true, is_organizer: 1, profileCompleted: false }));
  assert.equal(r.status, 200);
  const after = row(SOFIA);
  assert.deepEqual([after.role, after.status, after.is_organizer, after.profile_completed], ['member', 'student', 0, 1]);
  assert.equal((await sofia.put('/api/profile/status', { status: 'professional' })).status, 403);
  assert.equal((await sofia.put('/api/profile/status', { status: 'beginner' })).status, 200);
  assert.equal((await sofia.put('/api/profile/status', { status: 'student' })).status, 200);
  const priya = await signIn(PRIYA);
  assert.equal((await priya.put('/api/profile/status', { status: 'student' })).status, 403, 'an approved Professional cannot step down by themselves');
  assert.equal(row(PRIYA).status, 'professional');
  // existing validation of the original fields is intact
  assert.equal((await sofia.put('/api/profile', { profession: 'x', bio: 'short', skills: [] })).status, 400);
  const full = (await sofia.get('/api/profile')).body.user;
  assert.deepEqual([full.profession, full.skills.length > 0, !!full.bio], ['DevOps Engineer', true, true], 'the existing fields were not wiped by the new code');
});

// ====================================================================================
// My Work (portfolio projects)
// ====================================================================================
const project = (extra = {}) => ({ kind: 'project', title: 'Personal Portfolio Website', description: 'A responsive website showcasing my projects.', url: 'https://github.com/maya-chen/portfolio', technologies: ['HTML', 'CSS', 'JavaScript'], demoUrl: 'https://maya.example.dev/', ...extra });

test('a member creates a project; it is stored for that member and returned with the profile', async () => {
  const maya = await signIn(MAYA);
  const mayaId = row(MAYA).id;
  const r = await maya.post('/api/profile/items', project());
  assert.equal(r.status, 201);
  const it = r.body.item;
  assert.deepEqual([it.kind, it.title, it.url, it.technologies, it.demoUrl, it.imageUrl], ['project', 'Personal Portfolio Website', 'https://github.com/maya-chen/portfolio', ['HTML', 'CSS', 'JavaScript'], 'https://maya.example.dev', null]);
  const stored = db().prepare('SELECT * FROM profile_items WHERE id = ?').get(it.id);
  assert.equal(stored.user_id, mayaId);
  assert.equal(stored.kind, 'project');
  assert.equal(stored.url, 'https://github.com/maya-chen/portfolio');
  assert.equal(stored.tech, '["HTML","CSS","JavaScript"]');
  assert.equal(stored.demo_url, 'https://maya.example.dev');
  const profile = (await (await signIn(MAYA)).get('/api/profile')).body;
  assert.ok(profile.items.projects.some((p) => p.id === it.id));
  const seenByOther = (await (await signIn(DANIEL)).get(`/api/users/${mayaId}`)).body;
  assert.ok(seenByOther.items.projects.some((p) => p.id === it.id && p.technologies.length === 3), 'visible on the public profile');
});

test('only a title and a valid GitHub repository link are required; optional fields stay empty', async () => {
  const maya = await signIn(MAYA);
  const r = await maya.post('/api/profile/items', { kind: 'project', title: 'Minimal project', url: 'https://github.com/maya-chen/minimal' });
  assert.equal(r.status, 201);
  assert.deepEqual([r.body.item.description, r.body.item.technologies, r.body.item.demoUrl, r.body.item.imageUrl], [null, [], null, null]);
  assert.equal(JSON.stringify(r.body.item).includes('undefined'), false);
});

test('invalid project data and repository links are rejected', async () => {
  const maya = await signIn(MAYA);
  const count = () => db().prepare("SELECT COUNT(*) AS n FROM profile_items WHERE kind = 'project'").get().n;
  const before = count();
  for (const url of ['', 'javascript:alert(1)', 'https://example.com/a/b', 'https://gitlab.com/a/b', 'https://github.com/octocat', 'https://github.com/a/b/tree/main', 'http://github.com/a/b', 'https://github.com.evil.com/a/b', 'ftp://github.com/a/b', 'https://github.com/orgs/x', 'data:text/html,x']) {
    const r = await maya.post('/api/profile/items', project({ url }));
    assert.equal(r.status, 400, `repository ${url}`);
    assert.ok(r.body.error.fields.url, `message for ${url}`);
  }
  assert.ok((await maya.post('/api/profile/items', project({ title: '' }))).body.error.fields.title);
  assert.ok((await maya.post('/api/profile/items', project({ demoUrl: 'javascript:alert(1)' }))).body.error.fields.demoUrl);
  assert.ok((await maya.post('/api/profile/items', project({ technologies: Array.from({ length: 11 }, (_, i) => `T${i}`) }))).body.error.fields.technologies);
  assert.ok((await maya.post('/api/profile/items', project({ description: 'x'.repeat(501) }))).body.error.fields.description);
  assert.equal(count(), before, 'nothing was stored by the rejected requests');
});

test('a member updates their own project, including the repository link', async () => {
  const maya = await signIn(MAYA);
  const id = (await maya.post('/api/profile/items', project({ title: 'To be edited' }))).body.item.id;
  const r = await maya.put(`/api/profile/items/${id}`, { title: 'Edited title', description: 'New text', url: 'https://github.com/maya-chen/portfolio-v2', technologies: 'React, Vite', demoUrl: '' });
  assert.equal(r.status, 200);
  assert.deepEqual([r.body.item.title, r.body.item.url, r.body.item.technologies, r.body.item.demoUrl, r.body.item.kind], ['Edited title', 'https://github.com/maya-chen/portfolio-v2', ['React', 'Vite'], null, 'project']);
  assert.equal(db().prepare('SELECT url FROM profile_items WHERE id = ?').get(id).url, 'https://github.com/maya-chen/portfolio-v2');
  assert.equal((await maya.put(`/api/profile/items/${id}`, { title: 'Edited title', url: 'https://example.com/x' })).status, 400, 'cannot switch to a non-GitHub link');
  assert.equal(db().prepare('SELECT url FROM profile_items WHERE id = ?').get(id).url, 'https://github.com/maya-chen/portfolio-v2');
  const partial = await maya.put(`/api/profile/items/${id}`, { title: 'Only the title changed', url: 'https://github.com/maya-chen/portfolio-v2' });
  assert.deepEqual(partial.body.item.technologies, ['React', 'Vite'], 'technologies that are not sent are kept');
  assert.equal(partial.body.item.description, null, 'description is replaced by what was sent, as before Part 5');
});

test('a member deletes their own project; deleting twice reports not found', async () => {
  const maya = await signIn(MAYA);
  const id = (await maya.post('/api/profile/items', project({ title: 'To be deleted' }))).body.item.id;
  assert.equal((await maya.del(`/api/profile/items/${id}`)).status, 200);
  assert.equal(db().prepare('SELECT COUNT(*) AS n FROM profile_items WHERE id = ?').get(id).n, 0);
  assert.equal((await maya.del(`/api/profile/items/${id}`)).status, 404);
});

test('a member cannot edit, delete or add a thumbnail to another member\'s project', async () => {
  const maya = await signIn(MAYA);
  const daniel = await signIn(DANIEL);
  const id = (await maya.post('/api/profile/items', project({ title: 'Maya only' }))).body.item.id;
  const snapshot = { ...db().prepare('SELECT * FROM profile_items WHERE id = ?').get(id) };
  assert.equal((await daniel.put(`/api/profile/items/${id}`, { title: 'Hijacked', url: 'https://github.com/daniel/evil' })).status, 404);
  assert.equal((await daniel.del(`/api/profile/items/${id}`)).status, 404);
  assert.equal((await daniel.upload(`/api/profile/items/${id}/image`, png())).status, 404);
  assert.equal((await daniel.del(`/api/profile/items/${id}/image`)).status, 404);
  assert.equal((await browser().put(`/api/profile/items/${id}`, { title: 'visitor' })).status, 401);
  assert.equal((await browser().del(`/api/profile/items/${id}`)).status, 401);
  assert.deepEqual({ ...db().prepare('SELECT * FROM profile_items WHERE id = ?').get(id) }, snapshot, 'the project is exactly as it was');
  // Daniel's own projects are separate from Maya's
  const danielProject = (await daniel.post('/api/profile/items', project({ title: 'Daniel project', url: 'https://github.com/daniel-okoro/api' }))).body.item.id;
  assert.equal(db().prepare('SELECT user_id FROM profile_items WHERE id = ?').get(danielProject).user_id, row(DANIEL).id);
  const mine = (await maya.get('/api/profile')).body.items.projects;
  assert.ok(!mine.some((p) => p.id === danielProject), 'projects belong to the correct user');
});

test('optional thumbnail: real images only, replaceable, removable, and removed with the project', async () => {
  const maya = await signIn(MAYA);
  const id = (await maya.post('/api/profile/items', project({ title: 'With picture' }))).body.item.id;
  const bad = new FormData();
  bad.append('image', new Blob(['<script>alert(1)</script>'], { type: 'image/png' }), 'x.png');
  assert.equal((await maya.upload(`/api/profile/items/${id}/image`, bad)).status, 400, 'content is checked, not the claimed type');
  const ok = await maya.upload(`/api/profile/items/${id}/image`, png());
  assert.equal(ok.status, 200);
  assert.match(ok.body.item.imageUrl, /^\/api\/uploads\/[a-f0-9]{32}\.png$/);
  const file = db().prepare('SELECT image_file FROM profile_items WHERE id = ?').get(id).image_file;
  assert.ok(fs.existsSync(path.join(process.env.PROCONNECT_UPLOADS, file)));
  const replaced = await maya.upload(`/api/profile/items/${id}/image`, png('second.png'));
  assert.equal(fs.existsSync(path.join(process.env.PROCONNECT_UPLOADS, file)), false, 'the old file is deleted');
  const removed = await maya.del(`/api/profile/items/${id}/image`);
  assert.equal(removed.body.item.imageUrl, null);
  await maya.upload(`/api/profile/items/${id}/image`, png());
  const last = db().prepare('SELECT image_file FROM profile_items WHERE id = ?').get(id).image_file;
  await maya.del(`/api/profile/items/${id}`);
  assert.equal(fs.existsSync(path.join(process.env.PROCONNECT_UPLOADS, last)), false, 'deleting the project removes its image');
  assert.ok(replaced.status === 200);
  const exp = await maya.post('/api/profile/items', { kind: 'experience', title: 'A job' });
  assert.equal((await maya.upload(`/api/profile/items/${exp.body.item.id}/image`, png())).status, 404, 'only projects take a thumbnail');
});

test('older project links (saved before Part 5) are kept as they are and still editable', async () => {
  const alex = browser();
  assert.equal((await alex.post('/api/auth/login', { email: 'alex.morgan@example.com', password: DEMO_PASSWORD })).status, 200);
  const legacy = (await alex.get('/api/profile')).body.items.projects.find((p) => p.url === 'https://example.com/alexmorgan.design');
  assert.ok(legacy, 'the Part 1 demo project is still there');
  assert.deepEqual([legacy.technologies, legacy.demoUrl, legacy.imageUrl], [[], null, null]);
  const same = await alex.put(`/api/profile/items/${legacy.id}`, { title: 'Portfolio website (renamed)', url: legacy.url });
  assert.equal(same.status, 200, 'a title change keeps the older link untouched');
  assert.equal(same.body.item.url, 'https://example.com/alexmorgan.design');
  assert.equal(same.body.item.subtitle, legacy.subtitle, 'older fields that the new form does not send are preserved');
  assert.equal((await alex.put(`/api/profile/items/${legacy.id}`, { title: 'x', url: 'https://example.org/other' })).status, 400, 'a new non-GitHub link is refused');
  assert.equal((await alex.put(`/api/profile/items/${legacy.id}`, { title: 'x', url: 'https://github.com/alex/portfolio' })).status, 200);
});

test('experience and education entries behave as before', async () => {
  const maya = await signIn(MAYA);
  const e = await maya.post('/api/profile/items', { kind: 'experience', title: 'Intern', subtitle: 'Acme', period: '2025' });
  assert.equal(e.status, 201);
  assert.deepEqual([e.body.item.technologies, e.body.item.demoUrl], [[], null]);
  assert.equal((await maya.put(`/api/profile/items/${e.body.item.id}`, { title: 'Intern II', subtitle: 'Acme', period: '2026' })).body.item.title, 'Intern II');
  assert.equal((await maya.del(`/api/profile/items/${e.body.item.id}`)).status, 200);
});

// ====================================================================================
// Database migration and the five test accounts
// ====================================================================================
test('a database from Part 4 gains the new columns without losing data (real migration)', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-migrate-'));
  const file = path.join(dir, 'old.db');
  const old = new DatabaseSync(file);
  old.exec(`PRAGMA foreign_keys = ON;
    CREATE TABLE users (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE COLLATE NOCASE, password_hash TEXT NOT NULL, profession TEXT, headline TEXT, bio TEXT,
      skills TEXT NOT NULL DEFAULT '[]', location TEXT, years_experience INTEGER, avatar_file TEXT, profile_completed INTEGER NOT NULL DEFAULT 0,
      role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('member', 'admin')), status TEXT NOT NULL DEFAULT 'beginner', is_bot INTEGER NOT NULL DEFAULT 0, is_organizer INTEGER NOT NULL DEFAULT 0,
      created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')), updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')));
    CREATE TABLE profile_items (id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE, kind TEXT NOT NULL CHECK (kind IN ('experience', 'education', 'project')), title TEXT NOT NULL, subtitle TEXT, period TEXT, description TEXT, url TEXT);
    INSERT INTO users (name, email, password_hash, profession, bio, skills, profile_completed, status) VALUES ('Old User', 'old@example.com', 'hash-stays', 'Tester', 'An existing biography text', '["QA"]', 1, 'professional');
    INSERT INTO profile_items (user_id, kind, title, url) VALUES (1, 'project', 'Old project', 'https://example.com/old');`);
  old.close();
  const script = `import('${path.resolve('src/db/index.js').replace(/\\/g, '/')}').then(({ getDb }) => { const d = getDb();
    const cols = (t) => d.prepare('PRAGMA table_info(' + t + ')').all().map((c) => c.name);
    const u = d.prepare('SELECT * FROM users').get(); const p = d.prepare('SELECT * FROM profile_items').get();
    console.log(JSON.stringify({ userCols: cols('users'), itemCols: cols('profile_items'), u, p })); })`;
  const run = spawnSync(process.execPath, ['--disable-warning=ExperimentalWarning', '-e', script], { env: { ...process.env, PROCONNECT_DB: file }, encoding: 'utf8' });
  assert.equal(run.status, 0, run.stderr);
  const out = JSON.parse(run.stdout.trim().split('\n').pop());
  for (const c of ['linkedin_url', 'github_url']) assert.ok(out.userCols.includes(c), c);
  for (const c of ['tech', 'demo_url', 'image_file']) assert.ok(out.itemCols.includes(c), c);
  assert.deepEqual([out.u.name, out.u.password_hash, out.u.status, out.u.bio, out.u.linkedin_url, out.u.github_url], ['Old User', 'hash-stays', 'professional', 'An existing biography text', null, null]);
  assert.deepEqual([out.p.title, out.p.url, out.p.tech, out.p.demo_url, out.p.image_file], ['Old project', 'https://example.com/old', '[]', null, null]);
  const second = spawnSync(process.execPath, ['--disable-warning=ExperimentalWarning', '-e', script], { env: { ...process.env, PROCONNECT_DB: file }, encoding: 'utf8' });
  assert.equal(second.status, 0, 'running the migration again is harmless');
});

test('the five Part 3 test accounts are preserved (same ids, passwords, status, role) and are not duplicated', () => {
  const after = db().prepare(`SELECT id, email, password_hash, status, role FROM users WHERE email IN (${TEST_ACCOUNTS.map(() => '?').join(',')}) ORDER BY email`).all(...TEST_ACCOUNTS.map((a) => a.email)).map((r) => ({ ...r }));
  assert.deepEqual(after, before5);
  const again = ensureTestAccounts();
  assert.equal(again.created.length, 0);
  assert.equal(db().prepare("SELECT COUNT(*) AS n FROM users WHERE email LIKE '%@proconnect.example' AND email <> 'owner.admin@proconnect.example'").get().n >= 5, true);
  assert.equal(db().prepare("SELECT COUNT(*) AS n FROM users WHERE email IN (?, ?, ?, ?, ?)").get(MAYA, DANIEL, PRIYA, LUKAS, SOFIA).n, 5);
});
