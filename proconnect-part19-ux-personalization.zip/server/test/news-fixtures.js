// Builders for the response formats of the news sources. They are modelled on the documented/typical shapes
// (RSS 2.0 with media/dc/content namespaces, Atom, the Algolia Hacker News search and the DEV.to articles API).
// They are NOT captures of live responses: this sandbox could not reach the real sites. Dates are relative to the test clock.

const rfc822 = (ms) => new Date(ms).toUTCString();
const esc = (s) => String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

/** RSS 2.0 as TechCrunch / Ars Technica publish it. items: { id, title, link, at (ms), tags, html, image, creator } */
export function rssFeed(title, items) {
  const body = items
    .map(
      (i) => `    <item>
      <title><![CDATA[${i.title}]]></title>
      <link>${i.link}</link>
      <dc:creator><![CDATA[${i.creator || 'Staff Writer'}]]></dc:creator>
      <pubDate>${rfc822(i.at)}</pubDate>
      ${(i.tags || []).map((t) => `<category><![CDATA[${t}]]></category>`).join('\n      ')}
      <guid isPermaLink="false">${i.id}</guid>
      <description><![CDATA[${i.html ?? `<p>Summary for ${i.title}.</p>`}]]></description>
      ${i.image ? `<media:content url="${i.image}" medium="image" width="1024" height="683"/>` : ''}
    </item>`
    )
    .join('\n');
  return `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:content="http://purl.org/rss/1.0/modules/content/" xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:media="http://search.yahoo.com/mrss/" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>${esc(title)}</title>
    <link>https://example.org/</link>
    <description>Feed</description>
${body}
  </channel>
</rss>`;
}

export function atomFeed(items) {
  return `<?xml version="1.0" encoding="utf-8"?>
<feed xmlns="http://www.w3.org/2005/Atom">
  <title>Example Atom</title>
  ${items
    .map(
      (i) => `<entry>
    <id>${i.id}</id>
    <title type="html">${esc(i.title)}</title>
    <link rel="self" href="${i.link}.atom"/>
    <link rel="alternate" type="text/html" href="${i.link}"/>
    <published>${new Date(i.at).toISOString()}</published>
    <updated>${new Date(i.at).toISOString()}</updated>
    <category term="${i.tag || 'news'}"/>
    <summary type="html">${esc(i.html || `<p>Atom summary for ${i.title}</p>`)}</summary>
  </entry>`
    )
    .join('\n  ')}
</feed>`;
}

/** Algolia Hacker News search response (tags=front_page). */
export function hnResponse(hits) {
  return JSON.stringify({
    hits: hits.map((h) => ({
      created_at: new Date(h.at).toISOString(),
      title: h.title,
      url: h.url ?? null,
      author: 'someone',
      points: h.points ?? 100,
      story_text: h.story_text ?? null,
      num_comments: h.comments ?? 10,
      created_at_i: Math.floor(h.at / 1000),
      _tags: ['story', 'front_page'],
      objectID: String(h.id),
    })),
    nbHits: hits.length,
    page: 0,
    hitsPerPage: hits.length,
  });
}

/** DEV.to /api/articles response. */
export function devtoResponse(items) {
  return JSON.stringify(
    items.map((a) => ({
      type_of: 'article',
      id: a.id,
      title: a.title,
      description: a.description ?? `About ${a.title}`,
      readable_publish_date: 'Oct 27',
      url: a.url,
      comments_count: 3,
      public_reactions_count: 40,
      published_timestamp: new Date(a.at).toISOString(),
      cover_image: a.cover ?? null,
      social_image: a.social ?? 'https://media2.dev.to/social.png',
      canonical_url: a.canonical ?? a.url,
      published_at: new Date(a.at).toISOString(),
      tag_list: a.tags ?? ['webdev'],
      user: { name: 'Jane Dev', username: 'janedev' },
    }))
  );
}

export const HTML_PAGE = '<!DOCTYPE html><html><head><title>Not a feed</title></head><body>Hello</body></html>';
export const BROKEN_XML = '<?xml version="1.0"?><rss><channel><item><title>Broken</item></channel>';
export const DOCTYPE_XML = '<?xml version="1.0"?><!DOCTYPE rss [<!ENTITY a "aaaa">]><rss version="2.0"><channel><item><title>&a;</title></item></channel></rss>';
