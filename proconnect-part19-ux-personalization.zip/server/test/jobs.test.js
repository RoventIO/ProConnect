// Part 17 tests: Jobs (normalizers, sync engine, API) and the demo Courses & Webinars (seed, API, registration, migration).
// EVERY external job source is MOCKED here: no internet is used. The Arbeitnow fixtures copy the field layout of a live response
// that was inspected while building this part; the Muse fixtures follow The Muse's documented/OpenAPI field names. See README (Jobs).
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

process.env.PROCONNECT_DB = ':memory:';
process.env.JOBS_SYNC = 'off';
process.env.PROCONNECT_UPLOADS = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-jobs-uploads-'));

import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';

const { createApp } = await import('../src/app.js');
const { seedDatabase, DEMO_PASSWORD } = await import('../src/db/seed.js');
const { getDb } = await import('../src/db/index.js');
const { createJobsService, createJobsScheduler } = await import('../src/jobs/service.js');
const { configureJobsService } = await import('../src/jobs/index.js');
const { normalizeArbeitnow, normalizeMuse, safeSourceUrl } = await import('../src/jobs/normalize.js');
const { categoryFromText, CATEGORY_KEYS, JOB_CATEGORIES } = await import('../src/jobs/categories.js');
const { NewsError } = await import('../src/news/urls.js');
const { seedDemoCourses, DEMO_ANNOUNCEMENTS } = await import('../src/db/demoCourses.js');

const NOW = Date.parse('2026-11-02T10:00:00Z');
const unix = (iso) => Math.floor(Date.parse(iso) / 1000);
const silent = { info() {}, warn() {}, error() {} };
const settings = (over = {}) => ({
  enabled: true, intervalMinutes: 180, startupMinAgeMinutes: 60, manualMinAgeMinutes: 10, requestTimeoutMs: 1000, maxResponseBytes: 1e6,
  requestDelayMs: 0, arbeitnowMaxPages: 3, museMaxPagesPerCategory: 2, museMinRemaining: 25, museApiKey: '', retentionDays: 45, maxStored: 3000, userAgent: 't', ...over,
});

// ---- fixtures ----
const an = (slug, title, o = {}) => ({
  slug, company_name: o.company ?? 'Example GmbH', title, description: o.description ?? `<p>About <b>${title}</b></p><script>alert(1)</script>`, remote: o.remote ?? false,
  url: o.url ?? `https://www.arbeitnow.com/jobs/companies/example/${slug}`, tags: o.tags ?? [], job_types: o.job_types ?? [], location: o.location ?? 'Berlin',
  created_at: o.created_at ?? unix('2026-11-01T08:00:00Z'),
});
const arbeitnowPage = (items, next) => ({ data: items, links: { next: next ?? null } });
const muse = (id, name, categories, o = {}) => ({
  id, name, contents: o.contents ?? `<p>Join us as ${name}</p>`, publication_date: o.date ?? '2026-10-30T12:00:00Z', type: 'external',
  locations: (o.locations ?? ['New York, NY']).map((n) => ({ name: n })), categories: categories.map((n) => ({ name: n })),
  levels: (o.levels ?? ['Mid Level']).map((n) => ({ name: n, short_name: n.split(' ')[0].toLowerCase() })), tags: (o.tags ?? []).map((n) => ({ name: n })),
  refs: { landing_page: o.url ?? `https://www.themuse.com/jobs/acme/${id}` }, company: { id: 7, short_name: 'acme', name: o.company ?? 'Acme Inc' },
});
const musePage = (results, page = 0, page_count = 1) => ({ page, page_count, results });

/** A scripted fake network. `routes` maps a function(url) to a body, an Error to throw, or {body, headers}. */
function fakeNetwork(routeFn) {
  const calls = [];
  const fetchText = async (url) => {
    calls.push(url);
    const r = routeFn(new URL(url), calls.length);
    if (r instanceof Error) throw r;
    const body = r && r.body !== undefined ? r.body : r;
    return { text: typeof body === 'string' ? body : JSON.stringify(body), headers: r?.headers || {}, contentType: 'application/json', url };
  };
  return { fetchText, calls };
}
const netDown = () => new NewsError('network', 'The source could not be reached.');
const clock = (t = NOW) => ({ now: () => t });
const clearJobs = () => { getDb().exec('DELETE FROM jobs; DELETE FROM job_sources;'); };
const svc = (net, over = {}, t = NOW) => createJobsService({ db: () => getDb(), fetchText: net.fetchText, now: () => t, sleep: async () => {}, logger: silent, settings: settings(over) });
const count = (sql = 'SELECT COUNT(*) AS n FROM jobs', ...p) => getDb().prepare(sql).get(...p).n;

const ARBEITNOW_SAMPLE = [
  an('sdr-1', 'Sales Development Representative (SDR) - German speaking', { tags: ['Revenue'], job_types: ['Full Time'] }),
  an('ae-1', 'Account Executive (AE) | DACH (d/f/m)', { location: '🇩🇪 Berlin (hybrid)', tags: ['Go-to-Market'] }),
  an('sec-1', 'Senior Associate Information Security Consultant', { remote: true, job_types: ['Senior'], tags: ['Engineering'] }),
  an('iot-1', 'Senior IoT Engineer', { location: 'Munich', job_types: ['Fulltime permanent'] }),
  an('soc-1', 'Social Content Manager', { tags: ['Creative'], job_types: ['Part Time'] }),
  an('mw-1', 'Microwave Design Engineer', {}),
  an('fin-1', 'Teamleiter Finanzbuchhaltung & Controlling (m/w/d)', { location: 'Hamburg', job_types: ['Mid'] }),
  an('bar-1', 'Barista', { location: 'Vienna', job_types: ['Internship'] }),
];

// ================= categories and normalizers =================
test('the category system has the twelve required ProConnect fields', () => {
  assert.deepEqual(JOB_CATEGORIES.map((c) => c.label), [
    'IT & Software Engineering', 'Design & Creative', 'Marketing & Sales', 'Business & Management', 'Finance & Accounting', 'Education',
    'Healthcare', 'Engineering', 'Human Resources', 'Customer Support', 'Data Science & Analytics', 'Other',
  ]);
});

test('Arbeitnow listings are normalized and categorized by transparent rules (unknown -> other)', () => {
  const byslug = Object.fromEntries(ARBEITNOW_SAMPLE.map((i) => [i.slug, normalizeArbeitnow(i, NOW)]));
  const cat = (s) => byslug[s].category;
  assert.equal(cat('sdr-1'), 'marketing-sales');
  assert.equal(cat('ae-1'), 'marketing-sales');
  assert.equal(cat('sec-1'), 'it-software');
  assert.equal(cat('iot-1'), 'it-software');
  assert.equal(cat('soc-1'), 'marketing-sales');
  assert.equal(cat('mw-1'), 'engineering');
  assert.equal(cat('fin-1'), 'finance-accounting');
  assert.equal(cat('bar-1'), 'other');
  assert.match(byslug['bar-1'].categoryBasis, /No title keyword/);
  assert.match(byslug['ae-1'].categoryBasis, /Account Executive/i);
  assert.ok(Object.values(byslug).every((j) => CATEGORY_KEYS.includes(j.category)));
});

test('Arbeitnow: work mode, employment type, level, date, text and URL come only from the source data', () => {
  const j = (s) => normalizeArbeitnow(ARBEITNOW_SAMPLE.find((i) => i.slug === s), NOW);
  assert.equal(j('sec-1').workMode, 'remote');
  assert.equal(j('ae-1').workMode, 'hybrid');
  assert.equal(j('ae-1').location, '🇩🇪 Berlin');
  assert.equal(j('iot-1').workMode, 'on_site');
  assert.equal(j('sdr-1').employmentType, 'full_time');
  assert.equal(j('iot-1').employmentType, 'full_time');
  assert.equal(j('soc-1').employmentType, 'part_time');
  assert.equal(j('bar-1').employmentType, 'internship');
  assert.equal(j('sec-1').experienceLevel, 'senior');
  assert.equal(j('fin-1').experienceLevel, 'mid');
  assert.equal(j('mw-1').employmentType, null);
  assert.equal(j('mw-1').experienceLevel, null);
  assert.equal(j('sdr-1').publishedAt, '2026-11-01T08:00:00.000Z');
  assert.equal(j('sdr-1').url, 'https://www.arbeitnow.com/jobs/companies/example/sdr-1');
  assert.equal(j('sdr-1').logoUrl, null);
  assert.deepEqual(j('sdr-1').tags, ['Revenue']);
  assert.ok(!/[<>]|alert\(1\)/.test(j('sdr-1').summary) && !/[<>]/.test(j('sdr-1').descriptionText), 'markup and script are stripped to plain text');
  assert.equal(normalizeArbeitnow({ ...ARBEITNOW_SAMPLE[0], remote: undefined, location: 'X' }, NOW).workMode, null, 'an unknown mode stays unknown');
});

test('unusable or unsafe listings are refused instead of repaired', () => {
  const base = ARBEITNOW_SAMPLE[0];
  assert.equal(normalizeArbeitnow({ ...base, url: 'javascript:alert(1)' }, NOW), null);
  assert.equal(normalizeArbeitnow({ ...base, url: 'https://evil.example/apply' }, NOW), null, 'a link off the source domain is not accepted');
  assert.equal(normalizeArbeitnow({ ...base, url: 'http://www.arbeitnow.com/x' }, NOW), null, 'https only');
  assert.equal(normalizeArbeitnow({ ...base, url: 'https://user:pw@www.arbeitnow.com/x' }, NOW), null);
  assert.equal(normalizeArbeitnow({ ...base, title: '  ' }, NOW), null);
  assert.equal(normalizeArbeitnow({ ...base, company_name: '' }, NOW), null);
  assert.equal(normalizeArbeitnow({ ...base, slug: '' }, NOW), null);
  assert.equal(normalizeArbeitnow(null, NOW), null);
  assert.equal(normalizeArbeitnow({ ...base, created_at: unix('2031-01-01T00:00:00Z') }, NOW).publishedAt, null, 'a date in the future is dropped, not invented');
  assert.equal(normalizeArbeitnow({ ...base, created_at: 'soon' }, NOW).publishedAt, null);
  assert.equal(safeSourceUrl('https://www.themuse.com/jobs/a/b', 'muse'), 'https://www.themuse.com/jobs/a/b');
  assert.equal(safeSourceUrl('https://themuse.com.evil.example/jobs', 'muse'), null);
});

test('The Muse listings are normalized: mapped categories, honest "other", remote only when stated, internship from the level', () => {
  const n = (id, cats, o) => normalizeMuse(muse(id, `Role ${id}`, cats, o), NOW);
  assert.equal(n(1, ['Software Engineering']).category, 'it-software');
  assert.equal(n(2, ['Accounting and Finance']).category, 'finance-accounting');
  assert.equal(n(3, ['Healthcare']).category, 'healthcare');
  assert.equal(n(4, ['Education']).category, 'education');
  assert.equal(n(5, ['Data and Analytics']).category, 'data-science');
  assert.equal(n(6, ['Customer Service']).category, 'customer-support');
  assert.equal(n(7, ['Human Resources and Recruitment']).category, 'human-resources');
  assert.equal(n(8, ['Design and UX']).category, 'design-creative');
  assert.equal(n(9, ['Project Management']).category, 'business-management');
  assert.equal(n(10, ['Science and Engineering']).category, 'engineering');
  assert.equal(n(11, ['Retail']).category, 'other');
  assert.equal(n(12, ['Retail', 'Sales']).category, 'marketing-sales', 'the first mappable category wins');
  assert.equal(n(13, []).category, 'other');
  const remote = n(14, ['Sales'], { locations: ['Flexible / Remote'] });
  assert.equal(remote.workMode, 'remote');
  assert.equal(remote.location, 'Remote');
  const city = n(15, ['Sales'], { locations: ['Austin, TX', 'Denver, CO'] });
  assert.equal(city.workMode, null, 'The Muse has no on-site flag, so the mode stays unknown');
  assert.equal(city.location, 'Austin, TX; Denver, CO');
  const intern = n(16, ['Sales'], { levels: ['Internship'] });
  assert.equal(intern.employmentType, 'internship');
  assert.equal(intern.experienceLevel, null);
  assert.equal(n(17, ['Sales'], { levels: ['Senior Level'] }).experienceLevel, 'senior');
  assert.equal(n(18, ['Sales'], { levels: ['Entry Level'] }).experienceLevel, 'entry');
  assert.equal(n(19, ['Sales'], { levels: ['management'] }).experienceLevel, 'management');
  const j = n(20, ['Sales'], { tags: ['SQL', 'sql', 'Excel'] });
  assert.deepEqual(j.tags, ['SQL', 'Excel']);
  assert.equal(j.url, 'https://www.themuse.com/jobs/acme/20');
  assert.equal(j.externalId, '20');
  assert.equal(normalizeMuse(muse(21, 'X', ['Sales'], { url: 'https://example.com/x' }), NOW), null);
  assert.equal(normalizeMuse({ name: 'no id' }, NOW), null);
  assert.equal(categoryFromText('', []).key, 'other');
});

// ================= the sync engine =================
const bothSources = () =>
  fakeNetwork((u) => {
    if (u.hostname === 'www.arbeitnow.com') return arbeitnowPage(ARBEITNOW_SAMPLE);
    const cat = u.searchParams.get('category');
    return musePage(cat === 'Healthcare' ? [muse(100, 'Registered Nurse', ['Healthcare'], { company: 'CareCo' })] : cat === 'Education' ? [muse(200, 'High School Teacher', ['Education'], { locations: ['Flexible / Remote'] })] : []);
  });

test('both sources are fetched into one consistent format, with the source recorded', async () => {
  clearJobs();
  const net = bothSources();
  const run = await svc(net).run('test');
  assert.deepEqual(run.sources.map((s) => `${s.key}:${s.status}`), ['arbeitnow:ok', 'muse:ok']);
  assert.equal(count(), ARBEITNOW_SAMPLE.length + 2);
  assert.equal(count("SELECT COUNT(*) AS n FROM jobs WHERE source = 'muse'"), 2);
  const rows = getDb().prepare('SELECT * FROM jobs').all();
  assert.ok(rows.every((r) => r.title && r.company && /^https:\/\//.test(r.url) && r.url_key && CATEGORY_KEYS.includes(r.category) && Array.isArray(JSON.parse(r.tags))));
  const cats = new Set(rows.map((r) => r.category));
  for (const c of ['it-software', 'marketing-sales', 'finance-accounting', 'engineering', 'healthcare', 'education', 'other']) assert.ok(cats.has(c), `category ${c} is represented`);
  const st = getDb().prepare('SELECT * FROM job_sources ORDER BY key').all();
  assert.deepEqual(st.map((s) => [s.key, s.last_status]), [['arbeitnow', 'ok'], ['muse', 'ok']]);
  assert.ok(net.calls.filter((u) => u.includes('themuse.com')).every((u) => /[?&]page=\d/.test(u) && /category=/.test(u)));
});

test('running again creates no duplicates; changed text is refreshed; the same URL under a new id is not inserted twice', async () => {
  clearJobs();
  const net = bothSources();
  await svc(net).run('first');
  const before = count();
  const ids = getDb().prepare('SELECT id FROM jobs ORDER BY id').all().map((r) => r.id);
  const again = await svc(net, {}, NOW + 3600e3).run('second');
  assert.equal(count(), before);
  assert.deepEqual(getDb().prepare('SELECT id FROM jobs ORDER BY id').all().map((r) => r.id), ids, 'rows are kept, not recreated');
  assert.equal(again.sources[0].inserted, 0);
  assert.ok(again.sources[0].updated >= ARBEITNOW_SAMPLE.length);
  // same listing page, different slug => duplicate by URL
  const dup = fakeNetwork((u) => (u.hostname === 'www.arbeitnow.com' ? arbeitnowPage([{ ...ARBEITNOW_SAMPLE[0], slug: 'sdr-renamed' }]) : musePage([])));
  const r = await svc(dup, {}, NOW + 7200e3).run('dup');
  assert.equal(r.sources[0].inserted, 0);
  assert.equal(count("SELECT COUNT(*) AS n FROM jobs WHERE external_id = 'sdr-renamed'"), 0);
  // a duplicate inside one response
  clearJobs();
  const twice = fakeNetwork((u) => (u.hostname === 'www.arbeitnow.com' ? arbeitnowPage([ARBEITNOW_SAMPLE[0], ARBEITNOW_SAMPLE[0]]) : musePage([])));
  await svc(twice).run('x');
  assert.equal(count(), 1);
});

test('one failing source does not hurt the other, and stored listings survive every kind of failure', async () => {
  clearJobs();
  await svc(bothSources()).run('seed');
  const stored = count();
  const arbeitnowStored = count("SELECT COUNT(*) AS n FROM jobs WHERE source = 'arbeitnow'");
  // Arbeitnow down, Muse answers
  const half = fakeNetwork((u) => (u.hostname === 'www.arbeitnow.com' ? netDown() : musePage([muse(300, 'New Muse Job', ['Sales'])])));
  const r = await svc(half, {}, NOW + 3600e3).run('half');
  assert.equal(r.sources[0].status, 'error');
  assert.equal(r.sources[1].status, 'ok');
  assert.equal(count("SELECT COUNT(*) AS n FROM jobs WHERE source = 'arbeitnow'"), arbeitnowStored, 'Arbeitnow listings remain');
  assert.equal(count("SELECT COUNT(*) AS n FROM jobs WHERE external_id = '300'"), 1);
  assert.equal(getDb().prepare("SELECT last_status FROM job_sources WHERE key = 'arbeitnow'").get().last_status, 'error');
  // both down, plus bad payloads
  for (const bad of [netDown(), new NewsError('http', 'The source answered with HTTP 500.'), '<html>not json</html>', { unexpected: true }, { data: 'nope' }, new Error('boom')]) {
    const dead = fakeNetwork(() => bad);
    const run = await svc(dead, {}, NOW + 7200e3).run('dead');
    assert.deepEqual(run.sources.map((s) => s.status), ['error', 'error']);
    assert.equal(run.pruned, 0, 'nothing is pruned when no source delivered');
  }
  assert.equal(count(), stored + 1, 'all previously fetched jobs are still there');
  const msg = getDb().prepare("SELECT last_message FROM job_sources WHERE key = 'muse'").get().last_message;
  assert.ok(msg && !/boom|Error:|at .*\.js/.test(msg), 'error messages are short and contain no internals');
});

test('Muse paging: follows page_count, sends the key only when configured, and never records it', async () => {
  clearJobs();
  const net = fakeNetwork((u) => {
    if (u.hostname === 'www.arbeitnow.com') return arbeitnowPage([]);
    const page = Number(u.searchParams.get('page'));
    return u.searchParams.get('category') === 'Sales'
      ? musePage([muse(1000 + page, `Sales ${page}`, ['Sales'], { url: `https://www.themuse.com/jobs/a/s${page}` })], page, 5)
      : musePage([], 0, 1);
  });
  await svc(net, { museApiKey: 'SECRET-KEY-123', museMaxPagesPerCategory: 3 }).run('t');
  const salesCalls = net.calls.filter((u) => u.includes('category=Sales'));
  assert.deepEqual(salesCalls.map((u) => new URL(u).searchParams.get('page')), ['0', '1', '2'], 'pages start at 0 and stop at the limit');
  assert.ok(net.calls.filter((u) => u.includes('themuse.com')).every((u) => u.includes('api_key=SECRET-KEY-123')));
  assert.ok(net.calls.filter((u) => u.includes('arbeitnow')).every((u) => !u.includes('api_key')));
  assert.equal(count("SELECT COUNT(*) AS n FROM jobs WHERE source = 'muse'"), 3);
  assert.ok(!JSON.stringify(getDb().prepare('SELECT * FROM job_sources').all()).includes('SECRET-KEY'));
  // without a key nothing is added
  const noKey = fakeNetwork(() => musePage([]));
  await svc(noKey).run('t');
  assert.ok(noKey.calls.every((u) => !u.includes('api_key')));
});

test('Muse rate limits are respected: a low quota, an HTTP 403 and repeated failures all stop the requests early', async () => {
  clearJobs();
  const low = fakeNetwork((u) => (u.hostname === 'www.arbeitnow.com' ? arbeitnowPage([]) : { body: musePage([muse(1, 'A', ['Sales'])], 0, 9), headers: { 'x-ratelimit-remaining': '3' } }));
  const r1 = await svc(low).run('low');
  assert.equal(low.calls.filter((u) => u.includes('themuse')).length, 1);
  assert.equal(r1.sources[1].status, 'partial');
  assert.match(r1.sources[1].message, /3 requests left/);
  const forbidden = fakeNetwork((u) => (u.hostname === 'www.arbeitnow.com' ? arbeitnowPage([]) : new NewsError('http', 'The source answered with HTTP 403.')));
  const r2 = await svc(forbidden, {}, NOW + 1e6).run('403');
  assert.equal(forbidden.calls.filter((u) => u.includes('themuse')).length, 1, 'one refused request is enough');
  assert.equal(r2.sources[1].status, 'error');
  const flaky = fakeNetwork((u) => (u.hostname === 'www.arbeitnow.com' ? arbeitnowPage([]) : netDown()));
  await svc(flaky, {}, NOW + 2e6).run('down');
  assert.equal(flaky.calls.filter((u) => u.includes('themuse')).length, 3, 'stops after three failures in a row');
});

test('Arbeitnow paging only follows an https next link on its own host, up to the page limit', async () => {
  clearJobs();
  let n = 0;
  const net = fakeNetwork((u) => {
    if (u.hostname !== 'www.arbeitnow.com') return musePage([]);
    n++;
    return arbeitnowPage([an(`p${n}`, `Developer ${n}`)], n === 1 ? 'https://www.arbeitnow.com/api/job-board-api?page=2' : n === 2 ? 'https://evil.example/api?page=3' : null);
  });
  await svc(net).run('t');
  assert.equal(net.calls.filter((u) => u.includes('arbeitnow')).length, 2, 'the foreign link is ignored');
  assert.equal(count("SELECT COUNT(*) AS n FROM jobs WHERE source = 'arbeitnow'"), 2);
});

test('retention removes old listings only after a successful fetch', async () => {
  clearJobs();
  const old = an('old-1', 'Old Developer', { created_at: unix('2026-08-01T00:00:00Z') });
  const net = fakeNetwork((u) => (u.hostname === 'www.arbeitnow.com' ? arbeitnowPage([old, ARBEITNOW_SAMPLE[0]]) : musePage([])));
  // store while "now" is the same time the old job was published
  await svc(net, {}, Date.parse('2026-08-02T00:00:00Z')).run('a');
  assert.equal(count(), 2);
  await svc(fakeNetwork(() => netDown()), {}, NOW).run('down');
  assert.equal(count(), 2, 'a failed fetch prunes nothing');
  await svc(fakeNetwork((u) => (u.hostname === 'www.arbeitnow.com' ? arbeitnowPage([ARBEITNOW_SAMPLE[0]]) : musePage([]))), {}, NOW).run('ok');
  assert.equal(count("SELECT COUNT(*) AS n FROM jobs WHERE external_id = 'old-1'"), 0, 'the 3-month-old listing is pruned after a successful fetch');
  assert.equal(count(), 1);
});

test('freshness: a restart does not fetch again, overlapping runs are refused, the scheduler is registered once', async () => {
  clearJobs();
  const net = bothSources();
  const s = svc(net);
  await s.run('first');
  const calls = net.calls.length;
  const skipped = await s.run('startup', { minAgeMinutes: 60 });
  assert.deepEqual([skipped.skipped, skipped.reason], [true, 'fresh']);
  assert.equal(net.calls.length, calls, 'no request was made');
  const later = svc(net, {}, NOW + 61 * 60_000);
  assert.equal((await later.run('startup', { minAgeMinutes: 60 })).skipped, undefined, 'older than an hour: fetch again');
  // overlap
  let release;
  const gate = new Promise((r) => { release = r; });
  const slow = createJobsService({ db: () => getDb(), fetchText: async () => { await gate; return { text: JSON.stringify(arbeitnowPage([])), headers: {} }; }, now: () => NOW, sleep: async () => {}, logger: silent, settings: settings({ museMaxPagesPerCategory: 1 }) });
  const p1 = slow.run('a');
  assert.equal(slow.isRunning(), true);
  assert.deepEqual((await slow.run('b')).reason, 'already_running');
  release();
  await p1;
  assert.equal(slow.isRunning(), false);
  // scheduler
  const timers = { setIntervalFn: (fn, ms) => { timers.fn = fn; timers.ms = ms; timers.registered = (timers.registered || 0) + 1; return { unref() {} }; }, clearIntervalFn() { timers.cleared = true; } };
  const sched = createJobsScheduler({ service: svc(bothSources()), ...timers });
  await sched.start();
  sched.start();
  assert.equal(timers.registered, 1);
  assert.equal(timers.ms, 180 * 60_000);
  sched.stop();
  assert.equal(timers.cleared, true);
});

// ================= the HTTP API =================
let server;
let base;
before(async () => {
  seedDatabase();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server.close());

function browser() {
  let cookie = '';
  const call = async (method, p, body) => {
    const res = await fetch(base + p, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) }, body: body ? JSON.stringify(body) : undefined });
    const set = res.headers.getSetCookie().map((c) => c.split(';')[0]).find((c) => c.startsWith('pc_token='));
    if (set) cookie = set;
    return { status: res.status, body: await res.json() };
  };
  return { get: (p) => call('GET', p), post: (p, b) => call('POST', p, b), del: (p) => call('DELETE', p) };
}
const loginAs = async (email) => {
  const b = browser();
  assert.equal((await b.post('/api/auth/login', { email, password: DEMO_PASSWORD })).status, 200);
  return b;
};

test('the jobs API is for signed-in members only', async () => {
  assert.equal((await browser().get('/api/jobs')).status, 401);
  assert.equal((await browser().post('/api/jobs/refresh')).status, 401);
});

test('an empty job store gives an empty list (never made-up jobs) and reports the sources', async () => {
  clearJobs();
  const alex = await loginAs('alex.morgan@example.com');
  const { status, body } = await alex.get('/api/jobs');
  assert.equal(status, 200);
  assert.deepEqual([body.jobs.length, body.total, body.totalStored], [0, 0, 0]);
  assert.deepEqual(body.sources.map((s) => s.key), ['arbeitnow', 'muse']);
  assert.equal(body.facets.categories.length, 12);
});

test('search, every filter, sort order, paging and the Apply link work on the stored data', async () => {
  clearJobs();
  await svc(bothSources(), {}, NOW).run('fixture');
  const alex = await loginAs('alex.morgan@example.com');
  const get = async (q = '') => (await alex.get(`/api/jobs${q}`)).body;
  const all = await get('?pageSize=24');
  assert.equal(all.total, ARBEITNOW_SAMPLE.length + 2);
  // newest first
  const dates = all.jobs.map((j) => j.publishedAt || j.firstSeenAt);
  assert.deepEqual(dates, [...dates].sort().reverse());
  // shape and Apply
  const sdr = all.jobs.find((j) => j.title.startsWith('Sales Development'));
  assert.deepEqual(Object.keys(sdr).sort(), ['applicationId', 'applyUrl', 'category', 'company', 'employmentType', 'experienceLevel', 'firstSeenAt', 'id', 'location', 'logoUrl', 'publishedAt', 'savedId', 'source', 'summary', 'tags', 'title', 'workMode']);
  assert.equal(sdr.applyUrl, 'https://www.arbeitnow.com/jobs/companies/example/sdr-1', 'Apply is the original listing URL, unchanged');
  assert.deepEqual(sdr.source, { key: 'arbeitnow', name: 'Arbeitnow' });
  assert.equal(sdr.category.label, 'Marketing & Sales');
  assert.ok(all.jobs.every((j) => !/[<>]/.test(j.summary || '') && /^https:\/\//.test(j.applyUrl)));
  // search: title, company, keyword in description
  assert.equal((await get('?q=barista')).total, 1);
  assert.equal((await get('?q=CareCo')).jobs[0].title, 'Registered Nurse');
  assert.equal((await get('?q=about%20senior%20iot')).total, 1);
  assert.equal((await get('?q=zzzz-nothing')).total, 0);
  // category
  const mkt = await get('?category=marketing-sales');
  assert.equal(mkt.total, 3);
  assert.ok(mkt.jobs.every((j) => j.category.key === 'marketing-sales'));
  assert.equal((await get('?category=healthcare')).jobs[0].title, 'Registered Nurse');
  // location, mode, type, level, source
  assert.equal((await get('?location=munich')).total, 1);
  assert.deepEqual((await get('?mode=remote')).jobs.map((j) => j.workMode), ['remote', 'remote'].slice(0, (await get('?mode=remote')).total));
  assert.ok((await get('?mode=remote')).total >= 2 && (await get('?mode=hybrid')).total === 1);
  assert.equal((await get('?type=part_time')).total, 1);
  assert.equal((await get('?type=internship')).jobs[0].title, 'Barista');
  assert.equal((await get('?level=senior')).total, 1);
  assert.equal((await get('?source=muse')).total, 2);
  assert.equal((await get('?category=marketing-sales&mode=hybrid')).total, 1, 'filters combine');
  // facets only offer options that exist
  assert.equal(all.facets.modes.remote >= 2, true);
  assert.equal(all.facets.types.contract, undefined);
  assert.equal(all.facets.levels.management, undefined);
  assert.equal(all.facets.categories.find((c) => c.key === 'customer-support').count, 0);
  // paging
  const p1 = await get('?pageSize=4&page=1');
  const p3 = await get('?pageSize=4&page=3');
  assert.deepEqual([p1.jobs.length, p1.pageCount, p3.jobs.length], [4, 3, 2]);
  assert.equal(new Set([...p1.jobs, ...(await get('?pageSize=4&page=2')).jobs, ...p3.jobs].map((j) => j.id)).size, 10);
  assert.equal((await get('?pageSize=500')).pageSize, 24, 'page size is capped');
  // invalid values are rejected, not ignored
  for (const bad of ['category=nonsense', 'mode=moon', 'type=forever', 'level=god', 'source=other']) assert.equal((await alex.get(`/api/jobs?${bad}`)).status, 400, bad);
});

test('Refresh is for administrators; it starts a background fetch and respects the cooldown', async () => {
  clearJobs();
  const net = bothSources();
  configureJobsService({ db: () => getDb(), fetchText: net.fetchText, now: () => Date.now(), sleep: async () => {}, logger: silent, settings: settings() });
  const alex = await loginAs('alex.morgan@example.com');
  assert.equal((await alex.post('/api/jobs/refresh')).status, 403);
  const admin = await loginAs('admin@proconnect.example');
  const first = await admin.post('/api/jobs/refresh');
  assert.deepEqual([first.status, first.body.started], [202, true]);
  for (let i = 0; i < 50 && count() === 0; i++) await new Promise((r) => setTimeout(r, 20));
  await new Promise((r) => setTimeout(r, 50));
  assert.ok(count() > 0, 'listings arrived from the (mocked) sources');
  const second = await admin.post('/api/jobs/refresh');
  assert.deepEqual([second.status, second.body.started, second.body.reason], [202, false, 'fresh']);
  const list = (await admin.get('/api/jobs')).body;
  assert.equal(list.sources.every((s) => s.status === 'ok'), true);
  assert.ok(list.lastUpdated);
});

// ================= demo Courses & Webinars =================
test('the demo seed adds 11 clearly fictional, varied, future-dated announcements and is idempotent', async () => {
  const db = getDb();
  const before = db.prepare('SELECT * FROM courses WHERE seed_key IS NULL ORDER BY id').all();
  const userMade = db.prepare("INSERT INTO courses (title, description, type, category, organizer, is_free, is_sample, publisher_id) VALUES ('My own workshop', 'by a user', 'webinar', 'Writing', 'Me', 1, 0, 2)").run().lastInsertRowid;
  const first = seedDemoCourses({ now: NOW });
  assert.deepEqual([first.inserted, first.existing], [11, 0]);
  for (let i = 0; i < 3; i++) assert.deepEqual(Object.values(seedDemoCourses({ now: NOW + i * 1e6 })), [0, 11, 0]);
  const demo = db.prepare('SELECT * FROM courses WHERE seed_key IS NOT NULL').all();
  assert.equal(demo.length, 11);
  assert.ok(demo.length >= 8 && demo.length <= 12);
  assert.ok(demo.some((c) => c.type === 'course') && demo.some((c) => c.type === 'webinar'));
  assert.ok(new Set(demo.map((c) => c.category)).size >= 8, 'many professional fields');
  assert.ok(demo.every((c) => c.is_sample === 1 && c.instructor_name && c.instructor_role && c.delivery_mode && c.duration && c.image?.startsWith('/courses/') && c.description && c.external_url === null));
  assert.ok(demo.some((c) => c.is_free) && demo.some((c) => !c.is_free && /^\$\d+/.test(c.price_text)));
  assert.ok(demo.filter((c) => c.delivery_mode !== 'online').every((c) => c.location), 'in-person and hybrid listings have a location');
  assert.ok(demo.filter((c) => c.delivery_mode === 'online').every((c) => c.location === null));
  assert.ok(demo.every((c) => !c.starts_at || (Date.parse(c.starts_at) > NOW && Date.parse(c.registration_deadline) > NOW && Date.parse(c.registration_deadline) < Date.parse(c.starts_at))), 'no date has passed');
  assert.equal(demo.filter((c) => c.category === 'Programming & IT').length, 2, 'not everything is programming');
  // existing rows untouched
  const after = db.prepare('SELECT * FROM courses WHERE seed_key IS NULL AND id != ? ORDER BY id').all(userMade);
  assert.deepEqual(after, before);
  assert.equal(db.prepare('SELECT title FROM courses WHERE id = ?').get(userMade).title, 'My own workshop');
  // real images exist
  const publicDir = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', '..', 'client', 'public');
  for (const c of demo) if (fs.existsSync(publicDir)) assert.ok(fs.existsSync(path.join(publicDir, c.image)), `${c.image} exists`);
  // --refresh-dates moves only past demo dates, nothing else
  db.prepare("UPDATE courses SET starts_at = '2020-01-01T00:00:00.000Z' WHERE seed_key = 'demo-p17-human-resources-fundamentals'").run();
  db.prepare("UPDATE courses SET title = 'Edited by admin' WHERE seed_key = 'demo-p17-ui-ux-design-workshop'").run();
  const r = seedDemoCourses({ now: NOW, refreshDates: true });
  assert.equal(r.datesRefreshed, 1);
  assert.ok(Date.parse(db.prepare("SELECT starts_at FROM courses WHERE seed_key = 'demo-p17-human-resources-fundamentals'").get().starts_at) > NOW);
  assert.equal(db.prepare("SELECT title FROM courses WHERE seed_key = 'demo-p17-ui-ux-design-workshop'").get().title, 'Edited by admin', 'content edits are never overwritten');
  assert.equal(DEMO_ANNOUNCEMENTS.length, 11);
});

test('Courses API: new fields, search, category and format filters, options only for existing data', async () => {
  const alex = await loginAs('alex.morgan@example.com');
  const all = (await alex.get('/api/courses')).body;
  assert.ok(all.courses.length >= 17);
  const demo = all.courses.find((c) => c.title === 'Digital Marketing Strategy');
  assert.deepEqual([demo.instructorName, demo.deliveryMode, demo.isSample, demo.registrationKind], ['Maya Okafor', 'hybrid', true, 'demo']);
  assert.ok(demo.instructorRole && demo.location && demo.registrationDeadline && demo.image);
  assert.ok(all.facets.categories.some((c) => c.name === 'Human Resources') && all.facets.modes.in_person === 1);
  const old = all.courses.find((c) => c.title === 'Scaling Engineering Teams');
  assert.deepEqual([old.instructorName, old.deliveryMode, old.image], [null, null, null], 'earlier listings keep working with the new fields empty');
  const q = async (s) => (await alex.get(`/api/courses?${s}`)).body.courses;
  assert.equal((await q('type=webinar')).every((c) => c.type === 'webinar'), true);
  assert.ok((await q('type=course')).length >= 5 && (await q('type=webinar')).length >= 6);
  assert.deepEqual((await q('category=finance%20%26%20accounting')).map((c) => c.category).filter((v, i, a) => a.indexOf(v) === i), ['Finance & Accounting']);
  assert.deepEqual((await q('mode=in_person')).map((c) => c.title), ['Effective Communication Skills']);
  assert.ok((await q('mode=online')).length >= 7);
  assert.ok((await q('q=maya')).some((c) => c.title === 'Digital Marketing Strategy'), 'instructor names are searchable');
  assert.ok((await q('q=phishing')).some((c) => c.title === 'Practical Cybersecurity Awareness'));
  assert.ok((await q('price=free&mode=online&type=webinar')).every((c) => c.isFree && c.deliveryMode === 'online' && c.type === 'webinar'));
  assert.equal((await alex.get('/api/courses?mode=teleport')).status, 400);
  assert.equal((await browser().get('/api/courses')).status, 401);
});

test('demo registration: works on demo listings, is repeatable, cancellable, and refused where it makes no sense', async () => {
  const alex = await loginAs('alex.morgan@example.com');
  const sara = await loginAs('sara.kim@example.com');
  const demoId = getDb().prepare("SELECT id FROM courses WHERE seed_key = 'demo-p17-leadership-and-team-management'").get().id;
  assert.equal((await alex.get(`/api/courses/${demoId}`)).body.course.registered, false);
  const reg = await alex.post(`/api/courses/${demoId}/register`);
  assert.deepEqual([reg.status, reg.body.course.registered], [201, true]);
  assert.equal((await alex.post(`/api/courses/${demoId}/register`)).status, 201);
  assert.equal(getDb().prepare('SELECT COUNT(*) AS n FROM course_registrations WHERE course_id = ?').get(demoId).n, 1, 'registering twice stores one row');
  assert.equal((await alex.get(`/api/courses/${demoId}`)).body.course.registered, true);
  assert.equal((await sara.get(`/api/courses/${demoId}`)).body.course.registered, false, 'registration is per member');
  assert.equal((await alex.del(`/api/courses/${demoId}/register`)).body.course.registered, false);
  // closed: past deadline
  getDb().prepare("UPDATE courses SET registration_deadline = '2020-01-01T00:00:00.000Z' WHERE id = ?").run(demoId);
  const closed = await alex.post(`/api/courses/${demoId}/register`);
  assert.deepEqual([closed.status, closed.body.error?.code ?? closed.body.code], [400, 'registration_closed']);
  // a listing that is not demo content keeps its organizer's own link
  const real = getDb().prepare("INSERT INTO courses (title, description, type, category, organizer, is_free, external_url, is_sample) VALUES ('Real one', 'x', 'course', 'X', 'Org', 1, 'https://example.org/reg', 0)").run().lastInsertRowid;
  const refused = await alex.post(`/api/courses/${real}/register`);
  assert.equal(refused.status, 400);
  const detail = (await alex.get(`/api/courses/${real}`)).body.course;
  assert.deepEqual([detail.registrationKind, detail.externalUrl], ['external', 'https://example.org/reg']);
  assert.equal((await alex.post('/api/courses/999999/register')).status, 404);
  assert.equal((await browser().post(`/api/courses/${demoId}/register`)).status, 401);
});

test('permissions are unchanged: there is no route for members to publish courses or webinars', async () => {
  const alex = await loginAs('alex.morgan@example.com');
  const admin = await loginAs('admin@proconnect.example');
  for (const who of [alex, admin]) assert.ok([404, 405].includes((await who.post('/api/courses', { title: 'x', type: 'course' })).status));
});

test('migration and persistence: an older database keeps its data, gains the new columns, and the seed survives a restart', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-migrate-'));
  const dbFile = path.join(dir, 'old.db');
  const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
  const run = (code) => spawnSync(process.execPath, ['--disable-warning=ExperimentalWarning', '--input-type=module', '-e', code], { cwd: root, env: { ...process.env, PROCONNECT_DB: dbFile, JOBS_SYNC: 'off' }, encoding: 'utf8' });
  // 1. build a database the way Part 16 had it: create the current schema, then remove everything Part 17 added and add one user-made row
  const old = run(`
    const { getDb } = await import('./src/db/index.js');
    const d = getDb();
    d.exec('DROP INDEX IF EXISTS idx_courses_seed_key; DROP TABLE jobs; DROP TABLE job_sources; DROP TABLE course_registrations;');
    for (const c of ['instructor_name', 'instructor_role', 'delivery_mode', 'location', 'registration_deadline', 'image', 'seed_key']) d.exec('ALTER TABLE courses DROP COLUMN ' + c);
    d.exec("INSERT INTO courses (title, type, description, organizer, is_free) VALUES ('Old user course', 'course', 'keep me', 'Someone', 1)");
    const cols = d.prepare('PRAGMA table_info(courses)').all().map((c) => c.name);
    if (cols.includes('seed_key') || cols.includes('image')) throw new Error('the old schema was not reproduced');
  `);
  assert.equal(old.status, 0, old.stderr);
  // 2. open it with the new code (migration), seed twice
  const upgrade = run(`
    const { getDb } = await import('./src/db/index.js');
    const { seedDemoCourses } = await import('./src/db/demoCourses.js');
    const d = getDb();
    const cols = d.prepare('PRAGMA table_info(courses)').all().map((c) => c.name);
    const a = seedDemoCourses(); const b = seedDemoCourses();
    console.log(JSON.stringify({ cols, a, b, old: d.prepare("SELECT title, description FROM courses WHERE seed_key IS NULL").all(), total: d.prepare('SELECT COUNT(*) AS n FROM courses').get().n, tables: d.prepare("SELECT name FROM sqlite_master WHERE name IN ('jobs','job_sources','course_registrations')").all().length }));
  `);
  assert.equal(upgrade.status, 0, upgrade.stderr);
  const r = JSON.parse(upgrade.stdout.trim().split('\n').pop());
  for (const c of ['instructor_name', 'instructor_role', 'delivery_mode', 'location', 'registration_deadline', 'image', 'seed_key']) assert.ok(r.cols.includes(c), c);
  assert.deepEqual([r.a.inserted, r.b.inserted, r.b.existing], [11, 0, 11]);
  assert.deepEqual(r.old, [{ title: 'Old user course', description: 'keep me' }]);
  assert.equal(r.total, 12);
  assert.equal(r.tables, 3);
  // 3. "restart": a brand new process still sees everything, and seeding adds nothing
  const restart = run(`
    const { getDb } = await import('./src/db/index.js');
    const { seedDemoCourses } = await import('./src/db/demoCourses.js');
    console.log(JSON.stringify({ n: getDb().prepare('SELECT COUNT(*) AS n FROM courses WHERE seed_key IS NOT NULL').get().n, again: seedDemoCourses() }));
  `);
  assert.equal(restart.status, 0, restart.stderr);
  assert.deepEqual(JSON.parse(restart.stdout.trim().split('\n').pop()), { n: 11, again: { inserted: 0, existing: 11, datesRefreshed: 0 } });
});
