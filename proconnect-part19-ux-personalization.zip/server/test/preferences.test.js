// Part 19 tests: member preferences (GET/PUT /api/preferences), the additive `personal` block of GET /api/home, profile strength,
// community recommendations, sign-out and the additive migration. API level, throw-away in-memory database, no network.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

process.env.PROCONNECT_DB = ':memory:';
process.env.JOBS_SYNC = 'off';
process.env.NEWS_SYNC = 'off';
process.env.PROCONNECT_UPLOADS = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-p19-uploads-'));

import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';

const { createApp } = await import('../src/app.js');
const { seedDatabase, DEMO_PASSWORD } = await import('../src/db/seed.js');
const { getDb } = await import('../src/db/index.js');
const { recommendCommunities, professionTerms } = await import('../src/utils/recommend.js');
const { HOME_SECTION_KEYS } = await import('../src/utils/preferences.js');
const { CATEGORY_KEYS } = await import('../src/jobs/categories.js');

const here = path.dirname(fileURLToPath(import.meta.url));
let server;
let base;
before(async () => {
  seedDatabase();
  const d = getDb();
  const add = d.prepare(
    `INSERT INTO jobs (source, external_id, url, url_key, title, company, location, work_mode, category, employment_type, tags, summary, description_text, published_at, first_seen_at, last_seen_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '[]', ?, ?, ?, ?, ?)`
  );
  const t = '2026-10-30T10:00:00.000Z';
  add.run('arbeitnow', 'dev-1', 'https://www.arbeitnow.com/jobs/dev-1', 'arbeitnow.com/jobs/dev-1', 'Remote Backend Developer', 'Acme GmbH', 'Berlin', 'remote', 'it-software', 'full_time', 's', 'd', t, t, t);
  add.run('arbeitnow', 'dev-2', 'https://www.arbeitnow.com/jobs/dev-2', 'arbeitnow.com/jobs/dev-2', 'On-site Developer', 'Acme GmbH', 'Berlin', 'on_site', 'it-software', 'full_time', 's', 'd', t, t, t);
  add.run('muse', '4711', 'https://www.themuse.com/jobs/care/nurse', 'themuse.com/jobs/care/nurse', 'Remote Nurse', 'CareCo', 'Austin, TX', 'remote', 'healthcare', null, 's', 'd', t, t, t);
  add.run('muse', '4712', 'https://www.themuse.com/jobs/care/unknown-mode', 'themuse.com/jobs/care/unknown-mode', 'Mode Unknown', 'CareCo', 'Austin, TX', null, 'it-software', null, 's', 'd', t, t, t);
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server.close());

function browser() {
  let cookie = '';
  const call = async (method, p, body, raw) => {
    const res = await fetch(base + p, { method, headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) }, body: raw !== undefined ? raw : body !== undefined ? JSON.stringify(body) : undefined });
    const cookies = res.headers.getSetCookie();
    const set = cookies.map((c) => c.split(';')[0]).find((c) => c.startsWith('pc_token='));
    if (set) cookie = set === 'pc_token=' ? '' : set;
    return { status: res.status, body: await res.json(), headers: res.headers, setCookie: cookies };
  };
  return { get: (p) => call('GET', p), post: (p, b) => call('POST', p, b ?? {}), put: (p, b) => call('PUT', p, b), putRaw: (p, raw) => call('PUT', p, undefined, raw), has: () => !!cookie };
}
const loginAs = async (email) => {
  const b = browser();
  assert.equal((await b.post('/api/auth/login', { email, password: DEMO_PASSWORD })).status, 200);
  return b;
};
const uid = (email) => getDb().prepare('SELECT id FROM users WHERE email = ?').get(email).id;
const rowCount = (userId) => getDb().prepare('SELECT COUNT(*) AS n FROM user_preferences WHERE user_id = ?').get(userId).n;
const code = (r) => r.body.error?.code;
const SARA = 'sara.kim@example.com';
const ALEX = 'alex.morgan@example.com';
const DANIEL = 'daniel.reyes@example.com';

// ===================== Preferences API =====================

test('preferences need a signed-in member with a finished profile (401 / 403)', async () => {
  const v = browser();
  assert.equal((await v.get('/api/preferences')).status, 401);
  assert.equal((await v.put('/api/preferences', { theme: 'dark' })).status, 401);
  const n = browser();
  assert.equal((await n.post('/api/auth/register', { name: 'New Person', email: 'new.person@example.com', password: 'Password123!' })).status, 201);
  const r = await n.get('/api/preferences');
  assert.equal(r.status, 403);
  assert.equal(code(r), 'profile_incomplete');
  assert.equal((await n.put('/api/preferences', { theme: 'dark' })).status, 403);
});

test('a member who never saved anything gets safe defaults, and reading them creates no record', async () => {
  const b = await loginAs(DANIEL);
  const r = await b.get('/api/preferences');
  assert.equal(r.status, 200);
  assert.deepEqual(r.body.preferences, {
    theme: 'light', newsDefaultTab: 'all', jobCategory: null, jobWorkMode: null,
    homeSections: { newInCommunities: true, communitiesForYou: true, jobsForYou: true, jobSearch: true, registrations: true },
    persisted: false,
  });
  assert.equal(rowCount(uid(DANIEL)), 0, 'GET must not write anything');
  assert.match(r.headers.get('cache-control') || '', /no-store/);
});

test('a member can save each preference; the changes persist and one record exists per member', async () => {
  const b = await loginAs(SARA);
  let r = await b.put('/api/preferences', { theme: 'dark' });
  assert.equal(r.status, 200);
  assert.equal(r.body.preferences.theme, 'dark');
  assert.equal(r.body.preferences.persisted, true);
  assert.equal(r.body.preferences.newsDefaultTab, 'all', 'untouched preferences keep their defaults');

  await b.put('/api/preferences', { newsDefaultTab: 'for-you' });
  await b.put('/api/preferences', { jobCategory: 'it-software', jobWorkMode: 'remote' });
  await b.put('/api/preferences', { theme: 'system' });
  r = await b.get('/api/preferences');
  assert.deepEqual({ ...r.body.preferences, homeSections: undefined }, { theme: 'system', newsDefaultTab: 'for-you', jobCategory: 'it-software', jobWorkMode: 'remote', homeSections: undefined, persisted: true });
  assert.equal(rowCount(uid(SARA)), 1, 'four saves, still exactly one record');

  // a brand new session (a different "browser") sees the same stored preferences
  const again = await loginAs(SARA);
  assert.equal((await again.get('/api/preferences')).body.preferences.theme, 'system');
});

test('the three theme values are accepted and anything else is refused', async () => {
  const b = await loginAs(ALEX);
  for (const theme of ['light', 'dark', 'system']) assert.equal((await b.put('/api/preferences', { theme })).body.preferences.theme, theme);
  for (const bad of ['Dark', 'auto', '', null, 1, true, ['dark'], { a: 1 }, 'dark; DROP TABLE users']) {
    const r = await b.put('/api/preferences', { theme: bad });
    assert.equal(r.status, 400, JSON.stringify(bad));
    assert.equal(code(r), 'validation_error');
    assert.ok(r.body.error.fields.theme);
  }
  assert.equal((await b.get('/api/preferences')).body.preferences.theme, 'system', 'refused values change nothing');
});

test('strict whitelists: news tab, job category, work mode and Home sections', async () => {
  const b = await loginAs(ALEX);
  assert.equal((await b.put('/api/preferences', { newsDefaultTab: 'ai' })).status, 400, 'only All and For You can be the default tab');
  assert.equal((await b.put('/api/preferences', { newsDefaultTab: 'for-you' })).status, 200);
  assert.equal((await b.put('/api/preferences', { jobCategory: 'astronaut' })).status, 400);
  assert.equal((await b.put('/api/preferences', { jobCategory: '' })).status, 400, 'no preference is null, not an empty string');
  for (const k of CATEGORY_KEYS) assert.equal((await b.put('/api/preferences', { jobCategory: k })).status, 200, k);
  assert.equal((await b.put('/api/preferences', { jobWorkMode: 'office' })).status, 400);
  assert.equal((await b.put('/api/preferences', { jobWorkMode: 'on-site' })).status, 400, 'the stored value is on_site');
  for (const m of ['remote', 'hybrid', 'on_site']) assert.equal((await b.put('/api/preferences', { jobWorkMode: m })).status, 200, m);
  assert.equal((await b.put('/api/preferences', { homeSections: { nonsense: false } })).status, 400);
  assert.equal((await b.put('/api/preferences', { homeSections: { jobsForYou: 'no' } })).status, 400, 'values must be true or false');
  assert.equal((await b.put('/api/preferences', { homeSections: ['jobsForYou'] })).status, 400);
  assert.equal((await b.put('/api/preferences', { homeSections: null })).status, 400);
});

test('null clears a job preference', async () => {
  const b = await loginAs(ALEX);
  await b.put('/api/preferences', { jobCategory: 'design-creative', jobWorkMode: 'hybrid' });
  const r = await b.put('/api/preferences', { jobCategory: null, jobWorkMode: null });
  assert.equal(r.status, 200);
  assert.equal(r.body.preferences.jobCategory, null);
  assert.equal(r.body.preferences.jobWorkMode, null);
});

test('unknown properties are refused, never stored (no arbitrary data, no way to touch other fields)', async () => {
  const b = await loginAs(ALEX);
  for (const body of [{ role: 'admin' }, { userId: 1 }, { user_id: 1 }, { theme: 'dark', extra: 1 }, { isAdmin: true }, { password: 'x' }, { updated_at: 'x' }, { persisted: false }]) {
    const r = await b.put('/api/preferences', body);
    assert.equal(r.status, 400, JSON.stringify(body));
    assert.equal(code(r), 'validation_error');
  }
  // a __proto__ key arrives as an ordinary own property of the parsed JSON; it must be refused as well
  const proto = await b.putRaw('/api/preferences', '{"__proto__":{"theme":"dark"}}');
  assert.equal(proto.status, 400);
  assert.equal(({}).theme, undefined, 'nothing leaked onto Object.prototype');
  assert.equal(getDb().prepare('SELECT role FROM users WHERE email = ?').get(ALEX).role, 'member');
});

test('a request with one bad field saves none of its fields', async () => {
  const b = await loginAs(ALEX);
  await b.put('/api/preferences', { theme: 'light', jobWorkMode: null });
  const r = await b.put('/api/preferences', { theme: 'dark', jobWorkMode: 'nowhere' });
  assert.equal(r.status, 400);
  assert.ok(r.body.error.fields.jobWorkMode);
  assert.ok(!r.body.error.fields.theme);
  assert.equal((await b.get('/api/preferences')).body.preferences.theme, 'light');
});

test('the body must be a JSON object', async () => {
  const b = await loginAs(ALEX);
  for (const raw of ['[]', '"dark"', '5', 'null']) assert.equal((await b.putRaw('/api/preferences', raw)).status, 400, raw);
  const bad = await b.putRaw('/api/preferences', '{not json');
  assert.equal(bad.status, 400);
  assert.ok(bad.body.error, 'errors keep the usual { error } shape');
});

test('Home sections: hide and show individually, others keep their state', async () => {
  const b = await loginAs(ALEX);
  await b.put('/api/preferences', { homeSections: { newInCommunities: true, communitiesForYou: true, jobsForYou: true, jobSearch: true, registrations: true } });
  let r = await b.put('/api/preferences', { homeSections: { jobsForYou: false, registrations: false } });
  assert.deepEqual(r.body.preferences.homeSections, { newInCommunities: true, communitiesForYou: true, jobsForYou: false, jobSearch: true, registrations: false });
  r = await b.put('/api/preferences', { homeSections: { jobsForYou: true } });
  assert.deepEqual(r.body.preferences.homeSections, { newInCommunities: true, communitiesForYou: true, jobsForYou: true, jobSearch: true, registrations: false });
  assert.deepEqual(Object.keys(r.body.preferences.homeSections), HOME_SECTION_KEYS);
  const stored = JSON.parse(getDb().prepare('SELECT home_hidden FROM user_preferences WHERE user_id = ?').get(uid(ALEX)).home_hidden);
  assert.deepEqual(stored, ['registrations']);
});

test('preferences are private: each member only ever reads and writes their own', async () => {
  const a = await loginAs(ALEX);
  const s = await loginAs(SARA);
  await a.put('/api/preferences', { theme: 'dark', newsDefaultTab: 'for-you', jobCategory: 'design-creative', jobWorkMode: 'hybrid' });
  await s.put('/api/preferences', { theme: 'light', newsDefaultTab: 'all', jobCategory: 'it-software', jobWorkMode: 'remote' });
  assert.equal((await a.get('/api/preferences')).body.preferences.jobCategory, 'design-creative');
  assert.equal((await s.get('/api/preferences')).body.preferences.jobCategory, 'it-software');
  // there is no id in the URL, and an id in the body is refused
  assert.equal((await s.put('/api/preferences', { userId: uid(ALEX), theme: 'dark' })).status, 400);
  assert.equal((await a.get('/api/preferences')).body.preferences.theme, 'dark');
  assert.equal((await s.get(`/api/preferences/${uid(ALEX)}`)).status, 404);
  assert.equal((await s.get(`/api/preferences?userId=${uid(ALEX)}`)).body.preferences.jobCategory, 'it-software', 'a query string cannot select another member');
});

test('the database itself refuses invalid values, and removing a member removes their preferences', () => {
  const d = getDb();
  const id = d.prepare("INSERT INTO users (name, email, password_hash) VALUES ('Temp', 'temp.pref@example.com', 'x')").run().lastInsertRowid;
  assert.throws(() => d.prepare("INSERT INTO user_preferences (user_id, theme) VALUES (?, 'purple')").run(id), /CHECK|constraint/i);
  assert.throws(() => d.prepare("INSERT INTO user_preferences (user_id, news_default_tab) VALUES (?, 'ai')").run(id), /CHECK|constraint/i);
  assert.throws(() => d.prepare("INSERT INTO user_preferences (user_id, job_work_mode) VALUES (?, 'office')").run(id), /CHECK|constraint/i);
  assert.throws(() => d.prepare("INSERT INTO user_preferences (user_id) VALUES (999999)").run(), /FOREIGN|constraint/i, 'a record needs an existing member');
  d.prepare('INSERT INTO user_preferences (user_id, theme) VALUES (?, ?)').run(id, 'dark');
  assert.throws(() => d.prepare('INSERT INTO user_preferences (user_id) VALUES (?)').run(id), /UNIQUE|constraint/i, 'one record per member');
  d.prepare('DELETE FROM users WHERE id = ?').run(id);
  assert.equal(rowCount(id), 0);
});

// ===================== Home: the additive `personal` block =====================

test('GET /api/home keeps every earlier field and adds `personal`; visitors still get 401', async () => {
  assert.equal((await browser().get('/api/home')).status, 401);
  const b = await loginAs(SARA);
  const r = await b.get('/api/home');
  assert.equal(r.status, 200);
  for (const k of ['trending', 'courses', 'popularCommunities']) assert.ok(Array.isArray(r.body[k]), k);
  assert.ok(r.body.trending.length > 0);
  assert.deepEqual(Object.keys(r.body.trending[0]).sort(), ['author', 'community', 'createdAt', 'id', 'replyCount', 'title']);
  assert.deepEqual(Object.keys(r.body.personal).sort(), ['communitiesForYou', 'jobSearch', 'jobsForYou', 'newInCommunities', 'profile', 'registrations']);
  assert.match(r.headers.get('cache-control') || '', /no-store/);
});

test('profile strength is calculated from real profile data', async () => {
  const d = getDb();
  const id = d.prepare("INSERT INTO users (name, email, password_hash, profession, bio, skills, profile_completed) VALUES ('Min Imal', 'min.imal@example.com', ?, 'Accountant', 'I count.', '[\"Excel\"]', 1)")
    .run((await import('bcryptjs')).default.hashSync(DEMO_PASSWORD, 4)).lastInsertRowid;
  const b = await loginAs('min.imal@example.com');
  const strength = async () => (await b.get('/api/home')).body.personal.profile.completion;
  let c = await strength();
  const done = (x) => x.items.filter((i) => i.done).map((i) => i.key).sort();
  assert.deepEqual(done(c), ['bio', 'profession']);
  assert.equal(c.total, 12);
  assert.equal(c.percent, Math.round((2 / 12) * 100));
  assert.ok(c.items.every((i) => typeof i.label === 'string' && i.href.startsWith('/')), 'every item says where to finish it');

  d.prepare("UPDATE users SET headline = 'Numbers person', location = 'Gyumri', years_experience = 0, skills = '[\"Excel\",\"SQL\",\"Audit\"]', linkedin_url = 'https://www.linkedin.com/in/x/', avatar_file = 'x.png' WHERE id = ?").run(id);
  d.prepare("INSERT INTO profile_items (user_id, kind, title) VALUES (?, 'experience', 'Accountant')").run(id);
  d.prepare("INSERT INTO profile_items (user_id, kind, title) VALUES (?, 'education', 'BA')").run(id);
  d.prepare("INSERT INTO profile_items (user_id, kind, title, url) VALUES (?, 'project', 'Ledger', 'https://github.com/a/b')").run(id);
  c = await strength();
  assert.deepEqual(done(c), ['bio', 'education', 'experience', 'experience-years', 'headline', 'links', 'location', 'photo', 'profession', 'project', 'skills'].sort());
  assert.equal(c.percent, Math.round((11 / 12) * 100));
  const community = d.prepare('SELECT id FROM communities WHERE parent_id IS NULL LIMIT 1').get().id;
  d.prepare('INSERT INTO memberships (user_id, community_id) VALUES (?, ?)').run(id, community);
  c = await strength();
  assert.equal(c.percent, 100);
  assert.equal(c.completed, c.total);
});

test('New in Your Communities: joined communities and their subcommunities only, newest first, not the member\'s own posts', async () => {
  const d = getDb();
  const sara = uid(SARA);
  const alex = uid(ALEX);
  const dev = d.prepare("SELECT id FROM communities WHERE name = 'Software Development'").get().id;
  const backend = d.prepare("SELECT id FROM communities WHERE name = 'Backend' AND parent_id = ?").get(dev).id;
  const health = d.prepare("SELECT id FROM communities WHERE name = 'Healthcare Professionals'").get().id;
  const post = d.prepare('INSERT INTO posts (author_id, community_id, title, content, created_at) VALUES (?, ?, ?, ?, ?)');
  post.run(alex, dev, 'P19 main community post', 'x', '2099-01-01T10:00:00.000Z');
  post.run(alex, backend, 'P19 subcommunity post', 'x', '2099-01-01T11:00:00.000Z');
  post.run(alex, health, 'P19 not joined', 'x', '2099-01-01T12:00:00.000Z');
  post.run(sara, dev, 'P19 own post', 'x', '2099-01-01T13:00:00.000Z');

  const b = await loginAs(SARA);
  const n = (await b.get('/api/home')).body.personal.newInCommunities;
  assert.ok(n.joinedCount >= 1);
  const titles = n.items.map((i) => i.title);
  assert.deepEqual(titles.slice(0, 2), ['P19 subcommunity post', 'P19 main community post'], 'newest first');
  assert.ok(!titles.includes('P19 not joined'), 'a community the member did not join is not included');
  assert.ok(!titles.includes('P19 own post'), 'the member\'s own posts are left out');
  const sub = n.items.find((i) => i.title === 'P19 subcommunity post');
  assert.equal(sub.community.name, 'Backend');
  assert.equal(sub.parentCommunity.name, 'Software Development', 'subcommunity posts name their main community');
  assert.equal(n.items.find((i) => i.title === 'P19 main community post').parentCommunity, null);
  assert.ok(n.items.length <= 5);

  // a member who joined nothing gets an honest empty list, not filler
  const lonely = d.prepare("INSERT INTO users (name, email, password_hash, profession, bio, skills, profile_completed) VALUES ('No Joins', 'no.joins@example.com', ?, 'Writer', 'b', '[]', 1)")
    .run((await import('bcryptjs')).default.hashSync(DEMO_PASSWORD, 4)).lastInsertRowid;
  assert.ok(lonely);
  const l = await loginAs('no.joins@example.com');
  const none = (await l.get('/api/home')).body.personal.newInCommunities;
  assert.deepEqual(none, { joinedCount: 0, items: [] });
});

test('Jobs for You uses the saved category and work mode, with the same listings and shape as /api/jobs', async () => {
  const b = await loginAs(DANIEL);
  const empty = (await b.get('/api/home')).body.personal.jobsForYou;
  assert.deepEqual(empty, { hasPreferences: false, category: null, workMode: null, total: 0, items: [] }, 'no preferences: nothing is guessed');

  await b.put('/api/preferences', { jobCategory: 'it-software', jobWorkMode: 'remote' });
  let j = (await b.get('/api/home')).body.personal.jobsForYou;
  assert.equal(j.hasPreferences, true);
  assert.deepEqual(j.category, { key: 'it-software', label: 'IT & Software Engineering' });
  assert.equal(j.workMode, 'remote');
  assert.deepEqual(j.items.map((x) => x.title), ['Remote Backend Developer'], 'category AND work mode');
  assert.equal(j.total, 1);
  const viaJobsApi = (await b.get('/api/jobs?category=it-software&mode=remote')).body.jobs;
  assert.deepEqual(j.items, viaJobsApi, 'identical to what the Jobs page receives');
  assert.ok('savedId' in j.items[0] && 'applicationId' in j.items[0]);

  await b.put('/api/preferences', { jobWorkMode: null });
  j = (await b.get('/api/home')).body.personal.jobsForYou;
  assert.deepEqual(j.items.map((x) => x.title).sort(), ['Mode Unknown', 'On-site Developer', 'Remote Backend Developer']);
  await b.put('/api/preferences', { jobCategory: null, jobWorkMode: 'remote' });
  j = (await b.get('/api/home')).body.personal.jobsForYou;
  assert.deepEqual(j.items.map((x) => x.title).sort(), ['Remote Backend Developer', 'Remote Nurse']);
  await b.put('/api/preferences', { jobCategory: 'finance-accounting', jobWorkMode: 'hybrid' });
  j = (await b.get('/api/home')).body.personal.jobsForYou;
  assert.deepEqual({ total: j.total, items: j.items }, { total: 0, items: [] }, 'preferences with no match: an empty list');
});

test('Your Job Search counts the member\'s own saved jobs and applications only', async () => {
  const d = getDb();
  const a = await loginAs(ALEX);
  const s = await loginAs(SARA);
  d.exec('DELETE FROM saved_jobs; DELETE FROM job_applications;');
  assert.deepEqual((await a.get('/api/home')).body.personal.jobSearch, { savedCount: 0, applications: { total: 0, applied: 0, reviewing: 0, interview: 0, accepted: 0, rejected: 0, withdrawn: 0 } });
  const jobId = d.prepare("SELECT id FROM jobs WHERE external_id = 'dev-1'").get().id;
  assert.equal((await a.post('/api/saved-jobs', { jobId })).status, 201);
  assert.equal((await a.post('/api/job-applications', { title: 'Designer', company: 'Studio', appliedOn: new Date().toISOString().slice(0, 10), status: 'interview' })).status, 201);
  const mine = (await a.get('/api/home')).body.personal.jobSearch;
  assert.equal(mine.savedCount, 1);
  assert.equal(mine.applications.total, 1);
  assert.equal(mine.applications.interview, 1);
  const theirs = (await s.get('/api/home')).body.personal.jobSearch;
  assert.equal(theirs.savedCount, 0);
  assert.equal(theirs.applications.total, 0);
  d.exec('DELETE FROM saved_jobs; DELETE FROM job_applications;');
});

test('Your Registrations lists only the member\'s own upcoming registrations; nothing is invented', async () => {
  const d = getDb();
  const alex = uid(ALEX);
  const sara = uid(SARA);
  const course = d.prepare("INSERT INTO courses (title, description, type, category, organizer, is_free, starts_at, is_sample) VALUES (?, 'x', ?, 'Design', 'Org', 1, ?, 1)");
  const future1 = course.run('P19 later webinar', 'webinar', '2099-03-01T10:00:00.000Z').lastInsertRowid;
  const future2 = course.run('P19 sooner course', 'course', '2099-02-01T10:00:00.000Z').lastInsertRowid;
  const past = course.run('P19 past event', 'webinar', '2020-01-01T10:00:00.000Z').lastInsertRowid;
  const notRegistered = course.run('P19 not registered', 'course', '2099-01-01T10:00:00.000Z').lastInsertRowid;
  const reg = d.prepare('INSERT INTO course_registrations (user_id, course_id) VALUES (?, ?)');
  for (const c of [future1, future2, past]) reg.run(alex, c);
  reg.run(sara, notRegistered);

  const a = await loginAs(ALEX);
  const r = (await a.get('/api/home')).body.personal.registrations;
  assert.deepEqual(r.items.map((c) => c.title), ['P19 sooner course', 'P19 later webinar'], 'upcoming only, soonest first');
  assert.equal(r.total, 2);
  assert.ok(r.items.every((c) => c.registered === true && c.isSample === true));
  const s = await loginAs(SARA);
  assert.deepEqual((await s.get('/api/home')).body.personal.registrations.items.map((c) => c.title), ['P19 not registered'], 'another member\'s registrations are not shown');
  const d2 = await loginAs(DANIEL);
  assert.deepEqual((await d2.get('/api/home')).body.personal.registrations, { total: 0, items: [] });
  d.exec("DELETE FROM course_registrations; DELETE FROM courses WHERE title LIKE 'P19 %'");
});

// ===================== Community recommendations =====================

test('professionTerms keeps meaningful words and drops generic seniority words', () => {
  assert.deepEqual(professionTerms('Senior Software Engineer'), ['software', 'engineer']);
  assert.deepEqual(professionTerms('Lead UX Designer'), ['ux', 'designer'].filter((w) => w.length >= 3));
  assert.deepEqual(professionTerms(null), []);
});

test('recommendations match profession and skills, explain why, skip joined communities and fall back to popular ones', () => {
  const d = getDb();
  const ins = d.prepare('INSERT INTO communities (name, slug, description, category, parent_id) VALUES (?, ?, ?, ?, ?)');
  const vet = ins.run('Veterinary Medicine', 'p19-vet', 'Animal care and clinical practice.', 'Healthcare', null).lastInsertRowid;
  ins.run('Beekeepers Club', 'p19-bees', 'Hives, honey and seasonal work.', 'Agriculture', null);
  ins.run('Quiet Cartographers', 'p19-maps', 'Maps and surveys.', 'Geography', null);
  const mk = (over) => ({ id: -1, profession: null, skills: '[]', ...over });

  const byProfession = recommendCommunities(d, mk({ profession: 'Veterinary Nurse' }), { limit: 4 });
  assert.equal(byProfession[0].name, 'Veterinary Medicine');
  assert.equal(byProfession[0].reason.kind, 'profession');
  assert.match(byProfession[0].reason.text, /profession: Veterinary Nurse/);

  const bySkill = recommendCommunities(d, mk({ profession: 'Zzz', skills: JSON.stringify(['Honey', 'Beekeepers']) }), { limit: 4 });
  assert.equal(bySkill[0].name, 'Beekeepers Club');
  assert.equal(bySkill[0].reason.kind, 'skills');
  assert.match(bySkill[0].reason.text, /skills: /);

  const both = recommendCommunities(d, mk({ profession: 'Veterinary Nurse', skills: JSON.stringify(['Animal']) }), { limit: 4 });
  assert.equal(both[0].reason.kind, 'both');

  // whole-word rule for short skills: "C" or "Go" must not match every community containing those letters
  const short = recommendCommunities(d, mk({ profession: 'Zzz', skills: JSON.stringify(['C', 'Go', 'R']) }), { limit: 4 });
  assert.ok(short.every((c) => c.reason.kind === 'popular'), 'short skills matched inside longer words');

  // no usable profile information: popular communities, most members first, and the hint says how to improve
  const fallback = recommendCommunities(d, mk(), { limit: 3 });
  assert.equal(fallback.length, 3);
  assert.ok(fallback.every((c) => c.reason.kind === 'popular'));
  assert.match(fallback[0].reason.text, /Add skills/);
  for (let i = 1; i < fallback.length; i++) assert.ok(fallback[i - 1].memberCount >= fallback[i].memberCount);

  // joined communities (also through a joined subcommunity) are never recommended; subcommunities themselves are never listed
  const sara = uid(SARA);
  const joinedIds = d.prepare('SELECT community_id FROM memberships WHERE user_id = ?').all(sara).map((r) => r.community_id);
  const recs = recommendCommunities(d, d.prepare('SELECT * FROM users WHERE id = ?').get(sara), { limit: 10 });
  assert.ok(recs.every((c) => !joinedIds.includes(c.id)));
  assert.ok(recs.every((c) => d.prepare('SELECT parent_id FROM communities WHERE id = ?').get(c.id).parent_id === null));
  d.prepare('INSERT INTO memberships (user_id, community_id) VALUES (?, ?)').run(sara, vet);
  assert.ok(recommendCommunities(d, mk({ id: sara, profession: 'Veterinary Nurse' }), { limit: 10 }).every((c) => c.id !== vet));
  d.prepare('DELETE FROM memberships WHERE user_id = ? AND community_id = ?').run(sara, vet);
});

test('communitiesForYou in /api/home is explained and never contains communities the member joined', async () => {
  const b = await loginAs(SARA);
  const list = (await b.get('/api/home')).body.personal.communitiesForYou;
  assert.ok(list.length > 0 && list.length <= 4);
  assert.ok(list.every((c) => c.reason && typeof c.reason.text === 'string' && c.reason.text.length > 0));
  const joined = getDb().prepare('SELECT community_id FROM memberships WHERE user_id = ?').all(uid(SARA)).map((r) => r.community_id);
  assert.ok(list.every((c) => !joined.includes(c.id)));
});

// ===================== Sign out =====================

test('POST /api/auth/logout clears the session cookie, and every protected API then answers 401', async () => {
  const b = await loginAs(SARA);
  assert.equal((await b.get('/api/preferences')).status, 200);
  const out = await b.post('/api/auth/logout');
  assert.equal(out.status, 200);
  const cleared = out.setCookie.find((c) => c.startsWith('pc_token='));
  assert.ok(cleared, 'the logout response expires the session cookie');
  assert.match(cleared, /^pc_token=;/);
  assert.match(cleared, /Expires=Thu, 01 Jan 1970/);
  assert.match(cleared, /HttpOnly/i);
  assert.equal(b.has(), false);
  for (const p of ['/api/preferences', '/api/home', '/api/saved-jobs', '/api/job-applications', '/api/jobs', '/api/notifications']) {
    assert.equal((await b.get(p)).status, 401, p);
  }
  assert.deepEqual((await b.get('/api/auth/me')).body, { user: null });
  assert.equal((await b.put('/api/preferences', { theme: 'dark' })).status, 401, 'a signed-out request cannot save preferences');
  // signing out does not delete or change anything about the member
  assert.equal(getDb().prepare('SELECT COUNT(*) AS n FROM users WHERE email = ?').get(SARA).n, 1);
  assert.equal((await loginAs(SARA).then((x) => x.get('/api/preferences'))).status, 200);
});

// ===================== Migration on an existing database =====================

test('opening a Part 18 database adds user_preferences and keeps every existing record', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-p19-migrate-'));
  const dbFile = path.join(dir, 'old.db');
  const schema = fs.readFileSync(path.join(here, '..', 'src', 'db', 'schema.sql'), 'utf8');
  const marker = schema.indexOf('-- Member preferences (Part 19)');
  assert.ok(marker > 0);
  const part18 = schema.slice(0, marker); // exactly the schema before this part
  const script = `
    import { DatabaseSync } from 'node:sqlite';
    import fs from 'node:fs';
    const old = new DatabaseSync(${JSON.stringify(dbFile)});
    old.exec(fs.readFileSync(${JSON.stringify(path.join(dir, 'part18.sql'))}, 'utf8'));
    old.prepare("INSERT INTO users (name, email, password_hash, profile_completed) VALUES ('Old User', 'old@example.com', 'hash', 1)").run();
    old.prepare("INSERT INTO saved_jobs (user_id, source, external_id, title, company) VALUES (1, 'muse', '1', 'Old saved job', 'Old Co')").run();
    const before = old.prepare("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'user_preferences'").all().length;
    old.close();
    const { getDb } = await import(${JSON.stringify(path.join(here, '..', 'src', 'db', 'index.js'))});
    const db = getDb();
    const cols = db.prepare('PRAGMA table_info(user_preferences)').all().map((c) => c.name);
    console.log(JSON.stringify({
      before,
      cols,
      users: db.prepare('SELECT COUNT(*) AS n FROM users').get().n,
      email: db.prepare('SELECT email FROM users').get().email,
      saved: db.prepare('SELECT title FROM saved_jobs').all().map((j) => j.title),
      prefRows: db.prepare('SELECT COUNT(*) AS n FROM user_preferences').get().n,
    }));`;
  fs.writeFileSync(path.join(dir, 'part18.sql'), part18);
  fs.writeFileSync(path.join(dir, 'run.mjs'), script);
  const r = spawnSync(process.execPath, ['--disable-warning=ExperimentalWarning', path.join(dir, 'run.mjs')], { env: { ...process.env, PROCONNECT_DB: dbFile, JOBS_SYNC: 'off', NEWS_SYNC: 'off' }, encoding: 'utf8' });
  assert.equal(r.status, 0, r.stderr);
  const out = JSON.parse(r.stdout.trim().split('\n').pop());
  assert.equal(out.before, 0, 'the old database really had no preferences table');
  assert.deepEqual(out.cols, ['user_id', 'theme', 'news_default_tab', 'job_category', 'job_work_mode', 'home_hidden', 'updated_at']);
  assert.equal(out.users, 1);
  assert.equal(out.email, 'old@example.com');
  assert.deepEqual(out.saved, ['Old saved job']);
  assert.equal(out.prefRows, 0, 'the migration creates no preference rows: existing accounts are untouched');
});
