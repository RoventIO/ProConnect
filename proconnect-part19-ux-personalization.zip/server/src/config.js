import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));

export const config = {
  port: Number(process.env.PORT) || 4000,
  // Use PROCONNECT_DB=:memory: for throwaway databases (tests).
  dbPath: process.env.PROCONNECT_DB || path.join(here, '..', 'data', 'proconnect.db'),
  // Uploaded images (profile photos now, post images later). Never served without a signed-in session.
  uploadDir: process.env.PROCONNECT_UPLOADS || path.join(here, '..', 'data', 'uploads'),
  clientOrigin: process.env.CLIENT_ORIGIN || 'http://localhost:5173',
  isProd: process.env.NODE_ENV === 'production',
  // Set JWT_SECRET in the environment for anything beyond local demonstration.
  jwtSecret: process.env.JWT_SECRET || 'dev-only-secret-change-me',
  // Automated news (Part 4). Set NEWS_SYNC=off to start the API without fetching news (for example while offline).
  news: {
    enabled: (process.env.NEWS_SYNC || 'on').toLowerCase() !== 'off',
    intervalMinutes: 120, // repeat synchronization while the server is running
    retentionHours: 72, // articles older than this are deleted
    requestTimeoutMs: 10_000,
    maxResponseBytes: 2 * 1024 * 1024,
    maxArticlesPerSource: 40,
    maxSources: 20,
    userAgent: 'ProConnectNewsBot/1.0 (+academic project; metadata and links only)',
  },
  // Jobs (Part 17). Listings come from Arbeitnow (no key) and The Muse (a key is optional but raises its limit).
  // Set JOBS_SYNC=off to start the API without contacting either source.
  jobs: {
    enabled: (process.env.JOBS_SYNC || 'on').toLowerCase() !== 'off',
    intervalMinutes: 180, // repeat while the server runs
    startupMinAgeMinutes: 60, // a restart does not fetch again if the last successful fetch is newer than this
    manualMinAgeMinutes: 10, // an administrator's Refresh button is ignored when the last fetch is newer than this
    requestTimeoutMs: 15_000,
    maxResponseBytes: 8 * 1024 * 1024,
    requestDelayMs: 300, // pause between two requests to the same source
    arbeitnowMaxPages: 3,
    museMaxPagesPerCategory: 2, // The Muse returns 20 jobs per page
    museMinRemaining: 25, // stop asking The Muse when it reports fewer requests left in the hour
    museApiKey: process.env.MUSE_API_KEY || '', // server side only; never sent to the browser
    retentionDays: 45, // listings published (or first seen) longer ago than this are removed after a successful fetch
    maxStored: 3000,
    userAgent: 'ProConnectJobsBot/1.0 (+academic project; links to the original listings)',
  },
};
