import { getDb } from '../db/index.js';
import { CATEGORY_KEYS } from '../jobs/categories.js';
import { validationError } from './httpError.js';

/** Strict whitelists for every preference. Nothing outside these lists is ever stored. */
export const THEMES = ['light', 'dark', 'system'];
export const NEWS_TABS = ['all', 'for-you'];
export const WORK_MODES = ['remote', 'hybrid', 'on_site'];
/** The personalized Home sections a member can hide. Names are part of the API; the order is the order on the page. */
export const HOME_SECTION_KEYS = ['newInCommunities', 'communitiesForYou', 'jobsForYou', 'jobSearch', 'registrations'];

export const DEFAULTS = Object.freeze({ theme: 'light', newsDefaultTab: 'all', jobCategory: null, jobWorkMode: null, hidden: [] });

const has = (obj, key) => Object.prototype.hasOwnProperty.call(obj, key);
const isPlainObject = (v) => v !== null && typeof v === 'object' && !Array.isArray(v) && Object.getPrototypeOf(v) === Object.prototype;

function parseHidden(text) {
  try {
    const list = JSON.parse(text || '[]');
    return Array.isArray(list) ? HOME_SECTION_KEYS.filter((k) => list.includes(k)) : [];
  } catch {
    return [];
  }
}

/** The member's stored row as the internal shape, or the defaults when they never saved anything. */
export function loadPreferences(userId) {
  const row = getDb().prepare('SELECT * FROM user_preferences WHERE user_id = ?').get(userId);
  if (!row) return { ...DEFAULTS, hidden: [], persisted: false };
  return {
    theme: THEMES.includes(row.theme) ? row.theme : DEFAULTS.theme,
    newsDefaultTab: NEWS_TABS.includes(row.news_default_tab) ? row.news_default_tab : DEFAULTS.newsDefaultTab,
    jobCategory: CATEGORY_KEYS.includes(row.job_category) ? row.job_category : null,
    jobWorkMode: WORK_MODES.includes(row.job_work_mode) ? row.job_work_mode : null,
    hidden: parseHidden(row.home_hidden),
    persisted: true,
  };
}

/** The API shape: homeSections maps every section key to true (shown) or false (hidden). */
export function shapePreferences(p) {
  return {
    theme: p.theme,
    newsDefaultTab: p.newsDefaultTab,
    jobCategory: p.jobCategory,
    jobWorkMode: p.jobWorkMode,
    homeSections: Object.fromEntries(HOME_SECTION_KEYS.map((k) => [k, !p.hidden.includes(k)])),
    persisted: p.persisted,
  };
}

const ALLOWED_FIELDS = ['theme', 'newsDefaultTab', 'jobCategory', 'jobWorkMode', 'homeSections'];

/**
 * Validates a (partial) update. Returns the changes as an internal patch, or throws a validation error naming every bad field.
 * Unknown properties are refused, never ignored: the endpoint does not accept arbitrary data.
 */
export function validatePatch(body) {
  if (!isPlainObject(body)) throw validationError({ _: 'Send a JSON object with the preferences to change.' });
  // Null-prototype objects: a key such as "__proto__" is then an ordinary key that gets reported, not silently swallowed.
  const fields = Object.create(null);
  const patch = {};
  for (const key of Object.keys(body)) if (!ALLOWED_FIELDS.includes(key)) fields[key] = 'This is not a preference.';

  if (has(body, 'theme')) {
    if (THEMES.includes(body.theme)) patch.theme = body.theme;
    else fields.theme = `Choose one of: ${THEMES.join(', ')}.`;
  }
  if (has(body, 'newsDefaultTab')) {
    if (NEWS_TABS.includes(body.newsDefaultTab)) patch.newsDefaultTab = body.newsDefaultTab;
    else fields.newsDefaultTab = `Choose one of: ${NEWS_TABS.join(', ')}.`;
  }
  if (has(body, 'jobCategory')) {
    if (body.jobCategory === null || CATEGORY_KEYS.includes(body.jobCategory)) patch.jobCategory = body.jobCategory;
    else fields.jobCategory = 'Choose a job category from the list, or null for no preference.';
  }
  if (has(body, 'jobWorkMode')) {
    if (body.jobWorkMode === null || WORK_MODES.includes(body.jobWorkMode)) patch.jobWorkMode = body.jobWorkMode;
    else fields.jobWorkMode = `Choose one of: ${WORK_MODES.join(', ')}, or null for no preference.`;
  }
  if (has(body, 'homeSections')) {
    const s = body.homeSections;
    if (!isPlainObject(s)) fields.homeSections = 'Send an object that maps section names to true or false.';
    else {
      const bad = Object.keys(s).filter((k) => !HOME_SECTION_KEYS.includes(k) || typeof s[k] !== 'boolean');
      if (bad.length) fields.homeSections = `Only these sections can be shown or hidden, with true or false: ${HOME_SECTION_KEYS.join(', ')}.`;
      else patch.homeSections = { ...s };
    }
  }
  if (Object.keys(fields).length) throw validationError(fields);
  return patch;
}

/** Applies a validated patch on top of the member's current preferences and stores the result (one row per member). */
export function savePreferences(userId, patch) {
  const current = loadPreferences(userId);
  const next = { ...current };
  for (const k of ['theme', 'newsDefaultTab', 'jobCategory', 'jobWorkMode']) if (has(patch, k)) next[k] = patch[k];
  if (patch.homeSections) {
    const hidden = new Set(current.hidden);
    for (const [k, visible] of Object.entries(patch.homeSections)) {
      if (visible) hidden.delete(k);
      else hidden.add(k);
    }
    next.hidden = HOME_SECTION_KEYS.filter((k) => hidden.has(k));
  }
  getDb()
    .prepare(
      `INSERT INTO user_preferences (user_id, theme, news_default_tab, job_category, job_work_mode, home_hidden, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
       ON CONFLICT(user_id) DO UPDATE SET theme = excluded.theme, news_default_tab = excluded.news_default_tab,
         job_category = excluded.job_category, job_work_mode = excluded.job_work_mode, home_hidden = excluded.home_hidden,
         updated_at = excluded.updated_at`
    )
    .run(userId, next.theme, next.newsDefaultTab, next.jobCategory, next.jobWorkMode, JSON.stringify(next.hidden));
  return { ...next, persisted: true };
}
