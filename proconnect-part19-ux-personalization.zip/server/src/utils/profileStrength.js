import { getDb } from '../db/index.js';

/**
 * Profile strength (Part 19). Every item is checked against the member's real stored data; nothing is hardcoded.
 * Each item counts the same, so the percentage is simply the finished items out of all items, rounded.
 * `href` is the page (and section) where the member can finish the item.
 */
export function profileStrength(user) {
  const db = getDb();
  const kinds = Object.fromEntries(db.prepare('SELECT kind, COUNT(*) AS n FROM profile_items WHERE user_id = ? GROUP BY kind').all(user.id).map((r) => [r.kind, r.n]));
  const joined = db.prepare('SELECT COUNT(*) AS n FROM memberships WHERE user_id = ?').get(user.id).n;
  let skills = [];
  try {
    skills = JSON.parse(user.skills || '[]');
  } catch {
    skills = [];
  }
  const filled = (v) => typeof v === 'string' && v.trim().length > 0;

  const items = [
    { key: 'profession', label: 'Add your profession', done: filled(user.profession), href: '/profile?edit=basics' },
    { key: 'headline', label: 'Write a headline', done: filled(user.headline), href: '/profile?edit=basics' },
    { key: 'bio', label: 'Write a short biography', done: filled(user.bio), href: '/profile?edit=basics' },
    { key: 'skills', label: 'List at least 3 skills', done: Array.isArray(skills) && skills.filter(filled).length >= 3, href: '/profile?edit=basics' },
    { key: 'location', label: 'Add your location', done: filled(user.location), href: '/profile?edit=basics' },
    { key: 'experience-years', label: 'Add your years of experience', done: user.years_experience != null, href: '/profile?edit=basics' },
    { key: 'photo', label: 'Upload a profile photo', done: filled(user.avatar_file), href: '/profile?edit=photo' },
    { key: 'links', label: 'Add a LinkedIn or GitHub link', done: filled(user.linkedin_url) || filled(user.github_url), href: '/profile?edit=basics' },
    { key: 'experience', label: 'Add a work experience', done: (kinds.experience || 0) > 0, href: '/profile?add=experience' },
    { key: 'education', label: 'Add your education', done: (kinds.education || 0) > 0, href: '/profile?add=education' },
    { key: 'project', label: 'Add a project to My Work', done: (kinds.project || 0) > 0, href: '/profile?add=project' },
    { key: 'community', label: 'Join a community', done: joined > 0, href: '/communities' },
  ];
  const completed = items.filter((i) => i.done).length;
  return { percent: Math.round((completed / items.length) * 100), completed, total: items.length, items };
}
