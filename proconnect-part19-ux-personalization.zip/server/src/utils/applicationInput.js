import { canonicalUrl } from '../news/urls.js';
import { validationError } from './httpError.js';

export const APPLICATION_STATUSES = ['applied', 'reviewing', 'interview', 'rejected', 'accepted', 'withdrawn'];
export const LIMITS = { title: 200, company: 120, url: 500, notes: 2000 };

/** Case- and accent-insensitive-ish text key (NFC, upper then lower so special letters fold the same way everywhere). */
export const fold = (v) => String(v).normalize('NFC').replace(/\s+/g, ' ').trim().toUpperCase().toLowerCase();

/** Accepts an http(s) address without credentials. Returns the cleaned address or null. Never repairs or invents anything. */
export function cleanJobUrl(raw) {
  if (typeof raw !== 'string') return null;
  const text = raw.trim();
  if (!text || text.length > LIMITS.url || /\s/.test(text)) return null;
  let u;
  try {
    u = new URL(text);
  } catch {
    return null;
  }
  if ((u.protocol !== 'https:' && u.protocol !== 'http:') || u.username || u.password || !u.hostname.includes('.')) return null;
  u.hash = '';
  return u.toString();
}

/** Two applications are the same position when they share a normalized URL, or (without any URL) the same title and company. */
export const duplicateKey = ({ url, title, company }) => {
  const key = url && canonicalUrl(url);
  return key ? `url:${key}` : `text:${fold(title)}|${fold(company)}`;
};

const isDateOnly = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(`${s}T00:00:00Z`)) && new Date(`${s}T00:00:00Z`).toISOString().startsWith(s);

/**
 * Validates the editable fields of an application. `partial` (updates) only checks the fields that were sent.
 * Returns the cleaned values for the fields present; throws a validation_error listing every problem.
 */
export function validateApplicationInput(body, { partial = false, linked = false, now = Date.now() } = {}) {
  const b = body && typeof body === 'object' && !Array.isArray(body) ? body : {};
  const errors = {};
  const out = {};
  const has = (k) => Object.prototype.hasOwnProperty.call(b, k);

  const text = (key, label, max, { required }) => {
    if (!has(key)) {
      if (required && !partial && !linked) errors[key] = `${label} is required.`;
      return;
    }
    if (b[key] == null || b[key] === '') {
      if (required) errors[key] = `${label} is required.`;
      else out[key] = null;
      return;
    }
    if (typeof b[key] !== 'string') { errors[key] = `${label} must be text.`; return; }
    const v = b[key].trim();
    if (!v && required) errors[key] = `${label} is required.`;
    else if (v.length > max) errors[key] = `${label} can be up to ${max} characters.`;
    else out[key] = v || null;
  };
  text('title', 'Job title', LIMITS.title, { required: true });
  text('company', 'Company', LIMITS.company, { required: true });
  text('notes', 'Notes', LIMITS.notes, { required: false });
  if (out.title && out.title.length < 2) errors.title = 'Job title must have at least 2 characters.';

  if (has('url')) {
    if (b.url == null || (typeof b.url === 'string' && !b.url.trim())) out.url = null;
    else {
      const url = cleanJobUrl(b.url);
      if (!url) errors.url = `Enter a full link starting with https:// (up to ${LIMITS.url} characters).`;
      else out.url = url;
    }
  }

  if (has('appliedOn')) {
    if (typeof b.appliedOn !== 'string' || !isDateOnly(b.appliedOn)) errors.appliedOn = 'Enter the application date.';
    else if (b.appliedOn < '2000-01-01') errors.appliedOn = 'The application date looks too old.';
    else if (Date.parse(`${b.appliedOn}T00:00:00Z`) > now + 36 * 3600_000) errors.appliedOn = 'The application date cannot be in the future.';
    else out.appliedOn = b.appliedOn;
  } else if (!partial) errors.appliedOn = 'Enter the application date.';

  if (has('status')) {
    if (!APPLICATION_STATUSES.includes(b.status)) errors.status = `Status must be one of: ${APPLICATION_STATUSES.join(', ')}.`;
    else out.status = b.status;
  } else if (!partial) errors.status = 'Select the current status.'; // never defaulted: a status is the member's own statement

  if (Object.keys(errors).length) throw validationError(errors);
  return out;
}
