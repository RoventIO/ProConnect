import { COUNTS } from '../routes/communities.js';

// Community recommendations (Part 19): a simple, explainable keyword match between the member's profession and skills and the
// names, categories, descriptions and subcommunity names of the communities they have not joined. No machine learning, no tracking.

const fold = (v) => String(v ?? '').normalize('NFC').toUpperCase().toLowerCase();
const escape = (s) => s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
const STOP = new Set(['and', 'the', 'for', 'with', 'senior', 'junior', 'lead', 'principal', 'staff', 'associate', 'assistant', 'intern', 'trainee']);

/**
 * A matcher for one word or skill. Short terms must match a whole word ("go", "c++", "ux"); longer ones also match the start of a longer
 * word, so "engineer" finds "engineering" and "design" finds "designers".
 */
function matcher(term) {
  const t = fold(term).trim();
  if (!t) return null;
  const tail = t.length >= 6 ? '' : '(?![\\p{L}\\p{N}])';
  return new RegExp(`(?<![\\p{L}\\p{N}])${escape(t)}${tail}`, 'u');
}

/** Words of the profession worth matching: 3+ letters, not generic seniority words. */
export const professionTerms = (profession) =>
  [...new Set(fold(profession).split(/[^\p{L}\p{N}+#.]+/u).filter((w) => w.length >= 3 && !STOP.has(w)))];

export function recommendCommunities(db, user, { limit = 4 } = {}) {
  const rows = db
    .prepare(
      `SELECT c.id, c.name, c.description, c.category, ${COUNTS}
         FROM communities c
        WHERE c.parent_id IS NULL AND c.status = 'approved'
          AND NOT EXISTS (SELECT 1 FROM memberships m WHERE m.user_id = ? AND (m.community_id = c.id OR m.community_id IN (SELECT id FROM communities WHERE parent_id = c.id)))`
    )
    .all(user.id);
  const kids = new Map();
  for (const k of db.prepare("SELECT parent_id, name FROM communities WHERE parent_id IS NOT NULL AND status = 'approved'").all()) {
    if (!kids.has(k.parent_id)) kids.set(k.parent_id, []);
    kids.get(k.parent_id).push(k.name);
  }

  let skills = [];
  try {
    skills = JSON.parse(user.skills || '[]').filter((s) => typeof s === 'string' && s.trim());
  } catch {
    skills = [];
  }
  const profTerms = professionTerms(user.profession).map((t) => ({ t, re: matcher(t) })).filter((x) => x.re);
  const skillTerms = [...new Set(skills.map((s) => s.trim()))].map((s) => ({ t: s, re: matcher(s) })).filter((x) => x.re);

  const hasInfo = profTerms.length > 0 || skillTerms.length > 0;
  const scored = rows.map((c) => {
    const strong = fold([c.name, ...(kids.get(c.id) || [])].join(' | ')); // name and subcommunity names
    const weak = fold(`${c.category} | ${c.description}`);
    let score = 0;
    const byProfession = [];
    const bySkills = [];
    for (const { t, re } of profTerms) {
      if (re.test(strong)) { score += 3; byProfession.push(t); } else if (re.test(weak)) { score += 1; byProfession.push(t); }
    }
    for (const { t, re } of skillTerms) {
      if (re.test(strong)) { score += 3; bySkills.push(t); } else if (re.test(weak)) { score += 1; bySkills.push(t); }
    }
    return { c, score, byProfession, bySkills };
  });

  const reasonOf = (s) => {
    if (s.byProfession.length && s.bySkills.length) return { kind: 'both', text: `Matches your profession and skills: ${s.bySkills.slice(0, 3).join(', ')}` };
    if (s.byProfession.length) return { kind: 'profession', text: `Matches your profession: ${user.profession}` };
    return { kind: 'skills', text: `Matches your skills: ${s.bySkills.slice(0, 3).join(', ')}` };
  };
  const shape = (c, reason) => ({ id: c.id, name: c.name, category: c.category, description: c.description, memberCount: c.member_count, postCount: c.post_count, reason });
  const byPopularity = (a, b) => b.c.member_count - a.c.member_count || a.c.name.localeCompare(b.c.name);

  const matched = scored.filter((s) => s.score > 0).sort((a, b) => b.score - a.score || byPopularity(a, b)).slice(0, limit);
  const taken = new Set(matched.map((s) => s.c.id));
  const popular = scored.filter((s) => !taken.has(s.c.id)).sort(byPopularity).slice(0, Math.max(limit - matched.length, 0));
  return [
    ...matched.map((s) => shape(s.c, reasonOf(s))),
    ...popular.map((s) => shape(s.c, { kind: 'popular', text: hasInfo ? 'Popular on ProConnect' : 'Popular on ProConnect. Add skills to your profile for closer matches.' })),
  ];
}
