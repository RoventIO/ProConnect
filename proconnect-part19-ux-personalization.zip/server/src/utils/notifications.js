import { getDb } from '../db/index.js';

/**
 * The two notification kinds in PRD FR-11, created from the discussion and reply routes (never from seed scripts).
 * Both are idempotent: UNIQUE (recipient_id, dedupe_key) turns a repeated event into a no-op.
 */

/**
 * A new discussion was published. Members of the community it belongs to are notified, except its author.
 * Membership lives on the main community (joining it covers its subcommunities), so a discussion in a subcommunity
 * notifies the main community's members. Bot accounts cannot sign in, so they never receive notifications.
 */
export function notifyNewDiscussion(post, db = getDb()) {
  const community = db.prepare('SELECT id, parent_id FROM communities WHERE id = ?').get(post.community_id);
  if (!community) return 0;
  const memberCommunityId = community.parent_id ?? community.id;
  return db
    .prepare(
      `INSERT OR IGNORE INTO notifications (recipient_id, type, actor_id, community_id, post_id, dedupe_key)
       SELECT m.user_id, 'new_discussion', ?, ?, ?, ?
         FROM memberships m JOIN users u ON u.id = m.user_id
        WHERE m.community_id = ? AND m.user_id <> ? AND u.is_bot = 0`
    )
    .run(post.author_id, post.community_id, post.id, `discussion:${post.id}`, memberCommunityId, post.author_id).changes;
}

/** A comment replied to another comment. The author of the original comment is notified, unless it is the replier or a bot. */
export function notifyCommentReply(reply, parent, db = getDb()) {
  if (!parent || parent.author_id === reply.author_id) return 0;
  const post = db.prepare('SELECT community_id FROM posts WHERE id = ?').get(reply.post_id);
  if (!post) return 0;
  return db
    .prepare(
      `INSERT OR IGNORE INTO notifications (recipient_id, type, actor_id, community_id, post_id, comment_id, dedupe_key)
       SELECT u.id, 'comment_reply', ?, ?, ?, ?, ? FROM users u WHERE u.id = ? AND u.is_bot = 0`
    )
    .run(reply.author_id, post.community_id, reply.post_id, reply.id, `reply:${reply.id}`, parent.author_id).changes;
}

/** Notification creation must never make posting fail: the content is already saved by then. */
export function safely(fn) {
  try {
    return fn();
  } catch (err) {
    console.error('Could not create notifications:', err.message);
    return 0;
  }
}
