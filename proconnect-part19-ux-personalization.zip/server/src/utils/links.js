// Validation of the external links a member can store on a profile. Only addresses on the expected sites are accepted,
// always over https for LinkedIn and GitHub. Query strings and fragments are dropped so only the profile or repository is stored.

const MAX_LENGTH = 300;

// Top-level GitHub paths that are site pages, not user or organization names.
const GITHUB_RESERVED = new Set([
  'about', 'account', 'apps', 'articles', 'blog', 'business', 'collections', 'contact', 'customer-stories', 'dashboard', 'enterprise',
  'events', 'explore', 'features', 'gist', 'issues', 'login', 'logout', 'marketplace', 'new', 'notifications', 'orgs', 'organizations',
  'pricing', 'pulls', 'readme', 'search', 'security', 'sessions', 'settings', 'signup', 'site', 'sponsors', 'stars', 'topics', 'trending', 'users', 'watching',
]);

/** Parses an address; returns a URL or null for anything that is not a plain https/http address without credentials or a custom port. */
function parse(raw, { httpsOnly }) {
  if (typeof raw !== 'string') return null;
  const text = raw.trim();
  if (!text || text.length > MAX_LENGTH || /\s/.test(text)) return null;
  let u;
  try {
    u = new URL(text);
  } catch {
    return null;
  }
  if (u.protocol !== 'https:' && (httpsOnly || u.protocol !== 'http:')) return null;
  if (u.username || u.password || u.port) return null;
  return u;
}

const clean = (u) => `${u.protocol}//${u.hostname}${u.pathname.replace(/\/+$/, '')}`;

/** Result shape: { ok: true, value } or { ok: false, message }. Empty input is handled by the callers (it means "no link"). */

export function checkLinkedIn(raw) {
  const message = 'Enter a LinkedIn profile address such as https://www.linkedin.com/in/your-profile/';
  const u = parse(raw, { httpsOnly: true });
  if (!u) return { ok: false, message };
  const host = u.hostname.toLowerCase();
  if (host !== 'linkedin.com' && !host.endsWith('.linkedin.com')) return { ok: false, message };
  if (!/^\/in\/[^/]{2,100}\/?$/.test(u.pathname)) return { ok: false, message };
  return { ok: true, value: clean(u) };
}

const OWNER = /^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})$/;
const REPO = /^[A-Za-z0-9._-]{1,100}$/;

function githubParts(raw) {
  const u = parse(raw, { httpsOnly: true });
  if (!u) return null;
  const host = u.hostname.toLowerCase();
  if (host !== 'github.com' && host !== 'www.github.com') return null;
  return { u, segments: u.pathname.split('/').filter(Boolean), trailingOnly: /^\/[^/]+(\/[^/]+)?\/?$/.test(u.pathname) };
}

export function checkGithubProfile(raw) {
  const message = 'Enter a GitHub profile address such as https://github.com/your-username';
  const g = githubParts(raw);
  if (!g || g.segments.length !== 1 || !g.trailingOnly) return { ok: false, message };
  const [owner] = g.segments;
  if (!OWNER.test(owner) || owner.endsWith('-') || owner.includes('--') || GITHUB_RESERVED.has(owner.toLowerCase())) return { ok: false, message };
  return { ok: true, value: clean(g.u) };
}

export function checkGithubRepo(raw) {
  const message = 'Enter a GitHub repository address such as https://github.com/owner/repository';
  const g = githubParts(raw);
  if (!g || g.segments.length !== 2 || !g.trailingOnly) return { ok: false, message };
  const [owner] = g.segments;
  let repo = g.segments[1];
  if (repo.toLowerCase().endsWith('.git')) repo = repo.slice(0, -4);
  if (!OWNER.test(owner) || owner.endsWith('-') || owner.includes('--') || GITHUB_RESERVED.has(owner.toLowerCase())) return { ok: false, message };
  if (!REPO.test(repo) || repo === '.' || repo === '..') return { ok: false, message };
  return { ok: true, value: `https://github.com/${owner}/${repo}` };
}

export function checkDemoUrl(raw) {
  const u = parse(raw, { httpsOnly: false });
  if (!u || !u.hostname.includes('.')) return { ok: false, message: 'Enter a full link starting with https://' };
  return { ok: true, value: `${u.protocol}//${u.host}${u.pathname === '/' ? '' : u.pathname.replace(/\/+$/, '')}${u.search}` };
}

/** True when a stored address is a GitHub repository link (used to decide which button a project card shows). */
export const isGithubRepo = (url) => !!url && checkGithubRepo(url).ok;
