import { Router } from 'express';
import { loadPreferences, savePreferences, shapePreferences, validatePatch } from '../utils/preferences.js';

const router = Router();

// Preferences are private: they are only ever read or written with the signed-in member's own id from the session.
// There is no id in the URL and no way to name another member. Responses are never cached by the browser.
router.use((req, res, next) => {
  res.set('Cache-Control', 'no-store');
  next();
});

// GET /api/preferences -> { preferences }. A member who never saved anything gets the defaults with persisted: false.
router.get('/', (req, res) => {
  res.json({ preferences: shapePreferences(loadPreferences(req.user.id)) });
});

// PUT /api/preferences  (partial update: send only what changed)
//   { theme?: 'light'|'dark'|'system', newsDefaultTab?: 'all'|'for-you', jobCategory?: <category key>|null,
//     jobWorkMode?: 'remote'|'hybrid'|'on_site'|null, homeSections?: { <section>: true|false } }
router.put('/', (req, res) => {
  const patch = validatePatch(req.body);
  res.json({ preferences: shapePreferences(savePreferences(req.user.id, patch)) });
});

export default router;
