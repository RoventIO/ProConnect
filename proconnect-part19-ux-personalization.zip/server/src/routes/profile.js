import { Router } from 'express';
import multer from 'multer';
import { getDb } from '../db/index.js';
import { notFoundError, parseId, validationError } from '../utils/httpError.js';
import { publicUser } from '../utils/user.js';
import { buildProfile, shapeItem } from '../utils/profileData.js';
import { requireAuth, requireOnboarded } from '../middleware/auth.js';
import { SELF_SELECTABLE_STATUSES } from '../utils/permissions.js';
import { HttpError } from '../utils/httpError.js';
import { saveImage, deleteImage, MAX_IMAGE_BYTES } from '../utils/images.js';
import { checkDemoUrl, checkGithubProfile, checkGithubRepo, checkLinkedIn } from '../utils/links.js';

const router = Router();
router.use(requireAuth);

// Images are held in memory, checked by their real content, then written under a random name.
const avatarUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: MAX_IMAGE_BYTES, files: 1 } }).single('avatar');
const projectImageUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: MAX_IMAGE_BYTES, files: 1 } }).single('image');

const str = (v) => (typeof v === 'string' ? v.trim() : '');

function parseSkills(input) {
  const list = Array.isArray(input) ? input : typeof input === 'string' ? input.split(',') : [];
  const seen = new Set();
  const out = [];
  for (const item of list) {
    const s = str(item);
    if (s && !seen.has(s.toLowerCase())) {
      seen.add(s.toLowerCase());
      out.push(s);
    }
  }
  return out;
}

// GET /api/profile: the signed-in member's own full profile.
router.get('/', requireOnboarded, (req, res) => {
  res.json(buildProfile(getDb(), req.user, { self: true }));
});

/**
 * PUT /api/profile: saves the member's own basic profile. Used for onboarding and later edits.
 * Minimum profile (unlocks content): profession, short bio, at least one skill.
 */
router.put('/', (req, res) => {
  const body = req.body || {};
  const profession = str(body.profession);
  const headline = str(body.headline);
  const bio = str(body.bio);
  const location = str(body.location);
  const skills = parseSkills(body.skills);
  let years = null;
  if (body.yearsExperience !== undefined && body.yearsExperience !== null && body.yearsExperience !== '') {
    years = Number(body.yearsExperience);
  }

  const fields = {};
  if (profession.length < 2 || profession.length > 80) fields.profession = 'Enter your profession (2 to 80 characters).';
  if (bio.length < 10) fields.bio = 'Write a short biography (at least 10 characters).';
  else if (bio.length > 1000) fields.bio = 'Keep your biography under 1000 characters.';
  if (skills.length < 1) fields.skills = 'Add at least one skill, separated by commas.';
  else if (skills.length > 15) fields.skills = 'Add no more than 15 skills.';
  else if (skills.some((s) => s.length > 40)) fields.skills = 'Each skill must be 40 characters or fewer.';
  if (headline.length > 120) fields.headline = 'Keep your headline under 120 characters.';
  if (location.length > 80) fields.location = 'Keep your location under 80 characters.';
  if (years !== null && (!Number.isInteger(years) || years < 0 || years > 60)) {
    fields.yearsExperience = 'Enter whole years between 0 and 60.';
  }
  // Social links are optional. A key that is not sent leaves the stored link alone (so onboarding and older clients never erase it);
  // an empty value removes the link; anything else must be a valid address on the right site.
  const social = { linkedin_url: req.user.linkedin_url ?? null, github_url: req.user.github_url ?? null };
  for (const [key, field, check] of [['linkedin_url', 'linkedinUrl', checkLinkedIn], ['github_url', 'githubUrl', checkGithubProfile]]) {
    if (body[field] === undefined) continue;
    if (body[field] !== null && typeof body[field] !== 'string') {
      fields[field] = 'Enter a link as text.';
    } else if (str(body[field]) === '') {
      social[key] = null;
    } else {
      const r = check(body[field]);
      if (r.ok) social[key] = r.value;
      else fields[field] = r.message;
    }
  }
  if (Object.keys(fields).length) throw validationError(fields);

  const db = getDb();
  // Only the member's own row is written (req.user comes from the session); role, status and permissions are never part of this statement.
  db.prepare(
    `UPDATE users SET profession = ?, headline = ?, bio = ?, skills = ?, location = ?, years_experience = ?,
            linkedin_url = ?, github_url = ?,
            profile_completed = 1, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
      WHERE id = ?`
  ).run(profession, headline || null, bio, JSON.stringify(skills), location || null, years, social.linkedin_url, social.github_url, req.user.id);

  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)) });
});

/**
 * PUT /api/profile/status { status }: Student or Beginner, chosen freely (no approval).
 * Professional is refused here: only an Admin can grant it (PRD FR-13). Role and permissions are never accepted from this route.
 */
router.put('/status', requireOnboarded, (req, res) => {
  const status = str(req.body?.status).toLowerCase();
  if (status === 'professional') {
    throw new HttpError(403, 'Professional status needs Admin approval. It cannot be selected here.', 'professional_requires_admin');
  }
  if (!SELF_SELECTABLE_STATUSES.includes(status)) {
    throw validationError({ status: 'Choose Student or Beginner.' });
  }
  if (req.user.status === 'professional') {
    throw new HttpError(403, 'Your Professional status can only be changed by an Admin.', 'professional_requires_admin');
  }
  const db = getDb();
  db.prepare("UPDATE users SET status = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(status, req.user.id);
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)) });
});

// ---- Profile photo ----

router.post('/avatar', requireOnboarded, avatarUpload, (req, res) => {
  if (!req.file) throw validationError({ avatar: 'Choose an image to upload.' });
  const fileName = saveImage(req.file.buffer);
  const db = getDb();
  const previous = req.user.avatar_file;
  db.prepare("UPDATE users SET avatar_file = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(fileName, req.user.id);
  deleteImage(previous);
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)) });
});

router.delete('/avatar', requireOnboarded, (req, res) => {
  const db = getDb();
  deleteImage(req.user.avatar_file);
  db.prepare("UPDATE users SET avatar_file = NULL, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(req.user.id);
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)) });
});

// ---- Experience, education and portfolio items (FR-02) ----
// Projects (kind "project") are the "My Work" section: title, description, GitHub repository link, technologies, optional live demo and thumbnail.

const KINDS = ['experience', 'education', 'project'];
const MAX_ITEMS_PER_KIND = 20;
const MAX_TECH = 10;

function parseTech(input) {
  const list = Array.isArray(input) ? input : typeof input === 'string' ? input.split(',') : [];
  const seen = new Set();
  const out = [];
  for (const item of list) {
    const t = str(item);
    if (t && !seen.has(t.toLowerCase())) {
      seen.add(t.toLowerCase());
      out.push(t);
    }
  }
  return out;
}

/**
 * Validates one entry. `existing` is the stored row when editing. For projects a repository link must be a GitHub repository,
 * except that an older link saved before Part 5 may stay exactly as it is (it is never rewritten silently).
 */
function parseItem(body = {}, existing = null) {
  const kind = existing ? existing.kind : str(body.kind);
  const keep = (field, stored) => (existing && body[field] === undefined ? stored || '' : str(body[field]));
  const item = {
    kind,
    title: str(body.title),
    subtitle: keep('subtitle', existing?.subtitle),
    period: keep('period', existing?.period),
    description: str(body.description),
    url: str(body.url),
    tech: [],
    demoUrl: null,
  };
  const fields = {};
  if (!item.title) fields.title = 'Enter a title.';
  else if (item.title.length > 120) fields.title = 'Keep the title under 120 characters.';
  if (item.subtitle.length > 120) fields.subtitle = 'Keep this under 120 characters.';
  if (item.period.length > 60) fields.period = 'Keep the period under 60 characters.';
  if (item.description.length > 500) fields.description = 'Keep the description under 500 characters.';

  if (kind === 'project') {
    if (!item.url) {
      if (!existing || existing.url) fields.url = 'Enter the GitHub repository address.';
    } else if (!(existing && item.url === existing.url)) {
      const r = checkGithubRepo(item.url);
      if (r.ok) item.url = r.value;
      else fields.url = r.message;
    }
    const tech = body.technologies === undefined && existing ? parseTech(existing.tech ? JSON.parse(existing.tech) : []) : parseTech(body.technologies);
    if (tech.length > MAX_TECH) fields.technologies = `Add no more than ${MAX_TECH} technologies.`;
    else if (tech.some((t) => t.length > 30)) fields.technologies = 'Each technology must be 30 characters or fewer.';
    item.tech = tech;
    if (body.demoUrl === undefined && existing) item.demoUrl = existing.demo_url || null;
    else if (str(body.demoUrl)) {
      const r = checkDemoUrl(body.demoUrl);
      if (r.ok) item.demoUrl = r.value;
      else fields.demoUrl = r.message;
    }
  } else if (item.url) {
    let ok = false;
    try {
      const u = new URL(item.url);
      ok = (u.protocol === 'http:' || u.protocol === 'https:') && item.url.length <= 300;
    } catch {
      ok = false;
    }
    if (!ok) fields.url = 'Enter a full link starting with http:// or https://';
  }
  return { item, fields };
}

router.post('/items', requireOnboarded, (req, res) => {
  const { item, fields } = parseItem(req.body);
  if (!KINDS.includes(item.kind)) fields.kind = 'Choose experience, education or project.';
  if (Object.keys(fields).length) throw validationError(fields);

  const db = getDb();
  const n = db.prepare('SELECT COUNT(*) AS n FROM profile_items WHERE user_id = ? AND kind = ?').get(req.user.id, item.kind).n;
  if (n >= MAX_ITEMS_PER_KIND) throw validationError({ title: `You can add up to ${MAX_ITEMS_PER_KIND} entries in this section.` });

  const id = db
    .prepare('INSERT INTO profile_items (user_id, kind, title, subtitle, period, description, url, tech, demo_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .run(req.user.id, item.kind, item.title, item.subtitle || null, item.period || null, item.description || null, item.url || null, JSON.stringify(item.tech), item.demoUrl).lastInsertRowid;
  res.status(201).json({ item: shapeItem(db.prepare('SELECT * FROM profile_items WHERE id = ?').get(id)) });
});

// Members can only change their own entries; someone else's entry looks like it does not exist.
router.put('/items/:id', requireOnboarded, (req, res) => {
  const id = parseId(req.params.id, 'item id');
  const db = getDb();
  const existing = db.prepare('SELECT * FROM profile_items WHERE id = ? AND user_id = ?').get(id, req.user.id);
  if (!existing) throw notFoundError('Entry not found.');
  const { item, fields } = parseItem(req.body, existing);
  if (Object.keys(fields).length) throw validationError(fields);
  db.prepare('UPDATE profile_items SET title = ?, subtitle = ?, period = ?, description = ?, url = ?, tech = ?, demo_url = ? WHERE id = ? AND user_id = ?')
    .run(item.title, item.subtitle || null, item.period || null, item.description || null, item.url || null, JSON.stringify(item.tech), item.demoUrl, id, req.user.id);
  res.json({ item: shapeItem(db.prepare('SELECT * FROM profile_items WHERE id = ?').get(id)) });
});

router.delete('/items/:id', requireOnboarded, (req, res) => {
  const id = parseId(req.params.id, 'item id');
  const db = getDb();
  const existing = db.prepare('SELECT image_file FROM profile_items WHERE id = ? AND user_id = ?').get(id, req.user.id);
  if (!existing) throw notFoundError('Entry not found.');
  db.prepare('DELETE FROM profile_items WHERE id = ? AND user_id = ?').run(id, req.user.id);
  deleteImage(existing.image_file);
  res.json({ ok: true });
});

// Optional project thumbnail (same checks as profile photos: real image content, 2 MB, random file name).
router.post('/items/:id/image', requireOnboarded, projectImageUpload, (req, res) => {
  const id = parseId(req.params.id, 'item id');
  const db = getDb();
  const existing = db.prepare("SELECT * FROM profile_items WHERE id = ? AND user_id = ? AND kind = 'project'").get(id, req.user.id);
  if (!existing) throw notFoundError('Entry not found.');
  if (!req.file) throw validationError({ image: 'Choose an image to upload.' });
  const fileName = saveImage(req.file.buffer);
  db.prepare('UPDATE profile_items SET image_file = ? WHERE id = ? AND user_id = ?').run(fileName, id, req.user.id);
  deleteImage(existing.image_file);
  res.json({ item: shapeItem(db.prepare('SELECT * FROM profile_items WHERE id = ?').get(id)) });
});

router.delete('/items/:id/image', requireOnboarded, (req, res) => {
  const id = parseId(req.params.id, 'item id');
  const db = getDb();
  const existing = db.prepare("SELECT * FROM profile_items WHERE id = ? AND user_id = ? AND kind = 'project'").get(id, req.user.id);
  if (!existing) throw notFoundError('Entry not found.');
  db.prepare('UPDATE profile_items SET image_file = NULL WHERE id = ? AND user_id = ?').run(id, req.user.id);
  deleteImage(existing.image_file);
  res.json({ item: shapeItem(db.prepare('SELECT * FROM profile_items WHERE id = ?').get(id)) });
});

export default router;
