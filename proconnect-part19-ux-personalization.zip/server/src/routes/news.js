import { Router } from 'express';
import { getDb } from '../db/index.js';
import { badRequest } from '../utils/httpError.js';
import { getNewsService } from '../news/index.js';
import { DEFAULT_NEWS_IMAGE } from '../news/defaultImage.js';
import { CATEGORIES, CATEGORY_KEYS, categoriesForText, categoryLabel } from '../news/categories.js';

// Members read news from the ProConnect database only; nothing here calls an external site.
const router = Router();

const json = (text, fallback) => {
  try {
    return JSON.parse(text);
  } catch {
    return fallback;
  }
};

function shape(r) {
  const basis = json(r.category_basis, {});
  return {
    id: r.id,
    title: r.title,
    summary: r.summary,
    url: r.url,
    source: { id: r.source_id, name: r.source_name },
    publisher: r.publisher || r.source_name,
    // Articles stored before the default existed (no image value) are answered with it too; nothing needs editing by hand.
    imageUrl: r.image_url || DEFAULT_NEWS_IMAGE,
    hasOriginalImage: !!r.image_url && r.image_url !== DEFAULT_NEWS_IMAGE,
    categories: json(r.categories, []).map((key) => ({ key, label: categoryLabel(key), basis: basis[key] || null })),
    tags: json(r.tags, []),
    publishedAt: r.published_at,
    ingestedAt: r.ingested_at,
    displayAt: r.retention_at,
  };
}

/** Topics for the "For you" tab: what the member chose plus what their joined communities are about. Own data only. */
export function recommendationFor(db, userId) {
  const interests = db.prepare('SELECT category FROM news_interests WHERE user_id = ?').all(userId).map((r) => r.category).filter((c) => CATEGORY_KEYS.includes(c));
  const rows = db
    .prepare(
      `SELECT c.name, c.category, p.name AS parent_name FROM memberships m
         JOIN communities c ON c.id = m.community_id LEFT JOIN communities p ON p.id = c.parent_id
        WHERE m.user_id = ? AND c.status = 'approved' ORDER BY c.name`
    )
    .all(userId);
  const byCategory = new Map();
  for (const r of rows) {
    for (const key of categoriesForText(`${r.name} ${r.parent_name || ''}`)) {
      if (!byCategory.has(key)) byCategory.set(key, new Set());
      byCategory.get(key).add(r.name);
    }
  }
  const fromCommunities = CATEGORY_KEYS.filter((k) => byCategory.has(k)).map((k) => ({ category: k, label: categoryLabel(k), communities: [...byCategory.get(k)] }));
  const categories = CATEGORY_KEYS.filter((k) => interests.includes(k) || byCategory.has(k));
  return { interests: CATEGORY_KEYS.filter((k) => interests.includes(k)), fromCommunities, categories };
}

function syncSummary(db, service) {
  const sources = db.prepare('SELECT name, enabled, last_status, last_sync_at FROM news_sources ORDER BY id').all();
  const enabled = sources.filter((s) => s.enabled);
  const times = enabled.map((s) => s.last_sync_at).filter(Boolean).sort();
  return {
    syncing: service.isRunning(),
    lastSyncAt: times.length ? times[times.length - 1] : null,
    sourceCount: enabled.length,
    failedSources: enabled.filter((s) => s.last_status === 'error').map((s) => s.name),
  };
}

// GET /api/news?category=all|for-you|ai|programming|cybersecurity|startups&limit=18&offset=0
router.get('/', (req, res) => {
  const db = getDb();
  const service = getNewsService();
  const category = String(req.query.category || 'all');
  if (!['all', 'for-you', ...CATEGORY_KEYS].includes(category)) throw badRequest('Unknown news category.');
  const limit = Math.min(Math.max(Number.parseInt(req.query.limit, 10) || 18, 1), 50);
  const offset = Math.max(Number.parseInt(req.query.offset, 10) || 0, 0);

  // Expired articles are deleted by the cleanup job; the cutoff here keeps the list correct between runs.
  // Articles of a source an Admin has disabled are hidden until it is enabled again.
  const where = ['a.retention_at >= ?', 's.enabled = 1'];
  const params = [service.cutoffIso()];
  let recommendation = null;
  let wanted = null;
  if (category === 'for-you') {
    recommendation = recommendationFor(db, req.user.id);
    wanted = recommendation.categories;
  } else if (category !== 'all') {
    wanted = [category];
  }
  if (wanted) {
    if (wanted.length === 0) {
      where.push('0 = 1');
    } else {
      where.push(`EXISTS (SELECT 1 FROM json_each(a.categories) WHERE value IN (${wanted.map(() => '?').join(',')}))`);
      params.push(...wanted);
    }
  }
  const whereSql = where.join(' AND ');
  const total = db.prepare(`SELECT COUNT(*) AS n FROM news_articles a JOIN news_sources s ON s.id = a.source_id WHERE ${whereSql}`).get(...params).n;
  const rows = db
    .prepare(
      `SELECT a.*, s.name AS source_name FROM news_articles a JOIN news_sources s ON s.id = a.source_id
        WHERE ${whereSql} ORDER BY a.retention_at DESC, a.id DESC LIMIT ? OFFSET ?`
    )
    .all(...params, limit, offset);
  res.json({
    articles: rows.map(shape),
    total,
    limit,
    offset,
    hasMore: offset + rows.length < total,
    category,
    retentionHours: service.retentionHours,
    sync: syncSummary(db, service),
    ...(recommendation ? { recommendation } : {}),
  });
});

// GET /api/news/interests: topics available, the member's own choices and what their communities suggest.
router.get('/interests', (req, res) => {
  const r = recommendationFor(getDb(), req.user.id);
  res.json({ available: CATEGORIES, interests: r.interests, fromCommunities: r.fromCommunities });
});

// PUT /api/news/interests { interests: ['ai', 'startups'] }: replaces the member's chosen topics.
router.put('/interests', (req, res) => {
  const list = req.body?.interests;
  if (!Array.isArray(list) || list.some((c) => typeof c !== 'string' || !CATEGORY_KEYS.includes(c))) throw badRequest('Choose topics from the list.');
  const unique = [...new Set(list)];
  const db = getDb();
  db.exec('BEGIN');
  try {
    db.prepare('DELETE FROM news_interests WHERE user_id = ?').run(req.user.id);
    for (const c of unique) db.prepare('INSERT INTO news_interests (user_id, category) VALUES (?, ?)').run(req.user.id, c);
    db.exec('COMMIT');
  } catch (err) {
    db.exec('ROLLBACK');
    throw err;
  }
  const r = recommendationFor(db, req.user.id);
  res.json({ available: CATEGORIES, interests: r.interests, fromCommunities: r.fromCommunities });
});

export default router;
