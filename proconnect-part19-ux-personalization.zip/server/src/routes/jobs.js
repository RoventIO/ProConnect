import { Router } from 'express';
import { getDb } from '../db/index.js';
import { config } from '../config.js';
import { badRequest, parseId } from '../utils/httpError.js';
import { isAdmin } from '../utils/permissions.js';
import { HttpError } from '../utils/httpError.js';
import { CATEGORY_KEYS, JOB_CATEGORIES, categoryLabel } from '../jobs/categories.js';
import { JOB_SOURCES } from '../jobs/service.js';
import { getJobsService } from '../jobs/index.js';

const router = Router();

const MODES = ['remote', 'hybrid', 'on_site'];
const TYPES = ['full_time', 'part_time', 'internship', 'contract'];
const LEVELS = ['entry', 'mid', 'senior', 'management'];
const SOURCE_KEYS = JOB_SOURCES.map((s) => s.key);
const SOURCE_NAME = Object.fromEntries(JOB_SOURCES.map((s) => [s.key, s.name]));

export const shapeJob = (j) => ({
  id: j.id,
  title: j.title,
  company: j.company,
  logoUrl: j.logo_url || null,
  location: j.location || null,
  category: { key: j.category, label: categoryLabel(j.category) },
  employmentType: j.employment_type || null,
  experienceLevel: j.experience_level || null,
  workMode: j.work_mode || null,
  tags: JSON.parse(j.tags || '[]'),
  summary: j.summary || null,
  publishedAt: j.published_at || null,
  firstSeenAt: j.first_seen_at,
  source: { key: j.source, name: SOURCE_NAME[j.source] || j.source },
  applyUrl: j.url, // the original listing page; never rewritten
});

/**
 * The member's own state for each listing (Part 18): savedId when they saved it, applicationId when they track an application for it.
 * Both are looked up with the signed-in member's id from the session, so one member never sees another's bookmarks or applications.
 */
export function memberFlags(db, userId, rows) {
  if (rows.length === 0) return () => ({ savedId: null, applicationId: null });
  const saved = new Map(db.prepare('SELECT source, external_id, id FROM saved_jobs WHERE user_id = ?').all(userId).map((r) => [`${r.source}:${r.external_id}`, r.id]));
  const tracked = new Map(db.prepare('SELECT job_source, job_external_id, id FROM job_applications WHERE user_id = ? AND job_external_id IS NOT NULL').all(userId).map((r) => [`${r.job_source}:${r.job_external_id}`, r.id]));
  return (j) => ({ savedId: saved.get(`${j.source}:${j.external_id}`) ?? null, applicationId: tracked.get(`${j.source}:${j.external_id}`) ?? null });
}

function oneOf(value, allowed, name) {
  if (value == null || value === '') return null;
  if (!allowed.includes(value)) throw badRequest(`${name} must be one of: ${allowed.join(', ')}.`);
  return value;
}

/** Builds the WHERE clause for the active filters. `skip` leaves one filter out (used to count the options of that filter). */
function where(f, skip) {
  const parts = [];
  const params = [];
  if (f.q) {
    parts.push('(ulike(title, ?) OR ulike(company, ?) OR ulike(tags, ?) OR ulike(description_text, ?))');
    params.push(f.q, f.q, f.q, f.q);
  }
  if (f.location) {
    parts.push('ulike(location, ?)');
    params.push(f.location);
  }
  for (const [name, column] of [['category', 'category'], ['mode', 'work_mode'], ['type', 'employment_type'], ['level', 'experience_level'], ['source', 'source']]) {
    if (f[name] && skip !== name) {
      parts.push(`${column} = ?`);
      params.push(f[name]);
    }
  }
  return { sql: parts.length ? `WHERE ${parts.join(' AND ')}` : '', params };
}

// GET /api/jobs?q=&category=&location=&mode=&type=&level=&source=&page=1&pageSize=12   (newest first; that is the only order)
router.get('/', (req, res) => {
  const q = String(req.query.q || '').trim().slice(0, 100);
  const location = String(req.query.location || '').trim().slice(0, 100);
  const f = {
    q, location,
    category: oneOf(req.query.category, CATEGORY_KEYS, 'category'),
    mode: oneOf(req.query.mode, MODES, 'mode'),
    type: oneOf(req.query.type, TYPES, 'type'),
    level: oneOf(req.query.level, LEVELS, 'level'),
    source: oneOf(req.query.source, SOURCE_KEYS, 'source'),
  };
  const pageSize = Math.min(Math.max(parseInt(req.query.pageSize, 10) || 12, 1), 24);
  const page = Math.max(parseInt(req.query.page, 10) || 1, 1);
  const db = getDb();

  const w = where(f);
  const total = db.prepare(`SELECT COUNT(*) AS n FROM jobs ${w.sql}`).get(...w.params).n;
  const rows = db
    .prepare(`SELECT * FROM jobs ${w.sql} ORDER BY COALESCE(published_at, first_seen_at) DESC, id DESC LIMIT ? OFFSET ?`)
    .all(...w.params, pageSize, (page - 1) * pageSize);

  const flags = memberFlags(db, req.user.id, rows);

  // Option counts: each filter is counted with every other filter applied, so an option is only offered when choosing it would return something.
  const facet = (name, column) => {
    const fw = where(f, name);
    return Object.fromEntries(db.prepare(`SELECT ${column} AS v, COUNT(*) AS n FROM jobs ${fw.sql} ${fw.sql ? 'AND' : 'WHERE'} ${column} IS NOT NULL GROUP BY ${column}`).all(...fw.params).map((r) => [r.v, r.n]));
  };
  const categories = facet('category', 'category');
  const facets = {
    categories: JOB_CATEGORIES.map((c) => ({ key: c.key, label: c.label, count: categories[c.key] || 0 })),
    modes: facet('mode', 'work_mode'),
    types: facet('type', 'employment_type'),
    levels: facet('level', 'experience_level'),
    sources: facet('source', 'source'),
  };

  const statusRows = Object.fromEntries(db.prepare('SELECT * FROM job_sources').all().map((r) => [r.key, r]));
  const stored = Object.fromEntries(db.prepare('SELECT source, COUNT(*) AS n FROM jobs GROUP BY source').all().map((r) => [r.source, r.n]));
  const sources = JOB_SOURCES.map((s) => ({
    key: s.key, name: s.name, site: s.site,
    status: statusRows[s.key]?.last_status || null,
    message: statusRows[s.key]?.last_message || null,
    lastSyncAt: statusRows[s.key]?.last_sync_at || null,
    lastOkAt: statusRows[s.key]?.last_ok_at || null,
    stored: stored[s.key] || 0,
  }));
  const svc = getJobsService();
  res.json({
    jobs: rows.map((r) => ({ ...shapeJob(r), ...flags(r) })),
    total, page, pageSize, pageCount: Math.max(Math.ceil(total / pageSize), 1),
    facets, sources,
    totalStored: Object.values(stored).reduce((a, b) => a + b, 0),
    lastUpdated: sources.map((s) => s.lastOkAt).filter(Boolean).sort().pop() || null,
    refreshing: svc.isRunning(),
    fetchingEnabled: config.jobs.enabled,
  });
});

// GET /api/jobs/:id: one stored listing with the member's own saved / tracked state. A listing that is no longer stored answers 404 job_not_found.
router.get('/:id', (req, res) => {
  const id = parseId(req.params.id, 'job id');
  const db = getDb();
  const row = db.prepare('SELECT * FROM jobs WHERE id = ?').get(id);
  if (!row) throw new HttpError(404, 'This job listing is no longer available.', 'job_not_found');
  res.json({ job: { ...shapeJob(row), ...memberFlags(db, req.user.id, [row])(row), description: row.description_text || null } });
});

// POST /api/jobs/refresh (administrators): start a fetch in the background; ignored when the data is fresher than manualMinAgeMinutes.
router.post('/refresh', (req, res) => {
  if (!isAdmin(req.user)) throw new HttpError(403, 'Only administrators can refresh the job listings.', 'forbidden');
  const svc = getJobsService();
  if (svc.isRunning()) return res.status(202).json({ started: false, reason: 'already_running' });
  const age = svc.minutesSinceLastOk();
  if (age < config.jobs.manualMinAgeMinutes) return res.status(202).json({ started: false, reason: 'fresh', minutesSinceLastFetch: Math.round(age) });
  svc.run('manual').catch((e) => svc.logger.error(`manual fetch failed: ${e?.message}`));
  res.status(202).json({ started: true });
});

export default router;
