import { Router } from 'express';
import { getDb } from '../db/index.js';
import { badRequest } from '../utils/httpError.js';
import { imageUrl } from '../utils/images.js';

/**
 * Search and discovery (PRD FR-05): people and communities only.
 *
 * Sorting. The default is "recent":
 *   people      newest first by users.updated_at (the last time the profile or status changed; equals the sign-up time
 *               until then), then by id, so the order is stable
 *   communities newest first by communities.created_at, then by id
 * "relevance" (sort=relevance) puts name matches first, then falls back to the same recent order.
 * Everything here needs a signed-in member (see app.js) and never returns emails or other account data.
 */
const router = Router();

const DEFAULT_LIMIT = 20;
const MAX_LIMIT = 100;
const STATUS_FILTERS = { student: 'Student', beginner: 'Beginner', professional: 'Professional', leader: 'Community Leader' };
const SORTS = ['recent', 'relevance'];

const str = (v) => (typeof v === 'string' ? v.trim() : '');

// GET /api/search/options: values for the Profession, Status and Specialty filters.
router.get('/options', (req, res) => {
  const db = getDb();
  res.json({
    professions: db
      .prepare("SELECT DISTINCT profession FROM users WHERE profile_completed = 1 AND role <> 'admin' AND profession IS NOT NULL AND profession != '' ORDER BY profession COLLATE NOCASE")
      .all()
      .map((r) => r.profession),
    statuses: Object.entries(STATUS_FILTERS).map(([value, label]) => ({ value, label })),
    categories: db
      .prepare("SELECT DISTINCT category FROM communities WHERE status = 'approved' ORDER BY category COLLATE NOCASE")
      .all()
      .map((r) => r.category),
  });
});

const IS_LEADER = 'EXISTS (SELECT 1 FROM community_leaders cl WHERE cl.user_id = u.id)';
// Joining happens on the main community, so a subcommunity shows its parent's members and the viewer's parent membership.
const MEMBER_COUNT = `(SELECT COUNT(DISTINCT m.user_id) FROM memberships m JOIN users mu ON mu.id = m.user_id
   WHERE mu.role <> 'admin' AND (m.community_id = COALESCE(c.parent_id, c.id) OR m.community_id IN (SELECT id FROM communities WHERE parent_id = c.id))) AS member_count`;
const POST_COUNT = '(SELECT COUNT(*) FROM posts p WHERE p.community_id = c.id OR p.community_id IN (SELECT id FROM communities WHERE parent_id = c.id)) AS post_count';
const VIEWER_IS_MEMBER = '(SELECT COUNT(*) FROM memberships mm WHERE mm.user_id = ? AND mm.community_id = COALESCE(c.parent_id, c.id)) AS is_member';

function shapePerson(u) {
  let skills = [];
  try { skills = JSON.parse(u.skills || '[]'); } catch { skills = []; }
  return {
    id: u.id,
    name: u.name,
    profession: u.profession,
    headline: u.headline,
    location: u.location,
    skills,
    bioExcerpt: u.bio_excerpt,
    avatarUrl: imageUrl(u.avatar_file),
    status: u.status,
    isLeader: !!u.is_leader,
    isBot: !!u.is_bot,
    updatedAt: u.updated_at,
  };
}

function shapeCommunity(c) {
  return {
    id: c.id,
    name: c.name,
    slug: c.slug,
    description: c.description,
    category: c.category,
    isSubcommunity: c.parent_id !== null,
    parent: c.parent_id ? { id: c.parent_id, name: c.parent_name, slug: c.parent_slug } : null,
    memberCount: c.member_count,
    postCount: c.post_count,
    isMember: !!c.is_member,
    joinTargetId: c.parent_id ?? c.id, // the community a member joins (subcommunities open with their parent)
    createdAt: c.created_at,
  };
}

/**
 * GET /api/search?q=&profession=&status=&category=&sort=&limit=
 *   q           matched case-insensitively (every script) as plain text; % and _ are ordinary characters
 *   profession  people: exact profession text
 *   status      people: student | beginner | professional | leader (Community Leader). Bots never match a status.
 *   category    communities: specialty/category
 *   sort        recent (default) | relevance
 *   limit       results per tab, default 20, at most 100
 * An empty search is a discovery view: the newest people and communities.
 */
router.get('/', (req, res) => {
  const db = getDb();
  const q = str(req.query.q);
  const profession = str(req.query.profession);
  const status = str(req.query.status).toLowerCase();
  const category = str(req.query.category);
  const sort = str(req.query.sort) || 'recent';
  if (q.length > 100) throw badRequest('Search text must be 100 characters or fewer.', 'query_too_long');
  if (profession.length > 80) throw badRequest('Invalid profession.', 'invalid_filter');
  if (category.length > 80) throw badRequest('Invalid specialty.', 'invalid_filter');
  if (status && !STATUS_FILTERS[status]) throw badRequest('Invalid status.', 'invalid_filter');
  if (!SORTS.includes(sort)) throw badRequest('Invalid sort order.', 'invalid_filter');
  let limit = DEFAULT_LIMIT;
  if (req.query.limit !== undefined && req.query.limit !== '') {
    limit = Number(req.query.limit);
    if (!Number.isInteger(limit) || limit < 1 || limit > MAX_LIMIT) throw badRequest(`limit must be a whole number from 1 to ${MAX_LIMIT}.`, 'invalid_filter');
  }

  // ---- people: completed profiles only, never administrators, never email or account data ----
  const pWhere = ['u.profile_completed = 1', "u.role <> 'admin'"];
  const pParams = [];
  if (q) {
    pWhere.push('(ulike(u.name, ?) OR ulike(u.profession, ?) OR ulike(u.headline, ?) OR ulike(u.bio, ?) OR ulike(u.skills, ?) OR ulike(u.location, ?))');
    pParams.push(...Array(6).fill(q));
  }
  if (profession) {
    pWhere.push('u.profession = ? COLLATE NOCASE');
    pParams.push(profession);
  }
  if (status === 'leader') pWhere.push('u.is_bot = 0', IS_LEADER);
  else if (status) {
    pWhere.push('u.is_bot = 0', 'u.status = ?');
    pParams.push(status);
  }
  const pFrom = `FROM users u WHERE ${pWhere.join(' AND ')}`;
  const pOrder = sort === 'relevance' && q ? '(ulike(u.name, ?)) DESC, (ulike(u.profession, ?)) DESC, u.updated_at DESC, u.id DESC' : 'u.updated_at DESC, u.id DESC';
  const pOrderParams = sort === 'relevance' && q ? [q, q] : [];
  const people = {
    total: db.prepare(`SELECT COUNT(*) AS n ${pFrom}`).get(...pParams).n,
    items: db
      .prepare(
        `SELECT u.id, u.name, u.profession, u.headline, u.location, u.skills, u.avatar_file, u.status, u.is_bot, u.updated_at,
                ${IS_LEADER} AS is_leader, substr(u.bio, 1, 140) AS bio_excerpt
           ${pFrom} ORDER BY ${pOrder} LIMIT ${limit}`
      )
      .all(...pParams, ...pOrderParams)
      .map(shapePerson),
  };

  // ---- communities and subcommunities ----
  const cWhere = ["c.status = 'approved'"];
  const cParams = [];
  if (q) {
    cWhere.push('(ulike(c.name, ?) OR ulike(c.description, ?) OR ulike(c.category, ?))');
    cParams.push(q, q, q);
  }
  if (category) {
    cWhere.push('c.category = ? COLLATE NOCASE');
    cParams.push(category);
  }
  const cFrom = `FROM communities c LEFT JOIN communities p ON p.id = c.parent_id WHERE ${cWhere.join(' AND ')}`;
  const cOrder = sort === 'relevance' && q ? '(ulike(c.name, ?)) DESC, member_count DESC, c.created_at DESC, c.id DESC' : 'c.created_at DESC, c.id DESC';
  const communities = {
    total: db.prepare(`SELECT COUNT(*) AS n ${cFrom}`).get(...cParams).n,
    items: db
      .prepare(
        `SELECT c.*, p.name AS parent_name, p.slug AS parent_slug, ${MEMBER_COUNT}, ${POST_COUNT}, ${VIEWER_IS_MEMBER}
           ${cFrom} ORDER BY ${cOrder} LIMIT ${limit}`
      )
      .all(req.user.id, ...cParams, ...(sort === 'relevance' && q ? [q] : []))
      .map(shapeCommunity),
  };

  res.json({
    query: { q, profession, status, category, sort, limit },
    sortedBy: sort === 'relevance' && q ? { people: 'best match', communities: 'best match' } : { people: 'last profile update, newest first', communities: 'creation date, newest first' },
    results: { people, communities },
  });
});

export default router;
