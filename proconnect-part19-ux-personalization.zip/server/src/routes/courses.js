import { Router } from 'express';
import { getDb } from '../db/index.js';
import { badRequest, notFoundError, parseId } from '../utils/httpError.js';

const router = Router();

export const DELIVERY_MODES = ['online', 'in_person', 'hybrid'];

export const shapeCourse = (c, { registered } = {}) => {
  const past = c.starts_at ? new Date(c.starts_at).getTime() < Date.now() : false;
  const deadlinePassed = c.registration_deadline ? new Date(c.registration_deadline).getTime() < Date.now() : false;
  return {
    id: c.id,
    title: c.title,
    description: c.description,
    type: c.type,
    category: c.category,
    organizer: c.organizer,
    isFree: !!c.is_free,
    priceLabel: c.is_free ? 'Free' : 'Paid',
    priceText: c.price_text,
    startsAt: c.starts_at,
    duration: c.duration,
    externalUrl: c.external_url,
    isSample: !!c.is_sample,
    isPast: past,
    // Part 17 fields; null on older listings, and the UI hides what is null.
    instructorName: c.instructor_name || null,
    instructorRole: c.instructor_role || null,
    deliveryMode: c.delivery_mode || null,
    location: c.location || null,
    registrationDeadline: c.registration_deadline || null,
    image: c.image || null,
    // Demo registration is only offered on sample listings; real listings keep their organizer's link.
    registrationKind: c.is_sample ? 'demo' : c.external_url ? 'external' : 'none',
    registrationOpen: !!c.is_sample && !past && !deadlinePassed,
    ...(registered === undefined ? {} : { registered }),
  };
};

// GET /api/courses?type=webinar&price=free&q=data&category=Finance&mode=online
router.get('/', (req, res) => {
  const where = ["approval_status = 'approved'"];
  const params = [];
  if (req.query.type) {
    if (!['course', 'webinar'].includes(req.query.type)) throw badRequest("type must be 'course' or 'webinar'.");
    where.push('type = ?');
    params.push(req.query.type);
  }
  if (req.query.price) {
    if (!['free', 'paid'].includes(req.query.price)) throw badRequest("price must be 'free' or 'paid'.");
    where.push('is_free = ?');
    params.push(req.query.price === 'free' ? 1 : 0);
  }
  if (req.query.mode) {
    if (!DELIVERY_MODES.includes(req.query.mode)) throw badRequest(`mode must be one of: ${DELIVERY_MODES.join(', ')}.`);
    where.push('delivery_mode = ?');
    params.push(req.query.mode);
  }
  if (req.query.category) {
    where.push('LOWER(category) = LOWER(?)'); // exact name, any letter case (category names are plain ASCII)
    params.push(String(req.query.category));
  }
  if (req.query.q) {
    where.push('(ulike(title, ?) OR ulike(description, ?) OR ulike(organizer, ?) OR ulike(category, ?) OR ulike(instructor_name, ?))');
    params.push(...Array(5).fill(String(req.query.q)));
  }
  const db = getDb();
  const rows = db
    .prepare(
      `SELECT * FROM courses WHERE ${where.join(' AND ')}
        ORDER BY CASE WHEN starts_at IS NULL THEN 1 WHEN starts_at >= ? THEN 0 ELSE 2 END, starts_at, title`
    )
    .all(...params, new Date().toISOString());
  // Filter options come from the stored listings, so every option offered really matches something.
  const categories = db.prepare("SELECT category, COUNT(*) AS n FROM courses WHERE approval_status = 'approved' AND category IS NOT NULL AND category <> '' GROUP BY category ORDER BY category").all();
  const modes = db.prepare("SELECT delivery_mode AS m, COUNT(*) AS n FROM courses WHERE approval_status = 'approved' AND delivery_mode IS NOT NULL GROUP BY delivery_mode").all();
  res.json({
    courses: rows.map((c) => shapeCourse(c)),
    facets: { categories: categories.map((r) => ({ name: r.category, count: r.n })), modes: Object.fromEntries(modes.map((r) => [r.m, r.n])) },
  });
});

const findApproved = (id) => getDb().prepare("SELECT * FROM courses WHERE id = ? AND approval_status = 'approved'").get(id);
const isRegistered = (userId, courseId) => !!getDb().prepare('SELECT 1 FROM course_registrations WHERE user_id = ? AND course_id = ?').get(userId, courseId);

router.get('/:id', (req, res) => {
  const id = parseId(req.params.id, 'course id');
  const row = findApproved(id);
  if (!row) throw notFoundError('Course or webinar not found.');
  res.json({ course: shapeCourse(row, { registered: isRegistered(req.user.id, id) }) });
});

// Demo registration (sample listings only). It records the member's choice in this database; nothing is sent to anyone.
router.post('/:id/register', (req, res) => {
  const id = parseId(req.params.id, 'course id');
  const row = findApproved(id);
  if (!row) throw notFoundError('Course or webinar not found.');
  if (!row.is_sample) throw badRequest("This listing uses its organizer's own registration link.", 'external_registration');
  const course = shapeCourse(row);
  if (!course.registrationOpen) throw badRequest('Registration for this demo listing is closed.', 'registration_closed');
  getDb().prepare('INSERT OR IGNORE INTO course_registrations (user_id, course_id) VALUES (?, ?)').run(req.user.id, id);
  res.status(201).json({ course: shapeCourse(row, { registered: true }) });
});

router.delete('/:id/register', (req, res) => {
  const id = parseId(req.params.id, 'course id');
  const row = findApproved(id);
  if (!row) throw notFoundError('Course or webinar not found.');
  getDb().prepare('DELETE FROM course_registrations WHERE user_id = ? AND course_id = ?').run(req.user.id, id);
  res.json({ course: shapeCourse(row, { registered: false }) });
});

export default router;
