import { Router } from 'express';
import { getDb } from '../db/index.js';
import { asyncHandler, badRequest, HttpError, notFoundError, parseId } from '../utils/httpError.js';
import { getNewsScheduler, getNewsService } from '../news/index.js';
import { NewsError, canonicalUrl, validateFeedUrl } from '../news/urls.js';
import { plainText } from '../news/text.js';
import { config } from '../config.js';

// Mounted under /api/admin/news, so the Admin-only guard in routes/admin.js applies to everything here.
const router = Router();

const shape = (s) => ({
  id: s.id,
  name: s.name,
  kind: s.kind,
  url: s.url,
  enabled: !!s.enabled,
  builtin: !!s.is_builtin,
  urlEditable: s.kind === 'rss',
  lastSyncAt: s.last_sync_at,
  lastStatus: s.last_status,
  lastMessage: s.last_message,
  lastFetched: s.last_fetched,
  lastInserted: s.last_inserted,
  articleCount: s.article_count ?? 0,
});

const listSql = `SELECT s.*, (SELECT COUNT(*) FROM news_articles a WHERE a.source_id = s.id) AS article_count FROM news_sources s`;
const load = (id) => getDb().prepare(`${listSql} WHERE s.id = ?`).get(id);
const TOUCH = "updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')";

function cleanName(value) {
  const name = plainText(typeof value === 'string' ? value : '');
  if (name.length < 2 || name.length > 60) throw new HttpError(400, 'Please fix the highlighted fields.', 'validation_error', { name: 'Enter a name of 2 to 60 characters.' });
  return name;
}

/** Turns an address problem into a 400 on the url field; anything unexpected is rethrown. */
async function checkedUrl(raw) {
  try {
    return await validateFeedUrl(raw, { resolve: getNewsService().resolveHost });
  } catch (err) {
    if (err instanceof NewsError) throw new HttpError(400, 'Please fix the highlighted fields.', 'validation_error', { url: err.message });
    throw err;
  }
}

// GET /api/admin/news/sources
router.get('/sources', (req, res) => {
  res.json({ sources: getDb().prepare(`${listSql} ORDER BY s.id`).all().map(shape) });
});

// GET /api/admin/news/status: scheduler registration and the last synchronization summary.
router.get('/status', (req, res) => {
  const service = getNewsService();
  const scheduler = getNewsScheduler();
  res.json({
    scheduler: scheduler ? scheduler.status() : { registered: false, intervalMinutes: service.intervalMinutes, nextRunAt: null, running: service.isRunning(), startedAt: null },
    retentionHours: service.retentionHours,
    syncEnabled: config.news.enabled,
    lastRun: service.lastRun(),
  });
});

// POST /api/admin/news/sources { name, url }: adds an RSS/Atom feed and fetches it once right away to prove it works.
router.post('/sources', asyncHandler(async (req, res) => {
  const db = getDb();
  const name = cleanName(req.body?.name);
  const url = await checkedUrl(req.body?.url);
  if (db.prepare('SELECT COUNT(*) AS n FROM news_sources').get().n >= config.news.maxSources) throw badRequest(`At most ${config.news.maxSources} sources can be configured.`, 'too_many_sources');
  const key = canonicalUrl(url);
  if (db.prepare('SELECT 1 FROM news_sources WHERE url_key = ?').get(key)) throw new HttpError(409, 'This feed is already configured.', 'duplicate_source', { url: 'This feed is already configured.' });
  const id = Number(db.prepare("INSERT INTO news_sources (key, name, kind, url, url_key, enabled, is_builtin) VALUES (NULL, ?, 'rss', ?, ?, 1, 0)").run(name, url, key).lastInsertRowid);
  const check = await getNewsService().runSource(id);
  res.status(201).json({ source: shape(load(id)), check: check.skipped ? { skipped: true } : { status: check.status, message: check.message } });
}));

// PUT /api/admin/news/sources/:id { enabled?, name?, url? }
router.put('/sources/:id', asyncHandler(async (req, res) => {
  const db = getDb();
  const id = parseId(req.params.id, 'source id');
  const source = db.prepare('SELECT * FROM news_sources WHERE id = ?').get(id);
  if (!source) throw notFoundError('Source not found.');
  const body = req.body || {};
  if (body.enabled === undefined && body.name === undefined && body.url === undefined) throw badRequest('Nothing to change.');
  if (body.enabled !== undefined && typeof body.enabled !== 'boolean') throw badRequest('enabled must be true or false.');
  const name = body.name === undefined ? source.name : cleanName(body.name);
  let url = source.url;
  let key = source.url_key;
  let urlChanged = false;
  if (body.url !== undefined && body.url !== source.url) {
    if (source.kind !== 'rss') throw new HttpError(400, 'Please fix the highlighted fields.', 'validation_error', { url: 'The address of this built-in API source cannot be changed.' });
    url = await checkedUrl(body.url);
    key = canonicalUrl(url);
    if (key !== source.url_key) {
      if (db.prepare('SELECT 1 FROM news_sources WHERE url_key = ? AND id <> ?').get(key, id)) throw new HttpError(409, 'This feed is already configured.', 'duplicate_source', { url: 'This feed is already configured.' });
      urlChanged = true;
    } else {
      url = source.url;
    }
  }
  const enabled = body.enabled === undefined ? source.enabled : body.enabled ? 1 : 0;
  db.prepare(`UPDATE news_sources SET name = ?, url = ?, url_key = ?, enabled = ?, ${TOUCH} WHERE id = ?`).run(name, url, key, enabled, id);
  let check = null;
  if (urlChanged) {
    // A new address starts with a clean result and articles from the old address stay until they expire.
    db.prepare('UPDATE news_sources SET last_sync_at = NULL, last_status = NULL, last_message = NULL, last_fetched = NULL, last_inserted = NULL WHERE id = ?').run(id);
    if (enabled) {
      const r = await getNewsService().runSource(id);
      check = r.skipped ? { skipped: true } : { status: r.status, message: r.message };
    }
  }
  res.json({ source: shape(load(id)), ...(check ? { check } : {}) });
}));

// DELETE /api/admin/news/sources/:id: only sources an Admin added can be removed; built-in ones are disabled instead.
router.delete('/sources/:id', (req, res) => {
  const db = getDb();
  const id = parseId(req.params.id, 'source id');
  const source = db.prepare('SELECT * FROM news_sources WHERE id = ?').get(id);
  if (!source) throw notFoundError('Source not found.');
  if (source.is_builtin) throw badRequest('Built-in sources cannot be removed. Disable the source instead.', 'builtin_source');
  const removedArticles = db.prepare('SELECT COUNT(*) AS n FROM news_articles WHERE source_id = ?').get(id).n;
  db.prepare('DELETE FROM news_sources WHERE id = ?').run(id); // its stored articles go with it (ON DELETE CASCADE); nothing else is touched
  res.json({ ok: true, removedArticles });
});

export default router;
