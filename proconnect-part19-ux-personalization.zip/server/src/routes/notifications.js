import { Router } from 'express';
import { getDb } from '../db/index.js';
import { notFoundError, parseId } from '../utils/httpError.js';
import { imageUrl } from '../utils/images.js';

// Every query below is scoped to req.user.id: a member can only ever see or change their own notifications.
const router = Router();

const MAX_LIMIT = 50;

const unreadCount = (db, userId) => db.prepare('SELECT COUNT(*) AS n FROM notifications WHERE recipient_id = ? AND read_at IS NULL').get(userId).n;

function shape(r) {
  return {
    id: r.id,
    type: r.type,
    read: r.read_at !== null,
    readAt: r.read_at,
    createdAt: r.created_at,
    actor: r.actor_id ? { id: r.actor_id, name: r.actor_name, avatarUrl: imageUrl(r.actor_avatar), isBot: !!r.actor_is_bot } : null,
    community: { id: r.community_id, name: r.community_name },
    post: { id: r.post_id, title: r.post_title },
    commentId: r.comment_id ?? null,
    link: r.comment_id ? `/posts/${r.post_id}#comment-${r.comment_id}` : `/posts/${r.post_id}`,
  };
}

// GET /api/notifications?limit=20&unread=1
router.get('/', (req, res) => {
  const db = getDb();
  const limit = Math.min(Math.max(Number.parseInt(req.query.limit, 10) || 20, 1), MAX_LIMIT);
  const onlyUnread = req.query.unread === '1' || req.query.unread === 'true';
  const rows = db
    .prepare(
      `SELECT n.*, a.name AS actor_name, a.avatar_file AS actor_avatar, a.is_bot AS actor_is_bot,
              c.name AS community_name, p.title AS post_title
         FROM notifications n
         JOIN communities c ON c.id = n.community_id
         JOIN posts p ON p.id = n.post_id
         LEFT JOIN users a ON a.id = n.actor_id
        WHERE n.recipient_id = ? ${onlyUnread ? 'AND n.read_at IS NULL' : ''}
        ORDER BY n.created_at DESC, n.id DESC LIMIT ?`
    )
    .all(req.user.id, limit);
  res.json({ notifications: rows.map(shape), unreadCount: unreadCount(db, req.user.id) });
});

// GET /api/notifications/unread-count
router.get('/unread-count', (req, res) => {
  res.json({ unreadCount: unreadCount(getDb(), req.user.id) });
});

// POST /api/notifications/read-all
router.post('/read-all', (req, res) => {
  const db = getDb();
  db.prepare("UPDATE notifications SET read_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE recipient_id = ? AND read_at IS NULL").run(req.user.id);
  res.json({ unreadCount: unreadCount(db, req.user.id) });
});

// POST /api/notifications/:id/read. Someone else's notification looks exactly like a missing one.
router.post('/:id/read', (req, res) => {
  const db = getDb();
  const id = parseId(req.params.id, 'notification id');
  const own = db.prepare('SELECT id FROM notifications WHERE id = ? AND recipient_id = ?').get(id, req.user.id);
  if (!own) throw notFoundError('Notification not found.');
  db.prepare("UPDATE notifications SET read_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ? AND read_at IS NULL").run(id);
  res.json({ unreadCount: unreadCount(db, req.user.id) });
});

export default router;
