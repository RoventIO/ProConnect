import { Router } from 'express';
import { getDb } from '../db/index.js';
import { COUNTS } from './communities.js';
import { shapeCourse } from './courses.js';
import { imageUrl } from '../utils/images.js';
import { shapeJob, memberFlags } from './jobs.js';
import { summary as applicationSummary } from './jobApplications.js';
import { loadPreferences } from '../utils/preferences.js';
import { profileStrength } from '../utils/profileStrength.js';
import { recommendCommunities } from '../utils/recommend.js';
import { categoryLabel } from '../jobs/categories.js';

const router = Router();

// Part 19: the member's own dashboard data. Everything is read with the signed-in member's id from the session and built from real records:
// nothing is invented, and a section with nothing to show says so (empty lists) instead of being filled with made-up items.
function personalFor(db, user) {
  const uid = user.id;

  // Recent discussions in the communities the member joined, including their subcommunities (members join main communities;
  // a subcommunity is covered by its parent). The member's own posts are left out: this list is about what is new to them.
  const joinedCount = db.prepare('SELECT COUNT(*) AS n FROM memberships WHERE user_id = ?').get(uid).n;
  const fresh = db
    .prepare(
      `SELECT p.id, p.title, p.created_at, u.id AS author_id, u.name AS author_name, u.is_bot AS author_is_bot, u.avatar_file AS author_avatar,
              c.id AS community_id, c.name AS community_name, parent.id AS parent_id, parent.name AS parent_name,
              (SELECT COUNT(*) FROM comments x WHERE x.post_id = p.id) AS reply_count
         FROM posts p
         JOIN users u ON u.id = p.author_id
         JOIN communities c ON c.id = p.community_id
         LEFT JOIN communities parent ON parent.id = c.parent_id
        WHERE (c.id IN (SELECT community_id FROM memberships WHERE user_id = ?) OR c.parent_id IN (SELECT community_id FROM memberships WHERE user_id = ?))
          AND p.author_id <> ?
        ORDER BY p.created_at DESC, p.id DESC LIMIT 5`
    )
    .all(uid, uid, uid)
    .map((p) => ({
      id: p.id,
      title: p.title,
      createdAt: p.created_at,
      replyCount: p.reply_count,
      author: { id: p.author_id, name: p.author_name, isBot: !!p.author_is_bot, avatarUrl: imageUrl(p.author_avatar) },
      community: { id: p.community_id, name: p.community_name },
      parentCommunity: p.parent_id ? { id: p.parent_id, name: p.parent_name } : null,
    }));

  // Jobs that match the saved preferences (same stored listings, same filters and the same shape as GET /api/jobs).
  const prefs = loadPreferences(uid);
  const jobs = { hasPreferences: !!(prefs.jobCategory || prefs.jobWorkMode), category: prefs.jobCategory ? { key: prefs.jobCategory, label: categoryLabel(prefs.jobCategory) } : null, workMode: prefs.jobWorkMode, total: 0, items: [] };
  if (jobs.hasPreferences) {
    const parts = [];
    const params = [];
    if (prefs.jobCategory) { parts.push('category = ?'); params.push(prefs.jobCategory); }
    if (prefs.jobWorkMode) { parts.push('work_mode = ?'); params.push(prefs.jobWorkMode); }
    const whereSql = `WHERE ${parts.join(' AND ')}`;
    jobs.total = db.prepare(`SELECT COUNT(*) AS n FROM jobs ${whereSql}`).get(...params).n;
    const rows = db.prepare(`SELECT * FROM jobs ${whereSql} ORDER BY COALESCE(published_at, first_seen_at) DESC, id DESC LIMIT 4`).all(...params);
    const flags = memberFlags(db, uid, rows);
    jobs.items = rows.map((r) => ({ ...shapeJob(r), ...flags(r) }));
  }

  // Upcoming registrations the member really made (demo registrations on sample listings are marked isSample).
  const now = new Date().toISOString();
  const upcoming = `FROM course_registrations r JOIN courses c ON c.id = r.course_id
                     WHERE r.user_id = ? AND c.approval_status = 'approved' AND c.starts_at IS NOT NULL AND c.starts_at >= ?`;
  const registrations = {
    total: db.prepare(`SELECT COUNT(*) AS n ${upcoming}`).get(uid, now).n,
    items: db.prepare(`SELECT c.* ${upcoming} ORDER BY c.starts_at, c.id LIMIT 5`).all(uid, now).map((c) => shapeCourse(c, { registered: true })),
  };

  return {
    profile: { name: user.name, profession: user.profession || null, status: user.status, completion: profileStrength(user) },
    newInCommunities: { joinedCount, items: fresh },
    communitiesForYou: recommendCommunities(db, user, { limit: 4 }),
    jobsForYou: jobs,
    jobSearch: { savedCount: db.prepare('SELECT COUNT(*) AS n FROM saved_jobs WHERE user_id = ?').get(uid).n, applications: applicationSummary(db, uid) },
    registrations,
  };
}

// GET /api/home: trending discussions, upcoming learning and popular communities for signed-in members.
router.get('/', (req, res) => {
  const db = getDb();

  const trending = db
    .prepare(
      `SELECT p.id, p.title, p.created_at, u.id AS author_id, u.name AS author_name, u.profession AS author_profession, u.avatar_file AS author_avatar, u.is_bot AS author_is_bot,
              c.id AS community_id, c.name AS community_name,
              (SELECT COUNT(*) FROM comments x WHERE x.post_id = p.id) AS reply_count
         FROM posts p JOIN users u ON u.id = p.author_id JOIN communities c ON c.id = p.community_id
        ORDER BY reply_count DESC, p.created_at DESC LIMIT 4`
    )
    .all()
    .map((p) => ({
      id: p.id,
      title: p.title,
      createdAt: p.created_at,
      replyCount: p.reply_count,
      author: { id: p.author_id, name: p.author_name, profession: p.author_profession, isBot: !!p.author_is_bot, avatarUrl: imageUrl(p.author_avatar) },
      community: { id: p.community_id, name: p.community_name },
    }));

  const now = new Date().toISOString();
  const courses = db
    .prepare(
      `SELECT * FROM courses WHERE approval_status = 'approved'
        ORDER BY CASE WHEN starts_at IS NULL THEN 1 WHEN starts_at >= ? THEN 0 ELSE 2 END, starts_at LIMIT 4`
    )
    .all(now)
    .map(shapeCourse);

  const popular = db
    .prepare(`SELECT c.id, c.name, ${COUNTS} FROM communities c WHERE c.parent_id IS NULL AND c.status = 'approved' ORDER BY member_count DESC, c.name LIMIT 3`)
    .all()
    .map((c) => ({ id: c.id, name: c.name, memberCount: c.member_count, postCount: c.post_count }));

  // `personal` is additive: every earlier field keeps its name and shape.
  res.set('Cache-Control', 'no-store');
  res.json({ trending, courses, popularCommunities: popular, personal: personalFor(db, req.user) });
});

export default router;
