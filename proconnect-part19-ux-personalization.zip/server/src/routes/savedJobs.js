import { Router } from 'express';
import { getDb } from '../db/index.js';
import { HttpError, badRequest, notFoundError, parseId } from '../utils/httpError.js';
import { CATEGORY_KEYS, JOB_CATEGORIES, categoryLabel } from '../jobs/categories.js';
import { JOB_SOURCES } from '../jobs/service.js';

// Saved Jobs (Part 18). Every query is scoped by req.user.id, which comes from the session cookie and never from the request.
const router = Router();
const SOURCE_NAME = Object.fromEntries(JOB_SOURCES.map((s) => [s.key, s.name]));
const SORTS = {
  recent: 's.saved_at DESC, s.id DESC',
  oldest: 's.saved_at ASC, s.id ASC',
  title: 'title_sort COLLATE NOCASE ASC, s.id ASC',
};
const MAX_LISTED = 500;

/**
 * One saved job as the client sees it. When the listing is still stored, its fresh values are shown; when it is not (the
 * source removed it, or ProConnect's retention cleanup did), the snapshot taken at save time is shown with available: false.
 * The original link of a missing listing is only the last known address, never rebuilt or guessed.
 */
export function shapeSaved(r) {
  const live = r.live_id != null;
  const pick = (liveValue, snap) => (live ? liveValue : snap);
  const url = pick(r.live_url, r.job_url);
  return {
    id: r.id,
    savedAt: r.saved_at,
    availability: live ? 'available' : 'unavailable',
    job: {
      id: live ? r.live_id : null,
      title: pick(r.live_title, r.title),
      company: pick(r.live_company, r.company),
      location: pick(r.live_location, r.location) || null,
      workMode: pick(r.live_work_mode, r.work_mode) || null,
      employmentType: pick(r.live_employment_type, r.employment_type) || null,
      category: { key: pick(r.live_category, r.category) || 'other', label: categoryLabel(pick(r.live_category, r.category) || 'other') },
      publishedAt: pick(r.live_published_at, r.published_at) || null,
      source: { key: r.source, name: SOURCE_NAME[r.source] || r.source },
      applyUrl: live ? url : null,
      lastKnownUrl: live ? null : url || null,
    },
  };
}

const SELECT = `SELECT s.*, j.id AS live_id, j.title AS live_title, j.company AS live_company, j.location AS live_location, j.work_mode AS live_work_mode,
    j.employment_type AS live_employment_type, j.category AS live_category, j.published_at AS live_published_at, j.url AS live_url,
    COALESCE(j.title, s.title) AS title_sort
  FROM saved_jobs s LEFT JOIN jobs j ON j.source = s.source AND j.external_id = s.external_id`;

// GET /api/saved-jobs?q=&category=&availability=available|unavailable&sort=recent|oldest|title
router.get('/', (req, res) => {
  const q = String(req.query.q || '').trim().slice(0, 100);
  const category = req.query.category ? String(req.query.category) : '';
  if (category && !CATEGORY_KEYS.includes(category)) throw badRequest(`category must be one of: ${CATEGORY_KEYS.join(', ')}.`);
  const availability = req.query.availability ? String(req.query.availability) : '';
  if (availability && !['available', 'unavailable'].includes(availability)) throw badRequest('availability must be available or unavailable.');
  const sort = req.query.sort ? String(req.query.sort) : 'recent';
  if (!SORTS[sort]) throw badRequest(`sort must be one of: ${Object.keys(SORTS).join(', ')}.`);

  const db = getDb();
  const all = db.prepare(`${SELECT} WHERE s.user_id = ?`).all(req.user.id);
  const effCategory = (r) => (r.live_id != null ? r.live_category : r.category) || 'other';
  const parts = ['s.user_id = ?'];
  const params = [req.user.id];
  if (q) {
    parts.push('(ulike(COALESCE(j.title, s.title), ?) OR ulike(COALESCE(j.company, s.company), ?))');
    params.push(q, q);
  }
  if (category) {
    parts.push("COALESCE(CASE WHEN j.id IS NOT NULL THEN j.category END, s.category, 'other') = ?");
    params.push(category);
  }
  if (availability) parts.push(availability === 'available' ? 'j.id IS NOT NULL' : 'j.id IS NULL');
  const rows = db.prepare(`${SELECT} WHERE ${parts.join(' AND ')} ORDER BY ${SORTS[sort]} LIMIT ${MAX_LISTED}`).all(...params);

  const counts = {};
  for (const r of all) counts[effCategory(r)] = (counts[effCategory(r)] || 0) + 1;
  res.json({
    savedJobs: rows.map(shapeSaved),
    total: rows.length,
    totalSaved: all.length, // all of the member's saved jobs, whatever the filters
    unavailable: all.filter((r) => r.live_id == null).length,
    facets: { categories: JOB_CATEGORIES.map((c) => ({ key: c.key, label: c.label, count: counts[c.key] || 0 })).filter((c) => c.count > 0) },
  });
});

// POST /api/saved-jobs { jobId }  -> 201 with the saved record; 409 already_saved when it is saved already; 404 job_not_found when the listing is gone.
router.post('/', (req, res) => {
  const jobId = req.body?.jobId;
  if (!Number.isInteger(jobId) || jobId <= 0) throw new HttpError(400, 'Choose a job to save.', 'validation_error', { jobId: 'A job id is required.' });
  const db = getDb();
  const job = db.prepare('SELECT * FROM jobs WHERE id = ?').get(jobId);
  if (!job) throw new HttpError(404, 'This job listing is no longer available, so it cannot be saved.', 'job_not_found');
  const existing = db.prepare('SELECT id FROM saved_jobs WHERE user_id = ? AND source = ? AND external_id = ?').get(req.user.id, job.source, job.external_id);
  if (existing) throw new HttpError(409, 'You have already saved this job.', 'already_saved', undefined, { savedId: existing.id });
  let id;
  try {
    id = db
      .prepare(
        `INSERT INTO saved_jobs (user_id, source, external_id, title, company, location, work_mode, employment_type, category, published_at, job_url)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      )
      .run(req.user.id, job.source, job.external_id, job.title, job.company, job.location, job.work_mode, job.employment_type, job.category, job.published_at, job.url).lastInsertRowid;
  } catch (err) {
    // Two clicks at the same moment: the unique index decides, and the second one is reported like any duplicate.
    if (/UNIQUE/i.test(err?.message || '')) {
      const again = db.prepare('SELECT id FROM saved_jobs WHERE user_id = ? AND source = ? AND external_id = ?').get(req.user.id, job.source, job.external_id);
      throw new HttpError(409, 'You have already saved this job.', 'already_saved', undefined, { savedId: again?.id });
    }
    throw err;
  }
  const row = db.prepare(`${SELECT} WHERE s.id = ? AND s.user_id = ?`).get(Number(id), req.user.id);
  res.status(201).json({ savedJob: shapeSaved(row) });
});

// DELETE /api/saved-jobs/:id  (the saved record's id). Someone else's record answers 404, the same as a record that does not exist.
router.delete('/:id', (req, res) => {
  const id = parseId(req.params.id, 'saved job id');
  const r = getDb().prepare('DELETE FROM saved_jobs WHERE id = ? AND user_id = ?').run(id, req.user.id);
  if (r.changes === 0) throw notFoundError('This saved job was not found.');
  res.json({ ok: true });
});

export default router;
