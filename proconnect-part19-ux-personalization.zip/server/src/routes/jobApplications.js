import { Router } from 'express';
import { getDb } from '../db/index.js';
import { HttpError, badRequest, notFoundError, parseId } from '../utils/httpError.js';
import { JOB_SOURCES } from '../jobs/service.js';
import { APPLICATION_STATUSES, duplicateKey, validateApplicationInput } from '../utils/applicationInput.js';

// My Applications (Part 18). A member's own tracking list. ProConnect has no internal application process: these records are what the
// member reports about applications made on employer websites, and nothing here is created when someone merely clicks Apply.
// Every query is scoped by req.user.id from the session; ids sent by the client never decide ownership.
const router = Router();
const SOURCE_NAME = Object.fromEntries(JOB_SOURCES.map((s) => [s.key, s.name]));
const SORTS = { applied: 'a.applied_on', updated: 'a.updated_at' };

const SELECT = `SELECT a.*, j.id AS live_id FROM job_applications a
  LEFT JOIN jobs j ON a.job_source IS NOT NULL AND j.source = a.job_source AND j.external_id = a.job_external_id`;

export const shapeApplication = (r) => ({
  id: r.id,
  title: r.job_title,
  company: r.company,
  url: r.job_url || null,
  appliedOn: r.applied_on,
  status: r.status,
  notes: r.notes || null,
  createdAt: r.created_at,
  updatedAt: r.updated_at,
  // How the record came to be. Always a member-kept record: ProConnect never submits applications to employers.
  tracking: { origin: 'self_reported', submittedViaProConnect: false },
  job: r.job_source
    ? { id: r.live_id ?? null, available: r.live_id != null, source: { key: r.job_source, name: SOURCE_NAME[r.job_source] || r.job_source } }
    : null,
});

export function summary(db, userId) {
  const by = Object.fromEntries(db.prepare('SELECT status, COUNT(*) AS n FROM job_applications WHERE user_id = ? GROUP BY status').all(userId).map((r) => [r.status, r.n]));
  const counts = Object.fromEntries(APPLICATION_STATUSES.map((s) => [s, by[s] || 0]));
  return { total: Object.values(counts).reduce((a, b) => a + b, 0), ...counts };
}

const find = (db, id, userId) => db.prepare(`${SELECT} WHERE a.id = ? AND a.user_id = ?`).get(id, userId);
const duplicate = () => new HttpError(409, 'You are already tracking this application.', 'duplicate_application');

// GET /api/job-applications?status=&q=&sort=applied|updated&dir=desc|asc
router.get('/', (req, res) => {
  const status = req.query.status ? String(req.query.status) : '';
  if (status && !APPLICATION_STATUSES.includes(status)) throw badRequest(`status must be one of: ${APPLICATION_STATUSES.join(', ')}.`);
  const sort = req.query.sort ? String(req.query.sort) : 'applied';
  if (!SORTS[sort]) throw badRequest('sort must be applied or updated.');
  const dir = req.query.dir ? String(req.query.dir) : 'desc';
  if (!['asc', 'desc'].includes(dir)) throw badRequest('dir must be asc or desc.');
  const q = String(req.query.q || '').trim().slice(0, 100);

  const db = getDb();
  const parts = ['a.user_id = ?'];
  const params = [req.user.id];
  if (status) { parts.push('a.status = ?'); params.push(status); }
  if (q) { parts.push('(ulike(a.job_title, ?) OR ulike(a.company, ?))'); params.push(q, q); }
  const rows = db.prepare(`${SELECT} WHERE ${parts.join(' AND ')} ORDER BY ${SORTS[sort]} ${dir.toUpperCase()}, a.id ${dir.toUpperCase()}`).all(...params);
  // The summary counts every record of the member, whatever filter is active, so the numbers on the dashboard never change with a filter.
  res.json({ applications: rows.map(shapeApplication), total: rows.length, summary: summary(db, req.user.id) });
});

// POST /api/job-applications  { jobId } or { title, company, url? }  plus { appliedOn, status, notes? }
router.post('/', (req, res) => {
  const db = getDb();
  const jobId = req.body?.jobId;
  let job = null;
  if (jobId != null) {
    if (!Number.isInteger(jobId) || jobId <= 0) throw new HttpError(400, 'Please fix the highlighted fields.', 'validation_error', { jobId: 'Choose a valid job.' });
    job = db.prepare('SELECT * FROM jobs WHERE id = ?').get(jobId);
    if (!job) throw new HttpError(404, 'This job listing is no longer available. Enter its details manually instead.', 'job_not_found');
  }
  const input = validateApplicationInput(req.body, { linked: !!job });
  // A ProConnect listing supplies its own title, company and link (the member cannot misattribute it); notes, date and status are theirs.
  const rec = job
    ? { title: job.title, company: job.company, url: job.url, source: job.source, externalId: job.external_id }
    : { title: input.title, company: input.company, url: input.url ?? null, source: null, externalId: null };
  const key = duplicateKey(rec);
  if (db.prepare('SELECT 1 FROM job_applications WHERE user_id = ? AND dup_key = ?').get(req.user.id, key)) throw duplicate();
  let id;
  try {
    id = db
      .prepare('INSERT INTO job_applications (user_id, job_source, job_external_id, job_title, company, job_url, dup_key, applied_on, status, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
      .run(req.user.id, rec.source, rec.externalId, rec.title, rec.company, rec.url, key, input.appliedOn, input.status, input.notes ?? null).lastInsertRowid;
  } catch (err) {
    if (/UNIQUE/i.test(err?.message || '')) throw duplicate();
    throw err;
  }
  res.status(201).json({ application: shapeApplication(find(db, Number(id), req.user.id)), summary: summary(db, req.user.id) });
});

router.get('/:id', (req, res) => {
  const row = find(getDb(), parseId(req.params.id, 'application id'), req.user.id);
  if (!row) throw notFoundError('This application was not found.');
  res.json({ application: shapeApplication(row) });
});

// PUT /api/job-applications/:id  (any of title, company, url, appliedOn, status, notes). Which listing a record is linked to cannot be changed.
router.put('/:id', (req, res) => {
  const db = getDb();
  const id = parseId(req.params.id, 'application id');
  const row = find(db, id, req.user.id);
  if (!row) throw notFoundError('This application was not found.');
  const input = validateApplicationInput(req.body, { partial: true });
  if (Object.keys(input).length === 0) throw badRequest('Send at least one field to change.', 'nothing_to_update');
  const next = {
    title: input.title ?? row.job_title,
    company: input.company ?? row.company,
    url: 'url' in input ? input.url : row.job_url,
    appliedOn: input.appliedOn ?? row.applied_on,
    status: input.status ?? row.status,
    notes: 'notes' in input ? input.notes : row.notes,
  };
  const key = duplicateKey(next);
  if (db.prepare('SELECT 1 FROM job_applications WHERE user_id = ? AND dup_key = ? AND id <> ?').get(req.user.id, key, id)) throw duplicate();
  try {
    db.prepare(
      `UPDATE job_applications SET job_title = ?, company = ?, job_url = ?, dup_key = ?, applied_on = ?, status = ?, notes = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
       WHERE id = ? AND user_id = ?`
    ).run(next.title, next.company, next.url ?? null, key, next.appliedOn, next.status, next.notes ?? null, id, req.user.id);
  } catch (err) {
    if (/UNIQUE/i.test(err?.message || '')) throw duplicate();
    throw err;
  }
  res.json({ application: shapeApplication(find(db, id, req.user.id)), summary: summary(db, req.user.id) });
});

router.delete('/:id', (req, res) => {
  const db = getDb();
  const r = db.prepare('DELETE FROM job_applications WHERE id = ? AND user_id = ?').run(parseId(req.params.id, 'application id'), req.user.id);
  if (r.changes === 0) throw notFoundError('This application was not found.');
  res.json({ ok: true, summary: summary(db, req.user.id) });
});

export default router;
