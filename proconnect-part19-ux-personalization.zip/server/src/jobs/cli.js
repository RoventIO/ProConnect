// Command line helpers for the jobs integration. Usage (from the server folder):
//   npm run jobs:smoke   contact the real sources once, normalize the answer and print a summary (uses a throw-away in-memory database, writes nothing)
//   npm run jobs:sync    run one full fetch into your own database now
//   npm run jobs:list    show what is stored
const command = process.argv[2];
if (command === 'smoke') process.env.PROCONNECT_DB = ':memory:';

const { getDb } = await import('../db/index.js');
const { createJobsService, consoleLogger } = await import('./service.js');

async function smoke() {
  const service = createJobsService({ logger: consoleLogger });
  const summary = await service.run('smoke');
  const db = getDb();
  for (const s of summary.sources) {
    const n = db.prepare('SELECT COUNT(*) AS n FROM jobs WHERE source = ?').get(s.key).n;
    console.log(`${s.status === 'error' ? 'FAIL' : 'OK  '} ${s.name}: ${s.message} (${n} stored in the throw-away database)`);
  }
  const cats = db.prepare('SELECT category, COUNT(*) AS n FROM jobs GROUP BY category ORDER BY n DESC').all();
  console.log('Categories found:', cats.map((c) => `${c.category}=${c.n}`).join(', ') || 'none');
  for (const j of db.prepare('SELECT source, title, company, category, work_mode, employment_type, experience_level, published_at FROM jobs ORDER BY id LIMIT 3').all()) console.log('  sample:', JSON.stringify(j));
  process.exit(summary.sources.some((s) => s.status !== 'error') ? 0 : 1);
}

async function sync() {
  const summary = await createJobsService({ logger: consoleLogger }).run('cli');
  console.log(JSON.stringify(summary, null, 2));
}

function list() {
  const d = getDb();
  for (const s of d.prepare('SELECT * FROM job_sources').all()) console.log(`${s.key}: ${s.last_status} at ${s.last_sync_at} - ${s.last_message}`);
  const rows = d.prepare('SELECT id, source, category, title, company, published_at FROM jobs ORDER BY COALESCE(published_at, first_seen_at) DESC LIMIT 40').all();
  if (!rows.length) console.log('No stored jobs.');
  for (const r of rows) console.log(`#${String(r.id).padEnd(5)} ${r.source.padEnd(9)} ${r.category.padEnd(20)} ${r.title.slice(0, 50)} | ${r.company}`);
}

if (command === 'smoke') await smoke();
else if (command === 'sync') await sync();
else if (command === 'list') list();
else {
  console.log('Usage: npm run jobs:smoke | jobs:sync | jobs:list');
  process.exit(1);
}
