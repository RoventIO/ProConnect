import { plainText, truncate } from '../news/text.js';
import { canonicalUrl } from '../news/urls.js';
import { categoryFromMuse, categoryFromText } from './categories.js';

/**
 * Normalizers: one function per source turns that source's JSON into the same internal job shape.
 * Only facts present in the source data are used. A field the source does not provide stays null and is hidden in the UI.
 *
 * Arbeitnow (checked against a live response): { data: [{ slug, company_name, title, description (HTML), remote (boolean), url,
 *   tags: [string], job_types: [string], location, created_at (Unix seconds) }], ... }
 * The Muse (official API docs plus its OpenAPI description): { page, page_count, results: [{ id, name, contents (HTML), publication_date,
 *   type, locations: [{name}], categories: [{name}], levels: [{name, short_name}], tags: [{name}], refs: {landing_page}, company: {id, name, short_name} }] }
 */

const HOSTS = { arbeitnow: ['arbeitnow.com'], muse: ['themuse.com'] };
const MAX = { title: 200, company: 120, location: 150, tag: 40, tags: 12, summary: 280, description: 3000 };

const str = (v) => (typeof v === 'string' ? plainText(v) : '');
const sameHost = (url, source) => {
  try {
    const h = new URL(url).hostname.replace(/^www\./i, '').toLowerCase();
    return HOSTS[source].some((d) => h === d || h.endsWith(`.${d}`));
  } catch {
    return false;
  }
};

/** Accepts an https URL on the source's own domain, without credentials. Anything else is refused (never repaired or invented). */
export function safeSourceUrl(raw, source) {
  if (typeof raw !== 'string') return null;
  let u;
  try {
    u = new URL(raw.trim());
  } catch {
    return null;
  }
  if (u.protocol !== 'https:' || u.username || u.password || !sameHost(u.toString(), source)) return null;
  u.hash = '';
  return u.toString();
}

function isoOrNull(value, nowMs) {
  const ms = typeof value === 'number' ? (value < 1e11 ? value * 1000 : value) : Date.parse(value);
  if (!Number.isFinite(ms) || ms < Date.UTC(2000, 0, 1) || ms > nowMs + 86_400_000) return null; // missing, absurd or in the future
  return new Date(ms).toISOString();
}

const cleanTags = (list) => {
  const seen = new Set();
  const out = [];
  for (const raw of list || []) {
    const t = truncate(str(typeof raw === 'string' ? raw : raw?.name), MAX.tag);
    const k = t.toLowerCase();
    if (t && !seen.has(k)) {
      seen.add(k);
      out.push(t);
    }
    if (out.length >= MAX.tags) break;
  }
  return out;
};

function employmentFrom(values) {
  const joined = values.join(' | ').toLowerCase();
  if (/intern|praktik|werkstudent|trainee/.test(joined)) return 'internship';
  if (/part[ -]?time|teilzeit/.test(joined)) return 'part_time';
  if (/contract|freelanc|temporary|werkvertrag|honorar/.test(joined)) return 'contract';
  if (/full[ -]?time|fulltime|vollzeit/.test(joined)) return 'full_time';
  return null;
}

function experienceFrom(values) {
  const joined = values.join(' | ').toLowerCase();
  if (/management|executive|führungs|leiter/.test(joined)) return 'management';
  if (/senior|lead|principal/.test(joined)) return 'senior';
  if (/\bmid\b|mid level|mid-level|professional|berufserfahren/.test(joined)) return 'mid';
  if (/\bentry\b|junior|berufseinsteiger|absolvent|graduate/.test(joined)) return 'entry';
  return null;
}

/** Common tail: validates required fields and builds the stored shape. Returns null when the listing is unusable. */
function finish(c, nowMs) {
  const title = truncate(c.title, MAX.title);
  const company = truncate(c.company, MAX.company);
  const url = c.url;
  const urlKey = url && canonicalUrl(url);
  if (!title || !company || !url || !urlKey || !c.externalId) return null;
  const text = truncate(c.descriptionText || '', MAX.description);
  return {
    source: c.source, externalId: String(c.externalId), url, urlKey, title, company,
    logoUrl: null,
    location: c.location ? truncate(c.location, MAX.location) : null,
    workMode: c.workMode || null,
    category: c.category.key, categoryBasis: c.category.basis,
    employmentType: c.employmentType || null, experienceLevel: c.experienceLevel || null,
    tags: c.tags, summary: text ? truncate(text, MAX.summary) : null, descriptionText: text || null,
    publishedAt: isoOrNull(c.publishedAt, nowMs),
  };
}

export function normalizeArbeitnow(item, nowMs = Date.now()) {
  if (!item || typeof item !== 'object') return null;
  const title = str(item.title);
  const tags = cleanTags(item.tags);
  const location = str(item.location);
  const jobTypes = Array.isArray(item.job_types) ? item.job_types.map(str).filter(Boolean) : [];
  const descriptionText = str(item.description);
  const hybrid = /hybrid/i.test(`${location} ${title}`) || /\bhybrid(e|es)?\b/i.test(descriptionText.slice(0, 1500));
  // The source's own boolean decides "remote". "Hybrid" only when the listing says so. A listing that is explicitly not remote and
  // does not mention hybrid work is on-site. A missing flag stays unknown.
  const workMode = item.remote === true ? 'remote' : hybrid ? 'hybrid' : item.remote === false ? 'on_site' : null;
  const url = safeSourceUrl(item.url, 'arbeitnow');
  return finish({
    source: 'arbeitnow', externalId: str(item.slug), url, title, company: str(item.company_name),
    location: location.replace(/\s*\((?:hybrid|remote)\)\s*/i, ' ').trim(), workMode,
    category: categoryFromText(title, tags), tags,
    employmentType: employmentFrom(jobTypes), experienceLevel: experienceFrom(jobTypes),
    descriptionText, publishedAt: item.created_at,
  }, nowMs);
}

export function normalizeMuse(item, nowMs = Date.now()) {
  if (!item || typeof item !== 'object' || item.id == null) return null;
  const categories = (item.categories || []).map((c) => str(c?.name)).filter(Boolean);
  const levels = (item.levels || []).map((l) => str(l?.name)).filter(Boolean);
  const locations = (item.locations || []).map((l) => str(l?.name)).filter(Boolean);
  const remote = locations.some((l) => /flexible|remote/i.test(l));
  const physical = locations.filter((l) => !/flexible|remote/i.test(l));
  const levelText = levels.join(' | ');
  return finish({
    source: 'muse', externalId: item.id, url: safeSourceUrl(item.refs?.landing_page, 'muse'), title: str(item.name), company: str(item.company?.name),
    location: physical.length ? truncate(physical.slice(0, 3).join('; ') + (physical.length > 3 ? ` +${physical.length - 3}` : ''), MAX.location) : remote ? 'Remote' : null,
    workMode: remote ? 'remote' : null, // The Muse has no on-site / hybrid flag, so those stay unknown
    category: categoryFromMuse(categories), tags: cleanTags(item.tags),
    employmentType: /internship/i.test(levelText) ? 'internship' : null, experienceLevel: experienceFrom(levels.filter((l) => !/internship/i.test(l))),
    descriptionText: str(item.contents), publishedAt: item.publication_date,
  }, nowMs);
}
