import { getDb } from '../db/index.js';
import { config } from '../config.js';
import { safeGet } from '../news/http.js';
import { NewsError } from '../news/urls.js';
import { MUSE_QUERY_CATEGORIES } from './categories.js';
import { normalizeArbeitnow, normalizeMuse } from './normalize.js';

export const JOB_SOURCES = [
  { key: 'arbeitnow', name: 'Arbeitnow', site: 'https://www.arbeitnow.com' },
  { key: 'muse', name: 'The Muse', site: 'https://www.themuse.com' },
];
const ARBEITNOW_URL = 'https://www.arbeitnow.com/api/job-board-api';
const MUSE_URL = 'https://www.themuse.com/api/public/jobs';

const DAY = 86_400_000;
export const consoleLogger = {
  info: (m) => console.log(`[jobs] ${m}`),
  warn: (m) => console.warn(`[jobs] ${m}`),
  error: (m) => console.error(`[jobs] ${m}`),
};

/** Short, safe text: never a URL (The Muse key travels in one), a response body or a stack. */
const describeError = (err) => (err instanceof NewsError ? err.message : 'Unexpected error while processing this source.');

/**
 * The jobs engine. Everything that touches the network, the clock or waiting is injectable so tests need no real source.
 * Rules it enforces: sources are fetched one request at a time with a pause; one failing source never affects the other or
 * deletes stored listings; a listing is unique per (source, source id) and per canonical URL; runs never overlap.
 */
export function createJobsService({
  db = () => getDb(),
  fetchText = (url, opts) => safeGet(url, opts),
  now = () => Date.now(),
  sleep = (ms) => new Promise((r) => setTimeout(r, ms)),
  logger = consoleLogger,
  settings = config.jobs,
} = {}) {
  let running = false;
  let lastRun = null;
  const iso = () => new Date(now()).toISOString();

  async function getJson(url, label) {
    const res = await fetchText(url, { timeoutMs: settings.requestTimeoutMs, maxBytes: settings.maxResponseBytes, accept: 'application/json', userAgent: settings.userAgent });
    let json;
    try {
      json = JSON.parse(res.text);
    } catch {
      throw new NewsError('parse', `${label} did not answer with valid JSON.`);
    }
    return { json, headers: res.headers || {} };
  }

  /** Arbeitnow: first page, then only the "next" link if the response itself offers one (same host, https), up to the page limit. */
  async function fetchArbeitnow() {
    const out = { items: [], requests: 0, failed: 0, notes: [] };
    let url = ARBEITNOW_URL;
    for (let page = 1; page <= settings.arbeitnowMaxPages && url; page++) {
      if (page > 1) await sleep(settings.requestDelayMs);
      let json;
      try {
        out.requests++;
        ({ json } = await getJson(url, 'Arbeitnow'));
      } catch (err) {
        out.failed++;
        out.notes.push(describeError(err));
        if (page === 1) throw err;
        break;
      }
      if (!Array.isArray(json?.data)) {
        out.failed++;
        out.notes.push('Arbeitnow answered without a "data" list.');
        if (page === 1) throw new NewsError('parse', 'Arbeitnow answered without a "data" list.');
        break;
      }
      out.items.push(...json.data.map((j) => normalizeArbeitnow(j, now())));
      const next = typeof json.links?.next === 'string' ? json.links.next : null;
      try {
        const u = next && new URL(next);
        url = u && u.protocol === 'https:' && u.hostname === 'www.arbeitnow.com' && u.pathname.startsWith('/api/') ? u.toString() : null;
      } catch {
        url = null;
      }
    }
    return out;
  }

  /** The Muse: for each wanted category, pages 0.. (20 jobs per page) up to the limit, stopping early on page_count, errors or low quota. */
  async function fetchMuse() {
    const out = { items: [], requests: 0, failed: 0, notes: [] };
    let lastError = null;
    let consecutiveFailures = 0;
    outer: for (const category of MUSE_QUERY_CATEGORIES) {
      for (let page = 0; page < settings.museMaxPagesPerCategory; page++) {
        if (out.requests > 0) await sleep(settings.requestDelayMs);
        const params = new URLSearchParams({ page: String(page), category });
        if (settings.museApiKey) params.set('api_key', settings.museApiKey);
        let res;
        try {
          out.requests++;
          res = await getJson(`${MUSE_URL}?${params}`, 'The Muse');
        } catch (err) {
          out.failed++;
          lastError = err;
          if (++consecutiveFailures >= 3) {
            out.notes.push('Stopped after 3 failed requests in a row.');
            break outer;
          }
          if (/HTTP 403/.test(err?.message || '')) {
            out.notes.push('The Muse refused the request (HTTP 403, usually its hourly limit); stopped early.');
            break outer;
          }
          break; // next category
        }
        const { json, headers } = res;
        consecutiveFailures = 0;
        if (!Array.isArray(json?.results)) {
          out.failed++;
          lastError = new NewsError('parse', 'The Muse answered without a "results" list.');
          break;
        }
        out.items.push(...json.results.map((j) => normalizeMuse(j, now())));
        const remaining = Number(headers['x-ratelimit-remaining']);
        if (Number.isFinite(remaining) && remaining < settings.museMinRemaining) {
          out.notes.push(`Stopped early: The Muse reports only ${remaining} requests left this hour.`);
          break outer;
        }
        if (!(Number(json.page_count) > page + 1)) break; // last page of this category
      }
    }
    if (out.items.length === 0 && lastError) throw lastError;
    return out;
  }

  /** Inserts new listings and refreshes known ones, in one transaction. A listing already stored under another source id but the same URL is a duplicate. */
  function store(listings) {
    const d = db();
    const ts = iso();
    const bySource = d.prepare('SELECT id FROM jobs WHERE source = ? AND external_id = ?');
    const byUrl = d.prepare('SELECT id FROM jobs WHERE url_key = ?');
    const insert = d.prepare(
      `INSERT INTO jobs (source, external_id, url, url_key, title, company, logo_url, location, work_mode, category, category_basis, employment_type, experience_level, tags, summary, description_text, published_at, first_seen_at, last_seen_at)
       VALUES (?, ?, ?, ?, ?, ?, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    const update = d.prepare(
      `UPDATE jobs SET title = ?, company = ?, location = ?, work_mode = ?, category = ?, category_basis = ?, employment_type = ?, experience_level = ?, tags = ?, summary = ?, description_text = ?,
              published_at = COALESCE(?, published_at), last_seen_at = ? WHERE id = ?`
    );
    const counts = { inserted: 0, updated: 0, duplicates: 0 };
    const seen = new Set();
    d.exec('BEGIN');
    try {
      for (const j of listings) {
        const k = `${j.source}:${j.externalId}`;
        if (seen.has(k) || seen.has(`u:${j.urlKey}`)) {
          counts.duplicates++;
          continue;
        }
        seen.add(k);
        seen.add(`u:${j.urlKey}`);
        const existing = bySource.get(j.source, j.externalId);
        const common = [j.title, j.company, j.location, j.workMode, j.category, j.categoryBasis, j.employmentType, j.experienceLevel, JSON.stringify(j.tags), j.summary, j.descriptionText];
        if (existing) {
          update.run(...common, j.publishedAt, ts, existing.id);
          counts.updated++;
        } else if (byUrl.get(j.urlKey)) {
          counts.duplicates++;
        } else {
          insert.run(j.source, j.externalId, j.url, j.urlKey, j.title, j.company, j.location, j.workMode, j.category, j.categoryBasis, j.employmentType, j.experienceLevel, JSON.stringify(j.tags), j.summary, j.descriptionText, j.publishedAt, ts, ts);
          counts.inserted++;
        }
      }
      d.exec('COMMIT');
    } catch (err) {
      d.exec('ROLLBACK');
      throw err;
    }
    return counts;
  }

  function record(key, { status, message, fetched = null, inserted = null }) {
    const ts = iso();
    db()
      .prepare(
        `INSERT INTO job_sources (key, last_sync_at, last_ok_at, last_status, last_message, last_fetched, last_inserted) VALUES (?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(key) DO UPDATE SET last_sync_at = excluded.last_sync_at, last_status = excluded.last_status, last_message = excluded.last_message,
           last_fetched = excluded.last_fetched, last_inserted = excluded.last_inserted,
           last_ok_at = CASE WHEN excluded.last_status IN ('ok', 'partial') THEN excluded.last_sync_at ELSE job_sources.last_ok_at END`
      )
      .run(key, ts, status === 'error' ? null : ts, status, String(message).slice(0, 240), fetched, inserted);
  }

  async function syncSource(source) {
    const started = now();
    const result = { key: source.key, name: source.name, status: 'ok', message: '', fetched: 0, inserted: 0, updated: 0, invalid: 0, duplicates: 0 };
    try {
      const out = await (source.key === 'arbeitnow' ? fetchArbeitnow() : fetchMuse());
      const valid = out.items.filter(Boolean);
      result.invalid = out.items.length - valid.length;
      if (out.items.length > 0 && valid.length === 0) throw new NewsError('parse', `None of the ${out.items.length} entries had a usable title, company and link.`);
      const counts = store(valid);
      Object.assign(result, { fetched: valid.length, inserted: counts.inserted, updated: counts.updated, duplicates: counts.duplicates });
      const bits = [`${valid.length} listing(s), ${counts.inserted} new, ${counts.updated} refreshed`];
      if (out.failed) bits.push(`${out.failed} of ${out.requests} request(s) failed`);
      bits.push(...out.notes.slice(0, 1));
      result.status = out.failed || out.notes.length ? 'partial' : 'ok';
      result.message = bits.join('; ');
    } catch (err) {
      result.status = 'error';
      result.message = describeError(err);
      if (!(err instanceof NewsError)) logger.error(`unexpected error in source "${source.name}": ${err?.message}`);
    }
    try {
      record(source.key, { status: result.status, message: result.message, fetched: result.status === 'error' ? null : result.fetched, inserted: result.status === 'error' ? null : result.inserted });
    } catch (err) {
      logger.error(`could not record the result for "${source.name}": ${err?.message}`);
    }
    const log = result.status === 'error' ? logger.warn : logger.info;
    log(`source "${source.name}": ${result.status}, ${result.message} (${now() - started} ms)`);
    return result;
  }

  /** Removes listings older than the retention period and trims to the size cap. Only called after at least one source delivered data. */
  function prune() {
    const cutoff = new Date(now() - settings.retentionDays * DAY).toISOString();
    const old = db().prepare('DELETE FROM jobs WHERE COALESCE(published_at, first_seen_at) < ?').run(cutoff).changes;
    const over = db()
      .prepare('DELETE FROM jobs WHERE id IN (SELECT id FROM jobs ORDER BY COALESCE(published_at, first_seen_at) DESC, id DESC LIMIT -1 OFFSET ?)')
      .run(settings.maxStored).changes;
    return old + over;
  }

  /** Age of the most recent successful fetch of any source, in minutes (Infinity when there never was one). */
  function minutesSinceLastOk() {
    const row = db().prepare('SELECT MAX(last_ok_at) AS t FROM job_sources').get();
    return row?.t ? (now() - Date.parse(row.t)) / 60_000 : Infinity;
  }

  /** One full run. When `minAgeMinutes` is given and the last successful fetch is newer, nothing is requested. */
  async function run(reason = 'manual', { minAgeMinutes = 0 } = {}) {
    if (running) return { skipped: true, reason: 'already_running' };
    const age = minutesSinceLastOk();
    if (minAgeMinutes > 0 && age < minAgeMinutes) {
      logger.info(`fetch (${reason}) skipped: the last successful fetch was ${Math.round(age)} min ago`);
      return { skipped: true, reason: 'fresh' };
    }
    running = true;
    const summary = { reason, startedAt: iso(), finishedAt: null, pruned: 0, sources: [] };
    logger.info(`fetch started (reason: ${reason})`);
    try {
      for (const source of JOB_SOURCES) summary.sources.push(await syncSource(source)); // one source after the other, never in parallel
      if (summary.sources.some((s) => s.status !== 'error')) {
        try {
          summary.pruned = prune();
        } catch (err) {
          logger.error(`pruning failed: ${err?.message}`);
        }
      }
    } catch (err) {
      logger.error(`unexpected error during the fetch: ${err?.message}`);
    } finally {
      summary.finishedAt = iso();
      lastRun = summary;
      running = false;
      logger.info(`fetch finished (${reason}): ${summary.sources.map((s) => `${s.name}=${s.status}`).join(', ')}, pruned=${summary.pruned}`);
    }
    return summary;
  }

  return { run, prune, isRunning: () => running, lastRun: () => lastRun, minutesSinceLastOk, settings, logger, now };
}

/** Owns the repeating schedule. Timers are injectable. A restart fetches only when the stored data is older than startupMinAgeMinutes. */
export function createJobsScheduler({ service, setIntervalFn = setInterval, clearIntervalFn = clearInterval } = {}) {
  const s = service.settings;
  let timer = null;
  let initial = null;
  const tick = () => service.run('scheduled', { minAgeMinutes: s.intervalMinutes / 2 }).catch((e) => service.logger.error(`scheduled fetch failed: ${e?.message}`));
  return {
    start() {
      if (timer) return initial;
      timer = setIntervalFn(tick, s.intervalMinutes * 60_000);
      timer?.unref?.();
      service.logger.info(`scheduler registered: every ${s.intervalMinutes} minutes`);
      initial = service.run('startup', { minAgeMinutes: s.startupMinAgeMinutes }).catch((e) => service.logger.error(`startup fetch failed: ${e?.message}`));
      return initial;
    },
    stop() {
      if (timer) clearIntervalFn(timer);
      timer = null;
    },
    tick,
    get initialRun() {
      return initial;
    },
    status: () => ({ registered: !!timer, intervalMinutes: s.intervalMinutes }),
  };
}
