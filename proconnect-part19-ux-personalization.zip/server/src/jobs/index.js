import { config } from '../config.js';
import { createJobsService, createJobsScheduler } from './service.js';

let service = null;
let scheduler = null;

export function getJobsService() {
  service ??= createJobsService();
  return service;
}

/** Replaces the shared engine (tests inject fake fetchers, clocks and loggers here). */
export function configureJobsService(options) {
  scheduler?.stop();
  scheduler = null;
  service = createJobsService(options);
  return service;
}

export function getJobsScheduler() {
  return scheduler;
}

/** Called once when the backend starts. Does nothing (no network) when JOBS_SYNC=off. Never waits for the sources. */
export function startJobs({ timers } = {}) {
  const svc = getJobsService();
  if (!config.jobs.enabled) {
    svc.logger.warn('automatic job fetching is switched off (JOBS_SYNC=off); stored listings stay available');
    return null;
  }
  scheduler?.stop();
  scheduler = createJobsScheduler({ service: svc, ...(timers || {}) });
  scheduler.start();
  return scheduler;
}
