/** ProConnect job categories (Part 17). `other` is the honest answer when a listing cannot be placed with confidence. */
export const JOB_CATEGORIES = [
  { key: 'it-software', label: 'IT & Software Engineering' },
  { key: 'design-creative', label: 'Design & Creative' },
  { key: 'marketing-sales', label: 'Marketing & Sales' },
  { key: 'business-management', label: 'Business & Management' },
  { key: 'finance-accounting', label: 'Finance & Accounting' },
  { key: 'education', label: 'Education' },
  { key: 'healthcare', label: 'Healthcare' },
  { key: 'engineering', label: 'Engineering' },
  { key: 'human-resources', label: 'Human Resources' },
  { key: 'customer-support', label: 'Customer Support' },
  { key: 'data-science', label: 'Data Science & Analytics' },
  { key: 'other', label: 'Other' },
];
export const CATEGORY_KEYS = JOB_CATEGORIES.map((c) => c.key);
export const categoryLabel = (key) => JOB_CATEGORIES.find((c) => c.key === key)?.label || 'Other';

/**
 * The Muse's own category names (taken from the list in its API documentation) mapped to ProConnect categories.
 * A Muse category that is not listed here (Retail, Food and Hospitality, Social Services, ...) is not guessed: it becomes "Other".
 */
export const MUSE_CATEGORY_MAP = {
  'Software Engineering': 'it-software', 'Software Engineer': 'it-software', 'Computer and IT': 'it-software', IT: 'it-software',
  Design: 'design-creative', 'Design and UX': 'design-creative', UX: 'design-creative', Arts: 'design-creative', Videography: 'design-creative',
  Writer: 'design-creative', 'Writing and Editing': 'design-creative', Editor: 'design-creative',
  'Advertising and Marketing': 'marketing-sales', Marketing: 'marketing-sales', Sales: 'marketing-sales', 'Account Management': 'marketing-sales',
  'Public Relations': 'marketing-sales', 'Media, PR, and Communications': 'marketing-sales',
  'Business Operations': 'business-management', Management: 'business-management', 'Project Management': 'business-management',
  Product: 'business-management', 'Product Management': 'business-management', Corporate: 'business-management',
  'Administration and Office': 'business-management', 'Office Administration': 'business-management',
  Accounting: 'finance-accounting', 'Accounting and Finance': 'finance-accounting',
  Education: 'education',
  Healthcare: 'healthcare', Nurses: 'healthcare', 'Mental Health': 'healthcare', 'Physical Assistant': 'healthcare',
  'Science and Engineering': 'engineering', Construction: 'engineering', 'Energy Generation and Mining': 'engineering', Mechanic: 'engineering',
  HR: 'human-resources', 'Human Resources and Recruitment': 'human-resources', Recruiting: 'human-resources',
  'Customer Service': 'customer-support',
  'Data and Analytics': 'data-science', 'Data Science': 'data-science',
};

/** Muse category names the backend asks for, so that every ProConnect field gets listings (each is an exact name from the Muse list). */
export const MUSE_QUERY_CATEGORIES = [
  'Software Engineering', 'Computer and IT', 'Design and UX', 'Advertising and Marketing', 'Sales', 'Business Operations',
  'Project Management', 'Accounting and Finance', 'Education', 'Healthcare', 'Science and Engineering',
  'Human Resources and Recruitment', 'Customer Service', 'Data and Analytics',
];

export function categoryFromMuse(names) {
  for (const n of names || []) {
    const key = MUSE_CATEGORY_MAP[n];
    if (key) return { key, basis: `The Muse category "${n}"` };
  }
  return { key: 'other', basis: names?.length ? `No ProConnect category matches The Muse category "${names[0]}"` : 'The source gave no category' };
}

// Arbeitnow gives free-form tags such as "Revenue" or "Go-to-Market", not categories. Transparent keyword rules are used instead:
// the title first (most reliable), then the tags. The first matching rule wins. Nothing matches -> "other".
// Words are matched as whole words (English) or as stems (German).
const w = (...words) => new RegExp(`(?:^|[^\\p{L}])(?:${words.join('|')})`, 'iu');
const TITLE_RULES = [
  ['data-science', w('data scien', 'data analy', 'data engineer', 'machine learning', 'ml engineer', 'analytics', 'business intelligence', 'bi analyst', 'datenanaly', 'data-scien')],
  ['it-software', w('software', 'developer', 'entwickler', 'devops', 'front-?end', 'back-?end', 'full-?stack', 'cloud', 'it-', 'it support', 'sysadmin', 'system administrator', 'cyber', 'information security', 'security engineer', 'qa engineer', 'test automation', 'embedded', 'programmer', 'sre', 'platform engineer', 'iot', 'informatik', 'ios', 'android', 'solutions architect', 'it ')],
  ['customer-support', w('customer support', 'customer service', 'customer success', 'kundenservice', 'kundenbetreuung', 'support agent', 'helpdesk', 'service desk', 'kundenberater')],
  ['human-resources', w('recruit', 'talent acquisition', 'human resources', 'hr ', 'hr-', 'people partner', 'personalreferent', 'personalsachbearbeit', 'personalleiter', 'people & culture')],
  ['finance-accounting', w('accountant', 'accounting', 'buchhalt', 'finanzbuchhalt', 'controller', 'controlling', 'steuer', 'tax ', 'finance', 'finanz', 'bilanz', 'payroll', 'lohnbuchhalt', 'auditor', 'wirtschaftsprüf')],
  ['healthcare', w('nurse', 'pflege', 'arzt', 'ärztin', 'physician', 'krankenschwester', 'gesundheits', 'medizin', 'therapeut', 'physiotherap', 'pharma', 'clinical', 'zahnmedizin', 'medical')],
  ['education', w('teacher', 'lehrer', 'erzieher', 'dozent', 'tutor', 'lecturer', 'pädagog', 'trainer', 'schulleit', 'professor')],
  ['marketing-sales', w('sales', 'vertrieb', 'account executive', 'account manager', 'business development', 'marketing', 'seo', 'content manager', 'social media', 'social content', 'brand', 'growth', 'communications', 'kommunikation', 'außendienst', 'key account')],
  ['engineering', w('engineer', 'ingenieur', 'elektro', 'mechatronik', 'maschinenbau', 'bauleiter', 'construction', 'hardware', 'konstrukteur', 'techniker', 'mechanical', 'electrical', 'electronics')],
  ['design-creative', w('designer', 'design', 'ux', 'ui ', 'creative', 'grafik', 'graphic', 'illustrat', 'art director', 'video', 'photograph', 'copywriter', 'redakt', 'editor')],
  ['business-management', w('project manager', 'projektleit', 'product manager', 'operations', 'office manager', 'geschäftsführ', 'managing director', 'general manager', 'consultant', 'berater', 'teamleiter', 'team lead', 'head of', 'director', 'leiter')],
];
const TAG_RULES = [
  ['data-science', w('data', 'analytics')],
  ['it-software', w('software', 'developer', 'devops', 'engineering - software')],
  ['marketing-sales', w('sales', 'revenue', 'commercial', 'marketing', 'go-to-market', 'business development')],
  ['finance-accounting', w('finance', 'accounting', 'tax')],
  ['human-resources', w('hr', 'people', 'recruit')],
  ['customer-support', w('support', 'customer')],
  ['healthcare', w('health', 'medical', 'pharma')],
  ['education', w('education', 'teach')],
  ['design-creative', w('creative', 'design')],
  ['engineering', w('engineering', 'hardware', 'manufacturing')],
  ['business-management', w('management', 'director', 'executive', 'operations', 'consult')],
];

export function categoryFromText(title, tags) {
  const t = ` ${String(title || '')} `;
  for (const [key, re] of TITLE_RULES) {
    const m = re.exec(t);
    if (m) return { key, basis: `Job title contains "${m[0].replace(/^[^\p{L}]/u, '').trim()}"` };
  }
  for (const tag of tags || []) {
    for (const [key, re] of TAG_RULES) if (re.test(` ${tag} `)) return { key, basis: `Tag "${tag}"` };
  }
  return { key: 'other', basis: 'No title keyword or tag matched a ProConnect category' };
}
