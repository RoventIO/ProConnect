import { createApp } from './app.js';
import { getDb } from './db/index.js';
import { config } from './config.js';
import { startNews } from './news/index.js';
import { startJobs } from './jobs/index.js';

/**
 * Starts the HTTP server and then, without waiting for any external source, the news scheduler.
 * The scheduler runs expired-news cleanup and the first synchronization immediately and repeats every 120 minutes.
 * Jobs (Part 17) start the same way: a fetch at start only when the stored listings are stale, then every 180 minutes.
 * Resolves once the server is listening. `news.timers` lets tests replace the clock and interval timers.
 */
export function startServer({ port = config.port, news, jobs } = {}) {
  const db = getDb();
  const hasData = db.prepare('SELECT COUNT(*) AS n FROM communities').get().n > 0;
  if (!hasData) console.log('Database is empty. Run "npm run seed" to load demonstration data.');

  return new Promise((resolve, reject) => {
    const server = createApp().listen(port, () => {
      console.log(`ProConnect API running at http://localhost:${server.address().port}`);
      const scheduler = startNews(news);
      const jobsScheduler = startJobs(jobs);
      resolve({ server, scheduler, jobsScheduler });
    });
    server.once('error', reject);
  });
}
