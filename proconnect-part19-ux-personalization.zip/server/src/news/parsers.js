import { XMLParser, XMLValidator } from 'fast-xml-parser';
import { NewsError } from './urls.js';
import { hostOf, plainText } from './text.js';

// Each parser turns one source's response into "candidates": loosely shaped articles that normalize.js validates.
// A parser throws NewsError('parse') when the response is not what that source type should return.

const bad = (msg) => new NewsError('parse', msg);

// ---------- RSS 2.0 / RSS 1.0 / Atom ----------

const xml = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '@_',
  textNodeName: '#text',
  parseTagValue: false,
  parseAttributeValue: false,
  trimValues: true,
  isArray: (name) => ['item', 'entry', 'category', 'link', 'media:content', 'media:thumbnail', 'enclosure', 'media:group'].includes(name),
});

const text = (node) => {
  if (node == null) return '';
  if (typeof node === 'string') return node;
  if (Array.isArray(node)) return text(node[0]);
  if (typeof node === 'object') return text(node['#text']);
  return String(node);
};
const arr = (v) => (v == null ? [] : Array.isArray(v) ? v : [v]);

function firstImageInHtml(html) {
  const re = /<img\b[^>]*?\bsrc=["']([^"']+)["'][^>]*>/gi;
  let m;
  while ((m = re.exec(html || ''))) {
    if (!/\b(width|height)=["']?1["']?[\s/>]/i.test(m[0])) return m[1];
  }
  return null;
}

function rssImage(item) {
  for (const m of [...arr(item['media:content']), ...arr(item['media:group']).flatMap((g) => arr(g?.['media:content']))]) {
    const url = m?.['@_url'];
    const type = m?.['@_type'] || '';
    const medium = m?.['@_medium'] || '';
    if (url && (medium === 'image' || type.startsWith('image/') || (!medium && !type && /\.(jpe?g|png|webp|gif)(\?|$)/i.test(url)))) return url;
  }
  for (const t of arr(item['media:thumbnail'])) if (t?.['@_url']) return t['@_url'];
  for (const e of arr(item.enclosure)) if (e?.['@_url'] && String(e['@_type'] || '').startsWith('image/')) return e['@_url'];
  return firstImageInHtml(text(item['content:encoded'])) || firstImageInHtml(text(item.description)) || firstImageInHtml(text(item.content)) || firstImageInHtml(text(item.summary));
}

function itemLink(item) {
  const links = arr(item.link);
  const plain = links.find((l) => typeof l === 'string' && l);
  if (plain) return plain;
  const atom = links.filter((l) => l && typeof l === 'object' && l['@_href']);
  return (atom.find((l) => !l['@_rel'] || l['@_rel'] === 'alternate') ?? atom[0])?.['@_href'] ?? null;
}

export function parseFeed(body, { publisher }) {
  const head = String(body).slice(0, 600).trimStart().toLowerCase();
  if (head.startsWith('<!doctype html') || head.startsWith('<html')) throw bad('The address returned a web page, not an RSS or Atom feed.');
  if (/<!doctype|<!entity/i.test(String(body).slice(0, 4096))) throw bad('Feeds that declare a document type or entities are not accepted.');
  let doc;
  try {
    // The parser alone accepts mismatched tags, so well-formedness is checked first.
    if (XMLValidator.validate(String(body)) !== true) throw new Error('invalid');
    doc = xml.parse(body);
  } catch {
    throw bad('The feed is not valid XML.');
  }
  const entries = doc?.rss?.channel?.item ?? doc?.['rdf:RDF']?.item ?? doc?.feed?.entry;
  if (!entries) {
    if (doc?.rss?.channel || doc?.feed || doc?.['rdf:RDF']) return [];
    throw bad('The response is not an RSS or Atom feed.');
  }
  return arr(entries).map((item) => {
    const link = itemLink(item);
    const guid = text(item.guid) || text(item.id);
    const tags = arr(item.category).map((c) => (typeof c === 'string' ? c : c?.['@_term'] || text(c))).filter(Boolean);
    return {
      externalId: guid || link,
      url: link,
      title: text(item.title),
      summaryHtml: text(item.description) || text(item.summary) || text(item.content) || text(item['content:encoded']),
      publisher: plainText(text(item.source)) || publisher,
      imageUrl: rssImage(item),
      tags,
      publishedAt: text(item.pubDate) || text(item['dc:date']) || text(item.published) || text(item.updated),
    };
  });
}

// ---------- Hacker News (Algolia front page) ----------

export function parseHackerNews(body) {
  let data;
  try {
    data = JSON.parse(body);
  } catch {
    throw bad('The Hacker News response is not JSON.');
  }
  if (!Array.isArray(data?.hits)) throw bad('The Hacker News response has no list of stories.');
  return data.hits.map((h) => {
    const id = h.objectID ?? h.story_id;
    const discussion = id ? `https://news.ycombinator.com/item?id=${id}` : null;
    const url = h.url || h.story_url || discussion;
    const self = !h.url && !h.story_url;
    const facts = [Number.isFinite(h.points) ? `${h.points} points` : null, Number.isFinite(h.num_comments) ? `${h.num_comments} comments` : null].filter(Boolean).join(' · ');
    return {
      externalId: id != null ? String(id) : null,
      url,
      title: h.title || h.story_title || '',
      summaryHtml: h.story_text || (facts ? `${facts} on Hacker News` : ''),
      publisher: self ? 'Hacker News' : hostOf(url) || 'Hacker News',
      imageUrl: null,
      tags: [],
      publishedAt: h.created_at || (Number.isFinite(h.created_at_i) ? new Date(h.created_at_i * 1000).toISOString() : null),
    };
  });
}

// ---------- DEV.to ----------

export function parseDevTo(body) {
  let data;
  try {
    data = JSON.parse(body);
  } catch {
    throw bad('The DEV.to response is not JSON.');
  }
  if (!Array.isArray(data)) throw bad('The DEV.to response is not a list of articles.');
  return data.map((a) => {
    const canonical = typeof a.canonical_url === 'string' && /^https?:\/\//i.test(a.canonical_url) ? a.canonical_url : null;
    const url = canonical || a.url;
    const host = hostOf(url);
    const tags = Array.isArray(a.tag_list) ? a.tag_list : String(a.tag_list || a.tags || '').split(',');
    return {
      externalId: a.id != null ? String(a.id) : null,
      url,
      title: a.title || '',
      summaryHtml: a.description || '',
      publisher: !host || host === 'dev.to' ? 'DEV Community' : host,
      imageUrl: a.cover_image || a.social_image || null,
      tags: tags.map((t) => String(t).trim()).filter(Boolean),
      publishedAt: a.published_at || a.published_timestamp || null,
    };
  });
}

export const PARSERS = {
  rss: (body, source) => parseFeed(body, { publisher: source.name }),
  hackernews: (body) => parseHackerNews(body),
  devto: (body) => parseDevTo(body),
};
export const ACCEPT = {
  rss: 'application/rss+xml, application/atom+xml, application/xml;q=0.9, text/xml;q=0.8',
  hackernews: 'application/json',
  devto: 'application/vnd.forem.api-v1+json, application/json',
};
