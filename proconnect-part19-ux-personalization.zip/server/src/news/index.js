import { config } from '../config.js';
import { createNewsService, createScheduler } from './service.js';

// One shared engine per server process. Routes and the scheduler both use it, so they share the same single-flight lock.
let service = null;
let scheduler = null;

export function getNewsService() {
  service ??= createNewsService();
  return service;
}

/** Replaces the shared engine (tests inject fake fetchers, clocks and loggers here). */
export function configureNewsService(options) {
  scheduler?.stop();
  scheduler = null;
  service = createNewsService(options);
  return service;
}

export function getNewsScheduler() {
  return scheduler;
}

/** Called once when the backend starts: registers the 120-minute job and begins the first synchronization at once. */
export function startNews({ timers } = {}) {
  const svc = getNewsService();
  if (!config.news.enabled) {
    svc.logger.warn('automatic news synchronization is switched off (NEWS_SYNC=off); expired-news cleanup still runs');
    try {
      svc.cleanup();
    } catch (err) {
      svc.logger.error(`cleanup failed: ${err?.message}`);
    }
    return null;
  }
  scheduler?.stop();
  scheduler = createScheduler({ service: svc, ...(timers || {}) });
  scheduler.start();
  return scheduler;
}
