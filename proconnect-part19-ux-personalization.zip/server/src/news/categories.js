// News categories and the transparent, keyword-based rules that assign them.
// An article gets a category only when the source's own tags map to it, a keyword appears in the title,
// or at least two different keywords appear in the summary. The reason is stored with the article (category_basis).

export const CATEGORIES = [
  { key: 'ai', label: 'AI & Machine Learning' },
  { key: 'programming', label: 'Programming' },
  { key: 'cybersecurity', label: 'Cybersecurity' },
  { key: 'startups', label: 'Startups' },
];
export const CATEGORY_KEYS = CATEGORIES.map((c) => c.key);
export const categoryLabel = (key) => CATEGORIES.find((c) => c.key === key)?.label ?? key;

const RULES = {
  ai: {
    tags: ['ai', 'artificial intelligence', 'machine learning', 'ml', 'deep learning', 'generative ai', 'llm', 'llms', 'openai', 'chatgpt', 'machinelearning'],
    words: [/\bartificial intelligence\b/i, /\bmachine learning\b/i, /\bdeep learning\b/i, /\bneural networks?\b/i, /\bLLMs?\b/, /\blarge language models?\b/i, /\bgenerative AI\b/i, /\bAI\b/, /\bOpenAI\b/i, /\bChatGPT\b/i, /\bAnthropic\b/, /\bDeepMind\b/i, /\bGPT-?\d/i, /\bchatbots?\b/i],
  },
  cybersecurity: {
    tags: ['security', 'cybersecurity', 'infosec', 'netsec', 'cyber security', 'cyberattack', 'privacy and security'],
    words: [/\bcyber-?security\b/i, /\bcyber ?attacks?\b/i, /\bransomware\b/i, /\bmalware\b/i, /\bphishing\b/i, /\bdata breach(es)?\b/i, /\bzero-?days?\b/i, /\bCVE-\d{4}-\d+/i, /\bvulnerabilit(y|ies)\b/i, /\bbotnets?\b/i, /\binfosec\b/i, /\bhack(ed|ers?)\b/i, /\bspyware\b/i, /\bDDoS\b/i, /\bsecurity (flaws?|bugs?|holes?|patch(es)?|updates?|researchers?|breach(es)?|incidents?|vulnerabilit(y|ies))\b/i],
  },
  startups: {
    tags: ['startups', 'startup', 'venture', 'venture capital', 'funding', 'fundraising'],
    words: [/\bstart-?ups?\b/i, /\bseed (round|funding)\b/i, /\bSeries [A-E]\b/, /\bventure (capital|funding|firms?)\b/i, /\bfounders?\b/i, /\bY Combinator\b/i, /\braises? \$[\d.,]+\s?(k|m|b|million|billion)\b/i, /\bfunding round\b/i, /\bunicorn\b/i],
  },
  programming: {
    tags: ['programming', 'webdev', 'web development', 'javascript', 'typescript', 'python', 'rust', 'devops', 'opensource', 'open source', 'coding', 'software development', 'software engineering', 'developer', 'java', 'golang'],
    words: [/\bprogramming\b/i, /\bprogrammers?\b/i, /\bcoding\b/i, /\bsoftware (development|engineering|engineers?|developers?)\b/i, /\bdevelopers?\b/i, /\bopen[- ]source\b/i, /\b(JavaScript|TypeScript|Python|Rust|Golang|Kotlin|WebAssembly|PHP)\b/, /\b(Node\.js|Next\.js|React\.js|ReactJS|Vue\.js)\b/, /\bGitHub\b/i, /\bcompilers?\b/i, /\bAPIs?\b/, /\bSDKs?\b/, /\bLinux\b/i, /\bKubernetes\b/i, /\bDocker\b/i, /\bDevOps\b/i, /\bweb development\b/i, /\bSQL(ite)?\b/, /\bPostgres(QL)?\b/i],
  },
};
const ORDER = ['cybersecurity', 'ai', 'startups', 'programming']; // tie-break: the more specific topic first

const normTag = (t) => String(t).trim().toLowerCase().replace(/^#/, '');

/** Returns { categories: ['ai', ...] (at most two), basis: { ai: 'keyword "OpenAI" in the title' } }. */
export function classify({ title = '', summary = '', tags = [] }) {
  const scores = {};
  const basis = {};
  const normTags = tags.map(normTag);
  for (const key of ORDER) {
    const rule = RULES[key];
    let score = 0;
    const tagHit = normTags.find((t) => rule.tags.includes(t));
    if (tagHit) {
      score += 3;
      basis[key] = `source tag "${tagHit}"`;
    }
    const titleHits = rule.words.map((re) => re.exec(title)?.[0]).filter(Boolean);
    if (titleHits.length) {
      score += 2 * titleHits.length;
      basis[key] ??= `keyword "${titleHits[0]}" in the title`;
    }
    const summaryHits = rule.words.map((re) => re.exec(summary)?.[0]).filter(Boolean);
    if (summaryHits.length >= 2 || (summaryHits.length === 1 && score > 0)) {
      score += summaryHits.length;
      basis[key] ??= `keywords "${summaryHits.slice(0, 2).join('", "')}" in the summary`;
    }
    if (score >= 2) scores[key] = score;
  }
  const categories = Object.keys(scores).sort((a, b) => scores[b] - scores[a] || ORDER.indexOf(a) - ORDER.indexOf(b)).slice(0, 2);
  return { categories, basis: Object.fromEntries(categories.map((c) => [c, basis[c]])) };
}

/** Topics suggested by free text such as a community name. A single keyword is enough here (used for the "For you" tab). */
export function categoriesForText(text) {
  const out = [];
  for (const key of ORDER) if (RULES[key].words.some((re) => re.test(text))) out.push(key);
  return out;
}
