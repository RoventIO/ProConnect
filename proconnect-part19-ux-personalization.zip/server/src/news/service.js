import { getDb } from '../db/index.js';
import { config } from '../config.js';
import { safeGet } from './http.js';
import { ACCEPT, PARSERS } from './parsers.js';
import { normalizeCandidate } from './normalize.js';
import { NewsError } from './urls.js';

const HOUR = 3_600_000;

/** Short, safe text for a failure: never the URL, a response body or an internal stack. */
function describeError(err) {
  if (err instanceof NewsError) return err.message;
  return 'Unexpected error while processing this source.';
}

const quietLogger = { info() {}, warn() {}, error() {} };
export const consoleLogger = {
  info: (m) => console.log(`[news] ${m}`),
  warn: (m) => console.warn(`[news] ${m}`),
  error: (m) => console.error(`[news] ${m}`),
};

/**
 * The news engine: cleanup, fetching, validation, deduplicated storage and a single-flight lock.
 * Everything that touches the network or the clock is injectable so the tests can run without real sources or real time.
 */
export function createNewsService({
  db = () => getDb(),
  fetchText = (url, opts) => safeGet(url, opts),
  now = () => Date.now(),
  logger = consoleLogger,
  retentionHours = config.news.retentionHours,
  intervalMinutes = config.news.intervalMinutes,
  timeoutMs = config.news.requestTimeoutMs,
  maxBytes = config.news.maxResponseBytes,
  maxPerSource = config.news.maxArticlesPerSource,
  resolveHost, // optional DNS resolver override (tests)
} = {}) {
  const retentionMs = retentionHours * HOUR;
  let running = false;
  let lastRun = null;

  const cutoffIso = () => new Date(now() - retentionMs).toISOString();

  /** Deletes articles older than the retention period. Only the news_articles table is touched. */
  function cleanup() {
    const cutoff = cutoffIso();
    const deleted = db().prepare('DELETE FROM news_articles WHERE retention_at < ?').run(cutoff).changes;
    logger.info(`cleanup: deleted ${deleted} expired article(s) (older than ${retentionHours} h, cutoff ${cutoff})`);
    return { deleted, cutoff };
  }

  function recordResult(source, { status, message, fetched = null, inserted = null }) {
    db()
      .prepare("UPDATE news_sources SET last_sync_at = ?, last_status = ?, last_message = ?, last_fetched = ?, last_inserted = ? WHERE id = ?")
      .run(new Date(now()).toISOString(), status, String(message).slice(0, 200), fetched, inserted, source.id);
  }

  /** Stores validated articles for one source. Returns counts. Runs in one transaction. */
  function store(source, articles) {
    const d = db();
    const bySource = d.prepare('SELECT id, title, summary, publisher, image_url, categories, category_basis, tags FROM news_articles WHERE source_id = ? AND external_id = ?');
    const byUrl = d.prepare('SELECT id FROM news_articles WHERE url_key = ?');
    const insert = d.prepare(
      `INSERT INTO news_articles (source_id, external_id, url, url_key, title, summary, publisher, image_url, categories, category_basis, tags, published_at, ingested_at, retention_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    const update = d.prepare('UPDATE news_articles SET title = ?, summary = ?, publisher = ?, image_url = ?, categories = ?, category_basis = ?, tags = ? WHERE id = ?');
    const counts = { inserted: 0, updated: 0, unchanged: 0, duplicates: 0 };
    d.exec('BEGIN');
    try {
      for (const a of articles) {
        const cats = JSON.stringify(a.categories);
        const basis = JSON.stringify(a.basis);
        const tags = JSON.stringify(a.tags);
        const existing = bySource.get(source.id, a.externalId);
        if (existing) {
          // Same article from the same source: refresh descriptive metadata only. Dates and the link never change.
          const same = existing.title === a.title && existing.summary === a.summary && existing.publisher === a.publisher && existing.image_url === a.imageUrl
            && existing.categories === cats && existing.category_basis === basis && existing.tags === tags;
          if (same) counts.unchanged++;
          else {
            update.run(a.title, a.summary, a.publisher, a.imageUrl, cats, basis, tags, existing.id);
            counts.updated++;
          }
        } else if (byUrl.get(a.urlKey)) {
          counts.duplicates++; // the same article URL is already stored (for example reached through another source)
        } else {
          insert.run(source.id, a.externalId, a.url, a.urlKey, a.title, a.summary, a.publisher, a.imageUrl, cats, basis, tags, a.publishedAt, a.ingestedAt, a.retentionAt);
          counts.inserted++;
        }
      }
      d.exec('COMMIT');
    } catch (err) {
      d.exec('ROLLBACK');
      throw err;
    }
    return counts;
  }

  /** Fetches, parses, validates and stores one source. Never throws: a failure is recorded and reported. */
  async function syncSource(source) {
    const started = now();
    const result = { id: source.id, name: source.name, status: 'ok', message: '', fetched: 0, inserted: 0, updated: 0, skipped: 0, invalid: 0, expired: 0, durationMs: 0 };
    try {
      const response = await fetchText(source.url, { timeoutMs, maxBytes, accept: ACCEPT[source.kind], userAgent: config.news.userAgent, resolveHost });
      const candidates = PARSERS[source.kind](response.text, source);
      const nowMs = now();
      const valid = [];
      for (const c of candidates) {
        const n = normalizeCandidate(c, { nowMs, retentionMs });
        if (n.ok) valid.push(n.article);
        else if (n.reason === 'expired') result.expired++;
        else result.invalid++;
      }
      if (candidates.length > 0 && result.invalid === candidates.length) throw new NewsError('parse', `None of the ${candidates.length} entries had a usable title and link.`);
      // Newest first, capped, so one huge feed cannot flood the table.
      valid.sort((a, b) => (Date.parse(b.retentionAt) || 0) - (Date.parse(a.retentionAt) || 0));
      const batch = valid.slice(0, maxPerSource);
      const counts = store(source, batch);
      result.fetched = valid.length;
      result.inserted = counts.inserted;
      result.updated = counts.updated;
      result.skipped = counts.unchanged + counts.duplicates + (valid.length - batch.length) + result.invalid + result.expired;
      result.message = `${valid.length} valid article(s), ${counts.inserted} new, ${counts.updated} updated`;
    } catch (err) {
      result.status = 'error';
      result.message = describeError(err);
      if (!(err instanceof NewsError)) logger.error(`unexpected error in source "${source.name}": ${err?.message}`);
    }
    result.durationMs = now() - started;
    try {
      recordResult(source, { status: result.status, message: result.message, fetched: result.status === 'ok' ? result.fetched : null, inserted: result.status === 'ok' ? result.inserted : null });
    } catch (err) {
      logger.error(`could not record the result for "${source.name}": ${err?.message}`);
    }
    if (result.status === 'ok') {
      logger.info(`source "${source.name}": ok, fetched=${result.fetched} inserted=${result.inserted} updated=${result.updated} skipped=${result.skipped} (${result.durationMs} ms)`);
    } else {
      logger.warn(`source "${source.name}": FAILED, ${result.message} (${result.durationMs} ms)`);
    }
    return result;
  }

  /**
   * One full synchronization: cleanup first (so it happens even if every source fails), then every enabled source in turn.
   * If a run is already in progress this returns immediately and starts nothing.
   */
  async function run(reason = 'manual') {
    if (running) {
      logger.warn(`sync (${reason}) skipped: the previous synchronization is still running`);
      return { skipped: true, reason: 'already_running' };
    }
    running = true;
    const startedAt = now();
    const summary = { reason, startedAt: new Date(startedAt).toISOString(), finishedAt: null, deleted: 0, cleanupError: null, sources: [], totals: { fetched: 0, inserted: 0, updated: 0, skipped: 0 } };
    logger.info(`sync started (reason: ${reason})`);
    try {
      try {
        summary.deleted = cleanup().deleted;
      } catch (err) {
        summary.cleanupError = 'Cleanup failed.';
        logger.error(`cleanup failed: ${err?.message}`);
      }
      const sources = db().prepare('SELECT * FROM news_sources WHERE enabled = 1 ORDER BY id').all();
      for (const source of sources) summary.sources.push(await syncSource(source)); // one at a time: no burst of parallel requests
    } catch (err) {
      logger.error(`unexpected error during synchronization: ${err?.message}`);
    } finally {
      for (const s of summary.sources) for (const k of ['fetched', 'inserted', 'updated', 'skipped']) summary.totals[k] += s[k];
      summary.finishedAt = new Date(now()).toISOString();
      lastRun = summary;
      running = false;
      const ok = summary.sources.filter((s) => s.status === 'ok').length;
      logger.info(`sync finished (${reason}): sources ok=${ok} failed=${summary.sources.length - ok}, fetched=${summary.totals.fetched} inserted=${summary.totals.inserted} skipped=${summary.totals.skipped} deleted=${summary.deleted}`);
    }
    return summary;
  }

  /** Fetches a single source right now (used after an Admin adds or edits a feed). Shares the same lock as run(). */
  async function runSource(id) {
    if (running) return { skipped: true, reason: 'already_running' };
    const source = db().prepare('SELECT * FROM news_sources WHERE id = ?').get(id);
    if (!source) return { skipped: true, reason: 'not_found' };
    running = true;
    try {
      return await syncSource(source);
    } finally {
      running = false;
    }
  }

  return {
    run,
    runSource,
    cleanup,
    cutoffIso,
    isRunning: () => running,
    lastRun: () => lastRun,
    retentionHours,
    intervalMinutes,
    resolveHost,
    now,
    logger,
  };
}

/** Starts and owns the repeating schedule. Timers and the clock are injectable. */
export function createScheduler({ service, intervalMinutes = service.intervalMinutes, setIntervalFn = setInterval, clearIntervalFn = clearInterval, now = () => Date.now(), logger = service.logger } = {}) {
  const intervalMs = intervalMinutes * 60_000;
  let timer = null;
  let nextRunAt = null;
  let initialRun = null;
  let startedAt = null;

  const tick = () => {
    nextRunAt = now() + intervalMs;
    service.run('scheduled').catch((err) => logger.error(`scheduled run failed: ${err?.message}`));
  };

  return {
    /** Registers the repeating job and starts the first synchronization immediately. Does not wait for it. */
    start() {
      if (timer) return initialRun;
      startedAt = now();
      nextRunAt = startedAt + intervalMs; // the normal schedule resumes from startup; missed runs are never replayed
      timer = setIntervalFn(tick, intervalMs);
      timer?.unref?.();
      logger.info(`scheduler registered: every ${intervalMinutes} minutes, next scheduled run at ${new Date(nextRunAt).toISOString()}`);
      initialRun = service.run('startup').catch((err) => logger.error(`startup synchronization failed: ${err?.message}`));
      return initialRun;
    },
    stop() {
      if (timer) clearIntervalFn(timer);
      timer = null;
      nextRunAt = null;
    },
    tick,
    status: () => ({ registered: !!timer, intervalMinutes, startedAt: startedAt ? new Date(startedAt).toISOString() : null, nextRunAt: nextRunAt ? new Date(nextRunAt).toISOString() : null, running: service.isRunning() }),
    get initialRun() {
      return initialRun;
    },
  };
}
