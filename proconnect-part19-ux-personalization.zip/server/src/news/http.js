import dns from 'node:dns';
import http from 'node:http';
import https from 'node:https';
import zlib from 'node:zlib';
import { pipeline } from 'node:stream';
import { NewsError, isPrivateAddress, parseFeedUrl } from './urls.js';

/** DNS lookup used for the actual connection: refuses non-public addresses, so a name that later resolves to an internal address (DNS rebinding) is still blocked. */
function guardedLookup(hostname, options, callback) {
  dns.lookup(hostname, { ...options, all: true }, (err, addresses) => {
    if (err) return callback(err);
    if (addresses.some((a) => isPrivateAddress(a.address))) return callback(new NewsError('blocked', 'Local and private network addresses are not allowed.'));
    if (options?.all) return callback(null, addresses);
    return callback(null, addresses[0].address, addresses[0].family);
  });
}

function decoderFor(encoding) {
  switch ((encoding || '').toLowerCase()) {
    case 'gzip': case 'x-gzip': return zlib.createGunzip();
    case 'deflate': return zlib.createInflate();
    case 'br': return zlib.createBrotliDecompress();
    default: return null;
  }
}

function once({ url, timeoutMs, maxBytes, accept, userAgent, allowPrivate }) {
  return new Promise((resolve, reject) => {
    const lib = url.protocol === 'https:' ? https : http;
    let settled = false;
    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      fn(value);
    };
    const req = lib.request(
      url,
      {
        method: 'GET',
        headers: { 'User-Agent': userAgent, Accept: accept, 'Accept-Encoding': 'gzip, deflate, br' },
        ...(allowPrivate ? {} : { lookup: guardedLookup }),
      },
      (res) => {
        const status = res.statusCode || 0;
        if (status >= 300 && status < 400 && res.headers.location) {
          res.resume();
          return finish(resolve, { redirect: new URL(res.headers.location, url).toString() });
        }
        if (status < 200 || status >= 300) {
          res.resume();
          return finish(reject, new NewsError('http', `The source answered with HTTP ${status}.`));
        }
        const declared = Number(res.headers['content-length']);
        if (Number.isFinite(declared) && declared > maxBytes) {
          res.destroy();
          return finish(reject, new NewsError('too_large', 'The response is larger than the allowed size.'));
        }
        const decoder = decoderFor(res.headers['content-encoding']);
        const body = decoder ? pipeline(res, decoder, () => {}) : res;
        const chunks = [];
        let size = 0;
        body.on('data', (chunk) => {
          size += chunk.length;
          if (size > maxBytes) {
            res.destroy();
            body.destroy();
            return finish(reject, new NewsError('too_large', 'The response is larger than the allowed size.'));
          }
          chunks.push(chunk);
        });
        body.on('end', () => finish(resolve, { status, contentType: String(res.headers['content-type'] || ''), headers: res.headers, buffer: Buffer.concat(chunks) }));
        body.on('error', () => finish(reject, new NewsError('network', 'The response could not be read.')));
        res.on('error', () => finish(reject, new NewsError('network', 'The connection was interrupted.')));
      }
    );
    const timer = setTimeout(() => {
      req.destroy();
      finish(reject, new NewsError('timeout', `No complete answer within ${Math.round(timeoutMs / 1000)} s.`));
    }, timeoutMs);
    req.on('error', (err) => finish(reject, err instanceof NewsError ? err : err?.cause instanceof NewsError ? err.cause : new NewsError('network', 'The source could not be reached.')));
    req.end();
  });
}

function decodeText(buffer, contentType) {
  const charset = /charset=([\w-]+)/i.exec(contentType)?.[1] || 'utf-8';
  try {
    return new TextDecoder(charset).decode(buffer);
  } catch {
    return new TextDecoder('utf-8').decode(buffer);
  }
}

/**
 * GET a public web address with a timeout, a size limit, at most 3 redirects, and no access to local or private networks.
 * Every redirect target is checked again. Returns { text, contentType, url }.
 * `allowPrivate` exists only so the tests can talk to a local fixture server; no environment setting turns it on.
 */
export async function safeGet(rawUrl, { timeoutMs = 10_000, maxBytes = 2 * 1024 * 1024, maxRedirects = 3, accept = '*/*', userAgent = 'ProConnectNewsBot/1.0', allowPrivate = false } = {}) {
  let current = rawUrl;
  const deadline = Date.now() + timeoutMs;
  for (let hop = 0; hop <= maxRedirects; hop++) {
    const url = allowPrivate ? new URL(current) : parseFeedUrl(current);
    const left = Math.max(1, deadline - Date.now());
    const result = await once({ url, timeoutMs: left, maxBytes, accept, userAgent, allowPrivate });
    if (result.redirect) {
      current = result.redirect;
      continue;
    }
    return { text: decodeText(result.buffer, result.contentType), contentType: result.contentType, headers: result.headers || {}, url: url.toString() };
  }
  throw new NewsError('http', 'Too many redirects.');
}
