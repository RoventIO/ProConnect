import dns from 'node:dns';
import net from 'node:net';

/** Error with a short, safe message that can be stored and shown (never includes full URLs or response bodies). */
export class NewsError extends Error {
  constructor(kind, message) {
    super(message);
    this.kind = kind; // 'invalid_url' | 'blocked' | 'timeout' | 'network' | 'http' | 'too_large' | 'parse'
  }
}

// ---------- address checks (SSRF protection) ----------

const v4 = (a, b, c, d) => (((a * 256 + b) * 256 + c) * 256 + d) >>> 0;
const V4_BLOCKS = [
  ['0.0.0.0', 8], ['10.0.0.0', 8], ['100.64.0.0', 10], ['127.0.0.0', 8], ['169.254.0.0', 16], ['172.16.0.0', 12],
  ['192.0.0.0', 24], ['192.0.2.0', 24], ['192.88.99.0', 24], ['192.168.0.0', 16], ['198.18.0.0', 15],
  ['198.51.100.0', 24], ['203.0.113.0', 24], ['224.0.0.0', 4], ['240.0.0.0', 4],
].map(([ip, bits]) => [v4(...ip.split('.').map(Number)), bits]);

function isPrivateV4(ip) {
  const n = v4(...ip.split('.').map(Number));
  return V4_BLOCKS.some(([base, bits]) => (bits === 0 ? true : (n >>> (32 - bits)) === (base >>> (32 - bits))));
}

/** Expands an IPv6 text address into 8 groups of 16 bits (handles "::" and a trailing dotted IPv4). */
function v6Groups(ip) {
  let text = ip.toLowerCase().split('%')[0];
  const dotted = /(\d+\.\d+\.\d+\.\d+)$/.exec(text);
  if (dotted) {
    const [a, b, c, d] = dotted[1].split('.').map(Number);
    text = text.replace(dotted[1], `${((a << 8) | b).toString(16)}:${((c << 8) | d).toString(16)}`);
  }
  const [head, tail] = text.split('::');
  const h = head ? head.split(':') : [];
  const t = tail !== undefined && tail !== '' ? tail.split(':') : [];
  const fill = tail === undefined ? [] : Array(8 - h.length - t.length).fill('0');
  return [...h, ...fill, ...t].map((g) => parseInt(g || '0', 16));
}

/** True for loopback, private, link-local, multicast, reserved and other non-public addresses (IPv4 and IPv6). */
export function isPrivateAddress(address) {
  const kind = net.isIP(address);
  if (kind === 4) return isPrivateV4(address);
  if (kind !== 6) return true; // not an IP at all: treat as unsafe
  const g = v6Groups(address);
  const embeddedV4 = `${g[6] >> 8}.${g[6] & 255}.${g[7] >> 8}.${g[7] & 255}`;
  if (g.slice(0, 5).every((x) => x === 0) && (g[5] === 0xffff || g[5] === 0)) {
    // ::, ::1 and IPv4-mapped / IPv4-compatible forms
    if (g.slice(0, 7).every((x) => x === 0) && g[7] <= 1) return true;
    return isPrivateV4(embeddedV4);
  }
  if (g[0] === 0x64 && g[1] === 0xff9b) return isPrivateV4(embeddedV4); // NAT64
  if (g[0] === 0x2002) return isPrivateV4(`${g[1] >> 8}.${g[1] & 255}.${g[2] >> 8}.${g[2] & 255}`); // 6to4
  if ((g[0] & 0xfe00) === 0xfc00) return true; // unique local fc00::/7
  if ((g[0] & 0xffc0) === 0xfe80) return true; // link-local fe80::/10
  if ((g[0] & 0xff00) === 0xff00) return true; // multicast
  if (g[0] === 0x2001 && g[1] === 0x0db8) return true; // documentation
  return false;
}

const BLOCKED_SUFFIXES = ['.localhost', '.local', '.internal', '.localdomain', '.lan', '.home', '.intranet', '.corp', '.private'];

/**
 * Syntax-level check of a feed address. Returns the parsed URL or throws NewsError('invalid_url' | 'blocked').
 * Only http(s) on the default ports, no embedded credentials, no local names and no private IP literals.
 */
export function parseFeedUrl(raw) {
  if (typeof raw !== 'string' || !raw.trim()) throw new NewsError('invalid_url', 'Enter a feed address.');
  if (raw.length > 2048) throw new NewsError('invalid_url', 'The address is too long.');
  let u;
  try {
    u = new URL(raw.trim());
  } catch {
    throw new NewsError('invalid_url', 'That is not a valid web address.');
  }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') throw new NewsError('invalid_url', 'Only http:// and https:// addresses are allowed.');
  if (u.username || u.password) throw new NewsError('invalid_url', 'Addresses with a user name or password are not allowed.');
  if (u.port) throw new NewsError('blocked', 'Custom ports are not allowed.');
  const host = u.hostname.replace(/^\[|\]$/g, '').replace(/\.$/, '').toLowerCase();
  if (!host) throw new NewsError('invalid_url', 'That is not a valid web address.');
  if (net.isIP(host)) {
    if (isPrivateAddress(host)) throw new NewsError('blocked', 'Local and private network addresses are not allowed.');
  } else if (host === 'localhost' || !host.includes('.') || BLOCKED_SUFFIXES.some((s) => host.endsWith(s))) {
    throw new NewsError('blocked', 'Local and private network addresses are not allowed.');
  }
  return u;
}

/** Resolves a host name and rejects it if any address is non-public. `resolve` can be replaced in tests. */
export async function assertPublicHost(hostname, resolve = defaultResolve) {
  const host = hostname.replace(/^\[|\]$/g, '');
  if (net.isIP(host)) {
    if (isPrivateAddress(host)) throw new NewsError('blocked', 'Local and private network addresses are not allowed.');
    return;
  }
  let addresses;
  try {
    addresses = await resolve(host);
  } catch {
    throw new NewsError('invalid_url', 'The host name could not be found.');
  }
  if (!addresses?.length) throw new NewsError('invalid_url', 'The host name could not be found.');
  if (addresses.some((a) => isPrivateAddress(a))) throw new NewsError('blocked', 'Local and private network addresses are not allowed.');
}

export const defaultResolve = async (host) => (await dns.promises.lookup(host, { all: true })).map((a) => a.address);

/** Full validation used when an Admin adds or edits a feed: syntax, then DNS. Returns the cleaned address. */
export async function validateFeedUrl(raw, { resolve } = {}) {
  const u = parseFeedUrl(raw);
  await assertPublicHost(u.hostname, resolve);
  u.hash = '';
  return u.toString();
}

// ---------- canonical article URLs (duplicate detection) ----------

const TRACKING = /^(utm_[a-z]+|fbclid|gclid|dclid|msclkid|mc_cid|mc_eid|ref|ref_src|ref_url|source|cmpid|ncid|_hsenc|_hsmi|igshid|yclid)$/i;

/** Lower-cases the host, drops "www.", the fragment, default ports, tracking parameters and a trailing slash. */
export function canonicalUrl(raw) {
  let u;
  try {
    u = new URL(String(raw).trim());
  } catch {
    return null;
  }
  if (u.protocol !== 'https:' && u.protocol !== 'http:') return null;
  const host = u.hostname.replace(/^www\./i, '').toLowerCase();
  const params = [...u.searchParams.entries()].filter(([k]) => !TRACKING.test(k)).sort(([a], [b]) => a.localeCompare(b));
  const query = params.length ? `?${params.map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join('&')}` : '';
  let pathname = u.pathname.replace(/\/{2,}/g, '/');
  if (pathname.length > 1) pathname = pathname.replace(/\/$/, '');
  // http and https versions of a page are the same article
  return `${host}${u.port ? `:${u.port}` : ''}${pathname}${query}`;
}
