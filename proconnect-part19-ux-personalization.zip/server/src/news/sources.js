import { canonicalUrl } from './urls.js';

/**
 * Built-in sources. Only RSS ones can have their address edited; the two JSON APIs have a fixed address and format.
 * The Ars Technica address is the official Technology Lab feed.
 */
export const BUILTIN_SOURCES = [
  { key: 'techcrunch', name: 'TechCrunch', kind: 'rss', url: 'https://techcrunch.com/feed/' },
  { key: 'arstechnica', name: 'Ars Technica', kind: 'rss', url: 'https://feeds.arstechnica.com/arstechnica/technology-lab' },
  { key: 'hackernews', name: 'Hacker News', kind: 'hackernews', url: 'https://hn.algolia.com/api/v1/search?tags=front_page&hitsPerPage=40' },
  { key: 'devto', name: 'DEV Community', kind: 'devto', url: 'https://dev.to/api/articles?top=1&per_page=30' },
];

/** Adds any missing built-in source. Never touches an existing row, so an Admin's enabled/disabled choice and edits survive restarts. */
export function ensureBuiltinSources(db) {
  const insert = db.prepare('INSERT OR IGNORE INTO news_sources (key, name, kind, url, url_key, enabled, is_builtin) VALUES (?, ?, ?, ?, ?, 1, 1)');
  for (const s of BUILTIN_SOURCES) insert.run(s.key, s.name, s.kind, s.url, canonicalUrl(s.url));
}
