// The local ProConnect picture used when an article has no usable image. The file lives in client/public/news, so the
// front end serves it as /news/proconnect-news-default.svg without any external image service.
export const DEFAULT_NEWS_IMAGE = '/news/proconnect-news-default.svg';
