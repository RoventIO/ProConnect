import { canonicalUrl } from './urls.js';
import { plainText, truncate } from './text.js';
import { classify } from './categories.js';
import { DEFAULT_NEWS_IMAGE } from './defaultImage.js';

const HOUR = 3_600_000;
const FUTURE_TOLERANCE = HOUR; // a publication time further ahead than this is a clock or feed error, not a reliable date

/** Parses a feed date (RFC 822, ISO 8601, ...). Returns epoch milliseconds or null. */
export function parseDate(value) {
  if (value == null || value === '') return null;
  const t = new Date(typeof value === 'number' ? value : String(value).trim()).getTime();
  return Number.isFinite(t) && t > Date.UTC(2000, 0, 1) ? t : null;
}

function safeUrl(raw) {
  if (typeof raw !== 'string') return null;
  let u;
  try {
    u = new URL(raw.trim());
  } catch {
    return null;
  }
  if ((u.protocol !== 'http:' && u.protocol !== 'https:') || u.username || u.password || u.hostname.length < 3) return null;
  u.hash = '';
  return u.toString().length <= 2048 ? u.toString() : null;
}

/**
 * Validates one candidate and shapes it for the database.
 * Returns { ok: true, article } or { ok: false, reason: 'invalid' | 'expired', detail }.
 */
export function normalizeCandidate(c, { nowMs, retentionMs }) {
  const title = truncate(plainText(c.title), 300);
  if (title.length < 3) return { ok: false, reason: 'invalid', detail: 'missing title' };
  const url = safeUrl(c.url);
  if (!url) return { ok: false, reason: 'invalid', detail: 'missing or unsafe article link' };
  const urlKey = canonicalUrl(url);
  if (!urlKey) return { ok: false, reason: 'invalid', detail: 'unusable article link' };

  let published = parseDate(c.publishedAt);
  if (published !== null && published > nowMs + FUTURE_TOLERANCE) published = null; // unreliable: fall back to ingestion time
  if (published !== null && nowMs - published > retentionMs) return { ok: false, reason: 'expired', detail: 'older than the retention period' };

  const ingestedAt = new Date(nowMs).toISOString();
  const publishedAt = published === null ? null : new Date(published).toISOString();

  let summary = truncate(plainText(c.summaryHtml), 300);
  if (!summary || summary.toLowerCase() === title.toLowerCase()) summary = null;

  const image = safeUrl(c.imageUrl);
  // A usable original image is kept as it is. http images would be blocked as mixed content, so, like a missing image,
  // they get the local ProConnect default picture.
  const imageUrl = image && image.startsWith('https://') ? image : DEFAULT_NEWS_IMAGE;

  const tags = [...new Set((c.tags || []).map((t) => plainText(t)).filter((t) => t && t.length <= 40))].slice(0, 8);
  const { categories, basis } = classify({ title, summary: summary || '', tags });

  const externalId = typeof c.externalId === 'string' && c.externalId.trim() && c.externalId.length <= 500 ? c.externalId.trim() : urlKey;
  const publisher = c.publisher ? truncate(plainText(c.publisher), 80) : null;

  return {
    ok: true,
    article: { externalId, url, urlKey, title, summary, publisher, imageUrl, categories, basis, tags, publishedAt, ingestedAt, retentionAt: publishedAt ?? ingestedAt },
  };
}
