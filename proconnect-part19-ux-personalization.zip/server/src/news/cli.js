// Command line helpers for the news system. Usage (from the server folder):
//   npm run news:smoke                 fetch the real sources once and show what was parsed (writes nothing)
//   npm run news:sync                  run one full synchronization against your database now
//   npm run news:list                  show the stored articles and their age
//   npm run news:backdate -- <id> <h>  make one stored article <h> hours old (to test the 72-hour rule)
//   npm run news:retention-demo        prove the 72-hour rule on a throw-away in-memory database
const command = process.argv[2];
if (command === 'retention-demo') process.env.PROCONNECT_DB = ':memory:'; // never touch the real database

const { getDb } = await import('../db/index.js');
const { config } = await import('../config.js');
const { safeGet } = await import('./http.js');
const { ACCEPT, PARSERS } = await import('./parsers.js');
const { normalizeCandidate } = await import('./normalize.js');
const { BUILTIN_SOURCES } = await import('./sources.js');
const { canonicalUrl } = await import('./urls.js');
const { createNewsService, consoleLogger } = await import('./service.js');

const HOUR = 3_600_000;
const iso = (ms) => new Date(ms).toISOString();

async function smoke() {
  let ok = 0;
  for (const s of BUILTIN_SOURCES) {
    const started = Date.now();
    try {
      const res = await safeGet(s.url, { timeoutMs: config.news.requestTimeoutMs, maxBytes: config.news.maxResponseBytes, accept: ACCEPT[s.kind], userAgent: config.news.userAgent });
      const candidates = PARSERS[s.kind](res.text, s);
      const normalized = candidates.map((c) => normalizeCandidate(c, { nowMs: Date.now(), retentionMs: config.news.retentionHours * HOUR }));
      const valid = normalized.filter((n) => n.ok).map((n) => n.article);
      console.log(`OK    ${s.name}: ${candidates.length} entries, ${valid.length} valid within ${config.news.retentionHours} h (${Date.now() - started} ms)`);
      for (const a of valid.slice(0, 2)) console.log(`        - ${a.title.slice(0, 90)} | ${a.publisher} | ${a.publishedAt ?? 'no date'} | categories: ${a.categories.join(',') || 'none'}`);
      if (valid.length) ok++;
    } catch (err) {
      console.log(`FAIL  ${s.name}: ${err.message}`);
    }
  }
  console.log(`\n${ok} of ${BUILTIN_SOURCES.length} sources returned usable articles. Nothing was written to the database.`);
  process.exit(ok ? 0 : 1);
}

async function sync() {
  const service = createNewsService({ logger: consoleLogger });
  const summary = await service.run('cli');
  console.log(JSON.stringify({ deleted: summary.deleted, totals: summary.totals, sources: summary.sources.map((s) => ({ name: s.name, status: s.status, message: s.message })) }, null, 2));
}

function list() {
  const rows = getDb().prepare(`SELECT a.id, a.title, a.retention_at, a.published_at, s.name AS source FROM news_articles a JOIN news_sources s ON s.id = a.source_id ORDER BY a.retention_at DESC LIMIT 40`).all();
  if (!rows.length) console.log('No stored articles.');
  for (const r of rows) console.log(`#${String(r.id).padEnd(5)} ${((Date.now() - Date.parse(r.retention_at)) / HOUR).toFixed(1).padStart(6)} h  ${r.source.padEnd(14)} ${r.published_at ? '' : '(no pub date) '}${r.title.slice(0, 70)}`);
}

function backdate() {
  const id = Number(process.argv[3]);
  const hours = Number(process.argv[4]);
  if (!Number.isInteger(id) || !(hours >= 0)) {
    console.log('Usage: npm run news:backdate -- <article id> <age in hours>   (ids: npm run news:list)');
    process.exit(1);
  }
  const at = iso(Date.now() - hours * HOUR);
  const r = getDb().prepare('UPDATE news_articles SET published_at = ?, retention_at = ? WHERE id = ?').run(at, at, id);
  console.log(r.changes ? `Article #${id} now has publication time ${at} (${hours} h old). Restart the backend, or wait for the next scheduled run, and it will be deleted if older than ${config.news.retentionHours} h.` : `No article with id ${id}.`);
}

function retentionDemo() {
  const d = getDb();
  const sid = d.prepare("SELECT id FROM news_sources WHERE key = 'techcrunch'").get().id;
  const ins = d.prepare("INSERT INTO news_articles (source_id, external_id, url, url_key, title, published_at, ingested_at, retention_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
  const now = Date.now();
  const rows = [['published 10 h ago', 10, true], ['published 71 h ago', 71, true], ['published 73 h ago', 73, true], ['published 120 h ago', 120, true], ['no date, ingested 10 h ago', 10, false], ['no date, ingested 80 h ago', 80, false]];
  rows.forEach(([title, h, dated], i) => {
    const at = iso(now - h * HOUR);
    const url = `https://example.com/demo/${i}`;
    ins.run(sid, `demo-${i}`, url, canonicalUrl(url), title, dated ? at : null, at, at);
  });
  console.log('Before cleanup (in-memory demo database):');
  for (const r of d.prepare('SELECT title FROM news_articles ORDER BY id').all()) console.log(`  ${r.title}`);
  const service = createNewsService({ logger: consoleLogger });
  const { deleted } = service.cleanup();
  console.log(`\nDeleted ${deleted}. Remaining:`);
  for (const r of d.prepare('SELECT title FROM news_articles ORDER BY id').all()) console.log(`  ${r.title}`);
}

const commands = { smoke, sync, list, backdate, 'retention-demo': retentionDemo };
if (!commands[command]) {
  console.log('Commands: smoke | sync | list | backdate <id> <hours> | retention-demo');
  process.exit(1);
}
await commands[command]();
