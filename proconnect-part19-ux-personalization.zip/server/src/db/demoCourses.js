import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { getDb, transaction } from './index.js';

/**
 * Demo Courses & Webinars (Part 17). Eleven GENERATED announcements, flagged is_sample = 1 and identified by a seed_key
 * ("demo-p17-..."). They are not real events: instructors and organizations are fictional and the UI says so.
 *
 * Behaviour (all idempotent):
 *  - a record is inserted only when its seed_key is missing, so running this again creates no duplicates;
 *  - nothing else is touched: user-created and earlier listings (seed_key IS NULL) are never read for writing, updated or deleted;
 *  - dates are chosen once, relative to the day of the first run, and then stay put (the page never regenerates anything);
 *  - `--refresh-dates` moves only the dates of demo records whose start has already passed, so the demo does not go stale.
 */
const DAY = 86_400_000;
const at = (offsetDays, hourUtc, now) => {
  const d = new Date(now + offsetDays * DAY);
  d.setUTCHours(hourUtc, 0, 0, 0);
  return d.toISOString();
};

// startDays: days after the seeding day (null = self-paced, no fixed start). Deadlines are two days before the start.
export const DEMO_ANNOUNCEMENTS = [
  { key: 'web-development-fundamentals', type: 'course', category: 'Programming & IT', title: 'Web Development Fundamentals',
    description: 'Build your first responsive website from scratch: HTML structure, CSS layout and a little JavaScript, with a small portfolio page as the final project.',
    instructor: 'Lena Marquardt', role: 'Frontend developer and trainer', organizer: 'Brightwell Learning Lab', mode: 'online', location: null,
    duration: '6 weeks · 3 evening sessions per week', free: 0, price: '$149', startDays: 14, hour: 16, image: 'web-development-fundamentals' },
  { key: 'ui-ux-design-workshop', type: 'webinar', category: 'Design & UX', title: 'UI/UX Design Workshop: From Sketch to Prototype',
    description: 'A live walkthrough of turning a rough idea into a clickable prototype, with a short critique round on participants\' screens.',
    instructor: 'Tomas Wirth', role: 'Product designer', organizer: 'Cedar & Finch Studio', mode: 'online', location: null,
    duration: 'Live · 90 min', free: 1, price: null, startDays: 9, hour: 15, image: 'ui-ux-design-workshop' },
  { key: 'digital-marketing-strategy', type: 'course', category: 'Marketing & Sales', title: 'Digital Marketing Strategy',
    description: 'Plan a campaign end to end: audience research, channel choice, budgeting and measuring results. Combines online lessons with two in-person working days.',
    instructor: 'Maya Okafor', role: 'Marketing consultant', organizer: 'Northfield Practice Academy', mode: 'hybrid', location: 'Harbor Street Training Room, Yerevan',
    duration: '5 weeks · online lessons plus 2 in-person days', free: 0, price: '$220', startDays: 21, hour: 10, image: 'digital-marketing-strategy' },
  { key: 'financial-literacy-for-professionals', type: 'course', category: 'Finance & Accounting', title: 'Financial Literacy for Professionals',
    description: 'Read a balance sheet, understand cash flow and make sense of budgets and basic investment risk, with no finance background required.',
    instructor: 'Daniel Reyes', role: 'Certified accountant', organizer: 'Silverline Skills Institute', mode: 'online', location: null,
    duration: '4 weeks · Self-paced with weekly office hours', free: 0, price: '$99', startDays: 12, hour: 17, image: 'financial-literacy-for-professionals' },
  { key: 'leadership-and-team-management', type: 'webinar', category: 'Business & Management', title: 'Leadership and Team Management',
    description: 'Practical habits for new team leads: setting expectations, giving feedback and running one-to-one conversations that actually help.',
    instructor: 'Sofia Lindqvist', role: 'Operations director and mentor', organizer: 'Harborlight Leadership Forum', mode: 'online', location: null,
    duration: 'Live · 60 min', free: 1, price: null, startDays: 16, hour: 14, image: 'leadership-and-team-management' },
  { key: 'introduction-to-data-analytics', type: 'course', category: 'Data & Analytics', title: 'Introduction to Data Analytics',
    description: 'Learn to clean a dataset, ask good questions of it and present findings with simple charts, using spreadsheets and basic SQL.',
    instructor: 'Arjun Mehta', role: 'Data analyst', organizer: 'Quillstone Data School', mode: 'online', location: null,
    duration: '6 weeks · 2 live sessions per week', free: 0, price: '$179', startDays: 28, hour: 16, image: 'introduction-to-data-analytics' },
  { key: 'engineering-project-management', type: 'webinar', category: 'Engineering', title: 'Engineering Project Management Essentials',
    description: 'How engineering projects stay on schedule: scoping, risk registers, change control and working with suppliers and site teams.',
    instructor: 'Katarina Novak', role: 'Senior project engineer', organizer: 'Ironbridge Professional Network', mode: 'online', location: null,
    duration: 'Live · 75 min', free: 1, price: null, startDays: 19, hour: 13, image: 'engineering-project-management' },
  { key: 'effective-communication-skills', type: 'course', category: 'Education & Professional Development', title: 'Effective Communication Skills',
    description: 'Clear writing, confident presenting and active listening for the workplace, taught through short exercises and peer feedback.',
    instructor: 'Elena Vardanyan', role: 'Communication coach and former teacher', organizer: 'Meridian Training Collective', mode: 'in_person', location: 'Harbor Street Training Room, Yerevan',
    duration: '3 weeks · 2 evening classes per week', free: 0, price: '$80', startDays: 24, hour: 15, image: 'effective-communication-skills' },
  { key: 'human-resources-fundamentals', type: 'webinar', category: 'Human Resources', title: 'Human Resources Fundamentals',
    description: 'An overview of the HR cycle for small teams: hiring, onboarding, performance conversations and the records worth keeping.',
    instructor: 'Priya Raman', role: 'HR generalist', organizer: 'Oakline People Practice', mode: 'online', location: null,
    duration: 'Live · 60 min', free: 1, price: null, startDays: 11, hour: 14, image: 'human-resources-fundamentals' },
  { key: 'practical-cybersecurity-awareness', type: 'course', category: 'Programming & IT', title: 'Practical Cybersecurity Awareness',
    description: 'Spot phishing, manage passwords sensibly and handle company data safely. Short lessons for people who are not security specialists.',
    instructor: 'Viktor Hallgren', role: 'Information security analyst', organizer: 'Brightwell Learning Lab', mode: 'online', location: null,
    duration: '2 weeks · Self-paced, about 3 hours per week', free: 1, price: null, startDays: 8, hour: 12, image: 'practical-cybersecurity-awareness' },
  { key: 'healthcare-quality-improvement', type: 'webinar', category: 'Healthcare', title: 'Introduction to Quality Improvement in Healthcare Teams',
    description: 'A first look at improvement cycles for clinics and care teams: choosing a measure, running a small test and sharing what you learned.',
    instructor: 'Dr. Hannah Brandt', role: 'Clinical quality lead', organizer: 'Willowmere Care Practice Forum', mode: 'hybrid', location: 'Harbor Street Training Room, Yerevan',
    duration: 'Live · 90 min, with a streamed option', free: 1, price: null, startDays: 26, hour: 15, image: 'healthcare-quality-improvement' },
];

const seedKey = (a) => `demo-p17-${a.key}`;

/** Inserts the missing demo announcements. Returns { inserted, existing, datesRefreshed }. */
export function seedDemoCourses({ now = Date.now(), refreshDates = false, db = getDb() } = {}) {
  const result = { inserted: 0, existing: 0, datesRefreshed: 0 };
  transaction(() => {
    const insert = db.prepare(
      `INSERT OR IGNORE INTO courses (title, description, type, category, organizer, is_free, price_text, starts_at, duration, external_url, is_sample,
                                      instructor_name, instructor_role, delivery_mode, location, registration_deadline, image, seed_key)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, 1, ?, ?, ?, ?, ?, ?, ?)`
    );
    const refresh = db.prepare('UPDATE courses SET starts_at = ?, registration_deadline = ? WHERE seed_key = ? AND starts_at < ?');
    for (const a of DEMO_ANNOUNCEMENTS) {
      const starts = a.startDays == null ? null : at(a.startDays, a.hour, now);
      const deadline = starts ? at(a.startDays - 2, 21, now) : null;
      const changes = insert.run(a.title, a.description, a.type, a.category, a.organizer, a.free, a.price, starts, a.duration, a.instructor, a.role, a.mode, a.location, deadline, `/courses/demo-${a.image}.svg`, seedKey(a)).changes;
      if (changes) result.inserted++;
      else {
        result.existing++;
        if (refreshDates && starts) result.datesRefreshed += refresh.run(starts, deadline, seedKey(a), new Date(now).toISOString()).changes;
      }
    }
  });
  return result;
}

const isMain = process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href;
if (isMain) {
  const r = seedDemoCourses({ refreshDates: process.argv.includes('--refresh-dates') });
  console.log(`Demo Courses & Webinars: ${r.inserted} added, ${r.existing} already present${r.datesRefreshed ? `, ${r.datesRefreshed} past date(s) moved forward` : ''}. Nothing else was changed.`);
}
