-- ProConnect conceptual data model (PRD section 12), P0 entities.
-- Deferred (P1/P2): notifications, credential reviews, status assignments, news, jobs.

CREATE TABLE IF NOT EXISTS users (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  name                TEXT    NOT NULL,
  email               TEXT    NOT NULL UNIQUE COLLATE NOCASE,
  password_hash       TEXT    NOT NULL,
  profession          TEXT,
  headline            TEXT,
  bio                 TEXT,
  skills              TEXT    NOT NULL DEFAULT '[]',   -- JSON array of strings
  location            TEXT,
  years_experience    INTEGER,
  avatar_file         TEXT,                        -- profile photo file name in the uploads folder
  linkedin_url        TEXT,                        -- optional LinkedIn profile link (validated; NULL when not provided)
  github_url          TEXT,                        -- optional GitHub profile link (validated; NULL when not provided)
  profile_completed   INTEGER NOT NULL DEFAULT 0,      -- 1 once minimum profile is filled (gates content, FR-01)
  role                TEXT    NOT NULL DEFAULT 'member' CHECK (role IN ('member', 'admin')),
  status              TEXT    NOT NULL DEFAULT 'beginner',  -- 'student' | 'beginner' (self-selected) | 'professional' (Admin only)
  is_bot              INTEGER NOT NULL DEFAULT 0,      -- 1 for clearly labelled demo bot accounts; they cannot sign in and hold no permissions
  is_organizer        INTEGER NOT NULL DEFAULT 0,      -- Authorized Organizer permission, granted by an Admin (courses and webinars)
  created_at          TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at          TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

-- Work experience, education and portfolio projects / external links (FR-02).
CREATE TABLE IF NOT EXISTS profile_items (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind        TEXT    NOT NULL CHECK (kind IN ('experience', 'education', 'project')),
  title       TEXT    NOT NULL,
  subtitle    TEXT,
  period      TEXT,
  description TEXT,
  url         TEXT,                                    -- for projects: the GitHub repository link
  tech        TEXT    NOT NULL DEFAULT '[]',           -- projects: JSON array of technologies
  demo_url    TEXT,                                    -- projects: optional live demo link
  image_file  TEXT                                     -- projects: optional thumbnail file name in the uploads folder
);
CREATE INDEX IF NOT EXISTS idx_profile_items_user ON profile_items(user_id);

CREATE TABLE IF NOT EXISTS communities (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT    NOT NULL,
  slug        TEXT    NOT NULL UNIQUE,
  description TEXT    NOT NULL DEFAULT '',
  category    TEXT    NOT NULL,
  parent_id   INTEGER REFERENCES communities(id) ON DELETE SET NULL,   -- subcommunity support (FR-03)
  created_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  status      TEXT    NOT NULL DEFAULT 'approved' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at  TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_communities_parent ON communities(parent_id);
CREATE INDEX IF NOT EXISTS idx_communities_category ON communities(category);

-- Community Leader assignments: a leader's authority is limited to these communities (and their subcommunities).
CREATE TABLE IF NOT EXISTS community_leaders (
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  community_id INTEGER NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
  assigned_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  assigned_at  TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  PRIMARY KEY (user_id, community_id)
);
CREATE INDEX IF NOT EXISTS idx_community_leaders_community ON community_leaders(community_id);

CREATE TABLE IF NOT EXISTS memberships (
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  community_id INTEGER NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
  joined_at    TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  PRIMARY KEY (user_id, community_id)
);
CREATE INDEX IF NOT EXISTS idx_memberships_community ON memberships(community_id);

CREATE TABLE IF NOT EXISTS posts (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  author_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  community_id INTEGER NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
  title        TEXT    NOT NULL,
  content      TEXT    NOT NULL,
  created_at   TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at   TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_posts_community ON posts(community_id, created_at);
CREATE INDEX IF NOT EXISTS idx_posts_author ON posts(author_id);

CREATE TABLE IF NOT EXISTS comments (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id    INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  author_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content    TEXT    NOT NULL,
  parent_comment_id INTEGER REFERENCES comments(id) ON DELETE SET NULL,  -- set when this is a reply to another comment on the same post
  created_at TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_comments_post ON comments(post_id, created_at);

CREATE TABLE IF NOT EXISTS courses (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  title           TEXT    NOT NULL,
  description     TEXT    NOT NULL DEFAULT '',
  type            TEXT    NOT NULL CHECK (type IN ('course', 'webinar')),
  category        TEXT,
  organizer       TEXT,
  is_free         INTEGER NOT NULL DEFAULT 1,
  price_text      TEXT,                       -- display only; ProConnect does not process payments (FR-16)
  starts_at       TEXT,                       -- ISO date-time for scheduled events
  duration        TEXT,
  external_url    TEXT,
  approval_status TEXT    NOT NULL DEFAULT 'approved' CHECK (approval_status IN ('pending', 'approved', 'rejected')),
  is_sample       INTEGER NOT NULL DEFAULT 0, -- demonstration listing, not a verified live opportunity (rule 14)
  publisher_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at      TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  instructor_name TEXT,                       -- Part 17: fictional for demo listings
  instructor_role TEXT,
  delivery_mode   TEXT,                       -- 'online' | 'in_person' | 'hybrid'
  location        TEXT,                       -- venue or city for in-person / hybrid listings
  registration_deadline TEXT,
  image           TEXT,                       -- local image path (served from the client's public folder)
  seed_key        TEXT                        -- set only on generated demo announcements (unique); NULL on every other listing
);
CREATE INDEX IF NOT EXISTS idx_courses_type ON courses(type);

-- Files attached to a post or a comment: images (JPG, PNG, WebP, GIF) and voice messages.
CREATE TABLE IF NOT EXISTS attachments (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id      INTEGER REFERENCES posts(id) ON DELETE CASCADE,
  comment_id   INTEGER REFERENCES comments(id) ON DELETE CASCADE,
  owner_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind         TEXT    NOT NULL CHECK (kind IN ('image', 'audio')),
  file         TEXT    NOT NULL,              -- name in the uploads folder (never a user-supplied name)
  duration_sec INTEGER,                       -- voice messages only
  position     INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  CHECK ((post_id IS NULL) <> (comment_id IS NULL))
);
CREATE INDEX IF NOT EXISTS idx_attachments_post ON attachments(post_id);
CREATE INDEX IF NOT EXISTS idx_attachments_comment ON attachments(comment_id);

-- In-app notifications (PRD FR-11): only two kinds, a new discussion in a joined community and a reply to the recipient's comment.
-- dedupe_key makes the same event impossible to record twice for the same recipient.
CREATE TABLE IF NOT EXISTS notifications (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  recipient_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type         TEXT    NOT NULL CHECK (type IN ('new_discussion', 'comment_reply')),
  actor_id     INTEGER REFERENCES users(id) ON DELETE SET NULL,
  community_id INTEGER NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
  post_id      INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  comment_id   INTEGER REFERENCES comments(id) ON DELETE CASCADE,
  dedupe_key   TEXT    NOT NULL,
  read_at      TEXT,
  created_at   TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  UNIQUE (recipient_id, dedupe_key)
);
CREATE INDEX IF NOT EXISTS idx_notifications_recipient ON notifications(recipient_id, created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(recipient_id) WHERE read_at IS NULL;

-- News (Part 4). Metadata and a link to the original article only; full article text is never stored.
-- Sources: the built-in ones (TechCrunch, Ars Technica, Hacker News, DEV.to) plus RSS feeds added by an Admin.
CREATE TABLE IF NOT EXISTS news_sources (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  key           TEXT    UNIQUE,                       -- stable id of a built-in source; NULL for sources added by an Admin
  name          TEXT    NOT NULL,
  kind          TEXT    NOT NULL CHECK (kind IN ('rss', 'hackernews', 'devto')),
  url           TEXT    NOT NULL,
  url_key       TEXT    NOT NULL UNIQUE,              -- canonical form of url, so the same feed cannot be added twice
  enabled       INTEGER NOT NULL DEFAULT 1,
  is_builtin    INTEGER NOT NULL DEFAULT 0,
  last_sync_at  TEXT,                                 -- when the last attempt finished (UTC ISO)
  last_status   TEXT    CHECK (last_status IN ('ok', 'error')),
  last_message  TEXT,                                 -- short, safe explanation of the last result
  last_fetched  INTEGER,                              -- valid articles found in the last attempt
  last_inserted INTEGER,                              -- new articles stored by the last attempt
  created_at    TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at    TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

-- retention_at is what the 72-hour rule measures: the original publication time when it is reliable,
-- otherwise the ingestion time. Always a UTC ISO string with milliseconds, so text comparison equals time comparison.
-- Duplicates: the same source article id, or the same canonical article URL, can only be stored once.
CREATE TABLE IF NOT EXISTS news_articles (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  source_id       INTEGER NOT NULL REFERENCES news_sources(id) ON DELETE CASCADE,
  external_id     TEXT    NOT NULL,                   -- the source's own article id (guid, HN objectID, DEV id) or the canonical URL
  url             TEXT    NOT NULL,                   -- link to the original article
  url_key         TEXT    NOT NULL,
  title           TEXT    NOT NULL,
  summary         TEXT,
  publisher       TEXT,                               -- original publisher name or site
  image_url       TEXT,
  categories      TEXT    NOT NULL DEFAULT '[]',      -- JSON array of news category keys
  category_basis  TEXT    NOT NULL DEFAULT '{}',      -- JSON { category: why it was assigned }
  tags            TEXT    NOT NULL DEFAULT '[]',      -- JSON array of the source's own tags
  published_at    TEXT,
  ingested_at     TEXT    NOT NULL,
  retention_at    TEXT    NOT NULL,
  UNIQUE (source_id, external_id),
  UNIQUE (url_key)
);
CREATE INDEX IF NOT EXISTS idx_news_articles_retention ON news_articles(retention_at DESC, id DESC);

-- Topics a member chose for their "For you" tab (the other input is the communities they joined).
CREATE TABLE IF NOT EXISTS news_interests (
  user_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  category TEXT    NOT NULL,
  PRIMARY KEY (user_id, category)
);

-- Demo registration for the generated Courses & Webinars announcements (Part 17). Nothing is sent anywhere.
CREATE TABLE IF NOT EXISTS course_registrations (
  user_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  course_id  INTEGER NOT NULL REFERENCES courses(id) ON DELETE CASCADE,
  created_at TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  PRIMARY KEY (user_id, course_id)
);
CREATE INDEX IF NOT EXISTS idx_course_registrations_course ON course_registrations(course_id);

-- Jobs (Part 17). Real listings fetched by the backend from Arbeitnow and The Muse, normalized into one format.
-- A listing is unique per source id and per canonical URL; a failing source never deletes what was stored before.
CREATE TABLE IF NOT EXISTS jobs (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  source           TEXT    NOT NULL CHECK (source IN ('arbeitnow', 'muse')),
  external_id      TEXT    NOT NULL,             -- the source's own id (Arbeitnow slug, The Muse job id)
  url              TEXT    NOT NULL,             -- the original listing / application page
  url_key          TEXT    NOT NULL,
  title            TEXT    NOT NULL,
  company          TEXT    NOT NULL,
  logo_url         TEXT,                         -- neither source includes a logo in its job payload, so this stays NULL
  location         TEXT,
  work_mode        TEXT    CHECK (work_mode IN ('remote', 'hybrid', 'on_site')),   -- NULL when the source does not say
  category         TEXT    NOT NULL,             -- ProConnect category key
  category_basis   TEXT,                         -- why that category was chosen (source category, tag or title keyword)
  employment_type  TEXT    CHECK (employment_type IN ('full_time', 'part_time', 'internship', 'contract')),
  experience_level TEXT    CHECK (experience_level IN ('entry', 'mid', 'senior', 'management')),
  tags             TEXT    NOT NULL DEFAULT '[]', -- JSON array
  summary          TEXT,                          -- short plain-text description for the card
  description_text TEXT,                          -- plain text (no markup), used for keyword search only
  published_at     TEXT,
  first_seen_at    TEXT    NOT NULL,
  last_seen_at     TEXT    NOT NULL,
  UNIQUE (source, external_id),
  UNIQUE (url_key)
);
CREATE INDEX IF NOT EXISTS idx_jobs_sort ON jobs(published_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS idx_jobs_category ON jobs(category);

CREATE TABLE IF NOT EXISTS job_sources (
  key           TEXT PRIMARY KEY,                 -- 'arbeitnow' | 'muse'
  last_sync_at  TEXT,                             -- when the last attempt finished (UTC ISO)
  last_ok_at    TEXT,                             -- when the last attempt that returned usable data finished
  last_status   TEXT CHECK (last_status IN ('ok', 'partial', 'error')),
  last_message  TEXT,
  last_fetched  INTEGER,
  last_inserted INTEGER
);

-- Saved Jobs (Part 18). A member's bookmarks. The listing is identified by its source and the source's own id, the same pair the jobs
-- table is unique on, so a saved job survives the listing being removed (retention cleanup) or fetched again under a new row id.
-- The snapshot columns keep the record understandable when the listing is gone. Nothing here is ever deleted by a fetch.
CREATE TABLE IF NOT EXISTS saved_jobs (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id          INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  source           TEXT    NOT NULL,
  external_id      TEXT    NOT NULL,
  title            TEXT    NOT NULL,
  company          TEXT    NOT NULL,
  location         TEXT,
  work_mode        TEXT,
  employment_type  TEXT,
  category         TEXT,
  published_at     TEXT,
  job_url          TEXT,                              -- the original listing page as it was when the job was saved (never rewritten)
  saved_at         TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  UNIQUE (user_id, source, external_id)
);
CREATE INDEX IF NOT EXISTS idx_saved_jobs_user ON saved_jobs(user_id, saved_at DESC, id DESC);

-- My Applications (Part 18). The member's own tracking list. A row means "the member says they applied", never "ProConnect submitted
-- an application": ProConnect has no internal application process, and clicking Apply on a listing creates nothing here.
-- job_source / job_external_id point at a ProConnect listing when the record was created from one (NULL for a manually entered job);
-- title, company and URL are always copied, so the record stays readable after the listing disappears.
CREATE TABLE IF NOT EXISTS job_applications (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id          INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  job_source       TEXT,
  job_external_id  TEXT,
  job_title        TEXT    NOT NULL,
  company          TEXT    NOT NULL,
  job_url          TEXT,
  dup_key          TEXT    NOT NULL,                  -- same position for the same member: normalized URL, else title + company
  applied_on       TEXT    NOT NULL,                  -- YYYY-MM-DD, entered by the member
  status           TEXT    NOT NULL DEFAULT 'applied' CHECK (status IN ('applied', 'reviewing', 'interview', 'rejected', 'accepted', 'withdrawn')),
  notes            TEXT,
  created_at       TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at       TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  UNIQUE (user_id, dup_key)
);
CREATE INDEX IF NOT EXISTS idx_job_applications_user ON job_applications(user_id, status);

-- Member preferences (Part 19). One row per member, created the first time the member saves a preference; a member without a row simply
-- has the defaults below (the API reports persisted = false), so existing accounts are never touched by this migration.
-- Every column is checked here as well as in the API (strict whitelists). Deleting a member removes their row (ON DELETE CASCADE).
CREATE TABLE IF NOT EXISTS user_preferences (
  user_id          INTEGER PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
  theme            TEXT    NOT NULL DEFAULT 'light' CHECK (theme IN ('light', 'dark', 'system')),
  news_default_tab TEXT    NOT NULL DEFAULT 'all'   CHECK (news_default_tab IN ('all', 'for-you')),
  job_category     TEXT,                                                    -- a ProConnect job category key, NULL = no preference
  job_work_mode    TEXT    CHECK (job_work_mode IN ('remote', 'hybrid', 'on_site')),  -- NULL = no preference
  home_hidden      TEXT    NOT NULL DEFAULT '[]',                           -- JSON array of the personalized Home sections the member hid
  updated_at       TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
