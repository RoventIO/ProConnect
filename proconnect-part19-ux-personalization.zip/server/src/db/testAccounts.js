import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import bcrypt from 'bcryptjs';
import { getDb, transaction } from './index.js';

/**
 * Five fictional people with different specialties and statuses, for manually testing search, filters and notifications.
 * ProConnect has no separate username: the email address is the sign-in name and the stable identifier used here.
 *
 * Passwords are not stored in source code. They live in server/test-accounts.local.json (listed in .gitignore, never
 * printed to logs). If that file is missing, fresh random passwords are generated and written to it.
 */
export const TEST_ACCOUNTS = [
  {
    key: 'frontend', name: 'Maya Chen', email: 'maya.chen@proconnect.example', status: 'student',
    profession: 'Frontend Developer', headline: 'Student building accessible React interfaces', location: 'Singapore', years: 1,
    bio: 'Computer science student who builds small web apps with React and TypeScript. Interested in accessible design systems and fast, readable interfaces.',
    skills: ['React', 'TypeScript', 'CSS', 'Accessibility'], joins: ['Web Development', 'UI/UX and Product Design', 'Software Development'],
  },
  {
    key: 'backend', name: 'Daniel Okoro', email: 'daniel.okoro@proconnect.example', status: 'beginner',
    profession: 'Backend Developer', headline: 'Junior backend developer learning APIs and databases', location: 'Lagos, Nigeria', years: 2,
    bio: 'Self-taught backend developer working with Node.js and PostgreSQL. Writing REST APIs, learning testing and how to keep services reliable.',
    skills: ['Node.js', 'PostgreSQL', 'REST APIs', 'Docker'], joins: ['Web Development', 'Data and Databases', 'Software Development'],
  },
  {
    key: 'ai', name: 'Priya Nair', email: 'priya.nair@proconnect.example', status: 'professional',
    profession: 'Machine Learning Engineer', headline: 'ML engineer working on model evaluation and MLOps', location: 'Bangalore, India', years: 7,
    bio: 'Machine learning engineer focused on evaluation, data quality and getting models into production. Happy to answer beginner questions about Python and PyTorch.',
    skills: ['Python', 'PyTorch', 'MLOps', 'Statistics'], joins: ['AI and Machine Learning', 'Data and Databases', 'Software Development'],
  },
  {
    key: 'security', name: 'Lukas Brandt', email: 'lukas.brandt@proconnect.example', status: 'professional', leads: 'Cybersecurity',
    profession: 'Cybersecurity Analyst', headline: 'Security analyst and Cybersecurity community leader', location: 'Hamburg, Germany', years: 9,
    bio: 'Security analyst with experience in monitoring, incident response and secure development reviews. Helps look after the Cybersecurity community.',
    skills: ['Threat Modeling', 'Incident Response', 'Network Security', 'OWASP'], joins: ['Cybersecurity', 'IT Infrastructure and Networking', 'Software Development'],
  },
  {
    key: 'devops', name: 'Sofia Alvarez', email: 'sofia.alvarez@proconnect.example', status: 'student',
    profession: 'DevOps Engineer', headline: 'Student and aspiring DevOps engineer', location: 'Madrid, Spain', years: 1,
    bio: 'Studying systems engineering and practising with CI pipelines, containers and Linux servers in a home lab. Keen to learn how teams run software reliably.',
    skills: ['Linux', 'Docker', 'CI/CD', 'Kubernetes'], joins: ['Cloud and DevOps', 'IT Infrastructure and Networking', 'Software Development'],
  },
];

const here = path.dirname(fileURLToPath(import.meta.url));
export const CREDENTIALS_FILE = process.env.PROCONNECT_TEST_ACCOUNTS_FILE || path.join(here, '..', '..', 'test-accounts.local.json');

const generatePassword = () => `Pc-${crypto.randomBytes(9).toString('base64url')}-7`;

/** Reads the local passwords, creating the file (with random passwords) for any account that has none. */
export function loadPasswords(file = CREDENTIALS_FILE) {
  let saved = {};
  if (fs.existsSync(file)) saved = JSON.parse(fs.readFileSync(file, 'utf8'));
  let changed = false;
  for (const a of TEST_ACCOUNTS) {
    if (typeof saved[a.email] !== 'string' || saved[a.email].length < 8) {
      saved[a.email] = generatePassword();
      changed = true;
    }
  }
  if (changed) fs.writeFileSync(file, `${JSON.stringify(saved, null, 2)}\n`, { mode: 0o600 });
  return saved;
}

/**
 * Creates the five accounts if they do not exist. Repeatable: an existing account keeps its password, status and role,
 * and only its demo profile text is refreshed (and only when it differs). Nothing is deleted or reset.
 * Community memberships and the one leader assignment are added only where the communities exist (run seed:demo first).
 */
export function ensureTestAccounts(passwords = loadPasswords()) {
  const report = { created: [], updated: [], unchanged: [], memberships: 0, leaders: 0 };
  transaction((db) => {
    const owner = db.prepare("SELECT id FROM users WHERE email = 'owner.admin@proconnect.example' AND role = 'admin'").get();
    for (const a of TEST_ACCOUNTS) {
      const skills = JSON.stringify(a.skills);
      const existing = db.prepare('SELECT id, profession, headline, bio, skills, location, years_experience, profile_completed FROM users WHERE email = ?').get(a.email);
      let id;
      if (!existing) {
        id = Number(
          db.prepare(
            `INSERT INTO users (name, email, password_hash, profession, headline, bio, skills, location, years_experience, profile_completed, status, role, is_bot)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, 'member', 0)`
          ).run(a.name, a.email, bcrypt.hashSync(passwords[a.email], 10), a.profession, a.headline, a.bio, skills, a.location, a.years, a.status).lastInsertRowid
        );
        report.created.push(a.email);
      } else {
        id = existing.id;
        const same = existing.profession === a.profession && existing.headline === a.headline && existing.bio === a.bio && existing.skills === skills
          && existing.location === a.location && existing.years_experience === a.years && existing.profile_completed === 1;
        if (same) report.unchanged.push(a.email);
        else {
          db.prepare("UPDATE users SET profession = ?, headline = ?, bio = ?, skills = ?, location = ?, years_experience = ?, profile_completed = 1, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?")
            .run(a.profession, a.headline, a.bio, skills, a.location, a.years, id);
          report.updated.push(a.email);
        }
      }
      for (const name of a.joins) {
        const c = db.prepare('SELECT id FROM communities WHERE name = ? COLLATE NOCASE AND parent_id IS NULL').get(name);
        if (c) report.memberships += db.prepare('INSERT OR IGNORE INTO memberships (user_id, community_id) VALUES (?, ?)').run(id, c.id).changes;
      }
      if (a.leads) {
        const c = db.prepare('SELECT id FROM communities WHERE name = ? COLLATE NOCASE AND parent_id IS NULL').get(a.leads);
        if (c) report.leaders += db.prepare('INSERT OR IGNORE INTO community_leaders (user_id, community_id, assigned_by) VALUES (?, ?, ?)').run(id, c.id, owner?.id ?? null).changes;
      }
    }
  });
  return report;
}

const isMain = process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href;
if (isMain) {
  const report = ensureTestAccounts();
  getDb(); // make sure the connection is initialised before reporting
  console.log('Test accounts. Created:', report.created.length, '| profile text refreshed:', report.updated.length, '| already up to date:', report.unchanged.length);
  console.log(`Memberships added: ${report.memberships}. Leader assignments added: ${report.leaders}.`);
  if (report.memberships === 0 && report.created.length) console.log('No community memberships were added: run "npm run seed:demo" first to create the communities, then run this again.');
  console.log(`Passwords are in ${path.relative(process.cwd(), CREDENTIALS_FILE)} (local file, not tracked).`);
}
