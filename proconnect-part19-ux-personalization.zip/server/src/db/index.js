import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';
import { config } from '../config.js';
import { ensureBuiltinSources } from '../news/sources.js';
import { DEFAULT_NEWS_IMAGE } from '../news/defaultImage.js';

const here = path.dirname(fileURLToPath(import.meta.url));
let db;

/** Case folding for every script. Upper-casing first also unifies special letters such as the Armenian ligature "և" with "եւ". */
const fold = (v) => String(v).normalize('NFC').toUpperCase().toLowerCase();

/** Adds columns introduced after the first release to databases created earlier. */
function migrate(d) {
  const userCols = d.prepare('PRAGMA table_info(users)').all().map((c) => c.name);
  if (!userCols.includes('avatar_file')) d.exec('ALTER TABLE users ADD COLUMN avatar_file TEXT');
  // Articles stored without an image get the local default picture (the news API also answers with it at read time).
  d.prepare("UPDATE news_articles SET image_url = ? WHERE image_url IS NULL OR TRIM(image_url) = ''").run(DEFAULT_NEWS_IMAGE);
  if (!userCols.includes('is_bot')) d.exec('ALTER TABLE users ADD COLUMN is_bot INTEGER NOT NULL DEFAULT 0');
  if (!userCols.includes('is_organizer')) d.exec('ALTER TABLE users ADD COLUMN is_organizer INTEGER NOT NULL DEFAULT 0');
  // Part 5: social profile links and richer portfolio projects. Existing rows keep their data; new columns start empty.
  if (!userCols.includes('linkedin_url')) d.exec('ALTER TABLE users ADD COLUMN linkedin_url TEXT');
  if (!userCols.includes('github_url')) d.exec('ALTER TABLE users ADD COLUMN github_url TEXT');
  const itemCols = d.prepare('PRAGMA table_info(profile_items)').all().map((c) => c.name);
  if (!itemCols.includes('tech')) d.exec("ALTER TABLE profile_items ADD COLUMN tech TEXT NOT NULL DEFAULT '[]'");
  if (!itemCols.includes('demo_url')) d.exec('ALTER TABLE profile_items ADD COLUMN demo_url TEXT');
  if (!itemCols.includes('image_file')) d.exec('ALTER TABLE profile_items ADD COLUMN image_file TEXT');
  const commentCols = d.prepare('PRAGMA table_info(comments)').all().map((c) => c.name);
  if (!commentCols.includes('parent_comment_id')) d.exec('ALTER TABLE comments ADD COLUMN parent_comment_id INTEGER REFERENCES comments(id) ON DELETE SET NULL');
  d.exec('CREATE INDEX IF NOT EXISTS idx_comments_parent ON comments(parent_comment_id)');
  // Part 17: richer Courses & Webinars records. Existing rows keep their data; the new columns start empty.
  const courseCols = d.prepare('PRAGMA table_info(courses)').all().map((c) => c.name);
  for (const col of ['instructor_name', 'instructor_role', 'delivery_mode', 'location', 'registration_deadline', 'image', 'seed_key']) {
    if (!courseCols.includes(col)) d.exec(`ALTER TABLE courses ADD COLUMN ${col} TEXT`);
  }
  d.exec('CREATE UNIQUE INDEX IF NOT EXISTS idx_courses_seed_key ON courses(seed_key) WHERE seed_key IS NOT NULL');
  // Earlier builds stored free-text statuses. Keep professional ones, map everything else to the agreed labels.
  d.exec(`UPDATE users SET status = 'professional' WHERE status IN ('experienced_professional')`);
  d.exec(`UPDATE users SET status = 'beginner' WHERE status NOT IN ('student', 'beginner', 'professional')`);
  // News tables are created by schema.sql (CREATE TABLE IF NOT EXISTS), so databases from earlier parts only gain tables.
  ensureBuiltinSources(d);
}

/** Opens the database once, enforces foreign keys and makes sure the schema exists. */
export function getDb() {
  if (!db) {
    if (config.dbPath !== ':memory:') fs.mkdirSync(path.dirname(config.dbPath), { recursive: true });
    db = new DatabaseSync(config.dbPath);
    db.exec('PRAGMA foreign_keys = ON;');
    // SQLite's LIKE ignores letter case only for English letters. ulike(text, needle) is a case-insensitive
    // "contains" for every script (Armenian, Cyrillic, Greek...), used by search and list filters.
    db.function('ulike', { deterministic: true }, (text, needle) => {
      if (text == null || needle == null) return 0;
      return fold(text).includes(fold(needle)) ? 1 : 0;
    });
    db.exec(fs.readFileSync(path.join(here, 'schema.sql'), 'utf8'));
    migrate(db);
  }
  return db;
}

/** Runs fn inside a transaction; rolls back if it throws. */
export function transaction(fn) {
  const d = getDb();
  d.exec('BEGIN');
  try {
    const result = fn(d);
    d.exec('COMMIT');
    return result;
  } catch (err) {
    d.exec('ROLLBACK');
    throw err;
  }
}
