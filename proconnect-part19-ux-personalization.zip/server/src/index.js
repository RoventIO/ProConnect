import { config } from './config.js';
import { startServer } from './server.js';

if (config.isProd && config.jwtSecret === 'dev-only-secret-change-me') {
  console.warn('WARNING: set the JWT_SECRET environment variable before running in production.');
}

startServer().catch((err) => {
  console.error(err.code === 'EADDRINUSE' ? `Port ${config.port} is already in use.` : err);
  process.exit(1);
});
