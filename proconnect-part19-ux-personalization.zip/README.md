# ProConnect

Professional networking and knowledge-sharing platform (academic prototype).

## Build progress
- [x] Part 1: client foundation, WAct-inspired design system (light + dark), header, collapsible sidebar, Home, Sign In / Sign Up screens
- [x] Part 2: SQLite database, Express API skeleton, demonstration data
- [x] Part 3: sign up / sign in / sign out, session cookie, onboarding profile, protected content
- [x] Part 4: Home data from the database, My Profile (view and edit), other members' profiles
- [x] Part 4b: profile photo upload (JPG/PNG/WebP, max 2 MB), search field fix
- [x] Part 5: Communities (browse, filter, details, join/leave, admin create/delete)
- [x] Part 5b: styled confirmation dialogs and notifications (no browser pop-ups), clearer Join/Joined button
- [x] Part 6: Discussions and replies with emoji, images, GIFs and voice messages
- [x] Part 7: Search and filters, Courses & Webinars, My Communities / Discover Communities, themed voice player and scrollbars
- [x] Part 8: final testing and fixes (see ACCEPTANCE.md)
- [x] Part 19: UX & personalization: personalized member Home, Preferences page (theme Light/Dark/System, default News tab, job preferences, Home sections), filters kept in the address, account menu with Log Out, skip link, page titles (see "UX & Personalization (Part 19)" below)
- [x] Part 17: Jobs from Arbeitnow and The Muse for all professions, and 11 labelled demo Courses & Webinars (see "Jobs" and "Courses & Webinars" below)

## Requirements
Node.js 22.13 or newer (Node 24 is fine). No database program to install: the database is a single SQLite file
created in `server/data/` using Node's built-in `node:sqlite`.

## Run (two terminals)

Terminal 1, backend:
```bash
cd server
npm install
npm run seed:demo   # adds the demo communities, bots and the test administrator (safe to repeat, deletes nothing)
npm run dev         # API on http://localhost:4000 (keep this terminal open)
```

Terminal 2, frontend:
```bash
cd client
npm install
npm run dev      # site on http://localhost:5173
```

Check the API: open http://localhost:4000/api/health

## Tests and checks
```bash
cd server && npm test            # 191 API tests (temporary in-memory databases, all external sources mocked), incl. 23 Part 19 tests in test/preferences.test.js
cd server && npm run e2e         # 51-step run of the PRD user journeys against a real server (job sources switched off)
cd server && npm run e2e:part18  # 19 checks: Saved Jobs and My Applications over HTTP, including a server restart
cd server && npm run e2e:part19  # 15 checks: preferences, personalized Home data, sign-out and a restart (throw-away database file)
cd client && npm test            # 550 checks of the real UI in a simulated browser (jsdom), 11 test files, incl. 152 Part 19 checks in part19.test.jsx
cd client && npm run build       # production build
```
All tests and e2e scripts use temporary databases; none of them opens your own `server/data` folder.
Real-browser behaviour (actual first-paint, the OS dark-mode switch, the Back button across a real page load) is not covered by these tests; see the manual checks in `ACCEPTANCE.md`.
`ACCEPTANCE.md` maps every item of the PRD checklist to its evidence and lists what still needs a person in a real browser.

## Demo content and test accounts

There are no ordinary demo user accounts. Communities are populated by clearly labelled **community bots**, and one administrator account is provided for testing.

Load or top up the demo content (safe to repeat; it never wipes anything and never creates duplicates):
```bash
cd server
npm run seed:demo
```
It does five things, in this order:
1. Creates the test administrator if it is missing (never changes an existing one).
2. Removes the six earlier demo accounts (`student@`, `beginner@`, `professional@`, `leader@`, `organizer@`, `admin@` at `proconnect.example`) if they still exist. Their discussions and replies are kept and handed to a bot-labelled "ProConnect Demo Archive" account. `admin@proconnect.example` is removed only while it still has the old demo password and another administrator exists; otherwise it is kept. Other users and their content are never touched.
3. Creates the IT community directory: 12 main communities and 72 subcommunities (Software Development, Programming Languages, Web Development, AI and Machine Learning, Cybersecurity, Data and Databases, Cloud and DevOps, IT Infrastructure and Networking, Quality Assurance and Testing, UI/UX and Product Design, Product and Project Management, Other IT Specializations).
4. Creates 40 bot accounts (name, profession and skills vary; each profile says it is an automated bot).
5. Adds 3 discussions with 3 replies each to every community and subcommunity, written by different bots.

`npm run seed:demo -- --cleanup-only` only runs steps 1 and 2. `npm run seed -- --reset` is the only command that wipes the database; run `npm run seed:demo` after it.

**Administrator for testing**

| Email (used as the username) | Password |
|---|---|
| `owner.admin@proconnect.example` | `ProConnect-Owner-2026-Vk7Q` |

Change the password if you keep the data: `npm run make-admin -- owner.admin@proconnect.example --password "YourNewPassword1"`. To recover or create any other administrator the same way, use that command with the account's email. To make an existing account an administrator, run `npm run make-admin -- you@example.com`.

**How the bots work.** Bots are ordinary rows with `is_bot = 1`. They cannot sign in (no usable password), have no administrator, leader or organizer rights, and show a "Bot" label next to their name everywhere. Their text comes from curated, hand-checked entries in `server/src/db/botContent.js`, combined with varied phrasing in `server/src/db/demoData.js`. Nothing is generated when the app starts, no external service is used, and there is no background activity. Every row is looked up by a natural key (email, slug, community plus title, post plus author plus text) before it is inserted, so repeating the command adds nothing. To extend the content, add entries or bots to `botContent.js` and run `npm run seed:demo` again; only the new items are created.

You can also use Sign Up: choose Student or Beginner, complete the profile step, and change the choice later under **My Profile → Status**.

## News (Part 4)

Technology news is collected **by the backend only** (never by the browser) from TechCrunch and Ars Technica (RSS), Hacker News (Algolia API) and DEV.to (public API), plus any RSS/Atom feed an Admin adds. Only metadata and a link to the original article are stored.

- **At every backend start**, with no click needed: expired-news cleanup runs first, then all enabled sources are fetched one after another. The API answers immediately; it never waits for the sources.
- **Every 120 minutes** while the server runs: the same cleanup + fetch. Runs never overlap (a tick during a running sync is skipped and logged). Downtime is never replayed: after a restart you get one sync and the 120-minute timer starts again from that moment.
- **72-hour retention**: an article older than 72 hours (by publication time, or ingestion time when the source gave no reliable date) is deleted from `news_articles`. The News API also hides such rows between cleanups. Only the news tables are touched.
- **Duplicates**: unique per source article id and per canonical article URL (host without `www`, no fragment, no tracking parameters). Similar titles alone never count as duplicates.
- **Failures**: a failing source is logged and recorded (shown to Admins; members see a short warning) and the others continue. Cleanup runs even when every source fails; stored articles stay visible.
- **Categories** (AI & Machine Learning, Programming, Cybersecurity, Startups) come from the source's own tags or transparent keyword rules; hover a category pill to see why it was assigned. Articles that do not clearly match stay uncategorized and appear under All News only.
- **For You** combines topics a member picked with what their joined communities are about.
- **Admin** (`/news/sources`): enable/disable, add/edit RSS feeds, remove added feeds. Built-in sources can only be disabled; the two API sources have a fixed address. Disabled sources are not fetched and their stored articles are hidden. Feed addresses are checked on the server: only http(s) on default ports, no credentials, no local or private-network names or IPs, DNS results re-checked, redirects re-validated, 10 s timeout, 2 MB limit.
- Set `NEWS_SYNC=off` to start the API without fetching (cleanup still runs).

Helpers (run in `server/`): `npm run news:smoke` (fetch the real sources once, write nothing), `npm run news:sync` (one full sync now), `npm run news:list`, `npm run news:backdate -- <id> <hours>` (age one article to test the 72-hour rule), `npm run news:retention-demo` (72-hour rule on a throw-away database).

## Profile links and My Work (Part 5)

- **LinkedIn and GitHub links.** Edit Profile has two optional fields. LinkedIn must be an `https://` address on `linkedin.com` (or a subdomain such as `de.linkedin.com`) of the form `/in/<name>`; GitHub must be `https://github.com/<user>` (a profile, not a repository). Anything else (other sites, `http://`, `javascript:`, credentials, ports, look-alike domains such as `linkedin.com.evil.com`) is refused with a message, in the form and again on the server (`server/src/utils/links.js`). An empty field removes the link; a request that does not mention a link leaves it as it is. Links are shown with local brand icons in the profile header; a link that was not provided is not shown. They open in a new tab with `rel="noopener noreferrer"`.
- **My Work** is the existing portfolio model (`profile_items`, kind `project`) with new optional columns: `tech` (JSON list), `demo_url` and `image_file`. A project needs a title and a GitHub repository address (`https://github.com/owner/repository`). It can also have a description, up to 10 technologies, a live demo link and a thumbnail. Owners add, edit and delete (with a confirmation) on their own profile; the backend only ever touches rows whose `user_id` is the signed-in member, so another member's project looks like it does not exist (404).
- **Older project links** saved before Part 5 (any http/https address) are kept exactly as stored. They are shown as "Open link", and may stay unchanged when the project is edited, but a new or changed link must be a GitHub repository. This is a deliberate change: Part 1 accepted any web address for a project.
- **Database.** `users` gains `linkedin_url` and `github_url`; `profile_items` gains `tech`, `demo_url` and `image_file`. They are added automatically at startup (`ALTER TABLE ... ADD COLUMN`); existing rows and the five test accounts are not touched.
- **Roles and status** cannot be changed through profile editing: the profile endpoint never reads role, status or permissions, and the Professional rules are unchanged.

## Notifications

Only the two kinds in the PRD (FR-11) exist:
- **New discussion** in a community you joined. Membership lives on the main community, so a discussion in a subcommunity notifies members of its main community. The author is never notified about their own discussion.
- **Reply to your comment.** Use the **Reply** button under any comment; the notification goes to that comment's author (never to yourself). A plain comment on a discussion does not notify anyone.

The bell sits in the header, immediately left of your avatar. The badge shows the unread count; the panel lists newest first, unread items are bold with a dot, and each item can be marked read or opened (a reply link scrolls to and highlights the exact comment). "Mark all as read" clears the rest.

How it works: rows live in the `notifications` table (`recipient_id`, `type`, `actor_id`, `community_id`, `post_id`, `comment_id`, `read_at`). They are created by the discussion and reply routes in `server/src/routes/posts.js` (logic in `server/src/utils/notifications.js`), never by the front end or by seed scripts, so `seed:demo` creates none. A unique key on (recipient, event) prevents duplicates. Bot accounts (they cannot sign in) are never recipients. Deleting a discussion or reply removes its notifications. Every notification API query is limited to the signed-in member: `GET /api/notifications`, `GET /api/notifications/unread-count`, `POST /api/notifications/read-all`, `POST /api/notifications/:id/read` (someone else's id returns 404).

The bell refreshes the unread count every 30 seconds and when the tab becomes visible again; there is no real-time push.

## API
Public:
- `GET /api/health`, `GET /api/stats` (aggregate numbers only)
- `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout`, `GET /api/auth/me`

Signed-in:
- `PUT /api/profile` (basic profile; profession, bio, skills required)

Signed-in and profile completed (otherwise 401 / 403 `profile_incomplete`):
- `GET /api/profile`, `POST /api/profile/items`, `PUT|DELETE /api/profile/items/:id` (experience, education, projects/links; own entries only)
- `POST /api/profile/avatar` (multipart field `avatar`), `DELETE /api/profile/avatar`
- `GET /api/uploads/:file` (images are only served to signed-in members)
- `GET /api/users/:id` (another member's permitted profile, never the email)
- `GET /api/home` (trending discussions, upcoming courses, popular communities, and, since Part 19, the additive `personal` block described below)
- `GET /api/preferences`, `PUT /api/preferences` (the member's own preferences, Part 19)
- `POST /api/communities/:id/posts` (members), `GET|PUT|DELETE /api/posts/:id`, `POST /api/posts/:id/comments`, `PUT|DELETE /api/comments/:id`
- `GET /api/communities`, `GET /api/communities/:id`, `POST|DELETE /api/communities/:id/join` (main communities only)
- `POST /api/communities`, `DELETE /api/communities/:id` (administrators only)
- `GET /api/courses`, `GET /api/courses/:id`

Sessions use an httpOnly cookie (JWT, 7 days). For anything beyond local use, set `JWT_SECRET` in the environment.

## Search and discovery

The search page (header search box, or `/search`) has two tabs, **People** and **Communities**. Both come from the database through `GET /api/search`; nothing is hard-coded. A signed-in member is required.

- **People**: matches name, specialty (profession), headline, biography, skills and location, case-insensitively in every script. Filters: **Specialty** and **Status** (Student, Beginner, Professional, Community Leader; bots never match a status). Each result shows avatar, name, status, specialty and skills, and opens the real profile. Emails and other account data are never returned.
- **Communities**: matches name, description and specialty/category, and includes subcommunities, which are labelled "Subcommunity of {parent}". Filter: **Specialty**. Each result shows members, posts and its creation time, opens the real community page, and has a Join button. Membership is held by the main community, so joining from a subcommunity result joins its parent (the existing rule).
- **Sorting**: "Most recent" is the default. People are ordered by `users.updated_at` (the last profile or status change, which equals the sign-up time until then); communities by `communities.created_at`; ties by id. "Best match" puts name matches first. The page states which order is active.
- An empty search is a discovery view (newest people or communities). Results are limited to 20 per tab with a "Show more" button (up to 100).

Note: the PRD (FR-05) says results should be ranked by relevance, while Part 3 asked for most-recent ordering. Both exist: "Most recent" is the default, "Best match" is one click away. Change `sort` in `Search.jsx` if you prefer the other default.

## Test accounts

Five fictional accounts (Student, Beginner, two Professionals, one of them a Community Leader of Cybersecurity) for trying search, filters and notifications. ProConnect has no separate username, so the **email address is the sign-in name**.

```bash
cd server
npm run seed:demo           # communities, bots, owner administrator (once)
npm run seed:test-accounts  # the five accounts; safe to repeat
```

Passwords are not in the source. They are read from `server/test-accounts.local.json` (listed in `.gitignore`, never committed). If that file is missing, the command generates random passwords and writes it. Repeating the command never creates duplicates, never changes an existing account's password, status or role, and only refreshes its demo profile text when that text differs. See the file for the sign-in details.

## Courses & Webinars
`/courses` lists courses and webinars. The **All / Courses / Webinars** chips are the tabs; filters are price (Free/Paid), format
(Online / In person / Hybrid, only the formats that exist), category (a list built from the stored listings), and a keyword box that also
searches instructor names. Upcoming events come first, then undated courses, then past events. `/courses/:id` shows the details.

**Demo announcements (Part 17).** 11 generated announcements (5 courses, 6 webinars; programming and IT, design, marketing, finance, business,
data, engineering, education, HR, healthcare) are flagged `is_sample = 1` and identified by a `seed_key` starting with `demo-p17-`.
They are not real events: instructors and organizations are fictional, every card says "Sample", the list and the detail page carry a notice, and
the images are local SVG files in `client/public/courses/` marked "DEMO".

```bash
cd server
npm run seed:courses                    # adds the missing demo announcements; safe to repeat (run 2 adds 0)
npm run seed:courses -- --refresh-dates # also moves the dates of demo records whose start has already passed
npm run seed:demo                       # the bot/directory seed also runs the courses seed at its end
```
The seed inserts a record only when its `seed_key` is missing. It never reads, changes or deletes anything else, so listings you or your users
created, and the earlier sample listings, are untouched. Dates are fixed once (relative to the day of the first run) and stay stable; nothing is
generated when a page loads. The database gained columns (`instructor_name`, `instructor_role`, `delivery_mode`, `location`,
`registration_deadline`, `image`, `seed_key`) and a `course_registrations` table through the automatic migration; old rows keep working with the new fields empty.

**Registration.** Demo listings use an in-app *demo registration* (button "Register (demo)", cancellable): it stores the member's choice in this
database and sends nothing anywhere; the page says so. Listings that are not demo content keep their organizer's own external link. There is
still no publishing workflow, so no role can publish courses or webinars through the app; permissions are unchanged. Payments are not processed.

## Jobs (Part 17)
`/jobs` (sidebar item "Jobs", no longer "Soon") shows real listings fetched **by the backend** from two public sources and normalized into
one format (`jobs` table): title, company, location, ProConnect category, employment type, experience level, remote/hybrid/on-site, tags,
publication date, short plain-text description, source and the original URL. Apply opens that original page in a new tab. A field the
source does not provide is hidden, never invented. Neither source supplies company logos in its job data, so cards show initials, not a logo.

| Source | Endpoint | Key | What is used |
|---|---|---|---|
| Arbeitnow | `https://www.arbeitnow.com/api/job-board-api` | none | `data[]`: slug, title, company_name, location, remote, tags, job_types, description (HTML, stripped to text), url, created_at (Unix seconds). Follows `links.next` only if present, on its own host, up to 3 pages |
| The Muse | `https://www.themuse.com/api/public/jobs?page=N&category=...` | optional | `results[]`: id, name, contents, publication_date, locations, categories, levels, tags, refs.landing_page, company. Pages start at 0, 20 jobs per page; 14 category queries x 2 pages per fetch (about 28 requests) |

**Categories.** Twelve ProConnect categories (IT & Software Engineering, Design & Creative, Marketing & Sales, Business & Management,
Finance & Accounting, Education, Healthcare, Engineering, Human Resources, Customer Support, Data Science & Analytics, Other). The Muse's own
category names are mapped with a fixed table; unmapped ones (Retail, Food and Hospitality, ...) become **Other**. Arbeitnow has only free-form
tags, so transparent keyword rules on the title (English and German) and then the tags are used; no match becomes **Other**. The reason is stored
per job (`category_basis`). These rules are heuristics and will sometimes be wrong.

**Fetching.** The server fetches once at start (only if the stored data is older than 60 minutes, so restarts do not hit the sources), then every
180 minutes while it runs. Requests go one at a time with a 300 ms pause. A failing source never affects the other and never deletes stored jobs; the
status of each source (ok / partial / error, short message) is stored and shown. The Muse is protected against its limit (500 requests per hour
without a key): it stops early on HTTP 403, on `X-RateLimit-Remaining` below 25, or after 3 failed requests in a row. Duplicates are prevented per
(source, source id) and per canonical URL. Listings published (or first seen) more than 45 days ago are removed, only after a fetch in which
at least one source delivered data; the total is capped at 3000. Administrators get a **Refresh** button (ignored if the last fetch is under 10 minutes old).

**Configuration** (environment variables of the *server* process; there is no `.env` loader, set them in the shell):
```bash
MUSE_API_KEY=your-key npm run dev   # optional: The Muse asks for registration beyond testing and raises the limit to 3600/hour with a key
JOBS_SYNC=off npm run dev           # do not contact the job sources (stored jobs stay available)
```
```bash
npm run jobs:smoke   # contacts both real sources once and prints a summary (throw-away in-memory database)
npm run jobs:sync    # one full fetch into your own database now
npm run jobs:list    # show stored jobs and source status
```
The key is only ever sent to The Muse from the server; it is never logged, stored or returned by the API.

**API.** `GET /api/jobs?q=&category=&location=&mode=remote|hybrid|on_site&type=full_time|part_time|internship|contract&level=entry|mid|senior|management&source=arbeitnow|muse&page=&pageSize=`
(newest first is the only order; pageSize at most 24; invalid values return 400) returns `jobs`, `total`, `facets` (counts for each filter, so the page only
offers options that exist), `sources` (status per source) and `lastUpdated`. `POST /api/jobs/refresh` (administrators only) starts a background fetch.

**Rules for the derived fields.** Remote/hybrid/on-site: Arbeitnow's `remote` flag; "hybrid" only when the listing says so; `remote: false`
without a hybrid mention is on-site; The Muse has no such flag, so only "Flexible / Remote" locations are marked remote and the rest stay unknown.
Employment type and level come from Arbeitnow's `job_types` and The Muse's `levels` (an Internship level is an internship); anything else stays empty.

## Saved Jobs and My Applications (Part 18)

**Saved Jobs** (`/saved-jobs`, sidebar). Every job card and the job page (`/jobs/:id`) has a Save Job button. A saved job is identified by the listing's
source and the source's own id (the pair the `jobs` table is unique on), is unique per member, and keeps a snapshot of title, company, location, category,
publication date and original link. Jobs are removed from ProConnect after 45 days, so the snapshot is what keeps a saved job readable. When the listing is
no longer stored the saved job stays and is shown as "No longer available" with no Apply or View button; its last known link is offered only as a link that
may not work. A failed fetch never deletes anything, and a listing that comes back is recognised again.

**My Applications** (`/applications`, sidebar). The member's own tracking list: title, company, original link (optional), application date, status
(Applied, Reviewing, Interview, Accepted, Rejected, Withdrawn), notes, last updated. ProConnect has no internal application process, so every record means
"the member says they applied". Clicking Apply on a listing opens the employer's page and records nothing; the job page offers "Add to My Applications" for
afterwards. Every record says "Tracked by you" and the API reports `tracking.submittedViaProConnect: false`. A record can start from a stored listing (the listing
supplies title, company and link) or be typed by hand. Duplicates (same member and same normalized link, or without a link the same title and company) are
refused with 409; another position at the same company is fine.

API (all need a signed-in member with a completed profile; ownership always comes from the session, a user id in the request is ignored):

| Endpoint | Purpose |
| --- | --- |
| `GET /api/saved-jobs?q=&category=&availability=&sort=recent\|oldest\|title` | the member's saved jobs |
| `POST /api/saved-jobs` `{ jobId }` | save (201; 409 `already_saved`; 404 `job_not_found`) |
| `DELETE /api/saved-jobs/:id` | remove (404 for a record that is not the member's) |
| `GET /api/job-applications?status=&q=&sort=applied\|updated&dir=` | list + `summary` counts of all the member's records |
| `POST /api/job-applications` | `{ jobId, appliedOn, status, notes? }` or `{ title, company, url?, appliedOn, status, notes? }` (409 `duplicate_application`) |
| `GET / PUT / DELETE /api/job-applications/:id` | read, edit (any of title, company, url, appliedOn, status, notes), delete |
| `GET /api/jobs/:id` (new) | one stored listing; `GET /api/jobs` jobs now carry the member's own `savedId` and `applicationId` |

Database: two new tables, `saved_jobs` and `job_applications`, created with `CREATE TABLE IF NOT EXISTS` in `schema.sql` like the News and Jobs tables.
No existing table or column changes, so opening an older database only adds the two tables. Tests: `npm test` (server, includes `saved-applications.test.js`),
`npm run e2e:part18` (real server process and restart), `npm test` in `client` (includes `saved-applications.test.jsx`).

## Communities page

The directory lists main communities with their subcommunities. A community page shows its description, subcommunities (with descriptions), members and discussions.

**Who can do what** (checked on the server, not just in the buttons; `GET /api/communities/:id` returns a `permissions` object that drives the buttons):

| Action | Administrator | Leader of that community | Member | Others |
|---|---|---|---|---|
| Create / delete a main community | yes | no | no | no |
| Edit name and description (main or sub) | yes | own community and its subcommunities | no | no |
| Change the category (main community; subcommunities follow) | yes | no | no | no |
| Add a subcommunity | any main community | own main community only | no | no |
| Delete a subcommunity | yes | no | no | no |
| See the member list | yes | yes | yes | no (count only) |

Rules the server enforces: only one level of subcommunities; the parent, slug and creator can never be changed through the API; names are unique per parent (case-insensitive), so repeating a create adds nothing; membership is held by the main community, so a subcommunity is joined by joining its parent; only approved communities can be joined; administrators are never counted or listed as members.

**Safe deletion.** `DELETE /api/communities/:id` answers `409 needs_confirmation` with the counts (subcommunities, discussions, members) when the community still holds anything, and only deletes with `?confirm=true`. The page's dialog states those numbers first. Member accounts are never deleted. There is no community icon or image: the current data model has none, so none was added.

New endpoints: `PUT /api/communities/:id`, `GET /api/communities/:id/members?limit=`.

## Discussions
- Members of a main community can start discussions there (subcommunities follow their parent) and reply.
- A message can contain text with emoji, up to 4 images or GIFs (JPG, PNG, WebP, GIF, 5 MB each) and one voice message
  (recorded in the browser, up to 2 minutes). Voice recording needs microphone permission and works on localhost.
- Authors can edit text and delete their own discussions and replies; administrators can delete any.
- Searching for GIFs inside the app (Giphy/Tenor) is not included; GIF files can be uploaded.

## Readability, News images and profile logos (Part 7)

- **Readability.** Larger, higher-contrast text only on the Communities directory, community pages and discussion pages (CSS scoped to `.communities` and `.community-page`; other pages keep their typography). Long names and unbroken text wrap; the header now wraps at tablet widths, which previously made every page scroll sideways.
- **News images.** An article keeps its own picture when it has a usable `https` image. Otherwise the backend stores, and the API returns, the local `/news/proconnect-news-default.svg` (in `client/public/news`). Rows stored before this existed are answered with it at read time and backfilled at startup. In the browser a failed image is replaced by the default once; the default itself never triggers another swap. The sync schedule, deduplication and 72-hour cleanup were not touched.
- **Profile links.** LinkedIn and GitHub show only their logos (accessible names "LinkedIn profile" and "GitHub profile", keyboard focus ring), open in a new tab, and the whole area is hidden when neither link is saved.

## UX & Personalization (Part 19)

Everything here is additive. Visitor Home is unchanged (its rendered HTML is identical to Part 18), the three Home sections members already had keep their exact headings
(Trending Discussions, Courses & Webinars, Popular Communities), and every earlier API field keeps its name and shape.

**Member Home.** Above the existing content a member sees a dashboard built from their own records. Nothing is invented: a section with nothing to show says so.
- *Welcome* (greeting, name, profession, status) and *Profile strength*: a percentage and a checklist of the 12 profile steps still open, each linking to where it is done
  (`/profile?edit=basics`, `?edit=photo`, `?add=experience|education|project`, `/communities`). The percentage is the number of finished steps out of 12, calculated by the server from the member's
  real data (profession, headline, biography, 3+ skills, location, years of experience, photo, LinkedIn or GitHub link, a work experience, education, a project in My Work, one joined community).
- *New in Your Communities*: the 5 newest discussions by other members in communities the member joined, including their subcommunities (members join main communities; a subcommunity is covered by its parent).
- *Communities for You*: communities not yet joined, ranked by a keyword match between the member's profession and skills and each community's name, subcommunity names, category and description.
  Short skills ("C", "Go") must match a whole word. Every suggestion says why ("Matches your profession: ..."). With no match, or no profile text to match, the most popular communities are shown and say so.
- *Jobs for You*: stored listings that match the saved job category and work mode (same listings, filters and card as the Jobs page). With no saved preference it asks the member to choose them in Preferences; nothing is guessed.
- *Your Job Search*: saved-jobs count and the application summary, linking to Saved Jobs and My Applications.
- *Your Registrations*: the member's real upcoming course and webinar registrations (registrations on sample listings are labelled Sample).
Any of these five can be hidden in Preferences; the choice is stored on the server, so it survives refresh and sign-in.

**Preferences** (`/settings`, in the account menu; header title "Preferences"). Every change is saved immediately and announced.
- *Theme*: Light, Dark or System (follows the browser's `prefers-color-scheme`, live). The local key is still `pc-theme-v2` (it may now hold `system`). `index.html` applies it before the first paint. After sign-in a *saved* server theme is applied; a member who never saved one keeps the theme chosen on the device. The header sun/moon button flips what is shown and saves the result.
- *News*: default tab, All or For You. Used only when the address has no `?tab=`; an explicit `?tab=` always wins, and picking a tab always writes it to the address.
- *Jobs*: preferred category and work mode (Remote, Hybrid, On-site). They are never applied silently: the Jobs page has a **Use my preferences** button that applies the saved category and work mode and leaves every other filter alone.
- *Home sections*: show or hide the five personalized sections.

**Filters in the address.** Jobs (`q, category, location, mode, type, level, source`), Communities (`category, q`), Courses (`type, price, mode, category, q`) and News (`tab`) keep their filters in the query string,
through one small hook, `client/src/hooks/useUrlState.js`. Refresh, Back/Forward and copied links restore them; unknown values are ignored; typing in a search box updates the address without adding history entries, chips and selects add one.

**Account menu and Log Out.** The avatar menu has My Profile, Saved Jobs, My Applications, Preferences and Log Out; it is keyboard operable (Enter/Space/Arrow Down open it and focus the first item; Arrow Up/Down, Home, End move; Escape closes and returns focus; Tab closes).
Log Out uses the existing `POST /api/auth/logout` (it expires the `pc_token` cookie), clears the signed-in member and their preferences from the page, and returns to the public Home with `replace`, so the private page is not left as a history entry. Going Back to an earlier private page sends a visitor to Sign In and requests no private data.
If the server cannot be reached, the member is still signed out on this device and is told the session could not be ended on the server. A skip-to-content link is the first focusable element. The header and the browser tab title the page (`Jobs · ProConnect`, `News`, `News Sources`, `Preferences`, ...).

**API** (signed in with a completed profile, otherwise 401 / 403 `profile_incomplete`; responses are `Cache-Control: no-store`)

| Endpoint | Purpose |
| --- | --- |
| `GET /api/preferences` | `{ preferences: { theme, newsDefaultTab, jobCategory, jobWorkMode, homeSections: { newInCommunities, communitiesForYou, jobsForYou, jobSearch, registrations }, persisted } }`. A member who never saved gets the defaults with `persisted: false` and no row is created. |
| `PUT /api/preferences` | Partial update; send only what changed. `theme`: `light\|dark\|system`; `newsDefaultTab`: `all\|for-you`; `jobCategory`: one of the 12 job category keys or `null`; `jobWorkMode`: `remote\|hybrid\|on_site` or `null`; `homeSections`: `{ <section>: true\|false }`. Anything else (unknown properties, wrong types, another member's id) is refused with 400 `validation_error` and nothing is saved. |
| `GET /api/home` | adds `personal: { profile, newInCommunities, communitiesForYou, jobsForYou, jobSearch, registrations }` |

**Database.** One new table, `user_preferences`, created with `CREATE TABLE IF NOT EXISTS` in `schema.sql`: `user_id` (primary key, foreign key to `users`, `ON DELETE CASCADE`), `theme`, `news_default_tab`,
`job_category`, `job_work_mode`, `home_hidden` (JSON list of hidden sections), `updated_at`; values are also guarded by `CHECK` constraints. A row is written the first time a member saves a preference, so opening an existing database
only adds an empty table: no existing table, column, account or record is changed. To undo it, drop the table (`DROP TABLE user_preferences;`); nothing else depends on it.

**Upgrading safely.** Stop the server, then run `cd server && npm run backup`. It copies `server/data` (database and uploads) to `server/data-backups/data-<time>/` and verifies every file by size and SHA-256 before you start the new version.
Then copy your `server/data` folder into the new `server/` folder as described under "Keeping your data between versions". Never run `npm run seed -- --reset` on data you want to keep.

**Limitations.** Sessions are stateless JWTs: Log Out expires the cookie in the browser, but a copy of the token taken earlier would stay valid until it expires (7 days); revoking tokens would need a server-side session table, which this part does not add.
The 12 job category keys are listed in both `server/src/jobs/categories.js` and `client/src/utils/jobLabels.js`; keep them in step. Recommendations are keyword matches, not machine learning.

## Keeping your data between versions
The database lives in `server/data/proconnect.db` and uploaded images in `server/data/uploads/`. When you unzip a newer version, copy your old `server/data` folder
into the new `server/` folder instead of running `npm run seed` (seed resets everything). Make a verified copy first with `npm run backup` (see Part 19).

## Where things live
- `server/src/db/schema.sql`   tables (users, profile_items, communities, memberships, posts, comments, courses)
- `server/src/db/seed.js`      demonstration data
- `server/src/routes/`         API routes
- `client/src/styles/`         theme.css (all colors) and global.css
- `client/src/pages/`          Home, Profile, Sign In/Up, Onboarding, Settings (Preferences)
- `client/src/context/PreferencesContext.jsx`  saved preferences and theme sync; `client/src/hooks/useUrlState.js`  filters in the address
- `server/src/utils/preferences.js`, `profileStrength.js`, `recommend.js`  Part 19 rules

## Roles and permissions (Part 1)

| Label | How it is stored | Who can change it |
|---|---|---|
| Visitor | not signed in | n/a |
| Student / Beginner | `users.status` | the member (`PUT /api/profile/status`) |
| Professional | `users.status = 'professional'` | Admin only (`PUT /api/admin/users/:id/professional`) |
| Community Leader | `community_leaders` table (per community) | Admin only (`PUT/DELETE /api/admin/communities/:id/leaders/:userId`) |
| Authorized Organizer | `users.is_organizer` (courses and webinars) | Admin only (`PUT /api/admin/users/:id/organizer`) |
| Admin | `users.role = 'admin'` | `npm run make-admin -- email` |

Shared checks live in `server/src/utils/permissions.js` and `requireOrganizer` / `requireAdmin` in `server/src/middleware/auth.js`.
Demo data: Alex Morgan leads Design & UX, Sara Kim is an Authorized Organizer, the admin account is `admin@proconnect.example`.
