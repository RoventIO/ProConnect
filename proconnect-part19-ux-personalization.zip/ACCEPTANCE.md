# ProConnect: PRD acceptance checklist (PRD section 16.1)

Evidence legend
- **Server tests** `cd server && npm test` (45 tests, real API against a temporary database)
- **E2E** `cd server && npm run e2e` (42 checks: a real server process, PRD journeys 10.1 to 10.5, restart persistence)
- **UI tests** `cd client && npm test` (146 checks in a simulated browser: the real `<App />` shell, pages, composer)
- **Browser** = needs a person in a real browser. Nobody has run these yet, so they are marked *not yet verified*.

| # | PRD checklist item | Status | Evidence |
|---|---|---|---|
| 1 | Sign Up and Sign In validate input and support the auth states | Verified | Server tests, E2E, UI tests (`shell`): messages, duplicate email, wrong password, header states, Log Out |
| 2 | A visitor opening internal content is asked to register or sign in and complete the minimum profile | Verified | Server tests (401 / 403 `profile_incomplete`), UI tests (redirect to Sign In with explanation for 6 protected pages; incomplete profile goes to setup), E2E |
| 3 | A signed-in user can open and edit their own basic profile | API verified, page UI not yet verified | Server tests and E2E cover saving fields, experience, education, links and validation. The Profile page's edit forms are not covered by a UI test: Browser check needed |
| 4 | Communities can be browsed and opened; creation is not open to every member | Verified | Server tests (403 for members, admin-only create and delete), UI tests (button hidden for members; My Communities / Discover), E2E |
| 5 | A user can publish a post, read posts and add a comment in the right community | API verified, composer verified, post page not yet verified | Server tests, E2E (text, emoji, image, GIF, voice; membership required), UI tests (composer). The post page itself (`PostDetail`) has no UI test: Browser check needed |
| 6 | A user can edit or delete their own post or comment | API verified, page UI not yet verified | Server tests and E2E (author only, admin can delete, files removed). Edit and delete buttons on the post page: Browser check needed |
| 7 | Search and filters return relevant data | Verified | Server tests (all four types, three filters, empty results, Armenian/Cyrillic/Greek case-insensitivity), E2E, UI tests (tabs, counts, filters, empty state, header search) |
| 8 | Courses and webinars show Free/Paid and an external link when provided | Verified | Server tests, E2E, UI tests (list, filters, detail, safe link handling, sample notice) |
| 9 | Dark and light themes are usable, **dark is the default** | **Not met as shipped** | Switching and the moon/sun icons are verified (UI tests). The default theme is currently **light**, matching the WAct design you chose. The PRD says dark. One-line change in `client/src/context/ThemeContext.jsx` (`return 'light'` to `'dark'`). Colours and readability: Browser check needed |
| 10 | The sidebar collapses and expands in both themes and keeps the layout | Behaviour verified, appearance not yet verified | UI tests (toggle, tooltips, state kept, still present, works with either theme). Layout and overlap: Browser check needed |
| 11 | No navigation item has a "Soon" label any more (Jobs became real in Part 17, News in Part 4), and there is no Chats item | Verified | UI tests: no "Soon" badge or word anywhere, Jobs and News are real links. This supersedes the earlier "only Jobs is Soon" rule |
| 12 | The UI is in English and follows the visual direction | English verified, look not yet verified | Static scan found no non-English text in the source; rendered pages checked. Visual direction (WAct style replaced the PRD's Dribbble reference at your request): Browser check needed |
| 13 | The demo distinguishes implemented from sample or future functionality | Verified | Course listings carry a "Sample" label and a notice. Jobs shows real listings from Arbeitnow and The Muse with their source named, and the 11 Part 17 demo courses and webinars are labelled "Sample" with a notice; News shows real stored articles with their original publisher. The Home quote tile is labelled "Sample quote". Home numbers come from the database |

## UX & Personalization (Part 19)

| Item | Status | Evidence |
|---|---|---|
| Member Home dashboard: welcome, profile strength from real data, New in Your Communities, Communities for You (with reasons, popular fallback), Jobs for You, Your Job Search, Your Registrations | Verified | Server tests (`preferences.test.js`: real data only, subcommunities, own posts excluded, other members' data excluded), client tests (`part19`, jsdom) |
| Visitor Home unchanged; Trending Discussions, Courses & Webinars, Popular Communities keep their headings; earlier `/api/home` fields unchanged | Verified | Rendered visitor HTML compared with the Part 18 source (identical), all 10 earlier client test files and 168 earlier server tests pass unchanged |
| Home sections can be hidden and shown; choice persists across refresh and sign-in | Verified | Server tests, `npm run e2e:part19` (incl. restart), client tests |
| `/settings` page: theme Light / Dark / System, default News tab, job category and work mode, Home sections | Verified | Client tests (jsdom) |
| System theme follows `prefers-color-scheme`; `pc-theme-v2` kept; saved server theme applied after sign-in; header toggle still works | Verified (jsdom with a simulated media query) | Client tests. First-paint script in `index.html`: **not yet verified in a real browser** |
| `user_preferences`: one row per member, FK + cascade, safe defaults, CHECK constraints, strict whitelists, unknown properties refused, own data only, auth + onboarding required | Verified | Server tests (23), `npm run e2e:part19` |
| Additive migration: an existing database only gains the empty table | Verified | Server test (Part 18 schema reopened; users and saved jobs intact, zero preference rows) |
| News default tab only without `?tab=` | Verified | Client tests |
| Jobs "Use my preferences" applies category and work mode only on request and keeps other filters | Verified | Client tests |
| Filters kept in the address for Jobs, Communities, Courses, News; refresh/Back/Forward/direct links | Verified in jsdom (MemoryRouter history). Real browser history: **not yet verified** | Client tests |
| Account menu: My Profile, Saved Jobs, My Applications, Preferences, Log Out; keyboard operable | Verified | Client tests |
| Log Out: existing endpoint, cookie expired, client state cleared, public Home, Back to a private page lands on Sign In with no private requests, graceful failure | Verified (cookie expiry by server test, flow by jsdom) | Server test, client tests, `npm run e2e:part19` |
| Skip-to-content link, header titles and `document.title` for News, Jobs, News Sources, Preferences and other pages | Verified | Client tests |
| Existing Saved Jobs and My Applications unchanged; existing users and records intact | Verified | Existing tests pass; `npm run e2e:part18`; `npm run e2e:part19` compares row counts before and after |

## Not implemented on purpose (PRD P1/P2 or deferred)
Notifications, news, jobs, credential verification and status badges, community-creation requests, course publishing workflows,
integrated payments, AI moderation, password reset and email verification (no email is sent).

Private chat is permanently out of scope (PRD v2.0) and has been removed from the project.

## Extras requested beyond the PRD
Profile photos, images and GIF uploads, voice messages and emoji in discussions and replies, an admin account for managing communities.

## Known limitations
- Each search type returns at most 20 results and community pages show the newest 20 discussions (no pagination).
- Attachments cannot be added or removed when editing a post or reply; edit changes the text only. Deleting is permanent (no undo).
- Searching for GIFs inside the app (Giphy or Tenor) is not included; GIF files can be uploaded.
- `node:sqlite` is an experimental Node feature (the warning is silenced). Needs Node 22.13 or newer.
- `react-router-dom` 6.x has two moderate advisories (open redirect through user-controlled link targets, and server-side rendering). The app uses client-side routing only and never builds a link from user input. The fix is a major upgrade to v7 and has not been done.
- No rate limiting, no CSRF token beyond SameSite cookies, the JWT secret has a development default and all seeded accounts share one password. Fine for a local demonstration, not for a public site.
- Voice recording needs microphone permission and a modern browser (Chrome, Edge, Firefox or Safari) on localhost or HTTPS.

- Log Out expires the session cookie; the JWT itself is stateless, so a copy of a token taken earlier would work until it expires (7 days).

## Manual browser checks still to do (about 15 minutes)
1. Sign Up with a new email, complete the profile, and confirm Home shows discussions after that.
2. Switch dark and light on Home, Communities, a community, a discussion, Courses and Search. Look for unreadable text.
3. Collapse and expand the sidebar on each of those pages in both themes.
4. In a community you joined: write a discussion with an emoji, an image, a GIF and a voice message. Open it, play the voice message, open an image.
5. Reply with text and with a voice message. Edit and delete your own discussion and reply. Confirm another account cannot.
6. Refresh the page after each step and confirm everything is still there. Restart the backend and check again.
7. Join and leave a community and watch it move between My Communities and Discover Communities.
8. Search for "design" and for an Armenian word that appears in a discussion you wrote. Try each filter and open a result of each type.
9. Open a course and a webinar. Check Free/Paid, the Sample notice and the registration link.
10. Sign out and open `/communities` and `/search` to see the Sign In prompt.
11. Resize the window to a tablet and a phone width and look for broken layouts.


## Notifications (PRD FR-11)

| Item | Status | Evidence |
|---|---|---|
| Notification for a new discussion in a joined community (not the author, not non-members, not bots) | Verified | Server tests and browser run |
| Notification for a reply to the member's comment (not self-replies) | Verified | Server tests and browser run |
| No other notification categories | Verified | `type` is limited to the two kinds by a database CHECK |
| Bell with unread badge directly left of the avatar, panel, mark read, mark all read, empty state | Verified | Client tests and browser run (desktop and 390 px wide) |
| Duplicate and authorization protection | Verified | UNIQUE (recipient, dedupe key); other members' ids return 404 |


## Search and discovery (PRD FR-05) and test accounts

| Item | Status | Evidence |
|---|---|---|
| People and Communities tabs only (no discussions or courses) | Verified | Server tests, client tests, browser run |
| People: name, specialty, skill search; specialty and status filters | Verified | Server tests, browser run |
| Communities and subcommunities: name, description, specialty; parent label; join | Verified | Server tests, browser run (membership persists after refresh) |
| Sorting by last profile update / creation date, Best match option | Verified | Server tests |
| Empty, error and discovery states | Verified | Client tests, browser run |
| Five test accounts created, repeatable, sign in | Verified | Server test and browser run |


## Community management, News image fallback, profile logos, readability (Part 7)

| Item | Status | Evidence |
|---|---|---|
| Admin creates, edits, deletes main communities; leaders limited to their own community and its subcommunities | Verified | Server tests; browser run |
| Parent relationships validated, one level only, no re-parenting, no duplicates | Verified | Server tests |
| Join, leave, no duplicate memberships, counts equal membership records, member list rules | Verified | Server tests; browser run |
| News default image (backend assignment, read-time fallback, broken-image fallback) | Verified | Server and client tests; browser run (original kept, default shown, no loop) |
| LinkedIn and GitHub shown as logos only; hidden when absent | Verified | Client tests; browser run |
| Readability limited to community pages; no horizontal overflow on phone or tablet | Verified | CSS scope test; browser run at 390, 820 and 1360 px |
| Five test accounts intact | Verified | Server test; browser sign-in |
| Saved Jobs: save/unsave, no duplicates, per-member, persists after logout/login, unavailable listings kept (Part 18) | Verified | Server tests, `npm run e2e:part18`, client tests (jsdom; no real browser run) |
| My Applications: manual and linked records, statuses, filters, sorting, counts, ownership, Apply click records nothing (Part 18) | Verified | Server tests, `npm run e2e:part18`, client tests (jsdom; no real browser run) |
12. (Part 19) Set Theme to System, then switch your operating system between light and dark and watch the page follow it; reload and look for a flash of the wrong theme.
13. (Part 19) On Home, finish a profile step from the checklist and see the percentage change; hide and show a Home section in Preferences and refresh.
14. (Part 19) Set a job category and work mode, open Jobs, press "Use my preferences", then use the browser Back and Forward buttons and copy the address into a new tab.
15. (Part 19) Open the avatar menu with the keyboard only, use Log Out, then press the browser Back button.
