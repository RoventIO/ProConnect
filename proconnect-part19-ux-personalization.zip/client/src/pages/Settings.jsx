import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Monitor, Moon, Sun } from 'lucide-react';
import { useTheme } from '../context/ThemeContext.jsx';
import { HOME_SECTIONS, usePreferences } from '../context/PreferencesContext.jsx';
import { JOB_CATEGORIES, MODE_LABEL } from '../utils/jobLabels.js';

const THEMES = [
  { key: 'light', label: 'Light', icon: Sun, hint: 'Always use the light theme' },
  { key: 'dark', label: 'Dark', icon: Moon, hint: 'Always use the dark theme' },
  { key: 'system', label: 'System', icon: Monitor, hint: 'Follow your device or browser setting' },
];
const NEWS_TABS = [
  { key: 'all', label: 'All News', hint: 'Every recent article' },
  { key: 'for-you', label: 'For You', hint: 'Articles matching your topics and communities' },
];

/** One group of radio buttons: a fieldset with a legend, so screen readers announce the group and the current choice. */
function RadioGroup({ legend, name, value, options, onChange, disabled }) {
  return (
    <fieldset className="pref-group" disabled={disabled}>
      <legend>{legend}</legend>
      <div className="pref-options">
        {options.map((o) => {
          const Icon = o.icon;
          return (
            <label key={o.key} className={`pref-option ${value === o.key ? 'selected' : ''}`}>
              <input type="radio" name={name} value={o.key} checked={value === o.key} onChange={() => onChange(o.key)} />
              {Icon && <Icon size={16} aria-hidden="true" />}
              <span>
                <strong>{o.label}</strong>
                {o.hint && <small className="muted">{o.hint}</small>}
              </span>
            </label>
          );
        })}
      </div>
    </fieldset>
  );
}

export default function Settings() {
  const { prefs, loaded, save, chooseTheme } = usePreferences();
  const { themePreference } = useTheme();
  const [status, setStatus] = useState({ kind: '', text: '' });

  // Every change is saved as soon as it is made. The line under the title says what happened.
  const change = async (run) => {
    setStatus({ kind: 'busy', text: 'Saving…' });
    try {
      await run();
      setStatus({ kind: 'ok', text: 'Preferences saved.' });
    } catch (err) {
      setStatus({ kind: 'error', text: err.message || 'Your change could not be saved. Please try again.' });
    }
  };
  const disabled = !loaded;
  const hiddenCount = HOME_SECTIONS.filter((s) => prefs.homeSections[s.key] === false).length;

  return (
    <div className="settings">
      <header className="settings-head">
        <h2 className="serif">Preferences</h2>
        <p className="muted">Choose how ProConnect looks and what it shows first. Changes are saved automatically and stay with your account.</p>
        <p className={`pref-status ${status.kind}`} role={status.kind === 'error' ? 'alert' : 'status'} aria-live="polite">{status.text || ' '}</p>
      </header>

      <section className="card pref-card" aria-labelledby="pref-theme">
        <h3 id="pref-theme">Appearance</h3>
        <RadioGroup legend="Theme" name="theme" value={themePreference} options={THEMES} disabled={disabled} onChange={(k) => change(() => chooseTheme(k))} />
      </section>

      <section className="card pref-card" aria-labelledby="pref-news">
        <h3 id="pref-news">News</h3>
        <RadioGroup legend="Default News tab" name="news-tab" value={prefs.newsDefaultTab} options={NEWS_TABS} disabled={disabled} onChange={(k) => change(() => save({ newsDefaultTab: k }))} />
        <p className="muted pref-note">Used when you open News without a tab in the address. A link such as <code>/news?tab=ai</code> always opens the tab it names.</p>
      </section>

      <section className="card pref-card" aria-labelledby="pref-jobs">
        <h3 id="pref-jobs">Jobs</h3>
        <div className="field">
          <label htmlFor="pref-job-category">Preferred job category</label>
          <select id="pref-job-category" value={prefs.jobCategory || ''} disabled={disabled} onChange={(e) => change(() => save({ jobCategory: e.target.value || null }))}>
            <option value="">No preference</option>
            {JOB_CATEGORIES.map((c) => <option key={c.key} value={c.key}>{c.label}</option>)}
          </select>
        </div>
        <RadioGroup
          legend="Preferred work mode"
          name="work-mode"
          value={prefs.jobWorkMode || 'none'}
          disabled={disabled}
          options={[{ key: 'none', label: 'No preference' }, ...Object.entries(MODE_LABEL).map(([key, label]) => ({ key, label }))]}
          onChange={(k) => change(() => save({ jobWorkMode: k === 'none' ? null : k }))}
        />
        <p className="muted pref-note">
          These are never applied silently. On the <Link to="/jobs">Jobs</Link> page, press <strong>Use my preferences</strong> to filter by them, and they pick the listings shown under Jobs for You on Home.
        </p>
      </section>

      <section className="card pref-card" aria-labelledby="pref-home">
        <h3 id="pref-home">Home page sections</h3>
        <p className="muted pref-note">Choose which personalized sections appear on your Home page.{hiddenCount > 0 ? ` ${hiddenCount} hidden.` : ''}</p>
        <ul className="pref-switches">
          {HOME_SECTIONS.map((s) => (
            <li key={s.key}>
              <label className="pref-switch">
                <input type="checkbox" role="switch" checked={prefs.homeSections[s.key] !== false} disabled={disabled} onChange={(e) => change(() => save({ homeSections: { [s.key]: e.target.checked } }))} />
                <span>
                  <strong>{s.label}</strong>
                  <small className="muted">{s.hint}</small>
                </span>
              </label>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
