import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeft, Plus, Trash2 } from 'lucide-react';
import { api } from '../api.js';
import { useApi } from '../hooks/useApi.js';
import { useAuth } from '../context/AuthContext.jsx';
import { useFeedback } from '../components/Feedback.jsx';
import Field from '../components/Field.jsx';
import { dateTime } from '../utils/format.js';

const statusOf = (s) => (s.lastStatus === 'ok' ? ['Working', 'pill-free'] : s.lastStatus === 'error' ? ['Failed', 'pill-paid'] : ['Not synced yet', 'pill-sample']);

function AddForm({ onAdded }) {
  const [values, setValues] = useState({ name: '', url: '' });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [result, setResult] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setErrors({});
    setFormError('');
    setResult('');
    try {
      const d = await api('/admin/news/sources', { method: 'POST', body: values });
      setValues({ name: '', url: '' });
      setResult(d.check?.status === 'ok' ? `Added. The first fetch worked: ${d.check.message}.` : d.check?.status === 'error' ? `Added, but the first fetch failed: ${d.check.message}` : 'Added. It will be fetched in the next synchronization.');
      onAdded();
    } catch (err) {
      if (err.fields) setErrors(err.fields);
      else setFormError(err.message);
    } finally {
      setBusy(false);
    }
  };
  const onChange = (e) => setValues((v) => ({ ...v, [e.target.name]: e.target.value }));
  return (
    <form className="card edit-card" onSubmit={submit} noValidate aria-labelledby="add-source-title">
      <h3 id="add-source-title">Add an RSS or Atom feed</h3>
      <p className="muted">Only public http(s) feed addresses are accepted. Local, private-network and credential-carrying addresses are rejected.</p>
      <div className="field-row">
        <Field id="name" label="Source name" value={values.name} onChange={onChange} error={errors.name} placeholder="Example Weekly" maxLength={60} />
        <Field id="url" label="Feed address" value={values.url} onChange={onChange} error={errors.url} placeholder="https://example.com/feed.xml" inputMode="url" />
      </div>
      {formError && <div className="form-error" role="alert">{formError}</div>}
      {result && <div className="notice" role="status">{result}</div>}
      <div><button type="submit" className="btn btn-primary btn-sm" disabled={busy}><Plus size={14} aria-hidden="true" /> {busy ? 'Checking the feed…' : 'Add source'}</button></div>
    </form>
  );
}

function SourceRow({ source, onChanged }) {
  const { confirm, notify } = useFeedback();
  const [editing, setEditing] = useState(false);
  const [url, setUrl] = useState(source.url);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const [label, tone] = statusOf(source);

  const run = async (fn) => {
    setBusy(true);
    setError('');
    try {
      await fn();
      onChanged();
    } catch (e) {
      setError(e.fields?.url || e.message);
    } finally {
      setBusy(false);
    }
  };
  const toggle = () => run(() => api(`/admin/news/sources/${source.id}`, { method: 'PUT', body: { enabled: !source.enabled } }));
  const saveUrl = (e) => {
    e.preventDefault();
    return run(async () => {
      await api(`/admin/news/sources/${source.id}`, { method: 'PUT', body: { url } });
      setEditing(false);
    });
  };
  const remove = async () => {
    const ok = await confirm({ title: `Remove ${source.name}?`, message: `The source and its ${source.articleCount} stored article${source.articleCount === 1 ? '' : 's'} will be deleted. Other news is not affected.`, confirmLabel: 'Remove source', tone: 'danger' });
    if (!ok) return;
    await run(async () => {
      await api(`/admin/news/sources/${source.id}`, { method: 'DELETE' });
      notify(`${source.name} was removed.`);
    });
  };

  return (
    <article className={`card source-card ${source.enabled ? '' : 'is-off'}`} aria-label={source.name}>
      <div className="source-head">
        <h3>{source.name}</h3>
        <span className="course-pills">
          <span className="pill">{source.kind === 'rss' ? 'RSS' : 'API'}</span>
          {source.builtin && <span className="pill pill-sample">Built-in</span>}
          <span className={`pill ${source.enabled ? 'pill-accent' : 'pill-sample'}`}>{source.enabled ? 'Enabled' : 'Disabled'}</span>
          <span className={`pill ${tone}`}>{label}</span>
        </span>
      </div>
      {editing ? (
        <form onSubmit={saveUrl} className="source-edit" noValidate>
          <Field id={`url-${source.id}`} label="Feed address" value={url} onChange={(e) => setUrl(e.target.value)} error={error || undefined} />
          <div className="source-actions">
            <button type="submit" className="btn btn-primary btn-sm" disabled={busy}>{busy ? 'Checking…' : 'Save address'}</button>
            <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setEditing(false); setUrl(source.url); setError(''); }}>Cancel</button>
          </div>
        </form>
      ) : (
        <p className="source-url muted">{source.url}</p>
      )}
      <p className="muted result-note">
        {source.lastSyncAt ? <>Last attempt {dateTime(source.lastSyncAt)}: {source.lastMessage}</> : 'Not fetched yet.'} · {source.articleCount} stored article{source.articleCount === 1 ? '' : 's'}
      </p>
      {error && !editing && <div className="field-error" role="alert">{error}</div>}
      {!editing && (
        <div className="source-actions">
          <button type="button" className={`chip-btn ${source.enabled ? 'active' : ''}`} aria-pressed={source.enabled} disabled={busy} onClick={toggle}>{source.enabled ? 'Enabled' : 'Disabled'}</button>
          {source.urlEditable && <button type="button" className="btn btn-ghost btn-sm" onClick={() => setEditing(true)}>Edit address</button>}
          {!source.builtin && <button type="button" className="btn btn-ghost btn-sm" disabled={busy} onClick={remove}><Trash2 size={14} aria-hidden="true" /> Remove</button>}
        </div>
      )}
    </article>
  );
}

/** The backend enforces the Admin rule; this page also avoids even asking when the member is not an Admin. */
export default function NewsSources() {
  const { user } = useAuth();
  if (!user?.isAdmin) {
    return (
      <section className="card placeholder" role="alert">
        <h2>Administrators only</h2>
        <p>Only administrators can manage news sources.</p>
        <Link to="/news" className="btn btn-ghost">Back to News</Link>
      </section>
    );
  }
  return <SourcesAdmin />;
}

function SourcesAdmin() {
  const sources = useApi('/admin/news/sources');
  const status = useApi('/admin/news/status');
  const reloadAll = () => { sources.reload(); status.reload(); };
  const sched = status.data?.scheduler;
  return (
    <div className="news-sources">
      <div className="toolbar">
        <Link to="/news" className="btn btn-ghost btn-sm"><ArrowLeft size={14} aria-hidden="true" /> Back to News</Link>
      </div>
      <section className="card" aria-labelledby="sync-title">
        <h3 id="sync-title">Synchronization</h3>
        {status.loading ? <p className="muted">Loading…</p> : status.error ? <p className="field-error" role="alert">{status.error.message}</p> : (
          <p className="muted">
            {sched.registered ? `Scheduled every ${sched.intervalMinutes} minutes. Next run ${dateTime(sched.nextRunAt)}.` : 'The automatic schedule is not running in this server process.'}{' '}
            {status.data.lastRun ? `Last run: ${dateTime(status.data.lastRun.finishedAt || status.data.lastRun.startedAt)} (${status.data.lastRun.reason}), ${status.data.lastRun.totals.inserted} new, ${status.data.lastRun.deleted} expired deleted.` : 'No run has finished since this server started.'}{' '}
            Articles are kept for {status.data.retentionHours} hours.
          </p>
        )}
      </section>
      <AddForm onAdded={reloadAll} />
      {sources.loading ? (
        <div className="card page-loading" role="status">Loading…</div>
      ) : sources.error ? (
        <div className="card form-error" role="alert">{sources.error.message}</div>
      ) : (
        <div className="source-list">
          {sources.data.sources.map((s) => <SourceRow key={s.id} source={s} onChanged={reloadAll} />)}
        </div>
      )}
    </div>
  );
}
