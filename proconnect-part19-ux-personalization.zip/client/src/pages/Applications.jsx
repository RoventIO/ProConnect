import { useCallback, useEffect, useRef, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { ClipboardList, ExternalLink, Pencil, Plus, Search, Trash2, X } from 'lucide-react';
import { api } from '../api.js';
import { useFeedback } from '../components/Feedback.jsx';
import ApplicationForm from '../components/ApplicationForm.jsx';
import { dayLabel, isWebLink, plainDate } from '../utils/format.js';
import { APPLICATION_STATUSES, STATUS_LABEL } from '../utils/jobLabels.js';

const SORTS = [
  ['applied-desc', 'Application date · newest first'],
  ['applied-asc', 'Application date · oldest first'],
  ['updated-desc', 'Last updated · newest first'],
  ['updated-asc', 'Last updated · oldest first'],
];
const OVERVIEW = [
  ['total', 'Total applications', ''],
  ['applied', 'Applied', 'applied'],
  ['reviewing', 'Reviewing', 'reviewing'],
  ['interview', 'Interviews', 'interview'],
  ['accepted', 'Accepted', 'accepted'],
  ['rejected', 'Rejected', 'rejected'],
];

export function StatusPill({ status }) {
  return <span className={`pill status-pill status-${status}`}><span className="status-dot" aria-hidden="true" />{STATUS_LABEL[status] || status}</span>;
}

export default function Applications() {
  const { confirm, notify } = useFeedback();
  const [params, setParams] = useSearchParams();
  const [filters, setFilters] = useState({ status: '', q: '', sort: 'applied-desc' });
  const [text, setText] = useState('');
  const [state, setState] = useState({ status: 'loading', data: null, error: null });
  const [form, setForm] = useState(null); // null | { application } | { jobId }
  const [rowBusy, setRowBusy] = useState(null);
  const [rowError, setRowError] = useState({});
  const opened = useRef(false);

  useEffect(() => {
    const t = setTimeout(() => setFilters((f) => (f.q === text.trim() ? f : { ...f, q: text.trim() })), 300);
    return () => clearTimeout(t);
  }, [text]);

  const load = useCallback(async (f, { silent = false } = {}) => {
    if (!silent) setState((s) => ({ ...s, status: 'loading', error: null }));
    try {
      const [sort, dir] = f.sort.split('-');
      const p = new URLSearchParams({ sort, dir });
      if (f.status) p.set('status', f.status);
      if (f.q) p.set('q', f.q);
      const data = await api(`/job-applications?${p}`);
      setState({ status: 'ready', data, error: null });
    } catch (error) {
      setState((s) => ({ ...s, status: 'error', error }));
    }
  }, []);
  useEffect(() => { load(filters); }, [filters, load]);

  // Arriving from a job page ("Add to My Applications") opens the form with that job selected, once.
  useEffect(() => {
    const add = params.get('add');
    if (add && !opened.current) {
      opened.current = true;
      if (/^\d+$/.test(add)) setForm({ jobId: Number(add) });
      const next = new URLSearchParams(params);
      next.delete('add');
      setParams(next, { replace: true });
    }
  }, [params, setParams]);

  async function changeStatus(a, status) {
    if (status === a.status) return;
    setRowBusy(a.id);
    setRowError((e) => ({ ...e, [a.id]: '' }));
    try {
      await api(`/job-applications/${a.id}`, { method: 'PUT', body: { status } });
      await load(filters, { silent: true });
    } catch (e) {
      setRowError((r) => ({ ...r, [a.id]: e.message }));
    } finally {
      setRowBusy(null);
    }
  }

  async function remove(a) {
    const ok = await confirm({ title: 'Delete this application?', message: `"${a.title}" at ${a.company} will be removed from your tracking list. This does not affect the employer or the job listing.`, confirmLabel: 'Delete', tone: 'danger' });
    if (!ok) return;
    setRowBusy(a.id);
    try {
      try {
        await api(`/job-applications/${a.id}`, { method: 'DELETE' });
      } catch (e) {
        if (e.status !== 404) throw e;
      }
      notify('Application deleted.');
      await load(filters, { silent: true });
    } catch (e) {
      setRowError((r) => ({ ...r, [a.id]: e.message }));
    } finally {
      setRowBusy(null);
    }
  }

  const data = state.data;
  const summary = data?.summary;
  const active = !!(filters.status || filters.q || text);
  const clear = () => { setText(''); setFilters((f) => ({ ...f, status: '', q: '' })); };

  return (
    <div className="jobs applications">
      <header className="jobs-head">
        <div>
          <h2 className="serif">My Applications</h2>
          <p className="muted">Keep track of the jobs you have applied for and where each one stands.</p>
        </div>
        <div className="jobs-head-side">
          <Link to="/saved-jobs" className="btn btn-ghost btn-sm">Saved Jobs</Link>
          <button type="button" className="btn btn-primary btn-sm" onClick={() => setForm({})}><Plus size={14} aria-hidden="true" /> Add Application</button>
        </div>
      </header>

      <p className="notice apps-note" role="note">
        This is your own tracking list. Most jobs are applied for on the employer's website, and ProConnect does not submit applications or know whether you completed one. Clicking Apply never adds anything here: after you have applied, add it yourself.
      </p>

      {summary && (
        <section className="apps-overview" aria-label="Overview of your applications">
          {OVERVIEW.map(([key, label, status]) => {
            const on = status ? filters.status === status : false; // only the status cards act as toggles; Total clears the filter
            return (
              <button key={key} type="button" className={`card apps-stat ${status ? `apps-stat-${status}` : ''} ${on && status ? 'active' : ''}`} aria-pressed={status ? on : undefined}
                onClick={() => setFilters((f) => ({ ...f, status: status && f.status !== status ? status : '' }))}
                aria-label={`${label}: ${summary[key]}${status ? '. Show only these' : '. Show all'}`}>
                <strong>{summary[key]}</strong>
                <span>{label}</span>
              </button>
            );
          })}
        </section>
      )}

      {data && summary.total > 0 && (
        <section className="card jobs-filters" aria-label="Search, filters and sorting">
          <div className="jobs-filter-row apps-filter-row">
            <label className="search search-wide">
              <Search size={16} aria-hidden="true" />
              <input type="search" placeholder="Search by job title or company" aria-label="Search applications by job title or company" value={text} onChange={(e) => setText(e.target.value)} />
            </label>
            <div className="field">
              <label htmlFor="apps-status">Status</label>
              <select id="apps-status" value={filters.status} onChange={(e) => setFilters((f) => ({ ...f, status: e.target.value }))}>
                <option value="">All statuses ({summary.total})</option>
                {APPLICATION_STATUSES.map((s) => <option key={s.key} value={s.key}>{s.label} ({summary[s.key]})</option>)}
              </select>
            </div>
            <div className="field">
              <label htmlFor="apps-sort">Sort by</label>
              <select id="apps-sort" value={filters.sort} onChange={(e) => setFilters((f) => ({ ...f, sort: e.target.value }))}>
                {SORTS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
              </select>
            </div>
          </div>
          <div className="jobs-filter-foot">
            <small className="muted" aria-live="polite">{state.status === 'ready' ? `${data.total} of ${summary.total} ${summary.total === 1 ? 'application' : 'applications'}` : ' '}</small>
            {active && <button type="button" className="btn btn-ghost btn-sm" onClick={clear}><X size={14} aria-hidden="true" /> Clear filters</button>}
          </div>
        </section>
      )}

      {state.status === 'loading' && !data ? (
        <div className="card page-loading" role="status">Loading your applications…</div>
      ) : state.status === 'error' && !data ? (
        <div className="card form-error" role="alert">
          {state.error.message} <button type="button" className="btn btn-ghost btn-sm" onClick={() => load(filters)}>Try again</button>
        </div>
      ) : data && summary.total === 0 ? (
        <div className="card empty" role="status">
          <ClipboardList size={22} aria-hidden="true" />
          <h3>You are not tracking any applications yet</h3>
          <p className="muted">After you apply for a job on an employer's website, add it here and update its status as things move on.</p>
          <div className="job-actions empty-actions">
            <button type="button" className="btn btn-primary btn-sm" onClick={() => setForm({})}><Plus size={14} aria-hidden="true" /> Add Application</button>
            <Link to="/jobs" className="btn btn-ghost btn-sm">Browse jobs</Link>
          </div>
        </div>
      ) : data && data.total === 0 ? (
        <div className="card empty" role="status">
          <Search size={22} aria-hidden="true" />
          <h3>No applications match</h3>
          <p className="muted">Try other words or show all statuses.</p>
          <button type="button" className="btn btn-ghost btn-sm" onClick={clear}>Clear filters</button>
        </div>
      ) : (
        <>
          {state.status === 'error' && <p className="form-error" role="alert">{state.error.message}</p>}
          <ul className={`apps-list ${state.status === 'loading' ? 'is-busy' : ''}`} aria-label="Your applications">
            {data.applications.map((a) => (
              <li key={a.id} className="card apps-row">
                <div className="apps-main">
                  <h3><button type="button" className="link-btn" onClick={() => setForm({ application: a })} aria-label={`Open and edit ${a.title} at ${a.company}`}>{a.title}</button></h3>
                  <p className="muted">{a.company}</p>
                  <p className="apps-links">
                    {isWebLink(a.url) && <a href={a.url} target="_blank" rel="noopener noreferrer">Original listing <ExternalLink size={12} aria-hidden="true" /></a>}
                    {a.job && !a.job.available && <span className="pill pill-unavailable" title="The listing is no longer in ProConnect. Your record keeps its details.">Listing no longer available</span>}
                    {a.job?.available && <span className="pill pill-sample">ProConnect job</span>}
                    <span className="pill pill-sample" title="Kept by you. ProConnect did not submit this application.">Tracked by you</span>
                  </p>
                  {a.notes && <p className="apps-notes">{a.notes}</p>}
                </div>
                <dl className="apps-dates">
                  <div><dt>Applied</dt><dd><time dateTime={a.appliedOn}>{plainDate(a.appliedOn)}</time></dd></div>
                  <div><dt>Last updated</dt><dd><time dateTime={a.updatedAt}>{dayLabel(a.updatedAt)}</time></dd></div>
                </dl>
                <div className="apps-status">
                  <StatusPill status={a.status} />
                  <label className="visually-hidden" htmlFor={`status-${a.id}`}>Status of {a.title} at {a.company}</label>
                  <select id={`status-${a.id}`} className="apps-status-select" value={a.status} disabled={rowBusy === a.id} onChange={(e) => changeStatus(a, e.target.value)}>
                    {APPLICATION_STATUSES.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
                  </select>
                  {rowError[a.id] && <small className="field-error" role="alert">{rowError[a.id]}</small>}
                </div>
                <div className="apps-actions">
                  <button type="button" className="btn btn-ghost btn-sm" onClick={() => setForm({ application: a })} aria-label={`Edit ${a.title} at ${a.company}`}><Pencil size={13} aria-hidden="true" /> Edit</button>
                  <button type="button" className="btn btn-ghost btn-sm" onClick={() => remove(a)} disabled={rowBusy === a.id} aria-label={`Delete ${a.title} at ${a.company}`}><Trash2 size={13} aria-hidden="true" /> Delete</button>
                </div>
              </li>
            ))}
          </ul>
        </>
      )}

      {form && (
        <ApplicationForm
          application={form.application || null}
          jobId={form.jobId || null}
          onClose={() => setForm(null)}
          onSaved={(a, edited) => { setForm(null); notify(edited ? 'Application updated.' : 'Application added to your list.'); load(filters, { silent: true }); }}
        />
      )}
    </div>
  );
}
