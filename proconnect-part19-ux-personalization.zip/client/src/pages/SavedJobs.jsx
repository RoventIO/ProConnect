import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Bookmark, Search, X } from 'lucide-react';
import { api } from '../api.js';
import { useFeedback } from '../components/Feedback.jsx';
import JobCard from '../components/JobCard.jsx';

const SORTS = [
  ['recent', 'Most recently saved'],
  ['oldest', 'Oldest saved first'],
  ['title', 'Job title A–Z'],
];

/** Builds the job shape JobCard expects from a saved record (fresh values when the listing is still stored, the saved snapshot otherwise). */
const cardJob = (s) => ({ ...s.job, id: s.job.id, summary: null, tags: [], firstSeenAt: s.savedAt, savedId: s.id });

export default function SavedJobs() {
  const { confirm, notify } = useFeedback();
  const [text, setText] = useState('');
  const [filters, setFilters] = useState({ q: '', category: '', availability: '', sort: 'recent' });
  const [state, setState] = useState({ status: 'loading', data: null, error: null });
  const [removing, setRemoving] = useState(null);

  useEffect(() => {
    const t = setTimeout(() => setFilters((f) => (f.q === text.trim() ? f : { ...f, q: text.trim() })), 300);
    return () => clearTimeout(t);
  }, [text]);

  const load = useCallback(async (f, { silent = false } = {}) => {
    if (!silent) setState((s) => ({ ...s, status: 'loading', error: null }));
    try {
      const p = new URLSearchParams();
      for (const [k, v] of Object.entries(f)) if (v) p.set(k, v);
      const data = await api(`/saved-jobs?${p}`);
      setState({ status: 'ready', data, error: null });
    } catch (error) {
      setState((s) => ({ ...s, status: 'error', error }));
    }
  }, []);
  useEffect(() => { load(filters); }, [filters, load]);

  async function remove(item) {
    const ok = await confirm({
      title: 'Remove from saved jobs?',
      message: `"${item.job.title}" at ${item.job.company} will be removed from your saved jobs.${item.availability === 'unavailable' ? ' This listing is no longer available, so it cannot be saved again.' : ''}`,
      confirmLabel: 'Remove', tone: 'danger',
    });
    if (!ok) return;
    setRemoving(item.id);
    try {
      try {
        await api(`/saved-jobs/${item.id}`, { method: 'DELETE' });
      } catch (e) {
        if (e.status !== 404) throw e;
      }
      notify('Removed from your saved jobs.');
      await load(filters, { silent: true });
    } catch (e) {
      notify(e.message || 'Could not remove this job. Try again.');
    } finally {
      setRemoving(null);
    }
  }

  const data = state.data;
  const active = !!(filters.q || filters.category || filters.availability || text);
  const clear = () => { setText(''); setFilters((f) => ({ ...f, q: '', category: '', availability: '' })); };
  const set = (k) => (e) => setFilters((f) => ({ ...f, [k]: e.target.value }));

  return (
    <div className="jobs saved-jobs">
      <header className="jobs-head">
        <div>
          <h2 className="serif">Saved Jobs</h2>
          <p className="muted">Jobs you bookmarked. They stay here until you remove them, even when a listing disappears from the job feed.</p>
        </div>
        <div className="jobs-head-side">
          <Link to="/applications" className="btn btn-ghost btn-sm">My Applications</Link>
          <Link to="/jobs" className="btn btn-primary btn-sm">Browse jobs</Link>
        </div>
      </header>

      {data && data.totalSaved > 0 && (
        <section className="card jobs-filters" aria-label="Search and filters">
          <div className="jobs-filter-row saved-filter-row">
            <label className="search search-wide">
              <Search size={16} aria-hidden="true" />
              <input type="search" placeholder="Search by job title or company" aria-label="Search saved jobs by title or company" value={text} onChange={(e) => setText(e.target.value)} />
            </label>
            <div className="field">
              <label htmlFor="saved-category">Category</label>
              <select id="saved-category" value={filters.category} onChange={set('category')}>
                <option value="">All categories</option>
                {data.facets.categories.map((c) => <option key={c.key} value={c.key}>{c.label} ({c.count})</option>)}
              </select>
            </div>
            {(data.unavailable > 0 || filters.availability) && (
              <div className="field">
                <label htmlFor="saved-status">Job status</label>
                <select id="saved-status" value={filters.availability} onChange={set('availability')}>
                  <option value="">All saved jobs</option>
                  <option value="available">Available</option>
                  <option value="unavailable">No longer available</option>
                </select>
              </div>
            )}
            <div className="field">
              <label htmlFor="saved-sort">Sort by</label>
              <select id="saved-sort" value={filters.sort} onChange={set('sort')}>
                {SORTS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}
              </select>
            </div>
          </div>
          <div className="jobs-filter-foot">
            <small className="muted" aria-live="polite">{state.status === 'ready' ? `${data.total} of ${data.totalSaved} saved ${data.totalSaved === 1 ? 'job' : 'jobs'}` : ' '}</small>
            {active && <button type="button" className="btn btn-ghost btn-sm" onClick={clear}><X size={14} aria-hidden="true" /> Clear filters</button>}
          </div>
        </section>
      )}

      {data?.unavailable > 0 && state.status === 'ready' && (
        <p className="notice jobs-warning" role="status">
          {data.unavailable === 1 ? '1 saved job is' : `${data.unavailable} saved jobs are`} no longer in the job feed. {data.unavailable === 1 ? 'It is' : 'They are'} kept, marked as unavailable, until you remove {data.unavailable === 1 ? 'it' : 'them'}.
        </p>
      )}

      {state.status === 'loading' && !data ? (
        <div className="card page-loading" role="status">Loading saved jobs…</div>
      ) : state.status === 'error' && !data ? (
        <div className="card form-error" role="alert">
          {state.error.message} <button type="button" className="btn btn-ghost btn-sm" onClick={() => load(filters)}>Try again</button>
        </div>
      ) : data && data.totalSaved === 0 ? (
        <div className="card empty" role="status">
          <Bookmark size={22} aria-hidden="true" />
          <h3>You have not saved any jobs yet</h3>
          <p className="muted">Use Save Job on a job card or on a job's page to keep it here. Saved jobs stay after you sign out.</p>
          <Link to="/jobs" className="btn btn-primary btn-sm">Browse jobs</Link>
        </div>
      ) : data && data.total === 0 ? (
        <div className="card empty" role="status">
          <Search size={22} aria-hidden="true" />
          <h3>No saved jobs match your search</h3>
          <p className="muted">Try other words, another category, or remove a filter.</p>
          <button type="button" className="btn btn-ghost btn-sm" onClick={clear}>Clear filters</button>
        </div>
      ) : (
        <>
          {state.status === 'error' && <p className="form-error" role="alert">{state.error.message}</p>}
          <div className={`job-grid ${state.status === 'loading' ? 'is-busy' : ''}`}>
            {data.savedJobs.map((s) => (
              <JobCard key={s.id} job={cardJob(s)} saved={{ id: s.id, savedAt: s.savedAt, availability: s.availability, busy: removing === s.id, onRemove: () => remove(s) }} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
