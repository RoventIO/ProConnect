import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ChevronLeft, Trash2, Image as ImageIcon, Mic, PenLine, Pencil, Plus, Users } from 'lucide-react';
import { api } from '../api.js';
import { useApi } from '../hooks/useApi.js';
import { useAuth } from '../context/AuthContext.jsx';
import JoinButton from '../components/JoinButton.jsx';
import { Avatar, BotBadge } from '../components/Ui.jsx';
import { useFeedback } from '../components/Feedback.jsx';
import Composer from '../components/Composer.jsx';
import Field from '../components/Field.jsx';
import { initialsOf, timeAgo } from '../utils/format.js';

/** Edit name and description (administrators also the category). The parent never changes. */
function EditCommunityForm({ c, onSaved, onCancel }) {
  const perms = c.permissions;
  const [values, setValues] = useState({ name: c.name, description: c.description, category: c.category });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);
  const onChange = (e) => setValues((v) => ({ ...v, [e.target.name]: e.target.value }));
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setErrors({});
    setFormError('');
    try {
      const body = { name: values.name, description: values.description };
      if (perms.canEditCategory) body.category = values.category;
      await api(`/communities/${c.id}`, { method: 'PUT', body });
      onSaved();
    } catch (err) {
      if (err.fields) setErrors(err.fields);
      else setFormError(err.message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <form className="card edit-card" onSubmit={submit} noValidate aria-label="Edit community">
      <h3>Edit {c.parent ? 'subcommunity' : 'community'}</h3>
      <Field id="name" label="Name *" value={values.name} onChange={onChange} error={errors.name} />
      {perms.canEditCategory ? (
        <Field id="category" label="Category *" value={values.category} onChange={onChange} error={errors.category} hint="Changing the category also updates its subcommunities." />
      ) : (
        <p className="muted">Category: {c.category}{c.parent ? ' (set by the main community)' : ' (only administrators can change it)'}</p>
      )}
      <Field id="description" label="Description *" as="textarea" rows={3} value={values.description} onChange={onChange} error={errors.description} />
      {formError && <p className="form-error" role="alert">{formError}</p>}
      <div className="form-actions">
        <button type="submit" className="btn btn-primary" disabled={busy}>{busy ? 'Saving…' : 'Save changes'}</button>
        <button type="button" className="btn btn-ghost" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  );
}

/** Add a subcommunity under this main community (administrators, or the leader of this community). */
function AddSubcommunityForm({ parent, onCreated, onCancel }) {
  const [values, setValues] = useState({ name: '', description: '' });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);
  const onChange = (e) => setValues((v) => ({ ...v, [e.target.name]: e.target.value }));
  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setErrors({});
    setFormError('');
    try {
      await api('/communities', { method: 'POST', body: { ...values, parentId: parent.id } });
      onCreated(values.name.trim());
    } catch (err) {
      if (err.fields) setErrors(err.fields);
      else setFormError(err.message);
    } finally {
      setBusy(false);
    }
  };
  return (
    <form className="card edit-card" onSubmit={submit} noValidate aria-label="Add subcommunity">
      <h3>Add a subcommunity to {parent.name}</h3>
      <p className="muted">It will sit under {parent.name} and use its category.</p>
      <Field id="sub-name" name="name" label="Name *" placeholder="e.g. Frontend Development" value={values.name} onChange={onChange} error={errors.name} />
      <Field id="sub-description" name="description" label="Description *" as="textarea" rows={3} placeholder="What is this subcommunity about?" value={values.description} onChange={onChange} error={errors.description} />
      {errors.parentId && <p className="field-error" role="alert">{errors.parentId}</p>}
      {formError && <p className="form-error" role="alert">{formError}</p>}
      <div className="form-actions">
        <button type="submit" className="btn btn-primary" disabled={busy}>{busy ? 'Adding…' : 'Add subcommunity'}</button>
        <button type="button" className="btn btn-ghost" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  );
}

/** The member rows. Rendered only while the list is open, so nothing is requested until then. */
function MemberList({ c }) {
  const [limit, setLimit] = useState(50);
  const { data, error, loading } = useApi(`/communities/${c.id}/members?limit=${limit}`);
  if (error) return <p className="form-error" role="alert">{error.message}</p>;
  if (!data) return loading ? <p className="muted" role="status">Loading members…</p> : null;
  return (
    <>
      <ul className="list">
        {data.members.map((m) => (
          <li className="row" key={m.id}>
            <Avatar text={initialsOf(m.name)} src={m.avatarUrl} />
            <div className="row-body">
              <strong>
                <Link to={`/members/${m.id}`} className="post-link">{m.name}</Link>
                {m.isBot && <BotBadge />}
                {m.isLeader && <span className="pill pill-accent member-pill">Community Leader</span>}
              </strong>
              <small>{[m.isBot ? 'Community bot' : m.status && m.status[0].toUpperCase() + m.status.slice(1), m.profession].filter(Boolean).join(' · ')}</small>
            </div>
            <small className="muted">Joined {timeAgo(m.joinedAt)}</small>
          </li>
        ))}
      </ul>
      {data.total > data.members.length && (
        <div className="member-more">
          <p className="muted">Showing {data.members.length} of {data.total}.</p>
          {limit < 200 && <button type="button" className="btn btn-ghost btn-sm" onClick={() => setLimit(200)}>Show more</button>}
        </div>
      )}
    </>
  );
}

/** Who is in this community. Shown to its members, leaders and administrators. */
function MembersCard({ c }) {
  const [open, setOpen] = useState(false);
  return (
    <section className="card members-card" aria-label="Members">
      <div className="card-head">
        <h3>Members <span className="muted">({c.memberCount})</span></h3>
        <button type="button" className="btn btn-ghost btn-sm" aria-expanded={open} onClick={() => setOpen((o) => !o)}>
          <Users size={14} aria-hidden="true" /> {open ? 'Hide members' : 'Show members'}
        </button>
      </div>
      {c.parent && <p className="muted">Members join {c.parent.name}; they can take part here too.</p>}
      {open && <MemberList c={c} />}
    </section>
  );
}

export default function CommunityDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data, error, loading, reload } = useApi(`/communities/${id}`);
  const { confirm, notify } = useFeedback();
  const [actionError, setActionError] = useState('');
  const [composing, setComposing] = useState(false);
  const [panel, setPanel] = useState(null); // 'edit' | 'add' | null

  if (loading) return <div className="card page-loading" role="status">Loading…</div>;
  if (error) {
    return (
      <section className="card placeholder">
        <h2>{error.status === 404 ? 'Community not found' : 'Could not load this community'}</h2>
        <p>{error.message}</p>
        <Link to="/communities" className="btn btn-ghost">Back to Communities</Link>
      </section>
    );
  }

  const { community: c, recentPosts } = data;
  const perms = c.permissions || {};
  const remove = async () => {
    // The dialog says exactly what disappears; the server asks for ?confirm=true before removing anything that has content.
    const parts = [
      c.subcommunities.length && `${c.subcommunities.length} ${c.subcommunities.length === 1 ? 'subcommunity' : 'subcommunities'}`,
      c.postCount && `${c.postCount} ${c.postCount === 1 ? 'discussion' : 'discussions'} with their replies`,
      c.memberCount && `${c.memberCount} ${c.memberCount === 1 ? 'membership' : 'memberships'}`,
    ].filter(Boolean);
    const ok = await confirm({
      title: `Delete ${c.name}?`,
      message: parts.length
        ? `This permanently removes the community together with ${parts.join(', ')}. Member accounts are not deleted. This cannot be undone.`
        : 'This community is empty. It will be removed permanently.',
      confirmLabel: 'Delete community',
      tone: 'danger',
    });
    if (!ok) return;
    try {
      await api(`/communities/${c.id}?confirm=true`, { method: 'DELETE' });
      notify(`${c.name} was deleted.`);
      navigate(c.parent ? `/communities/${c.parent.id}` : '/communities', { replace: true });
    } catch (err) {
      setActionError(err.message);
    }
  };
  const saved = (message) => {
    setPanel(null);
    if (message) notify(message);
    reload();
  };

  return (
    <div className="community-page">
      <Link to={c.parent ? `/communities/${c.parent.id}` : '/communities'} className="back-link">
        <ChevronLeft size={16} aria-hidden="true" /> {c.parent ? c.parent.name : 'All communities'}
      </Link>

      <section className="card community-head">
        <Avatar text={initialsOf(c.name)} size={64} />
        <div className="community-info">
          <div className="community-title">
            <h2 className="serif">{c.name}</h2>
            <span className="pill pill-accent">{c.category}</span>
          </div>
          <p className="muted">{c.description}</p>
          <small className="muted">
            {c.memberCount} {c.memberCount === 1 ? 'member' : 'members'} · {c.postCount} {c.postCount === 1 ? 'post' : 'posts'}
          </small>
        </div>
        <div className="community-actions">
          {c.canJoin ? (
            <>
            <JoinButton community={c} size="md" linkInMessage={false} onChange={reload} />
              {!c.isMember && <p className="muted join-note">Join to add this community to your profile and follow its discussions.</p>}
            </>
          ) : (
            <p className="muted join-note">
              {c.isMember ? 'You are a member through ' : 'Join '}
              <Link to={`/communities/${c.parent.id}`}>{c.parent.name}</Link>
              {c.isMember ? '.' : ' to take part.'}
            </p>
          )}
          {(perms.canEdit || perms.canCreateSubcommunity || perms.canDelete) && (
            <div className="manage-actions">
              {perms.canEdit && (
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => setPanel(panel === 'edit' ? null : 'edit')}>
                  <Pencil size={14} aria-hidden="true" /> Edit
                </button>
              )}
              {perms.canCreateSubcommunity && (
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => setPanel(panel === 'add' ? null : 'add')}>
                  <Plus size={14} aria-hidden="true" /> Add subcommunity
                </button>
              )}
              {perms.canDelete && (
                <button type="button" className="btn btn-ghost btn-sm" onClick={remove}>
                  <Trash2 size={14} aria-hidden="true" /> Delete
                </button>
              )}
            </div>
          )}
        </div>
      </section>
      {actionError && <p className="form-error" role="alert">{actionError}</p>}
      {panel === 'edit' && <EditCommunityForm c={c} onSaved={() => saved('Community updated.')} onCancel={() => setPanel(null)} />}
      {panel === 'add' && <AddSubcommunityForm parent={c} onCreated={(name) => saved(`${name} was added.`)} onCancel={() => setPanel(null)} />}
      {perms.canViewMembers && <MembersCard c={c} />}

      {c.subcommunities.length > 0 && (
        <section className="card">
          <div className="card-head"><h3>Subcommunities</h3></div>
          <ul className="sub-list">
            {c.subcommunities.map((s) => (
              <li key={s.id}>
                <Link to={`/communities/${s.id}`} className="sub-link">{s.name}</Link>
                {s.description && <p className="sub-desc">{s.description}</p>}
              </li>
            ))}
          </ul>
        </section>
      )}

      <section className="card">
        <div className="card-head">
          <h3>Discussions</h3>
          {c.isMember && !composing && (
            <button type="button" className="btn btn-primary btn-sm" onClick={() => setComposing(true)}>
              <PenLine size={14} aria-hidden="true" /> New discussion
            </button>
          )}
        </div>
        {!c.isMember && (
          <p className="muted join-note-block">
            {c.canJoin ? 'Join this community to start discussions and reply.' : <>Join <Link to={`/communities/${c.parent.id}`}>{c.parent.name}</Link> to start discussions and reply here.</>}
          </p>
        )}
        {composing && (
          <Composer
            withTitle
            autoFocus
            placeholder="Share your experience or ask a question…"
            submitLabel="Post discussion"
            onCancel={() => setComposing(false)}
            onSubmit={async (body) => {
              const d = await api(`/communities/${c.id}/posts`, { method: 'POST', body });
              notify('Your discussion was posted.');
              navigate(`/posts/${d.post.id}`);
            }}
          />
        )}
        {recentPosts.length === 0 ? (
          <p className="muted">No discussions yet.{c.isMember ? ' Be the first to start one.' : ''}</p>
        ) : (
          <ul className="list">
            {recentPosts.map((p) => (
              <li className="row" key={p.id}>
                <Avatar text={initialsOf(p.author.name)} src={p.author.avatarUrl} />
                <div className="row-body">
                  <strong><Link to={`/posts/${p.id}`} className="post-link">{p.title}</Link></strong>
                  {p.excerpt && <small className="excerpt">{p.excerpt}</small>}
                  <small>
                    <Link to={`/members/${p.author.id}`}>{p.author.name}</Link>
                    {p.author.isBot && <BotBadge />}
                    {p.author.profession ? ` · ${p.author.profession}` : ''}
                    {p.community.id !== c.id ? ` · ${p.community.name}` : ''}
                  </small>
                  <small className="muted">
                    {p.commentCount} replies · {timeAgo(p.createdAt)}
                    {p.imageCount > 0 && <span className="meta-icon"><ImageIcon size={12} aria-label="Has images" /> {p.imageCount}</span>}
                    {p.hasVoice && <span className="meta-icon"><Mic size={12} aria-label="Has a voice message" /></span>}
                  </small>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
