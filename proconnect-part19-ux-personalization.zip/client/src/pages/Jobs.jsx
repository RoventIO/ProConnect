import { useCallback, useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { Briefcase, RefreshCw, Search, SlidersHorizontal, X } from 'lucide-react';
import { api } from '../api.js';
import { useAuth } from '../context/AuthContext.jsx';
import { usePreferences } from '../context/PreferencesContext.jsx';
import { useUrlState } from '../hooks/useUrlState.js';
import { timeAgo } from '../utils/format.js';
import { MODE_LABEL, TYPE_LABEL, LEVEL_LABEL, JOB_CATEGORY_LABEL } from '../utils/jobLabels.js';
import JobCard from '../components/JobCard.jsx';

const PAGE_SIZE = 12;
const EMPTY = { q: '', category: '', location: '', mode: '', type: '', level: '', source: '' };
// Filters live in the address (?q=&category=&location=&mode=&type=&level=&source=). A value that is not a known option is ignored.
const KEY_RE = /^[a-z0-9_-]{1,40}$/;
const VALID = { category: (v) => KEY_RE.test(v), source: (v) => KEY_RE.test(v), mode: (v) => v in MODE_LABEL, type: (v) => v in TYPE_LABEL, level: (v) => v in LEVEL_LABEL };

function FilterChips({ label, options, labels, value, onChange }) {
  const shown = Object.keys(labels).filter((k) => (options?.[k] || 0) > 0 || value === k);
  if (shown.length === 0) return null; // nothing in the stored data to filter by, so nothing is offered
  return (
    <div className="filters" role="group" aria-label={label}>
      {shown.map((k) => (
        <button key={k} type="button" className={`chip-btn ${value === k ? 'active' : ''}`} aria-pressed={value === k} onClick={() => onChange(value === k ? '' : k)}>
          {labels[k]} <small>{options?.[k] || 0}</small>
        </button>
      ))}
    </div>
  );
}

export default function Jobs() {
  const { user } = useAuth();
  const { values: filters, set: setUrl, clear: clearUrl } = useUrlState(EMPTY, VALID);
  const { prefs } = usePreferences();
  const [text, setText] = useState(filters.q);
  const [place, setPlace] = useState(filters.location);
  const [state, setState] = useState({ status: 'loading', jobs: [], meta: null, error: null, page: 1 });
  const [moreBusy, setMoreBusy] = useState(false);
  const [note, setNote] = useState('');
  const timer = useRef(null);

  // The two text boxes wait 300 ms after typing before they query (and before they reach the address; typing adds no history entries).
  useEffect(() => {
    const t = setTimeout(() => {
      if (filters.q !== text.trim() || filters.location !== place.trim()) setUrl({ q: text.trim(), location: place.trim() }, { replace: true });
    }, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text, place]);

  // Back, Forward or a pasted link changes the address: bring the two boxes in line with it.
  useEffect(() => { setText((t) => (t.trim() === filters.q ? t : filters.q)); }, [filters.q]);
  useEffect(() => { setPlace((t) => (t.trim() === filters.location ? t : filters.location)); }, [filters.location]);

  const query = useCallback((f, page) => {
    const p = new URLSearchParams({ page: String(page), pageSize: String(PAGE_SIZE) });
    for (const [k, v] of Object.entries(f)) if (v) p.set(k, v);
    return `/jobs?${p}`;
  }, []);

  const load = useCallback(async (f, { silent = false } = {}) => {
    if (!silent) setState((s) => ({ ...s, status: 'loading', error: null }));
    try {
      const data = await api(query(f, 1));
      setState({ status: 'ready', jobs: data.jobs, meta: data, error: null, page: 1 });
      return data;
    } catch (error) {
      setState((s) => ({ ...s, status: 'error', error }));
      return null;
    }
  }, [query]);

  useEffect(() => { load(filters); }, [filters, load]);

  // While an administrator's refresh runs in the background, check again every few seconds.
  useEffect(() => {
    if (!state.meta?.refreshing) return undefined;
    timer.current = setTimeout(() => load(filters, { silent: true }), 3000);
    return () => clearTimeout(timer.current);
  }, [state.meta, filters, load]);

  async function showMore() {
    setMoreBusy(true);
    try {
      const data = await api(query(filters, state.page + 1));
      setState((s) => ({ ...s, jobs: [...s.jobs, ...data.jobs.filter((j) => !s.jobs.some((x) => x.id === j.id))], meta: data, page: s.page + 1 }));
    } catch (error) {
      setNote(error.message);
    } finally {
      setMoreBusy(false);
    }
  }

  async function refresh() {
    setNote('');
    try {
      const r = await api('/jobs/refresh', { method: 'POST' });
      setNote(r.started ? 'Fetching new listings in the background…' : r.reason === 'fresh' ? `The listings were updated ${r.minutesSinceLastFetch} min ago, so no new request was made.` : 'A fetch is already running.');
      load(filters, { silent: true });
    } catch (error) {
      setNote(error.message);
    }
  }

  const set = (k) => (v) => setUrl({ [k]: v });
  const meta = state.meta;
  const active = Object.values(filters).some(Boolean) || text || place;
  const clear = () => { setText(''); setPlace(''); clearUrl(); };

  // "Use my preferences" applies the saved category and work mode when the member asks for it. It never runs by itself, and it
  // leaves every other filter (keywords, location, type, level, source) exactly as it is.
  const hasPrefs = !!(prefs.jobCategory || prefs.jobWorkMode);
  const prefLabels = [prefs.jobCategory && (JOB_CATEGORY_LABEL[prefs.jobCategory] || prefs.jobCategory), prefs.jobWorkMode && MODE_LABEL[prefs.jobWorkMode]].filter(Boolean);
  const applyPrefs = () => {
    setUrl({ ...(prefs.jobCategory ? { category: prefs.jobCategory } : {}), ...(prefs.jobWorkMode ? { mode: prefs.jobWorkMode } : {}) });
    setNote(`Applied your preferences: ${prefLabels.join(', ')}.`);
  };
  const sourceProblems = (meta?.sources || []).filter((s) => s.status === 'error' || s.status === 'partial');
  const categories = (meta?.facets.categories || []).filter((c) => c.count > 0 || filters.category === c.key);

  return (
    <div className="jobs">
      <header className="jobs-head">
        <div>
          <h2 className="serif">Jobs</h2>
          <p className="muted">Real listings from Arbeitnow and The Muse across all professions. Apply opens the original listing in a new tab. ProConnect does not submit applications for you: after you apply, add it to My Applications to track it.</p>
        </div>
        <div className="jobs-head-side">
          {meta?.lastUpdated && <small className="muted">Updated {timeAgo(meta.lastUpdated).toLowerCase()}</small>}
          {user?.isAdmin && (
            <button type="button" className="btn btn-ghost btn-sm" onClick={refresh} disabled={meta?.refreshing} aria-label="Refresh job listings">
              <RefreshCw size={14} aria-hidden="true" /> {meta?.refreshing ? 'Fetching…' : 'Refresh'}
            </button>
          )}
        </div>
      </header>
      {note && <p className="notice" role="status">{note}</p>}

      <section className="card jobs-filters" aria-label="Search and filters">
        <div className="jobs-filter-row">
          <label className="search search-wide">
            <Search size={16} aria-hidden="true" />
            <input type="search" placeholder="Search by title, company or keyword" aria-label="Search jobs by title, company or keyword" value={text} onChange={(e) => setText(e.target.value)} />
          </label>
          <div className="field">
            <label htmlFor="job-category">Category</label>
            <select id="job-category" value={filters.category} onChange={(e) => set('category')(e.target.value)}>
              <option value="">All categories</option>
              {categories.map((c) => <option key={c.key} value={c.key}>{c.label} ({c.count})</option>)}
            </select>
          </div>
          <div className="field">
            <label htmlFor="job-location">Location</label>
            <input id="job-location" type="text" placeholder="City or country" value={place} onChange={(e) => setPlace(e.target.value)} />
          </div>
          {(meta?.sources || []).filter((s) => s.stored > 0).length > 1 && (
            <div className="field">
              <label htmlFor="job-source">Source</label>
              <select id="job-source" value={filters.source} onChange={(e) => set('source')(e.target.value)}>
                <option value="">All sources</option>
                {meta.sources.filter((s) => s.stored > 0).map((s) => <option key={s.key} value={s.key}>{s.name}</option>)}
              </select>
            </div>
          )}
        </div>
        <div className="jobs-prefs" role="group" aria-label="Job preferences">
          <button type="button" className="btn btn-ghost btn-sm" onClick={applyPrefs} disabled={!hasPrefs} aria-describedby="jobs-prefs-hint">
            <SlidersHorizontal size={14} aria-hidden="true" /> Use my preferences
          </button>
          <small id="jobs-prefs-hint" className="muted">
            {hasPrefs ? `Applies ${prefLabels.join(' · ')}` : <>No saved job preferences yet. <Link to="/settings">Choose them in Preferences</Link>.</>}
          </small>
        </div>
        <div className="jobs-chip-rows">
          <FilterChips label="Work mode" options={meta?.facets.modes} labels={MODE_LABEL} value={filters.mode} onChange={set('mode')} />
          <FilterChips label="Employment type" options={meta?.facets.types} labels={TYPE_LABEL} value={filters.type} onChange={set('type')} />
          <FilterChips label="Experience level" options={meta?.facets.levels} labels={LEVEL_LABEL} value={filters.level} onChange={set('level')} />
        </div>
        <div className="jobs-filter-foot">
          <small className="muted" aria-live="polite">{state.status === 'ready' && meta ? `${meta.total} ${meta.total === 1 ? 'job' : 'jobs'} · newest first` : ' '}</small>
          {active && <button type="button" className="btn btn-ghost btn-sm" onClick={clear}><X size={14} aria-hidden="true" /> Clear filters</button>}
        </div>
      </section>

      {sourceProblems.length > 0 && meta?.totalStored > 0 && (
        <p className="notice jobs-warning" role="status">
          {sourceProblems.map((s) => s.name).join(' and ')} could not be fully updated the last time, so some listings may be older. Stored listings stay available.
        </p>
      )}

      {state.status === 'loading' && state.jobs.length === 0 ? (
        <div className="card page-loading" role="status">Loading jobs…</div>
      ) : state.status === 'error' && state.jobs.length === 0 ? (
        <div className="card form-error" role="alert">
          {state.error.message} <button type="button" className="btn btn-ghost btn-sm" onClick={() => load(filters)}>Try again</button>{active && <button type="button" className="btn btn-ghost btn-sm" onClick={clear}>Clear filters</button>}
        </div>
      ) : meta && meta.total === 0 ? (
        <div className="card empty" role="status">
          <Briefcase size={22} aria-hidden="true" />
          {meta.totalStored === 0 ? (
            <>
              <h3>No job listings have been loaded yet</h3>
              <p className="muted">
                {meta.fetchingEnabled
                  ? 'Listings are fetched from Arbeitnow and The Muse by the server. If a source cannot be reached, nothing is shown instead of made-up jobs.'
                  : 'Automatic fetching is switched off on this server (JOBS_SYNC=off).'}
              </p>
              <ul className="jobs-source-status">
                {meta.sources.map((s) => <li key={s.key}><strong>{s.name}:</strong> {s.status ? s.message || s.status : 'not fetched yet'}</li>)}
              </ul>
            </>
          ) : (
            <>
              <h3>No jobs match your search</h3>
              <p className="muted">Try other keywords, another category or location, or remove a filter.</p>
              <button type="button" className="btn btn-ghost btn-sm" onClick={clear}>Clear filters</button>
            </>
          )}
        </div>
      ) : (
        <>
          <div className={`job-grid ${state.status === 'loading' ? 'is-busy' : ''}`}>
            {state.jobs.map((j) => <JobCard key={j.id} job={j} />)}
          </div>
          {meta && state.page < meta.pageCount && (
            <div className="jobs-more">
              <button type="button" className="btn btn-ghost" onClick={showMore} disabled={moreBusy}>{moreBusy ? 'Loading…' : 'Show more jobs'}</button>
            </div>
          )}
        </>
      )}
    </div>
  );
}
