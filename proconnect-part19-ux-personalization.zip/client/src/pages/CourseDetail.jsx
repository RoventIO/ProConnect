import { useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { CalendarCheck, ChevronLeft, ExternalLink } from 'lucide-react';
import { api } from '../api.js';
import { useApi } from '../hooks/useApi.js';
import { useFeedback } from '../components/Feedback.jsx';
import { PriceBadge } from '../components/Ui.jsx';
import { longDate, timeOfDay, isWebLink, DELIVERY_LABEL } from '../utils/format.js';

export default function CourseDetail() {
  const { id } = useParams();
  const { data, error, loading, reload } = useApi(`/courses/${id}`);
  const { notify } = useFeedback();
  const [busy, setBusy] = useState(false);
  const [actionError, setActionError] = useState('');

  if (loading) return <div className="card page-loading" role="status">Loading…</div>;
  if (error) {
    return (
      <section className="card placeholder">
        <h2>{error.status === 404 ? 'Course or webinar not found' : 'Could not load this listing'}</h2>
        <p>{error.message}</p>
        <Link to="/courses" className="btn btn-ghost">Back to Courses & Webinars</Link>
      </section>
    );
  }

  const c = data.course;
  const rows = [
    c.startsAt && ['When', `${longDate(c.startsAt)} · ${timeOfDay(c.startsAt)}`],
    c.duration && ['Format and length', c.duration],
    c.deliveryMode && ['Delivery', `${DELIVERY_LABEL[c.deliveryMode]}${c.location && c.deliveryMode !== 'online' ? ` · ${c.location}` : ''}`],
    c.instructorName && [c.type === 'webinar' ? 'Host' : 'Instructor', `${c.instructorName}${c.instructorRole ? `, ${c.instructorRole}` : ''}`],
    c.organizer && [c.instructorName ? 'Organizer' : c.type === 'webinar' ? 'Host' : 'Instructor', c.organizer],
    c.category && ['Subject', c.category],
    ['Price', c.isFree ? 'Free' : c.priceText || 'Paid'],
    c.registrationDeadline && ['Register by', longDate(c.registrationDeadline)],
  ].filter(Boolean);

  async function changeRegistration(register) {
    setBusy(true);
    setActionError('');
    try {
      await api(`/courses/${c.id}/register`, { method: register ? 'POST' : 'DELETE' });
      notify(register ? 'Demo registration saved. Nothing was sent to anyone; this is a demonstration.' : 'Demo registration cancelled.');
      reload();
    } catch (e) {
      setActionError(e.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="community-page">
      <Link to="/courses" className="back-link"><ChevronLeft size={16} aria-hidden="true" /> Courses & Webinars</Link>

      <article className="card post-card">
        {c.image && <img className="course-img course-img-wide" src={c.image} alt="" />}
        <div className="course-top">
          <span className="pill pill-accent">{c.type === 'webinar' ? 'Webinar' : 'Course'}</span>
          <span className="course-pills">
            {c.isSample && <span className="pill pill-sample" title="Demonstration listing">Sample</span>}
            {c.isPast && <span className="pill pill-sample">Ended</span>}
            <PriceBadge price={c.priceLabel} />
          </span>
        </div>
        <h2 className="serif post-title">{c.title}</h2>
        {c.description && <p className="post-text">{c.description}</p>}

        <dl className="facts">
          {rows.map(([k, v]) => (
            <div key={k}><dt>{k}</dt><dd>{v}</dd></div>
          ))}
        </dl>

        {c.isSample && (
          <p className="notice" role="note">
            This is a demonstration listing created for the ProConnect prototype. It is not a real course or webinar, and the instructor and organizer are fictional.
          </p>
        )}

        <div className="course-cta">
          {c.registrationKind === 'demo' ? (
            <>
              {c.registered ? (
                <>
                  <span className="pill pill-free"><CalendarCheck size={14} aria-hidden="true" /> You are registered (demo)</span>
                  <button type="button" className="btn btn-ghost" disabled={busy} onClick={() => changeRegistration(false)}>Cancel demo registration</button>
                </>
              ) : (
                <button type="button" className="btn btn-primary" disabled={busy || !c.registrationOpen} onClick={() => changeRegistration(true)}>
                  {c.registrationOpen ? 'Register (demo)' : 'Registration closed'}
                </button>
              )}
              <small className="muted">Demo registration only: it is saved in this prototype and nothing is sent to an organizer.</small>
            </>
          ) : isWebLink(c.externalUrl) ? (
            <a className="btn btn-primary" href={c.externalUrl} target="_blank" rel="noopener noreferrer">
              {c.isFree ? 'Register or learn more' : 'View details and pricing'} <ExternalLink size={14} aria-hidden="true" />
            </a>
          ) : (
            <p className="muted">The organizer has not provided a registration link.</p>
          )}
          {!c.isFree && c.registrationKind !== 'demo' && <small className="muted">Payment happens on the organizer's website. ProConnect does not process payments.</small>}
          {!c.isFree && c.registrationKind === 'demo' && <small className="muted">The price is shown for illustration. ProConnect does not process payments.</small>}
        </div>
        {actionError && <p className="form-error" role="alert">{actionError}</p>}
      </article>
    </div>
  );
}
