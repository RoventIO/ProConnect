import { useCallback, useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { ExternalLink, Newspaper, Settings2 } from 'lucide-react';
import { api } from '../api.js';
import { useAuth } from '../context/AuthContext.jsx';
import { usePreferences } from '../context/PreferencesContext.jsx';
import { useUrlState } from '../hooks/useUrlState.js';
import { isWebLink, newsDate, timeAgo } from '../utils/format.js';
import { DEFAULT_NEWS_IMAGE } from '../utils/newsImage.js';

const TABS = [
  ['all', 'All News'],
  ['for-you', 'For You'],
  ['ai', 'AI & Machine Learning'],
  ['programming', 'Programming'],
  ['cybersecurity', 'Cybersecurity'],
  ['startups', 'Startups'],
];
const PAGE = 12;
const TAB_KEYS = TABS.map(([key]) => key);
const TAB_DEFAULTS = { tab: '' }; // '' = the address names no tab

/**
 * The article's own picture when it has a usable one, otherwise the local ProConnect default. If the original fails to
 * load, the default replaces it once; the default is a local file and never triggers another swap, so there is no loop
 * and no broken-image icon. Only if even the local file cannot load does the plain icon appear.
 */
function Thumb({ article }) {
  const [originalFailed, setOriginalFailed] = useState(false);
  const [defaultFailed, setDefaultFailed] = useState(false);
  const original = article.imageUrl && isWebLink(article.imageUrl) && !originalFailed ? article.imageUrl : null;
  const src = original || DEFAULT_NEWS_IMAGE;
  return (
    <div className={`news-thumb ${original ? '' : 'news-thumb-empty'}`} aria-hidden="true">
      {src === DEFAULT_NEWS_IMAGE && defaultFailed ? (
        <Newspaper size={26} />
      ) : (
        <img
          key={src}
          src={src}
          alt=""
          loading="lazy"
          referrerPolicy="no-referrer"
          data-fallback={original ? undefined : 'default'}
          onError={() => (original ? setOriginalFailed(true) : setDefaultFailed(true))}
        />
      )}
    </div>
  );
}

function ArticleCard({ article }) {
  const link = isWebLink(article.url);
  const via = article.publisher !== article.source.name ? article.source.name : null;
  const external = { target: '_blank', rel: 'noopener noreferrer' };
  return (
    <article className="card news-card">
      <Thumb article={article} />
      <div className="news-body">
        {article.categories.length > 0 && (
          <div className="news-pills">
            {article.categories.map((c) => (
              <span key={c.key} className="pill pill-accent" title={c.basis ? `Category assigned from: ${c.basis}` : undefined}>{c.label}</span>
            ))}
          </div>
        )}
        <h3>{link ? <a href={article.url} {...external}>{article.title}</a> : article.title}</h3>
        {article.summary && <p className="news-summary">{article.summary}</p>}
        <p className="news-meta">
          <strong className="news-source">{article.publisher}</strong>
          {via && <span className="news-via"> via {via}</span>}
          <span aria-hidden="true"> · </span>
          <time dateTime={article.displayAt}>{newsDate(article)}</time>
        </p>
        {link && (
          <a className="btn btn-ghost btn-sm news-read" href={article.url} {...external} aria-label={`Read article: ${article.title} (opens the original publisher in a new tab)`}>
            Read article <ExternalLink size={13} aria-hidden="true" />
          </a>
        )}
      </div>
    </article>
  );
}

/** Topic choices for "For You": the member's own picks plus what their joined communities suggest. */
function TopicPanel({ onChanged }) {
  const [info, setInfo] = useState(null);
  const [error, setError] = useState('');
  useEffect(() => {
    let alive = true;
    api('/news/interests').then((d) => alive && setInfo(d)).catch((e) => alive && setError(e.message));
    return () => { alive = false; };
  }, []);
  if (error) return <div className="notice" role="alert">{error}</div>;
  if (!info) return null;
  const toggle = async (key) => {
    const next = info.interests.includes(key) ? info.interests.filter((k) => k !== key) : [...info.interests, key];
    setError('');
    try {
      const d = await api('/news/interests', { method: 'PUT', body: { interests: next } });
      setInfo(d);
      onChanged();
    } catch (e) {
      setError(e.message);
    }
  };
  return (
    <section className="card news-topics" aria-labelledby="news-topics-title">
      <h3 id="news-topics-title">Your topics</h3>
      <div className="filters" role="group" aria-label="Topics you follow">
        {info.available.map((c) => (
          <button key={c.key} type="button" className={`chip-btn ${info.interests.includes(c.key) ? 'active' : ''}`} aria-pressed={info.interests.includes(c.key)} onClick={() => toggle(c.key)}>{c.label}</button>
        ))}
      </div>
      {info.fromCommunities.length > 0 ? (
        <p className="muted result-note">Also included because of your communities: {info.fromCommunities.map((f) => `${f.label} (${f.communities.join(', ')})`).join('; ')}.</p>
      ) : (
        <p className="muted result-note">Pick topics above, or <Link to="/communities">join communities</Link> to get matching news.</p>
      )}
    </section>
  );
}

export default function News() {
  const { user } = useAuth();
  // The tab lives in the address (?tab=for-you). Only when the address names no tab does the member's saved default apply (Preferences),
  // and picking a tab always writes it to the address, so an explicit choice is never overridden by the preference.
  const { values: url, set: setUrl } = useUrlState(TAB_DEFAULTS, { tab: (v) => TAB_KEYS.includes(v) });
  const { prefs, loaded: prefsLoaded } = usePreferences();
  const category = url.tab || prefs.newsDefaultTab;
  const ready = !!url.tab || prefsLoaded; // without a tab in the address, wait for the saved default so the list loads once, in the right tab
  const setCategory = (key) => setUrl({ tab: key });
  const [state, setState] = useState({ loading: true, error: null, articles: [], total: 0, hasMore: false, sync: null, retentionHours: 72, category: 'all' });
  const [more, setMore] = useState({ loading: false, error: '' });
  const [tick, setTick] = useState(0);

  useEffect(() => {
    if (!ready) return undefined;
    let alive = true;
    setState((s) => ({ ...s, loading: true, error: null }));
    api(`/news?category=${category}&limit=${PAGE}&offset=0`)
      .then((d) => alive && setState({ loading: false, error: null, articles: d.articles, total: d.total, hasMore: d.hasMore, sync: d.sync, retentionHours: d.retentionHours, category: d.category }))
      .catch((error) => alive && setState((s) => ({ ...s, loading: false, error, articles: [] })));
    return () => { alive = false; };
  }, [category, tick, ready]);

  const loadMore = useCallback(async () => {
    setMore({ loading: true, error: '' });
    try {
      const d = await api(`/news?category=${category}&limit=${PAGE}&offset=${state.articles.length}`);
      setState((s) => ({ ...s, articles: [...s.articles, ...d.articles.filter((a) => !s.articles.some((x) => x.id === a.id))], total: d.total, hasMore: d.hasMore, sync: d.sync }));
      setMore({ loading: false, error: '' });
    } catch (e) {
      setMore({ loading: false, error: e.message });
    }
  }, [category, state.articles.length]);

  const { loading, error, articles, total, hasMore, sync, retentionHours } = state;
  const allFailed = sync && sync.sourceCount > 0 && sync.failedSources.length === sync.sourceCount;

  return (
    <div className="news">
      <div className="toolbar">
        <div className="filters" role="group" aria-label="News category">
          {TABS.map(([key, label]) => (
            <button key={key} type="button" className={`chip-btn ${category === key ? 'active' : ''}`} aria-pressed={category === key} onClick={() => setCategory(key)}>{label}</button>
          ))}
        </div>
        {user?.isAdmin && (
          <Link to="/news/sources" className="btn btn-ghost btn-sm"><Settings2 size={14} aria-hidden="true" /> Manage sources</Link>
        )}
      </div>

      {category === 'for-you' && <TopicPanel onChanged={() => setTick((t) => t + 1)} />}

      {sync && sync.failedSources.length > 0 && !error && (
        <div className="notice news-warning" role="status">
          {allFailed ? 'The news sources could not be refreshed.' : `Some sources could not be refreshed: ${sync.failedSources.join(', ')}.`} Articles stored earlier are still shown.
        </div>
      )}

      {loading ? (
        <div className="card page-loading" role="status">Loading news…</div>
      ) : error ? (
        <div className="card empty" role="alert">
          <h3>News could not be loaded</h3>
          <p className="muted">{error.message}</p>
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => setTick((t) => t + 1)}>Try again</button>
        </div>
      ) : articles.length === 0 ? (
        <div className="card empty" role="status">
          {category === 'for-you' ? (
            <>
              <h3>Nothing to recommend yet</h3>
              <p className="muted">Choose topics above or join communities, and matching news appears here.</p>
            </>
          ) : category !== 'all' ? (
            <>
              <h3>No articles in this category right now</h3>
              <p className="muted">Only recent articles are kept, and a category is only assigned when the article clearly matches it.</p>
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => setCategory('all')}>Show all news</button>
            </>
          ) : (
            <>
              <h3>No news has been stored yet</h3>
              <p className="muted">
                {allFailed
                  ? 'The news sources could not be reached the last time ProConnect tried. It tries again every 2 hours and whenever the server starts.'
                  : 'ProConnect collects technology news when the server starts and every 2 hours. Articles appear here after the first collection finishes.'}
              </p>
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => setTick((t) => t + 1)}>Refresh</button>
            </>
          )}
        </div>
      ) : (
        <>
          <p className="muted result-note" aria-live="polite">
            {total} article{total === 1 ? '' : 's'} from the last {retentionHours} hours{sync?.lastSyncAt ? ` · last refreshed ${timeAgo(sync.lastSyncAt)}` : ''}
          </p>
          <div className="news-grid">
            {articles.map((a) => <ArticleCard key={a.id} article={a} />)}
          </div>
          {hasMore && (
            <div className="news-more">
              <button type="button" className="btn btn-ghost" disabled={more.loading} onClick={loadMore}>{more.loading ? 'Loading…' : 'Load more'}</button>
              {more.error && <span className="field-error" role="alert">{more.error}</span>}
            </div>
          )}
        </>
      )}
    </div>
  );
}
