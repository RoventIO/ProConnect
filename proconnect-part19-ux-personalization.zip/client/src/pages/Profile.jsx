import { useEffect, useRef, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { Pencil, Trash2, Plus, ExternalLink, Camera, FolderGit2 } from 'lucide-react';
import { api } from '../api.js';
import { useApi } from '../hooks/useApi.js';
import { useAuth } from '../context/AuthContext.jsx';
import Field from '../components/Field.jsx';
import StatusPicker, { STATUS_LABELS } from '../components/StatusPicker.jsx';
import { Avatar, BotBadge, UserAvatar } from '../components/Ui.jsx';
import { useFeedback } from '../components/Feedback.jsx';
import { GithubIcon, LinkedinIcon } from '../components/BrandIcons.jsx';
import { demoUrlError, githubProfileError, githubRepoError, isGithubRepo, linkedinError } from '../utils/links.js';
import { initialsOf, timeAgo, activityLabel, monthYear } from '../utils/format.js';

const LABELS = {
  experience: { title: 'Role', subtitle: 'Company or organisation', period: 'e.g. 2021 – Present', description: 'What did you work on?' },
  education: { title: 'Degree or programme', subtitle: 'School or institution', period: 'e.g. 2014 – 2016', description: 'Honours, focus, notes' },
  project: { title: 'Project or link title', subtitle: 'Short label, e.g. GitHub or Behance', period: 'Year (optional)', description: 'A one-line description' },
};

const splitSkills = (s) => [...new Set(s.split(',').map((x) => x.trim()).filter(Boolean))];

function BasicsForm({ user, onSaved, onCancel }) {
  const { saveProfile } = useAuth();
  const [values, setValues] = useState({
    profession: user.profession || '',
    headline: user.headline || '',
    bio: user.bio || '',
    skills: (user.skills || []).join(', '),
    location: user.location || '',
    yearsExperience: user.yearsExperience ?? '',
    linkedinUrl: user.linkedinUrl || '',
    githubUrl: user.githubUrl || '',
  });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);
  const onChange = (e) => setValues((v) => ({ ...v, [e.target.name]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setFormError('');
    // Both links are optional; a filled-in one must be a valid address on the right site (the server checks again).
    const social = {};
    if (values.linkedinUrl.trim() && linkedinError(values.linkedinUrl)) social.linkedinUrl = linkedinError(values.linkedinUrl);
    if (values.githubUrl.trim() && githubProfileError(values.githubUrl)) social.githubUrl = githubProfileError(values.githubUrl);
    if (Object.keys(social).length) {
      setErrors(social);
      return;
    }
    setBusy(true);
    setErrors({});
    try {
      await saveProfile({ ...values, skills: splitSkills(values.skills) });
      onSaved();
    } catch (err) {
      if (err.fields) setErrors(err.fields);
      else setFormError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="card edit-card" onSubmit={submit} noValidate>
      <h3>Edit profile</h3>
      <Field id="profession" label="Profession *" value={values.profession} onChange={onChange} error={errors.profession} />
      <Field id="headline" label="Headline" value={values.headline} onChange={onChange} error={errors.headline} />
      <Field id="bio" label="Biography *" as="textarea" rows={4} value={values.bio} onChange={onChange} error={errors.bio} />
      <Field id="skills" label="Skills * (separate with commas)" value={values.skills} onChange={onChange} error={errors.skills} />
      <div className="field-row">
        <Field id="location" label="Location" value={values.location} onChange={onChange} error={errors.location} />
        <Field id="yearsExperience" label="Years of experience" type="number" min="0" max="60" value={values.yearsExperience} onChange={onChange} error={errors.yearsExperience} />
      </div>
      <div className="field-row">
        <Field id="linkedinUrl" label="LinkedIn Profile URL" type="url" inputMode="url" autoComplete="off" placeholder="https://www.linkedin.com/in/your-profile/" value={values.linkedinUrl} onChange={onChange} error={errors.linkedinUrl} hint="Optional. Leave empty to remove the link." />
        <Field id="githubUrl" label="GitHub Profile URL" type="url" inputMode="url" autoComplete="off" placeholder="https://github.com/your-username" value={values.githubUrl} onChange={onChange} error={errors.githubUrl} hint="Optional. Your account page, not a repository." />
      </div>
      {formError && <p className="form-error" role="alert">{formError}</p>}
      <div className="form-actions">
        <button type="submit" className="btn btn-primary" disabled={busy}>{busy ? 'Saving…' : 'Save changes'}</button>
        <button type="button" className="btn btn-ghost" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  );
}

/** Own profile only: shows the real status from the server and lets the member switch between Student and Beginner. */
function StatusCard({ user, onChanged }) {
  const { updateUser } = useAuth();
  const { notify } = useFeedback();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const isPro = user.status === 'professional';

  const choose = async (status) => {
    if (status === user.status) return;
    setBusy(true);
    setError('');
    try {
      const d = await api('/profile/status', { method: 'PUT', body: { status } });
      updateUser(d.user);
      notify(`Status changed to ${STATUS_LABELS[d.user.status]}.`);
      onChanged();
    } catch (err) {
      setError(err.fields?.status || err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <section className="card" aria-label="Professional status">
      <div className="card-head"><h3>Status</h3><span className="pill pill-accent">{STATUS_LABELS[user.status] || user.status}</span></div>
      {isPro ? (
        <p className="muted">Your Professional status was approved by an Admin. Only an Admin can change it.</p>
      ) : (
        <>
          <StatusPicker value={user.status} onChange={choose} disabled={busy} id="profile-status" />
          {error && <p className="field-error" role="alert">{error}</p>}
          <p className="muted" style={{ marginTop: 10 }}>Student and Beginner need no approval. Professional status is reviewed and decided by an Admin.</p>
          <button type="button" className="btn btn-ghost btn-sm" style={{ marginTop: 8 }} disabled title="Professional applications are not open yet">Apply for Professional status</button>
          <p className="field-hint">Applications open in a later update. Your status is never upgraded automatically.</p>
        </>
      )}
    </section>
  );
}

function ItemForm({ kind, item, onSaved, onCancel }) {
  const labels = LABELS[kind];
  const [values, setValues] = useState({
    title: item?.title || '',
    subtitle: item?.subtitle || '',
    period: item?.period || '',
    description: item?.description || '',
    url: item?.url || '',
  });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);
  const onChange = (e) => setValues((v) => ({ ...v, [e.target.name]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setFormError('');
    setErrors({});
    try {
      if (item) await api(`/profile/items/${item.id}`, { method: 'PUT', body: values });
      else await api('/profile/items', { method: 'POST', body: { kind, ...values } });
      onSaved();
    } catch (err) {
      if (err.fields) setErrors(err.fields);
      else setFormError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="item-form" onSubmit={submit} noValidate>
      <Field id={`title-${kind}`} name="title" label={`${labels.title} *`} value={values.title} onChange={onChange} error={errors.title} />
      <div className="field-row">
        <Field id={`subtitle-${kind}`} name="subtitle" label={labels.subtitle} value={values.subtitle} onChange={onChange} error={errors.subtitle} />
        <Field id={`period-${kind}`} name="period" label="Period" placeholder={labels.period} value={values.period} onChange={onChange} error={errors.period} />
      </div>
      <Field id={`description-${kind}`} name="description" label="Description" placeholder={labels.description} value={values.description} onChange={onChange} error={errors.description} />
      {kind === 'project' && (
        <Field id={`url-${kind}`} name="url" label="Link" placeholder="https://" value={values.url} onChange={onChange} error={errors.url} />
      )}
      {formError && <p className="form-error" role="alert">{formError}</p>}
      <div className="form-actions">
        <button type="submit" className="btn btn-primary btn-sm" disabled={busy}>{busy ? 'Saving…' : item ? 'Save' : 'Add'}</button>
        <button type="button" className="btn btn-ghost btn-sm" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  );
}

function ItemSection({ title, kind, items, editable, onChanged, emptyText, autoAdd = false }) {
  const { confirm, notify } = useFeedback();
  const [adding, setAdding] = useState(autoAdd); // opened by a link such as /profile?add=education (Home, Profile strength)
  const sectionRef = useRef(null);
  useEffect(() => { if (autoAdd) sectionRef.current?.scrollIntoView?.({ block: 'center' }); }, [autoAdd]);
  const [editingId, setEditingId] = useState(null);
  const [actionError, setActionError] = useState('');

  const saved = () => {
    setAdding(false);
    setEditingId(null);
    onChanged();
  };
  const remove = async (item) => {
    const ok = await confirm({
      title: `Delete "${item.title}"?`,
      message: 'This entry will be removed from your profile.',
      confirmLabel: 'Delete',
      tone: 'danger',
    });
    if (!ok) return;
    setActionError('');
    try {
      await api(`/profile/items/${item.id}`, { method: 'DELETE' });
      notify('Entry deleted.');
      onChanged();
    } catch (err) {
      setActionError(err.message);
    }
  };

  return (
    <section className="card" ref={sectionRef}>
      <div className="card-head">
        <h3>{title}</h3>
        {editable && !adding && (
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setAdding(true); setEditingId(null); }}>
            <Plus size={14} aria-hidden="true" /> Add
          </button>
        )}
      </div>
      {actionError && <p className="form-error" role="alert">{actionError}</p>}
      {adding && <ItemForm kind={kind} onSaved={saved} onCancel={() => setAdding(false)} />}
      {items.length === 0 && !adding && <p className="muted">{emptyText}</p>}
      <ul className="list">
        {items.map((it) =>
          editingId === it.id ? (
            <li key={it.id}><ItemForm kind={kind} item={it} onSaved={saved} onCancel={() => setEditingId(null)} /></li>
          ) : (
            <li className="row" key={it.id}>
              {kind !== 'project' && <Avatar text={initialsOf(it.subtitle || it.title)} />}
              <div className="row-body">
                <strong>{it.title}</strong>
                {(it.subtitle || it.period) && (
                  <small>{[it.subtitle, it.period].filter(Boolean).join(' · ')}</small>
                )}
                {it.description && <small className="muted">{it.description}</small>}
              </div>
              {it.url && (
                <a className="btn btn-ghost btn-sm" href={it.url} target="_blank" rel="noopener noreferrer">
                  Open <ExternalLink size={13} aria-hidden="true" />
                </a>
              )}
              {editable && (
                <span className="item-actions">
                  <button type="button" className="icon-btn" aria-label={`Edit ${it.title}`} onClick={() => { setEditingId(it.id); setAdding(false); }}><Pencil size={14} /></button>
                  <button type="button" className="icon-btn" aria-label={`Delete ${it.title}`} onClick={() => remove(it)}><Trash2 size={14} /></button>
                </span>
              )}
            </li>
          )
        )}
      </ul>
    </section>
  );
}

/**
 * LinkedIn and GitHub: the brand logos and nothing else. No names, usernames, domains or addresses are shown; the
 * accessible name sits in aria-label. A link that was not saved is not shown, and with neither saved the whole area is
 * hidden (members add links with Edit Profile).
 */
function SocialLinks({ user }) {
  const links = [
    user.linkedinUrl && { key: 'linkedin', url: user.linkedinUrl, label: 'LinkedIn profile', Icon: LinkedinIcon },
    user.githubUrl && { key: 'github', url: user.githubUrl, label: 'GitHub profile', Icon: GithubIcon },
  ].filter(Boolean);
  if (links.length === 0) return null;
  return (
    <ul className="social-links" aria-label="Professional links">
      {links.map(({ key, url, label, Icon }) => (
        <li key={key}>
          <a className={`social-link social-${key}`} href={url} target="_blank" rel="noopener noreferrer" aria-label={label}>
            <Icon size={26} />
          </a>
        </li>
      ))}
    </ul>
  );
}

const MAX_THUMB_BYTES = 2 * 1024 * 1024;
const THUMB_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];

function ProjectForm({ project, onSaved, onCancel }) {
  const [values, setValues] = useState({
    title: project?.title || '',
    description: project?.description || '',
    url: project?.url || '',
    technologies: (project?.technologies || []).join(', '),
    demoUrl: project?.demoUrl || '',
  });
  const [file, setFile] = useState(null);
  const [removeImage, setRemoveImage] = useState(false);
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);
  const onChange = (e) => setValues((v) => ({ ...v, [e.target.name]: e.target.value }));
  // An older link saved before the GitHub rule may stay exactly as it is.
  const unchangedLegacy = project && values.url.trim() === project.url;

  const pick = (e) => {
    const f = e.target.files?.[0];
    e.target.value = '';
    if (!f) return;
    if (!THUMB_TYPES.includes(f.type)) return setErrors((x) => ({ ...x, image: 'Choose a JPG, PNG, GIF or WebP image.' }));
    if (f.size > MAX_THUMB_BYTES) return setErrors((x) => ({ ...x, image: 'That image is too large. The maximum size is 2 MB.' }));
    setErrors((x) => ({ ...x, image: undefined }));
    setFile(f);
    setRemoveImage(false);
  };

  const submit = async (e) => {
    e.preventDefault();
    setFormError('');
    const found = {};
    if (!values.title.trim()) found.title = 'Enter a project title.';
    if (!values.url.trim()) found.url = 'Enter the GitHub repository address.';
    else if (!unchangedLegacy && githubRepoError(values.url)) found.url = githubRepoError(values.url);
    if (values.demoUrl.trim() && demoUrlError(values.demoUrl)) found.demoUrl = demoUrlError(values.demoUrl);
    if (Object.keys(found).length) {
      setErrors(found);
      return;
    }
    setBusy(true);
    setErrors({});
    try {
      const body = { title: values.title, description: values.description, url: values.url, technologies: splitSkills(values.technologies), demoUrl: values.demoUrl };
      const saved = project ? await api(`/profile/items/${project.id}`, { method: 'PUT', body }) : await api('/profile/items', { method: 'POST', body: { kind: 'project', ...body } });
      const id = saved.item.id;
      try {
        if (file) {
          const form = new FormData();
          form.append('image', file);
          await api(`/profile/items/${id}/image`, { method: 'POST', body: form });
        } else if (removeImage && project?.imageUrl) {
          await api(`/profile/items/${id}/image`, { method: 'DELETE' });
        }
      } catch (imgErr) {
        // The project itself is saved; the list reports what went wrong with the picture.
        return onSaved({ imageError: imgErr.fields?.image || imgErr.message });
      }
      onSaved();
    } catch (err) {
      if (err.fields) setErrors(err.fields);
      else setFormError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const hasImage = !!project?.imageUrl && !removeImage;
  return (
    <form className="card edit-card project-form" onSubmit={submit} noValidate aria-label={project ? `Edit ${project.title}` : 'Add project'}>
      <h3>{project ? 'Edit project' : 'Add project'}</h3>
      <Field id="project-title" name="title" label="Project title *" value={values.title} onChange={onChange} error={errors.title} maxLength={120} placeholder="Personal Portfolio Website" />
      <Field id="project-description" name="description" label="Short description" as="textarea" rows={3} value={values.description} onChange={onChange} error={errors.description} maxLength={500} placeholder="A responsive website showcasing my projects and technical skills." />
      <Field id="project-url" name="url" label="GitHub repository URL *" type="url" inputMode="url" autoComplete="off" value={values.url} onChange={onChange} error={errors.url} placeholder="https://github.com/owner/repository" />
      <div className="field-row">
        <Field id="project-technologies" name="technologies" label="Technologies (separate with commas)" value={values.technologies} onChange={onChange} error={errors.technologies} placeholder="HTML, CSS, JavaScript" />
        <Field id="project-demo" name="demoUrl" label="Live demo URL (optional)" type="url" inputMode="url" autoComplete="off" value={values.demoUrl} onChange={onChange} error={errors.demoUrl} placeholder="https://" />
      </div>
      <div className="field">
        <label htmlFor="project-image">Thumbnail (optional)</label>
        <input id="project-image" type="file" accept="image/jpeg,image/png,image/webp,image/gif" onChange={pick} aria-invalid={errors.image ? 'true' : 'false'} />
        {file && <p className="field-hint">Selected: {file.name}</p>}
        {hasImage && !file && (
          <p className="field-hint">A thumbnail is set. <button type="button" className="link-btn" onClick={() => setRemoveImage(true)}>Remove thumbnail</button></p>
        )}
        {removeImage && <p className="field-hint">The thumbnail will be removed when you save.</p>}
        {errors.image && <p className="field-error" role="alert">{errors.image}</p>}
      </div>
      {formError && <p className="form-error" role="alert">{formError}</p>}
      <div className="form-actions">
        <button type="submit" className="btn btn-primary btn-sm" disabled={busy}>{busy ? 'Saving…' : project ? 'Save project' : 'Add project'}</button>
        <button type="button" className="btn btn-ghost btn-sm" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  );
}

function ProjectCard({ project, editable, onEdit, onDelete }) {
  const [imgBroken, setImgBroken] = useState(false);
  const repo = project.url && isGithubRepo(project.url);
  const legacyLine = [project.subtitle, project.period].filter(Boolean).join(' · ');
  const external = { target: '_blank', rel: 'noopener noreferrer' };
  return (
    <article className="card project-card" aria-label={project.title}>
      {project.imageUrl && !imgBroken && (
        <div className="project-thumb"><img src={project.imageUrl} alt="" loading="lazy" onError={() => setImgBroken(true)} /></div>
      )}
      <div className="project-body">
        <div className="project-title-row">
          <h4>{project.title}</h4>
          {editable && (
            <span className="item-actions">
              <button type="button" className="icon-btn" aria-label={`Edit ${project.title}`} onClick={onEdit}><Pencil size={14} /></button>
              <button type="button" className="icon-btn" aria-label={`Delete ${project.title}`} onClick={onDelete}><Trash2 size={14} /></button>
            </span>
          )}
        </div>
        {project.description && <p className="project-desc">{project.description}</p>}
        {legacyLine && <small className="muted">{legacyLine}</small>}
        {project.technologies.length > 0 && (
          <ul className="chips project-tech" aria-label="Technologies">
            {project.technologies.map((t) => <li key={t} className="pill pill-accent">{t}</li>)}
          </ul>
        )}
        {(project.url || project.demoUrl) && (
          <div className="project-links">
            {project.url && (repo ? (
              <a className="project-link project-repo" href={project.url} {...external} aria-label={`View repository for ${project.title} on GitHub (opens in a new tab)`}>
                <GithubIcon size={18} /> View Repository
              </a>
            ) : (
              <a className="project-link" href={project.url} {...external} aria-label={`Open link for ${project.title} (opens in a new tab)`}>
                <ExternalLink size={16} aria-hidden="true" /> Open link
              </a>
            ))}
            {project.demoUrl && (
              <a className="project-link project-demo" href={project.demoUrl} {...external} aria-label={`Live demo of ${project.title} (opens in a new tab)`}>
                <ExternalLink size={16} aria-hidden="true" /> Live Demo
              </a>
            )}
          </div>
        )}
      </div>
    </article>
  );
}

/** "My Work": the member's coding projects and repositories. Owners can add, edit and delete; everyone else only sees the cards. */
function MyWork({ projects, editable, onChanged, autoAdd = false }) {
  const { confirm, notify } = useFeedback();
  const [adding, setAdding] = useState(autoAdd);
  const workRef = useRef(null);
  useEffect(() => { if (autoAdd) workRef.current?.scrollIntoView?.({ block: 'center' }); }, [autoAdd]);
  const [editingId, setEditingId] = useState(null);
  const [actionError, setActionError] = useState('');

  const saved = (opts) => {
    setAdding(false);
    setEditingId(null);
    setActionError(opts?.imageError ? `The project was saved, but its thumbnail could not be uploaded: ${opts.imageError} Edit the project to try again.` : '');
    onChanged();
  };
  const remove = async (project) => {
    const ok = await confirm({ title: `Delete "${project.title}"?`, message: 'This project will be removed from My Work. The GitHub repository itself is not affected.', confirmLabel: 'Delete project', tone: 'danger' });
    if (!ok) return;
    setActionError('');
    try {
      await api(`/profile/items/${project.id}`, { method: 'DELETE' });
      notify('Project deleted.');
      onChanged();
    } catch (err) {
      setActionError(err.message);
    }
  };

  return (
    <section className="card my-work" aria-labelledby="my-work-title" ref={workRef}>
      <div className="card-head">
        <h3 id="my-work-title">My Work</h3>
        {editable && !adding && projects.length > 0 && (
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setAdding(true); setEditingId(null); }}>
            <Plus size={14} aria-hidden="true" /> Add Project
          </button>
        )}
      </div>
      {actionError && <p className="form-error" role="alert">{actionError}</p>}
      {adding && <ProjectForm onSaved={saved} onCancel={() => setAdding(false)} />}
      {projects.length === 0 && !adding && (
        <div className="work-empty" role="status">
          <FolderGit2 size={28} aria-hidden="true" />
          <p><strong>{editable ? 'No projects yet' : 'No projects added yet'}</strong></p>
          <p className="muted">{editable ? 'Showcase your coding projects and GitHub repositories here.' : 'This member has not shared any projects yet.'}</p>
          {editable && (
            <button type="button" className="btn btn-primary btn-sm" onClick={() => setAdding(true)}><Plus size={14} aria-hidden="true" /> Add Project</button>
          )}
        </div>
      )}
      {projects.length > 0 && (
        <div className="work-grid">
          {projects.map((p) =>
            editingId === p.id ? (
              <ProjectForm key={p.id} project={p} onSaved={saved} onCancel={() => setEditingId(null)} />
            ) : (
              <ProjectCard key={p.id} project={p} editable={editable} onEdit={() => { setEditingId(p.id); setAdding(false); }} onDelete={() => remove(p)} />
            )
          )}
        </div>
      )}
    </section>
  );
}

const MAX_PHOTO_BYTES = 2 * 1024 * 1024;
const PHOTO_TYPES = ['image/jpeg', 'image/png', 'image/webp'];

function PhotoControls({ user, onChanged }) {
  const { updateUser } = useAuth();
  const input = useRef(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');

  const send = async (request) => {
    setBusy(true);
    setMessage('');
    try {
      const d = await request();
      updateUser(d.user);
      onChanged();
    } catch (err) {
      setMessage(err.fields?.avatar || err.message);
    } finally {
      setBusy(false);
    }
  };

  const onPick = (e) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    if (!PHOTO_TYPES.includes(file.type)) return setMessage('Choose a JPG, PNG or WebP image.');
    if (file.size > MAX_PHOTO_BYTES) return setMessage('That image is too large. The maximum size is 2 MB.');
    const body = new FormData();
    body.append('avatar', file);
    send(() => api('/profile/avatar', { method: 'POST', body }));
  };

  return (
    <div className="photo-controls">
      <input ref={input} type="file" accept="image/jpeg,image/png,image/webp" hidden onChange={onPick} aria-label="Choose a profile photo" />
      <button type="button" className="btn btn-ghost btn-sm" disabled={busy} onClick={() => input.current.click()}>
        <Camera size={14} aria-hidden="true" /> {busy ? 'Uploading…' : user.avatarUrl ? 'Change photo' : 'Add photo'}
      </button>
      {user.avatarUrl && (
        <button type="button" className="btn btn-ghost btn-sm" disabled={busy} onClick={() => send(() => api('/profile/avatar', { method: 'DELETE' }))}>
          Remove
        </button>
      )}
      {message && <p className="field-error" role="alert">{message}</p>}
    </div>
  );
}

export default function Profile({ self = false }) {
  const params = useParams();
  const { data, error, loading, reload } = useApi(self ? '/profile' : `/users/${params.id}`);
  const [editing, setEditing] = useState(false);

  // Links from the Home "Profile strength" checklist: /profile?edit=basics | photo, /profile?add=experience | education | project.
  // They apply once, to the member's own profile, and are then removed from the address so a refresh does not repeat them.
  const [search, setSearch] = useSearchParams();
  const [intent] = useState(() => (self ? { edit: search.get('edit'), add: search.get('add') } : {}));
  useEffect(() => {
    if (!self || (!search.has('edit') && !search.has('add'))) return;
    if (intent.edit === 'basics') setEditing(true);
    const next = new URLSearchParams(search);
    next.delete('edit');
    next.delete('add');
    setSearch(next, { replace: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    if (loading || intent.edit !== 'photo') return;
    const btn = document.querySelector('.photo-controls button');
    btn?.focus();
    btn?.scrollIntoView?.({ block: 'center' });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [loading]);

  if (loading) return <div className="card page-loading" role="status">Loading…</div>;
  if (error) {
    return (
      <section className="card placeholder">
        <h2>{error.status === 404 ? 'Member not found' : 'Could not load this profile'}</h2>
        <p>{error.message}</p>
        <Link to="/" className="btn btn-ghost">Back to Home</Link>
      </section>
    );
  }

  const { user, items, communities, recentPosts, stats } = data;
  const years = user.yearsExperience != null ? `${user.yearsExperience} ${user.yearsExperience === 1 ? 'year' : 'years'} of experience` : '';

  return (
    <div className="profile">
      <section className="card profile-head">
        <div className="profile-photo">
          <UserAvatar user={user} size={84} className="big-avatar" />
          {self && <PhotoControls user={user} onChanged={reload} />}
        </div>
        <div className="profile-id">
          <h2 className="serif">{user.name} {user.isBot && <BotBadge />}{user.isAdmin && <span className="pill pill-accent admin-pill">Administrator</span>}</h2>
          <p>{user.headline || user.profession}</p>
          <small>{[user.isBot ? 'Community bot' : STATUS_LABELS[user.status], user.location, years].filter(Boolean).join(' · ')}</small>
          <SocialLinks user={user} />
        </div>
        {self && (
          <button type="button" className="btn btn-dark" onClick={() => setEditing((e) => !e)}>
            {editing ? 'Close' : 'Edit Profile'}
          </button>
        )}
      </section>

      {self && editing && (
        <BasicsForm user={user} onSaved={() => { setEditing(false); reload(); }} onCancel={() => setEditing(false)} />
      )}

      <section className="stat-row" aria-label="Activity">
        <div className="card stat-box"><small>Communities</small><strong>{stats.communities}</strong></div>
        <div className="card stat-box"><small>Discussions</small><strong>{stats.discussions}</strong></div>
        <div className="card stat-box"><small>Replies</small><strong>{stats.replies}</strong></div>
        <div className="card stat-box"><small>Member since</small><strong className="stat-text">{monthYear(user.memberSince)}</strong></div>
      </section>

      <MyWork projects={items.projects} editable={self} onChanged={reload} autoAdd={intent.add === 'project'} />

      <div className="profile-grid">
        <div className="profile-col">
          {self && <StatusCard user={user} onChanged={reload} />}
          <section className="card">
            <div className="card-head"><h3>Biography</h3></div>
            <p>{user.bio}</p>
          </section>
          <ItemSection autoAdd={intent.add === 'experience'} title="Work Experience" kind="experience" items={items.experience} editable={self} onChanged={reload} emptyText={self ? 'Add your roles to show your professional background.' : 'No work experience added yet.'} />
          <ItemSection autoAdd={intent.add === 'education'} title="Education" kind="education" items={items.education} editable={self} onChanged={reload} emptyText={self ? 'Add your studies and qualifications.' : 'No education added yet.'} />
          <section className="card">
            <div className="card-head"><h3>Recent Posts</h3></div>
            {recentPosts.length === 0 ? (
              <p className="muted">{self ? 'You have not posted yet. Join a community and start a discussion.' : 'No posts yet.'}</p>
            ) : (
              <ul className="list">
                {recentPosts.map((p) => (
                  <li className="row" key={p.id}>
                    <Avatar text={initialsOf(user.name)} />
                    <div className="row-body">
                      <strong><Link to={`/posts/${p.id}`} className="post-link">{p.title}</Link></strong>
                      <small>Discussion in {p.community.name}</small>
                      <small className="muted">{p.commentCount} replies · {timeAgo(p.createdAt)}</small>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>
        </div>

        <div className="profile-col">
          <section className="card">
            <div className="card-head"><h3>Joined Communities</h3></div>
            {communities.length === 0 ? (
              <p className="muted">{self ? <>You have not joined a community yet. <Link to="/communities">Explore communities</Link></> : 'Not a member of any community yet.'}</p>
            ) : (
              <ul className="list">
                {communities.map((c) => (
                  <li className="row" key={c.id}>
                    <Avatar text={initialsOf(c.name)} />
                    <div className="row-body">
                      <strong><Link to={`/communities/${c.id}`}>{c.name}</Link></strong>
                      <small>{c.memberCount} {c.memberCount === 1 ? 'member' : 'members'}</small>
                      <small className="muted">{activityLabel(c.lastActivity)}</small>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </section>
          <section className="card">
            <div className="card-head"><h3>Skills</h3></div>
            <ul className="chips">
              {user.skills.map((s) => <li key={s} className="pill pill-accent">{s}</li>)}
            </ul>
          </section>
        </div>
      </div>
    </div>
  );
}
