import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search } from 'lucide-react';
import { useApi } from '../hooks/useApi.js';
import { useUrlState } from '../hooks/useUrlState.js';
import { PriceBadge } from '../components/Ui.jsx';
import { courseBadge, courseNote, DELIVERY_LABEL } from '../utils/format.js';

const TYPES = [['', 'All'], ['course', 'Courses'], ['webinar', 'Webinars']];
const PRICES = [['', 'Any price'], ['free', 'Free'], ['paid', 'Paid']];
const MODES = [['', 'Any format'], ['online', 'Online'], ['in_person', 'In person'], ['hybrid', 'Hybrid']];

// The filters live in the address (?type=webinar&price=free&mode=online&category=Finance&q=data). Unknown values are ignored.
const FILTER_DEFAULTS = { type: '', price: '', mode: '', category: '', q: '' };
const FILTER_VALID = { type: (v) => TYPES.some(([k]) => k === v), price: (v) => PRICES.some(([k]) => k === v), mode: (v) => MODES.some(([k]) => k === v), category: (v) => v.length <= 80 };

export default function Courses() {
  const { values: url, set: setUrl, clear: clearUrl } = useUrlState(FILTER_DEFAULTS, FILTER_VALID);
  const { type, price, category, mode, q } = url;
  const setType = (v) => setUrl({ type: v });
  const setPrice = (v) => setUrl({ price: v });
  const setMode = (v) => setUrl({ mode: v });
  const setCategory = (v) => setUrl({ category: v });
  const [text, setText] = useState(q);
  useEffect(() => {
    const t = setTimeout(() => { if (q !== text.trim()) setUrl({ q: text.trim() }, { replace: true }); }, 300);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text]);
  useEffect(() => { setText((t) => (t.trim() === q ? t : q)); }, [q]);

  const params = new URLSearchParams();
  if (type) params.set('type', type);
  if (price) params.set('price', price);
  if (category) params.set('category', category);
  if (mode) params.set('mode', mode);
  if (q) params.set('q', q);
  const { data, error, loading } = useApi(`/courses?${params}`);
  const filtered = !!(type || price || q || category || mode);
  // Keep the last known filter options while a new list loads, so the controls do not disappear and reappear.
  const [facets, setFacets] = useState(null);
  useEffect(() => { if (data?.facets) setFacets(data.facets); }, [data]);
  const modeCounts = facets?.modes || {};
  const clearAll = () => { setText(''); clearUrl(); };

  return (
    <div className="courses">
      <div className="toolbar">
        <div className="filters-group">
          <div className="filters" role="group" aria-label="Type">
            {TYPES.map(([v, label]) => (
              <button key={v || 'all'} type="button" className={`chip-btn ${type === v ? 'active' : ''}`} aria-pressed={type === v} onClick={() => setType(v)}>{label}</button>
            ))}
          </div>
          <div className="filters" role="group" aria-label="Price">
            {PRICES.map(([v, label]) => (
              <button key={v || 'any'} type="button" className={`chip-btn ${price === v ? 'active' : ''}`} aria-pressed={price === v} onClick={() => setPrice(v)}>{label}</button>
            ))}
          </div>
          {(Object.keys(modeCounts).length > 0 || mode) && (
            <div className="filters" role="group" aria-label="Format">
              {MODES.filter(([v]) => !v || modeCounts[v] > 0 || mode === v).map(([v, label]) => (
                <button key={v || 'any'} type="button" className={`chip-btn ${mode === v ? 'active' : ''}`} aria-pressed={mode === v} onClick={() => setMode(v)}>{label}</button>
              ))}
            </div>
          )}
          {facets && facets.categories.length > 1 && (
            <label className="filter-select">
              <span className="sr-only">Category</span>
              <select value={category} aria-label="Filter by category" onChange={(e) => setCategory(e.target.value)}>
                <option value="">All categories</option>
                {facets.categories.map((c) => <option key={c.name} value={c.name}>{c.name} ({c.count})</option>)}
              </select>
            </label>
          )}
          {filtered && data?.courses.length > 0 && <button type="button" className="btn btn-ghost btn-sm" onClick={clearAll}>Clear filters</button>}
        </div>
        <label className="search search-inline">
          <Search size={16} aria-hidden="true" />
          <input type="search" placeholder="Filter courses" aria-label="Filter courses and webinars" value={text} onChange={(e) => setText(e.target.value)} />
        </label>
      </div>

      {loading ? (
        <div className="card page-loading" role="status">Loading…</div>
      ) : error ? (
        <div className="card form-error" role="alert">{error.message}</div>
      ) : data.courses.length === 0 ? (
        <div className="card empty" role="status">
          <h3>{filtered ? 'No courses or webinars match' : 'No courses or webinars are listed yet'}</h3>
          {filtered && (
            <>
              <p className="muted">Try a different type, price, category or keyword.</p>
              <button type="button" className="btn btn-ghost btn-sm" onClick={clearAll}>Clear filters</button>
            </>
          )}
        </div>
      ) : (
        <>
        {data.courses.some((c) => c.isSample) && (
          <p className="notice" role="note">
            Demo content: the sample courses and webinars below were generated for the ProConnect prototype. They are not real events, and their instructors and organizations are fictional.
          </p>
        )}
        <div className="course-grid">
          {data.courses.map((c) => (
            <article className={`card course-card ${c.isPast ? 'is-past' : ''}`} key={c.id}>
              {c.image && <img className="course-img" src={c.image} alt="" loading="lazy" />}
              <div className="course-top">
                <span className="pill pill-accent">{c.type === 'webinar' ? 'Webinar' : 'Course'}</span>
                <span className="course-pills">
                  {c.isSample && <span className="pill pill-sample" title="Demonstration listing">Sample</span>}
                  {c.isPast && <span className="pill pill-sample">Ended</span>}
                  <PriceBadge price={c.priceLabel} />
                </span>
              </div>
              <h3><Link to={`/courses/${c.id}`}>{c.title}</Link></h3>
              <p className="muted course-by">{c.instructorName ? `${c.instructorName}${c.instructorRole ? `, ${c.instructorRole}` : ''}` : c.organizer}</p>
              <ul className="course-tags" aria-label="Details">
                {c.category && <li className="pill pill-sample">{c.category}</li>}
                {c.deliveryMode && <li className="pill pill-sample">{DELIVERY_LABEL[c.deliveryMode]}{c.location && c.deliveryMode !== 'online' ? ` · ${c.location}` : ''}</li>}
              </ul>
              <p className="course-when"><span className="date-chip" aria-hidden="true">{courseBadge(c)}</span> <small>{courseNote(c) || 'Self-paced'}</small></p>
              <Link to={`/courses/${c.id}`} className="btn btn-ghost btn-sm">View Details</Link>
            </article>
          ))}
        </div>
        </>
      )}
    </div>
  );
}
