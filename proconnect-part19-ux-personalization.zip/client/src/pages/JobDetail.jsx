import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { ArrowLeft, Briefcase, ClipboardList, ExternalLink, MapPin } from 'lucide-react';
import { api } from '../api.js';
import { isWebLink } from '../utils/format.js';
import { MODE_LABEL, TYPE_LABEL, LEVEL_LABEL } from '../utils/jobLabels.js';
import { CompanyMark, PostedLine } from '../components/JobCard.jsx';
import SaveJobButton from '../components/SaveJobButton.jsx';

/** One job in full, with Save Job, the original Apply link and a way to track the application yourself afterwards. */
export default function JobDetail() {
  const { id } = useParams();
  const [state, setState] = useState({ status: 'loading', job: null, error: null });
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let alive = true;
    setState({ status: 'loading', job: null, error: null });
    api(`/jobs/${id}`)
      .then((d) => alive && setState({ status: 'ready', job: d.job, error: null }))
      .catch((error) => alive && setState({ status: 'error', job: null, error }));
    return () => { alive = false; };
  }, [id, tick]);

  if (state.status === 'loading') return <div className="card page-loading" role="status">Loading job…</div>;
  if (state.status === 'error') {
    const gone = state.error.code === 'job_not_found' || state.error.status === 404;
    return (
      <div className="jobs">
        <Link to="/jobs" className="back-link"><ArrowLeft size={15} aria-hidden="true" /> Back to Jobs</Link>
        <div className={`card ${gone ? 'empty' : 'form-error'}`} role={gone ? 'status' : 'alert'}>
          {gone ? (
            <>
              <Briefcase size={22} aria-hidden="true" />
              <h3>This job is no longer available</h3>
              <p className="muted">The listing was removed or is not stored in ProConnect any more. If you saved it, your saved copy is still on the Saved Jobs page.</p>
              <div className="empty-actions job-actions"><Link className="btn btn-ghost btn-sm" to="/saved-jobs">Saved Jobs</Link><Link className="btn btn-primary btn-sm" to="/jobs">Browse jobs</Link></div>
            </>
          ) : (
            <>{state.error.message} <button type="button" className="btn btn-ghost btn-sm" onClick={() => setTick((t) => t + 1)}>Try again</button></>
          )}
        </div>
      </div>
    );
  }

  const job = state.job;
  const paragraphs = (job.description || '').split(/\n+/).map((p) => p.trim()).filter(Boolean);
  return (
    <article className="jobs job-detail">
      <Link to="/jobs" className="back-link"><ArrowLeft size={15} aria-hidden="true" /> Back to Jobs</Link>
      <section className="card job-detail-card">
        <div className="job-head">
          <CompanyMark job={job} />
          <div className="job-titles">
            <h2 className="serif job-detail-title">{job.title}</h2>
            <p className="muted job-company">{job.company}</p>
          </div>
        </div>
        <ul className="job-meta" aria-label="Job details">
          {job.location && <li><MapPin size={14} aria-hidden="true" /> {job.location}</li>}
          <li><PostedLine job={job} /></li>
        </ul>
        <div className="job-pills">
          <span className="pill pill-accent">{job.category.label}</span>
          {job.workMode && <span className="pill pill-free">{MODE_LABEL[job.workMode]}</span>}
          {job.employmentType && <span className="pill pill-sample">{TYPE_LABEL[job.employmentType]}</span>}
          {job.experienceLevel && <span className="pill pill-sample">{LEVEL_LABEL[job.experienceLevel]}</span>}
        </div>
        <div className="job-actions job-detail-actions">
          <SaveJobButton jobId={job.id} savedId={job.savedId} title={`${job.title} at ${job.company}`} size="md" />
          {isWebLink(job.applyUrl) && (
            <a className="btn btn-primary" href={job.applyUrl} target="_blank" rel="noopener noreferrer" aria-label={`Apply for ${job.title} at ${job.company} (opens the original listing in a new tab)`}>
              Apply on the original site <ExternalLink size={14} aria-hidden="true" />
            </a>
          )}
        </div>
        <p className="notice job-apply-note" role="note">
          Apply opens the employer's own page. ProConnect does not submit applications and does not record that you applied.
          {job.applicationId ? (
            <> You are already tracking this job in <Link to="/applications">My Applications</Link>.</>
          ) : (
            <> Once you have applied there, add it yourself to keep track of it: <Link to={`/applications?add=${job.id}`} className="job-track-link"><ClipboardList size={14} aria-hidden="true" /> Add to My Applications</Link>.</>
          )}
        </p>
      </section>
      <section className="card job-detail-body" aria-label="Description">
        <h3>About this job</h3>
        {paragraphs.length > 0 ? paragraphs.map((p, i) => <p key={i}>{p}</p>) : job.summary ? <p>{job.summary}</p> : <p className="muted">The source did not provide a description. Open the original listing for the full text.</p>}
        {job.tags.length > 0 && (
          <ul className="chips job-tags" aria-label="Skills and tags">
            {job.tags.map((t) => <li key={t} className="pill pill-sample">{t}</li>)}
          </ul>
        )}
        <small className="muted">Source: {job.source.name}</small>
      </section>
    </article>
  );
}
