import { useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { useApi } from '../hooks/useApi.js';
import Highlight from '../components/Highlight.jsx';
import JoinButton from '../components/JoinButton.jsx';
import { Avatar, BotBadge } from '../components/Ui.jsx';
import { initialsOf, timeAgo } from '../utils/format.js';

const TABS = [['people', 'People'], ['communities', 'Communities']];
const STATUS_LABELS = { student: 'Student', beginner: 'Beginner', professional: 'Professional' };
const SUGGESTIONS = ['Frontend', 'Cybersecurity', 'Python', 'Kubernetes', 'Design'];
const STEP = 20;
const MAX = 100;

function PersonResult({ u, q }) {
  return (
    <li className="row result">
      <Avatar text={initialsOf(u.name)} src={u.avatarUrl} />
      <div className="row-body">
        <div className="chips-inline">
          <strong><Link to={`/members/${u.id}`} className="post-link"><Highlight text={u.name} query={q} /></Link></strong>
          {u.isBot && <BotBadge />}
        </div>
        <small className="chips-inline">
          <span className="pill pill-accent">{u.isBot ? 'Community bot' : STATUS_LABELS[u.status] || u.status}</span>
          {u.isLeader && <span className="pill pill-sample">Community Leader</span>}
        </small>
        <small>
          <Highlight text={[u.profession, u.location].filter(Boolean).join(' · ')} query={q} />
        </small>
        {u.headline && !u.isBot && <small className="muted"><Highlight text={u.headline} query={q} /></small>}
        {u.skills.length > 0 && (
          <ul className="chips" style={{ marginTop: 6 }}>
            {u.skills.slice(0, 5).map((s) => <li key={s} className="pill pill-sample"><Highlight text={s} query={q} /></li>)}
          </ul>
        )}
      </div>
    </li>
  );
}

function CommunityResult({ c, q, state, onMembership }) {
  const joined = state?.isMember ?? c.isMember;
  const memberCount = state?.memberCount ?? c.memberCount;
  // Joining happens on the main community; a subcommunity opens automatically with its parent.
  const target = { id: c.joinTargetId, name: c.parent ? c.parent.name : c.name, isMember: joined };
  return (
    <li className="row result">
      <Avatar text={initialsOf(c.name)} />
      <div className="row-body">
        <strong><Link to={`/communities/${c.id}`} className="post-link"><Highlight text={c.name} query={q} /></Link></strong>
        <small className="chips-inline">
          {c.isSubcommunity ? (
            <span className="pill pill-sample">Subcommunity of <Link to={`/communities/${c.parent.id}`}>{c.parent.name}</Link></span>
          ) : (
            <span className="pill pill-accent">Main community</span>
          )}
          <span className="pill pill-sample"><Highlight text={c.category} query={q} /></span>
        </small>
        <small className="excerpt"><Highlight text={c.description} query={q} /></small>
        <small className="muted">
          {memberCount} {memberCount === 1 ? 'member' : 'members'}{c.isSubcommunity ? ` of ${c.parent.name}` : ''} · {c.postCount} {c.postCount === 1 ? 'post' : 'posts'} · created {timeAgo(c.createdAt)}
        </small>
        {c.isSubcommunity && !joined && <small className="muted">Joining {c.parent.name} gives you access to this subcommunity.</small>}
      </div>
      <JoinButton community={target} onChange={(next) => onMembership(c.joinTargetId, next)} />
    </li>
  );
}

export default function Search() {
  const [params, setParams] = useSearchParams();
  const q = params.get('q') || '';
  const profession = params.get('profession') || '';
  const status = params.get('status') || '';
  const category = params.get('category') || '';
  const sort = params.get('sort') === 'relevance' ? 'relevance' : 'recent';
  const limit = Math.min(Math.max(Number.parseInt(params.get('limit'), 10) || STEP, STEP), MAX);
  const [memberState, setMemberState] = useState({}); // main community id -> { isMember, memberCount } after joining or leaving here

  const apiParams = new URLSearchParams();
  if (q) apiParams.set('q', q);
  if (profession) apiParams.set('profession', profession);
  if (status) apiParams.set('status', status);
  if (category) apiParams.set('category', category);
  if (sort !== 'recent') apiParams.set('sort', sort);
  if (limit !== STEP) apiParams.set('limit', String(limit));
  const { data, error, loading, reload } = useApi(`/search${apiParams.toString() ? `?${apiParams}` : ''}`);
  const { data: options } = useApi('/search/options');

  const total = (t) => data?.results?.[t]?.total ?? 0;
  // Without an explicit tab, open the one that has matches (People first).
  const explicit = params.get('type') === 'communities' || params.get('type') === 'people' ? params.get('type') : null;
  const autoCommunities = !explicit && !profession && !status && data && total('people') === 0 && total('communities') > 0;
  const type = explicit || (autoCommunities ? 'communities' : 'people');

  const update = (changes) => {
    const next = new URLSearchParams(params);
    if (!('type' in changes)) next.set('type', type); // keep the tab the member is looking at
    for (const [key, value] of Object.entries(changes)) {
      if (value) next.set(key, value);
      else next.delete(key);
    }
    if (!('limit' in changes)) next.delete('limit'); // a new query or filter starts from the first page again
    setParams(next);
  };
  const clearFilters = () => {
    const next = new URLSearchParams();
    if (q) next.set('q', q);
    if (type) next.set('type', type);
    setParams(next);
  };
  const peopleFiltered = !!(profession || status);
  const communitiesFiltered = !!category;
  const filtered = type === 'people' ? peopleFiltered : communitiesFiltered;

  const result = data?.results?.[type];
  const sortedBy = data?.sortedBy?.[type];
  const items = useMemo(() => result?.items || [], [result]);

  return (
    <div className="search-page">
      <div className="card search-toolbar">
        <div className="filters" role="tablist" aria-label="Result type">
          {TABS.map(([id, label]) => (
            <button key={id} type="button" role="tab" aria-selected={type === id} className={`chip-btn ${type === id ? 'active' : ''}`} onClick={() => update({ type: id, limit: '' })}>
              {label}{data ? ` (${total(id)})` : ''}
            </button>
          ))}
        </div>
        <div className="filter-row">
          {type === 'people' ? (
            <>
              <label className="filter-select">
                <span>Specialty</span>
                <select value={profession} onChange={(e) => update({ profession: e.target.value })}>
                  <option value="">Any specialty</option>
                  {options?.professions.map((p) => <option key={p} value={p}>{p}</option>)}
                </select>
              </label>
              <label className="filter-select">
                <span>Status</span>
                <select value={status} onChange={(e) => update({ status: e.target.value })}>
                  <option value="">Any status</option>
                  {options?.statuses.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
                </select>
              </label>
            </>
          ) : (
            <label className="filter-select">
              <span>Specialty</span>
              <select value={category} onChange={(e) => update({ category: e.target.value })}>
                <option value="">Any specialty</option>
                {options?.categories.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </label>
          )}
          <label className="filter-select">
            <span>Sort by</span>
            <select value={sort} onChange={(e) => update({ sort: e.target.value === 'recent' ? '' : e.target.value })}>
              <option value="recent">Most recent</option>
              <option value="relevance">Best match</option>
            </select>
          </label>
          {filtered && <button type="button" className="btn btn-ghost btn-sm" onClick={clearFilters}>Clear filters</button>}
        </div>
        {sortedBy && <p className="muted result-note">Sorted by {sortedBy}.</p>}
      </div>

      {loading ? (
        <div className="card page-loading" role="status">Searching…</div>
      ) : error ? (
        <div className="card form-error" role="alert">
          <p>{error.message || 'Search is not available right now.'}</p>
          <button type="button" className="btn btn-ghost btn-sm" onClick={reload}>Try again</button>
        </div>
      ) : items.length === 0 ? (
        <div className="card empty" role="status">
          <h3>{q ? `No ${type === 'people' ? 'people' : 'communities'} found for "${q}"` : `No ${type === 'people' ? 'people' : 'communities'} match these filters`}</h3>
          <p className="muted">
            Check the spelling, try fewer or different words{filtered ? ', or remove a filter' : ''}.
            {total(type === 'people' ? 'communities' : 'people') > 0 && <> The {type === 'people' ? 'Communities' : 'People'} tab has {total(type === 'people' ? 'communities' : 'people')} {total(type === 'people' ? 'communities' : 'people') === 1 ? 'match' : 'matches'}.</>}
          </p>
          <div className="empty-actions">
            {filtered && <button type="button" className="btn btn-ghost btn-sm" onClick={clearFilters}>Clear filters</button>}
            {!q && !filtered && (
              <ul className="chips">
                {SUGGESTIONS.map((s) => <li key={s}><button type="button" className="chip-btn" onClick={() => update({ q: s })}>{s}</button></li>)}
              </ul>
            )}
          </div>
        </div>
      ) : (
        <section className="card" aria-labelledby="res-title">
          <div className="card-head">
            <h3 id="res-title">
              {!q && !filtered ? (type === 'people' ? 'Recently active people' : 'Newest communities') : type === 'people' ? 'People' : 'Communities'} <span className="muted">({result.total})</span>
            </h3>
          </div>
          {!q && !filtered && (
            <p className="muted result-note">
              Showing the latest {type === 'people' ? 'profiles' : 'communities and subcommunities'}. Type in the search box above, or try:{' '}
              {SUGGESTIONS.map((s, i) => <span key={s}>{i ? ' · ' : ''}<button type="button" className="link-btn" onClick={() => update({ q: s })}>{s}</button></span>)}
            </p>
          )}
          <ul className="list">
            {items.map((item) => (type === 'people'
              ? <PersonResult key={item.id} u={item} q={q} />
              : <CommunityResult key={item.id} c={item} q={q} state={memberState[item.joinTargetId]} onMembership={(id, next) => setMemberState((m) => ({ ...m, [id]: { isMember: next.isMember, memberCount: next.memberCount } }))} />))}
          </ul>
          {result.total > items.length && (
            <div className="result-note">
              <p className="muted">Showing {items.length} of {result.total}.</p>
              {limit < MAX ? (
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => update({ limit: String(Math.min(limit + STEP, MAX)) })}>Show more</button>
              ) : (
                <p className="muted">Narrow the search with a keyword or a filter to see the rest.</p>
              )}
            </div>
          )}
        </section>
      )}
    </div>
  );
}
