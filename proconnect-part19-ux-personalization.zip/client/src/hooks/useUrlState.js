import { useCallback, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';

/**
 * Keeps page filters in the address bar (?q=...&category=...), so a refresh, the Back and Forward buttons and a copied link all
 * bring the same filters back.
 *
 *   const { values, set, clear } = useUrlState({ q: '', category: '' }, { category: (v) => /^[a-z-]+$/.test(v) });
 *
 *  - `defaults` lists the keys this page owns and what each means when it is absent from the address. A value equal to its default
 *    is removed from the address, so the plain page address stays clean. Other query parameters are never touched.
 *  - `valid` (optional) maps a key to a check function; a value in the address that fails the check is treated as absent, so a
 *    hand-edited link cannot put the page into a state it cannot show.
 *  - `set(patch, { replace })` changes some keys. By default it adds a history entry (Back returns to the previous filters);
 *    pass replace: true for changes that should not (typing in a search box).
 *  - `clear()` resets every key of this page.
 */
export function useUrlState(defaults, valid = {}) {
  const [params, setParams] = useSearchParams();
  const text = params.toString();

  const values = useMemo(() => {
    const out = {};
    for (const key of Object.keys(defaults)) {
      const raw = params.get(key);
      out[key] = raw !== null && raw !== '' && (!valid[key] || valid[key](raw)) ? raw : defaults[key];
    }
    return out;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text]);

  const set = useCallback((patch, { replace = false } = {}) => {
    const next = new URLSearchParams(params);
    for (const [key, value] of Object.entries(patch)) {
      if (!(key in defaults)) continue;
      if (value == null || value === '' || value === defaults[key]) next.delete(key);
      else next.set(key, String(value));
    }
    if (next.toString() === params.toString()) return; // nothing changed: no new history entry
    setParams(next, { replace });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [text, setParams]);

  const clear = useCallback((options) => set(Object.fromEntries(Object.keys(defaults).map((k) => [k, defaults[k]])), options), [set]); // eslint-disable-line react-hooks/exhaustive-deps

  return { values, set, clear };
}
