import { useState } from 'react';
import { Link } from 'react-router-dom';
import { AlertCircle, CalendarCheck, ClipboardCheck, Clock, ExternalLink, MapPin } from 'lucide-react';
import { isWebLink, timeAgo, dayLabel } from '../utils/format.js';
import { MODE_LABEL, TYPE_LABEL, LEVEL_LABEL } from '../utils/jobLabels.js';
import SaveJobButton from './SaveJobButton.jsx';

const initialsOf = (name = '') => name.replace(/[^\p{L}\p{N} ]/gu, '').split(' ').filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join('') || '?';

/** The company's logo only when the source supplied one (neither current source does); otherwise initials, which is decoration, not a logo. */
export function CompanyMark({ job }) {
  const [failed, setFailed] = useState(false);
  if (job.logoUrl && isWebLink(job.logoUrl) && !failed) {
    return <img className="job-logo" src={job.logoUrl} alt="" loading="lazy" referrerPolicy="no-referrer" onError={() => setFailed(true)} />;
  }
  return <span className="job-logo job-logo-initials" aria-hidden="true">{initialsOf(job.company)}</span>;
}

export function PostedLine({ job }) {
  if (job.publishedAt) return <><Clock size={14} aria-hidden="true" /> <time dateTime={job.publishedAt} title={dayLabel(job.publishedAt)}>Posted {timeAgo(job.publishedAt).toLowerCase()}</time></>;
  return <><Clock size={14} aria-hidden="true" /> Listed here {timeAgo(job.firstSeenAt).toLowerCase()}</>;
}

/**
 * One job. Used by the Jobs list and, with `saved`, by the Saved Jobs page.
 *   job    the job as returned by /api/jobs (or the same shape built from a saved record)
 *   saved  { id, savedAt, availability, onRemove } when shown on the Saved Jobs page
 * Apply opens the employer's own page in a new tab: nothing is submitted by ProConnect and nothing is recorded by clicking it.
 */
export default function JobCard({ job, saved = null }) {
  const unavailable = saved?.availability === 'unavailable';
  const canApply = !saved && isWebLink(job.applyUrl);
  const detailPath = job.id ? `/jobs/${job.id}` : null;
  return (
    <article className={`card job-card ${unavailable ? 'job-card-unavailable' : ''}`}>
      <div className="job-head">
        <CompanyMark job={job} />
        <div className="job-titles">
          <h3>{detailPath ? <Link to={detailPath} className="job-title-link">{job.title}</Link> : job.title}</h3>
          <p className="muted job-company">{job.company}</p>
        </div>
      </div>
      <ul className="job-meta" aria-label="Job details">
        {job.location && <li><MapPin size={14} aria-hidden="true" /> {job.location}</li>}
        <li><PostedLine job={job} /></li>
        {saved && <li><CalendarCheck size={14} aria-hidden="true" /> Saved <time dateTime={saved.savedAt}>{dayLabel(saved.savedAt)}</time></li>}
      </ul>
      <div className="job-pills">
        {saved && <span className={`pill ${unavailable ? 'pill-unavailable' : 'pill-free'}`}>{unavailable ? 'No longer available' : 'Available'}</span>}
        <span className="pill pill-accent">{job.category.label}</span>
        {job.workMode && <span className="pill pill-free">{MODE_LABEL[job.workMode]}</span>}
        {job.employmentType && <span className="pill pill-sample">{TYPE_LABEL[job.employmentType]}</span>}
        {job.experienceLevel && <span className="pill pill-sample">{LEVEL_LABEL[job.experienceLevel]}</span>}
      </div>
      {unavailable && (
        <p className="job-unavailable" role="note">
          <AlertCircle size={15} aria-hidden="true" />
          <span>
            This listing is no longer in ProConnect's job feed. It may have been filled or removed by the employer, or the source could not be reached. Your saved copy is kept.
            {isWebLink(job.lastKnownUrl) && <> <a href={job.lastKnownUrl} target="_blank" rel="noopener noreferrer">Last known listing page</a> (it may no longer work).</>}
          </span>
        </p>
      )}
      {job.summary && !unavailable && <p className="job-summary">{job.summary}</p>}
      {job.tags?.length > 0 && (
        <ul className="chips job-tags" aria-label="Skills and tags">
          {job.tags.slice(0, 5).map((t) => <li key={t} className="pill pill-sample">{t}</li>)}
        </ul>
      )}
      <div className="job-foot">
        <small className="muted">Source: {job.source.name}</small>
        <div className="job-actions">
          {saved ? (
            <>
              {detailPath ? <Link className="btn btn-primary btn-sm" to={detailPath} aria-label={`View ${job.title} at ${job.company}`}>View Job</Link> : <span className="btn btn-ghost btn-sm is-disabled" aria-disabled="true">Listing unavailable</span>}
              <button type="button" className="btn btn-ghost btn-sm" onClick={saved.onRemove} disabled={saved.busy} aria-label={`Remove ${job.title} at ${job.company} from saved jobs`}>Remove from Saved</button>
            </>
          ) : (
            <>
              {job.id && <SaveJobButton jobId={job.id} savedId={job.savedId} title={`${job.title} at ${job.company}`} />}
              {job.applicationId && <Link className="pill pill-accent job-tracked" to="/applications" title="You are tracking an application for this job"><ClipboardCheck size={12} aria-hidden="true" /> Tracked</Link>}
              {canApply && (
                <a className="btn btn-primary btn-sm" href={job.applyUrl} target="_blank" rel="noopener noreferrer" aria-label={`Apply for ${job.title} at ${job.company} (opens the original listing in a new tab)`}>
                  Apply <ExternalLink size={14} aria-hidden="true" />
                </a>
              )}
            </>
          )}
        </div>
      </div>
    </article>
  );
}
