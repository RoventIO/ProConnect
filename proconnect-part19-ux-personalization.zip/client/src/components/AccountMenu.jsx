import { useCallback, useEffect, useId, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Bookmark, ClipboardList, LogOut, Settings, User } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { useFeedback } from './Feedback.jsx';
import { UserAvatar } from './Ui.jsx';

const ITEMS = [
  { to: '/profile', label: 'My Profile', icon: User },
  { to: '/saved-jobs', label: 'Saved Jobs', icon: Bookmark },
  { to: '/applications', label: 'My Applications', icon: ClipboardList },
  { to: '/settings', label: 'Preferences', icon: Settings },
];

/**
 * The account menu opened from the avatar in the header (members only).
 * Keyboard: Enter / Space / Arrow Down open it and focus the first item; Arrow Up / Down, Home and End move between items;
 * Escape closes it and returns focus to the avatar; Tab closes it. Log Out is the last item.
 */
export default function AccountMenu() {
  const { user, logout } = useAuth();
  const feedback = useFeedback(); // optional: without it (a page rendered on its own) the warning below is simply not shown
  const notify = feedback?.notify;
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [signingOut, setSigningOut] = useState(false);
  const wrap = useRef(null);
  const button = useRef(null);
  const menuId = useId();

  const items = () => [...(wrap.current?.querySelectorAll('[role="menuitem"]') || [])];
  const close = useCallback((returnFocus = false) => {
    setOpen(false);
    if (returnFocus) button.current?.focus();
  }, []);

  useEffect(() => {
    if (!open) return undefined;
    items()[0]?.focus(); // keyboard users land on the first item
    const onClick = (e) => { if (wrap.current && !wrap.current.contains(e.target)) setOpen(false); };
    document.addEventListener('mousedown', onClick);
    return () => document.removeEventListener('mousedown', onClick);
  }, [open]);

  const onMenuKey = (e) => {
    const list = items();
    const i = list.indexOf(document.activeElement);
    if (e.key === 'Escape') { e.preventDefault(); close(true); }
    else if (e.key === 'Tab') close(false);
    else if (e.key === 'ArrowDown') { e.preventDefault(); list[(i + 1) % list.length]?.focus(); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); list[(i - 1 + list.length) % list.length]?.focus(); }
    else if (e.key === 'Home') { e.preventDefault(); list[0]?.focus(); }
    else if (e.key === 'End') { e.preventDefault(); list[list.length - 1]?.focus(); }
  };
  const onButtonKey = (e) => {
    if (e.key === 'ArrowDown' && !open) { e.preventDefault(); setOpen(true); }
    else if (e.key === 'Escape' && open) { e.preventDefault(); close(true); }
  };

  const signOut = async () => {
    if (signingOut) return;
    setSigningOut(true);
    setOpen(false);
    const { confirmed } = await logout(); // clears the signed-in member from the page in every case
    // replace: the page the member was on does not stay in history as a way back into a private view
    navigate('/', { replace: true });
    if (!confirmed && notify) notify('You were signed out on this device, but the server could not be reached to end the session. Sign out again once you are back online.');
    setSigningOut(false);
  };

  return (
    <div className="avatar-menu" ref={wrap}>
      <button
        ref={button}
        type="button"
        className="avatar-btn"
        aria-haspopup="menu"
        aria-expanded={open}
        aria-controls={open ? menuId : undefined}
        aria-label="Account menu"
        onClick={() => setOpen((o) => !o)}
        onKeyDown={onButtonKey}
      >
        <UserAvatar user={user} size={42} />
      </button>
      {open && (
        <div className="dropdown" role="menu" id={menuId} aria-label="Account" onKeyDown={onMenuKey}>
          <div className="dropdown-head">
            <UserAvatar user={user} size={42} />
            <div>
              <strong>{user.name}</strong>
              <small>{user.email}</small>
            </div>
          </div>
          {ITEMS.map(({ to, label, icon: Icon }) => (
            <Link key={to} role="menuitem" to={to} className="dropdown-item" onClick={() => setOpen(false)}>
              <Icon size={16} aria-hidden="true" /> {label}
            </Link>
          ))}
          <div className="dropdown-sep" role="separator" />
          <button role="menuitem" type="button" className="dropdown-item dropdown-logout" onClick={signOut} disabled={signingOut}>
            <LogOut size={16} aria-hidden="true" /> Log Out
          </button>
        </div>
      )}
    </div>
  );
}
