import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Search, X } from 'lucide-react';
import { api } from '../api.js';
import Field from './Field.jsx';
import { todayYmd } from '../utils/format.js';
import { APPLICATION_STATUSES } from '../utils/jobLabels.js';

const NOTES_MAX = 2000;

/**
 * Add or edit one tracked application. Nothing here contacts an employer: it only stores what the member reports.
 *   application  the record being edited, or null to add a new one
 *   jobId        optional ProConnect job to start from (when arriving from a job page)
 */
export default function ApplicationForm({ application = null, jobId = null, onClose, onSaved }) {
  const editing = !!application;
  const [mode, setMode] = useState(jobId ? 'job' : 'manual'); // 'job' = pick a ProConnect listing, 'manual' = type an external one
  const [picked, setPicked] = useState(null);
  const [search, setSearch] = useState('');
  const [results, setResults] = useState({ status: 'idle', jobs: [], error: '' });
  const [values, setValues] = useState({
    title: application?.title || '', company: application?.company || '', url: application?.url || '',
    appliedOn: application?.appliedOn || todayYmd(), status: application?.status || 'applied', notes: application?.notes || '',
  });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);
  const panel = useRef(null);
  const set = (k) => (e) => setValues((v) => ({ ...v, [k]: e.target.value }));

  // Keyboard: Escape closes, Tab stays inside, focus returns to where it was.
  useEffect(() => {
    const previous = document.activeElement;
    const overflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    panel.current?.querySelector('input:not([type=radio]), button.seg-active, select')?.focus();
    const onKey = (e) => {
      if (e.key === 'Escape') { e.preventDefault(); onClose(); }
      else if (e.key === 'Tab' && panel.current) {
        const items = [...panel.current.querySelectorAll('button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), a[href]')];
        if (!items.length) return;
        const first = items[0], last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener('keydown', onKey);
    return () => { document.removeEventListener('keydown', onKey); document.body.style.overflow = overflow; previous?.focus?.(); };
  }, [onClose]);

  // Arriving from a job page: load that listing.
  useEffect(() => {
    if (!jobId || editing) return undefined;
    let alive = true;
    api(`/jobs/${jobId}`)
      .then((d) => { if (alive) setPicked(d.job); })
      .catch((e) => {
        if (!alive) return;
        setMode('manual');
        setFormError(e.code === 'job_not_found' ? 'That listing is no longer available. Enter the job details yourself instead.' : e.message);
      });
    return () => { alive = false; };
  }, [jobId, editing]);

  // Searching ProConnect's jobs.
  useEffect(() => {
    if (mode !== 'job' || search.trim().length < 2) { setResults({ status: 'idle', jobs: [], error: '' }); return undefined; }
    let alive = true;
    setResults((r) => ({ ...r, status: 'loading', error: '' }));
    const t = setTimeout(() => {
      api(`/jobs?${new URLSearchParams({ q: search.trim(), pageSize: '6' })}`)
        .then((d) => alive && setResults({ status: 'ready', jobs: d.jobs, error: '' }))
        .catch((e) => alive && setResults({ status: 'error', jobs: [], error: e.message }));
    }, 300);
    return () => { alive = false; clearTimeout(t); };
  }, [search, mode]);

  async function submit(e) {
    e.preventDefault();
    if (busy) return;
    setErrors({});
    setFormError('');
    const local = {};
    if (!editing && mode === 'job' && !picked) local.job = 'Choose a job from the list, or switch to entering it yourself.';
    if (editing || mode === 'manual') {
      if (!values.title.trim()) local.title = 'Job title is required.';
      if (!values.company.trim()) local.company = 'Company is required.';
    }
    if (!values.appliedOn) local.appliedOn = 'Enter the application date.';
    if (Object.keys(local).length) { setErrors(local); return; }

    const common = { appliedOn: values.appliedOn, status: values.status, notes: values.notes.trim() };
    setBusy(true);
    try {
      let saved;
      if (editing) {
        saved = await api(`/job-applications/${application.id}`, { method: 'PUT', body: { ...common, title: values.title.trim(), company: values.company.trim(), url: values.url.trim() } });
      } else if (mode === 'job') {
        saved = await api('/job-applications', { method: 'POST', body: { ...common, jobId: picked.id } });
      } else {
        saved = await api('/job-applications', { method: 'POST', body: { ...common, title: values.title.trim(), company: values.company.trim(), ...(values.url.trim() ? { url: values.url.trim() } : {}) } });
      }
      onSaved(saved.application, editing);
    } catch (err) {
      if (err.fields) setErrors(err.fields);
      setFormError(err.fields ? 'Please fix the highlighted fields.' : err.code === 'duplicate_application' ? 'You are already tracking this application. Open it from your list to change it.' : err.message);
      setBusy(false);
    }
  }

  const linked = editing && !!application.job;
  return createPortal(
    <div className="modal-overlay" onMouseDown={(e) => e.target === e.currentTarget && !busy && onClose()}>
      <div className="modal app-modal" ref={panel} role="dialog" aria-modal="true" aria-labelledby="app-form-title">
        <div className="app-modal-head">
          <h3 id="app-form-title" className="serif">{editing ? 'Edit application' : 'Add application'}</h3>
          <button type="button" className="icon-btn" aria-label="Close" onClick={onClose}><X size={18} aria-hidden="true" /></button>
        </div>
        <p className="muted app-modal-note">
          {editing ? 'Update what you know about this application.' : 'Record an application you have already made on the employer\u2019s website. ProConnect does not submit applications for you.'}
        </p>
        <form className="app-form" onSubmit={submit} noValidate>
          {!editing && (
            <div className="seg" role="group" aria-label="Which job is this for?">
              <button type="button" className={`chip-btn ${mode === 'job' ? 'active seg-active' : ''}`} aria-pressed={mode === 'job'} onClick={() => setMode('job')}>A job from ProConnect</button>
              <button type="button" className={`chip-btn ${mode === 'manual' ? 'active seg-active' : ''}`} aria-pressed={mode === 'manual'} onClick={() => setMode('manual')}>Another job (enter it myself)</button>
            </div>
          )}

          {!editing && mode === 'job' && (
            <div className="app-job-pick">
              {picked ? (
                <div className="app-picked" role="status">
                  <div><strong>{picked.title}</strong><br /><span className="muted">{picked.company}</span></div>
                  <button type="button" className="btn btn-ghost btn-sm" onClick={() => setPicked(null)}>Change</button>
                </div>
              ) : (
                <>
                  <label className="search search-wide">
                    <Search size={16} aria-hidden="true" />
                    <input type="search" placeholder="Search ProConnect jobs by title or company" aria-label="Search ProConnect jobs" value={search} onChange={(e) => setSearch(e.target.value)} />
                  </label>
                  <div aria-live="polite">
                    {results.status === 'loading' && <small className="muted">Searching…</small>}
                    {results.status === 'error' && <small className="field-error" role="alert">{results.error}</small>}
                    {results.status === 'ready' && results.jobs.length === 0 && <small className="muted">No ProConnect job matches. Switch to entering the job yourself.</small>}
                  </div>
                  {results.jobs.length > 0 && (
                    <ul className="app-results" aria-label="Matching jobs">
                      {results.jobs.map((j) => (
                        <li key={j.id}>
                          <button type="button" className="app-result" disabled={!!j.applicationId} onClick={() => setPicked(j)}>
                            <strong>{j.title}</strong>
                            <span className="muted">{j.company}{j.location ? ` · ${j.location}` : ''}</span>
                            {j.applicationId && <span className="pill pill-sample">Already tracked</span>}
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                </>
              )}
              {errors.job && <p className="field-error" role="alert">{errors.job}</p>}
              {errors.jobId && <p className="field-error" role="alert">{errors.jobId}</p>}
            </div>
          )}

          {(editing || mode === 'manual') && (
            <>
              <Field id="app-title" label="Job title" value={values.title} onChange={set('title')} error={errors.title} maxLength={200} required autoComplete="off" />
              <Field id="app-company" label="Company" value={values.company} onChange={set('company')} error={errors.company} maxLength={120} required autoComplete="off" />
              <Field id="app-url" label="Original job link (optional)" type="url" inputMode="url" placeholder="https://" value={values.url} onChange={set('url')} error={errors.url}
                hint="The page of the listing on the employer\u2019s site, if you have it." autoComplete="off" />
              {linked && <p className="muted app-modal-note">This record started from a ProConnect listing. The details above are your own copy and stay readable if the listing disappears.</p>}
            </>
          )}

          <div className="field-row">
            <Field id="app-date" label="Application date" type="date" value={values.appliedOn} onChange={set('appliedOn')} error={errors.appliedOn} max={todayYmd()} required />
            <Field id="app-status" label="Status" as="select" value={values.status} onChange={set('status')} error={errors.status}>
              {APPLICATION_STATUSES.map((s) => <option key={s.key} value={s.key}>{s.label}</option>)}
            </Field>
          </div>
          <Field id="app-notes" label="Notes (optional)" as="textarea" rows={4} value={values.notes} onChange={set('notes')} error={errors.notes} maxLength={NOTES_MAX}
            hint={`${values.notes.length} / ${NOTES_MAX} characters`} placeholder="Contacts, interview dates, salary talk, follow-ups…" />

          {formError && <p className="form-error" role="alert">{formError}</p>}
          <div className="modal-actions">
            <button type="button" className="btn btn-ghost" onClick={onClose} disabled={busy}>Cancel</button>
            <button type="submit" className="btn btn-dark" disabled={busy}>{busy ? 'Saving…' : editing ? 'Save changes' : 'Add application'}</button>
          </div>
        </form>
      </div>
    </div>,
    document.body
  );
}
