import { useEffect, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Moon, Sun, Search } from 'lucide-react';
import { useTheme } from '../context/ThemeContext.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { usePreferences } from '../context/PreferencesContext.jsx';
import AccountMenu from './AccountMenu.jsx';
import NotificationBell from './NotificationBell.jsx';

const TITLES = {
  '/': ['Home', 'Welcome to ProConnect'],
  '/communities': ['Communities', 'Find communities in your profession'],
  '/courses': ['Courses & Webinars', 'Learn from experienced professionals'],
  '/profile': ['My Profile', 'Manage how professionals see you'],
  '/sign-in': ['Sign In', 'Access your ProConnect account'],
  '/sign-up': ['Sign Up', 'Join the professional community'],
  '/onboarding': ['Profile setup', 'Tell professionals who you are'],
  '/search': ['Search', 'People and communities'],
  '/news': ['News', 'Technology news from trusted sources'],
  '/news/sources': ['News Sources', 'Manage where the news comes from'],
  '/jobs': ['Jobs', 'Listings across all professions'],
  '/settings': ['Preferences', 'Theme, news, jobs and your Home page'],
  '/saved-jobs': ['Saved Jobs', 'Jobs you bookmarked'],
  '/applications': ['My Applications', 'Track where each application stands'],
};

export default function Header() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { theme } = useTheme();
  const { toggleTheme } = usePreferences(); // flips the theme and, for a signed-in member, saves the choice
  const { user, loading } = useAuth();
  const location = useLocation();
  const [searchText, setSearchText] = useState('');

  // Keep the box in step with the address when the search page is open (back/forward, suggestions).
  useEffect(() => {
    if (location.pathname === '/search') setSearchText(new URLSearchParams(location.search).get('q') || '');
  }, [location.pathname, location.search]);

  const onSearch = (e) => {
    e.preventDefault();
    const next = new URLSearchParams(location.pathname === '/search' ? location.search : '');
    const text = searchText.trim();
    if (text) next.set('q', text);
    else next.delete('q');
    navigate(`/search${next.toString() ? `?${next}` : ''}`);
  };

  const [title, subtitle] = pathname.startsWith('/members/')
    ? ['Member profile', 'Professional background and activity']
    : pathname.startsWith('/jobs/')
      ? ['Job', 'Details and original listing']
    : pathname.startsWith('/courses/')
      ? ['Course or webinar', 'Details and registration']
    : pathname.startsWith('/posts/')
      ? ['Discussion', 'Replies and attachments']
    : pathname.startsWith('/communities/')
      ? ['Community', 'Members and discussions']
      : TITLES[pathname] || ['ProConnect', ''];
  const subtitleText = pathname === '/' && user?.profileCompleted ? `Welcome back, ${user.name.split(' ')[0]}` : subtitle;
  // The browser tab names the page: "Jobs · ProConnect". Unknown pages keep the plain site name.
  useEffect(() => {
    document.title = title && title !== 'ProConnect' ? `${title} · ProConnect` : 'ProConnect';
  }, [title]);
  const themeLabel = theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode';

  return (
    <header className="header">
      <div className="header-title">
        <h1>{title}</h1>
        <p>{subtitleText}</p>
      </div>

      <div className="header-actions">
        <form className="search" role="search" onSubmit={onSearch}>
          <Search size={16} aria-hidden="true" />
          <input
            type="search"
            placeholder="Search professions, communities, topics, or people..."
            aria-label="Search professions, communities, topics, or people"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            maxLength={100}
          />
        </form>

        <button
          type="button"
          className="icon-btn theme-btn"
          onClick={toggleTheme}
          aria-label={themeLabel}
          title={themeLabel}
        >
          {theme === 'dark' ? <Moon size={16} /> : <Sun size={16} />}
        </button>

        {!loading && user && <NotificationBell />}

        {loading ? null : user ? (
          <AccountMenu />
        ) : (
          <>
            <Link to="/sign-in" className="btn btn-ghost">
              Sign In
            </Link>
            <Link to="/sign-up" className="btn btn-dark">
              Sign Up
            </Link>
          </>
        )}
      </div>
    </header>
  );
}
