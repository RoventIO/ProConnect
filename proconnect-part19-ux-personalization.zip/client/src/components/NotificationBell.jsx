import { useCallback, useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, Check } from 'lucide-react';
import { api } from '../api.js';
import { timeAgo } from '../utils/format.js';
import { UserAvatar } from './Ui.jsx';

const POLL_MS = 30000;

/** One line describing the event, e.g. "Priya Raman started a discussion in Kubernetes". */
function describe(n) {
  const who = n.actor?.name || 'Someone';
  return n.type === 'comment_reply'
    ? { head: `${who} replied to your comment`, tail: `in “${n.post.title}”` }
    : { head: `${who} started a discussion in ${n.community.name}`, tail: n.post.title };
}

/** Bell button with an unread badge and a dropdown list, placed directly left of the avatar in the header. */
export default function NotificationBell() {
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);
  const [unread, setUnread] = useState(0);
  const [items, setItems] = useState(null); // null while loading
  const [error, setError] = useState('');
  const wrap = useRef(null);

  const refreshCount = useCallback(async () => {
    try {
      const d = await api('/notifications/unread-count');
      setUnread(d.unreadCount);
    } catch {
      /* the badge simply keeps its last value */
    }
  }, []);

  const loadList = useCallback(async () => {
    setError('');
    try {
      const d = await api('/notifications?limit=20');
      setItems(d.notifications);
      setUnread(d.unreadCount);
    } catch (err) {
      setError(err.message || 'Could not load notifications.');
      setItems([]);
    }
  }, []);

  // Keep the badge fresh: on load, every 30 seconds, and when the tab becomes visible again.
  useEffect(() => {
    refreshCount();
    const timer = setInterval(() => document.visibilityState === 'visible' && refreshCount(), POLL_MS);
    const onVisible = () => document.visibilityState === 'visible' && refreshCount();
    document.addEventListener('visibilitychange', onVisible);
    return () => {
      clearInterval(timer);
      document.removeEventListener('visibilitychange', onVisible);
    };
  }, [refreshCount]);

  useEffect(() => {
    if (!open) return undefined;
    loadList();
    const onClick = (e) => wrap.current && !wrap.current.contains(e.target) && setOpen(false);
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('mousedown', onClick);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onClick);
      document.removeEventListener('keydown', onKey);
    };
  }, [open, loadList]);

  const markRead = async (n) => {
    if (n.read) return;
    setItems((list) => list.map((x) => (x.id === n.id ? { ...x, read: true } : x)));
    setUnread((c) => Math.max(0, c - 1));
    try {
      const d = await api(`/notifications/${n.id}/read`, { method: 'POST' });
      setUnread(d.unreadCount);
    } catch {
      loadList(); // restore the real state if it could not be saved
    }
  };

  const markAll = async () => {
    setItems((list) => list.map((x) => ({ ...x, read: true })));
    setUnread(0);
    try {
      await api('/notifications/read-all', { method: 'POST' });
    } catch {
      loadList();
    }
  };

  const openItem = async (n) => {
    setOpen(false);
    await markRead(n);
    const [path, hash] = n.link.split('#');
    navigate(path + (hash ? `#${hash}` : ''));
  };

  const label = unread ? `Notifications, ${unread} unread` : 'Notifications';

  return (
    <div className="notif-menu" ref={wrap}>
      <button type="button" className="icon-btn theme-btn notif-btn" aria-haspopup="dialog" aria-expanded={open} aria-label={label} title="Notifications" onClick={() => setOpen((o) => !o)}>
        <Bell size={16} />
        {unread > 0 && <span className="notif-badge" aria-hidden="true">{unread > 99 ? '99+' : unread}</span>}
      </button>
      {open && (
        <div className="dropdown notif-panel" role="dialog" aria-label="Notifications">
          <div className="notif-head">
            <strong>Notifications</strong>
            <button type="button" className="notif-link" onClick={markAll} disabled={!unread}>Mark all as read</button>
          </div>
          {items === null && <p className="muted notif-empty" role="status">Loading…</p>}
          {error && <p className="field-error notif-empty" role="alert">{error}</p>}
          {items && !error && items.length === 0 && (
            <p className="muted notif-empty">No notifications yet. You will see new discussions in communities you joined and replies to your comments here.</p>
          )}
          {items && items.length > 0 && (
            <ul className="notif-list">
              {items.map((n) => {
                const { head, tail } = describe(n);
                return (
                  <li key={n.id} className={`notif-item ${n.read ? 'is-read' : 'is-unread'}`}>
                    <button type="button" className="notif-open" onClick={() => openItem(n)}>
                      <UserAvatar user={{ name: n.actor?.name || '?', avatarUrl: n.actor?.avatarUrl }} size={34} />
                      <span className="notif-text">
                        <span className="notif-title">{head}</span>
                        <span className="notif-sub">{tail}</span>
                        <small>{n.type === 'comment_reply' ? `${n.community.name} · ` : ''}{timeAgo(n.createdAt)}{n.read ? '' : ' · Unread'}</small>
                      </span>
                      {!n.read && <span className="notif-dot" aria-hidden="true" />}
                    </button>
                    {!n.read && (
                      <button type="button" className="icon-btn notif-mark" aria-label="Mark as read" title="Mark as read" onClick={() => markRead(n)}>
                        <Check size={14} />
                      </button>
                    )}
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
