import { Link } from 'react-router-dom';
import { ArrowRight, Check, Circle } from 'lucide-react';
import { HOME_SECTIONS, usePreferences } from '../context/PreferencesContext.jsx';
import { Avatar, BotBadge, SampleTag } from './Ui.jsx';
import JobCard from './JobCard.jsx';
import { STATUS_LABELS } from './StatusPicker.jsx';
import { initialsOf, timeAgo, courseBadge, courseNote } from '../utils/format.js';
import { MODE_LABEL, STATUS_LABEL, APPLICATION_STATUSES } from '../utils/jobLabels.js';

const greeting = (now = new Date()) => (now.getHours() < 12 ? 'Good morning' : now.getHours() < 18 ? 'Good afternoon' : 'Good evening');

function WelcomePanel({ profile }) {
  const first = (profile.name || '').trim().split(/\s+/)[0] || 'there';
  const line = [profile.profession, STATUS_LABELS[profile.status] || profile.status].filter(Boolean).join(' · ');
  const { percent, completed, total } = profile.completion;
  return (
    <section className="card dash-welcome" aria-labelledby="dash-greeting">
      <span className="pill pill-accent">Your Home</span>
      <h2 id="dash-greeting" className="serif">{greeting()}, {first}</h2>
      <p className="dash-role">{line || 'Add your profession to complete your profile'}</p>
      <p className="muted">
        Your profile is <strong>{percent}% complete</strong> ({completed} of {total} steps).{' '}
        {percent < 100 ? 'A fuller profile helps professionals find and trust you.' : 'Well done, nothing is missing.'}
      </p>
    </section>
  );
}

/** Profile strength: the percentage and the checklist both come from the member's real data (computed by the server). */
function ProfileStrength({ completion }) {
  const todo = completion.items.filter((i) => !i.done);
  const done = completion.items.filter((i) => i.done);
  return (
    <section className="card dash-strength" aria-labelledby="dash-strength-title">
      <div className="card-head">
        <h3 id="dash-strength-title">Profile strength</h3>
        <span className="strength-percent">{completion.percent}%</span>
      </div>
      <div className="strength-bar" role="progressbar" aria-labelledby="dash-strength-title" aria-valuemin={0} aria-valuemax={100} aria-valuenow={completion.percent} aria-valuetext={`${completion.percent} percent complete`}>
        <span style={{ width: `${completion.percent}%` }} />
      </div>
      {todo.length === 0 ? (
        <p className="muted">Your profile is complete. Keep it up to date as you grow.</p>
      ) : (
        <>
          <p className="muted strength-sub">{todo.length} {todo.length === 1 ? 'step' : 'steps'} left</p>
          <ul className="strength-list" aria-label="Steps to complete">
            {todo.map((i) => (
              <li key={i.key}>
                <Link to={i.href}><Circle size={14} aria-hidden="true" /> <span>{i.label}</span> <ArrowRight size={14} aria-hidden="true" /></Link>
              </li>
            ))}
          </ul>
        </>
      )}
      {done.length > 0 && (
        <details className="strength-done">
          <summary>{done.length} completed</summary>
          <ul className="strength-list is-done">
            {done.map((i) => <li key={i.key}><span><Check size={14} aria-hidden="true" /> {i.label}</span></li>)}
          </ul>
        </details>
      )}
    </section>
  );
}

function Empty({ children }) { return <p className="muted dash-empty">{children}</p>; }

function NewInCommunities({ data }) {
  return (
    <section className="card" aria-labelledby="dash-new">
      <div className="card-head"><h3 id="dash-new">New in Your Communities</h3><Link to="/communities" className="view-all">My Communities</Link></div>
      <p className="card-sub">Recent discussions from communities you joined</p>
      {data.items.length === 0 ? (
        data.joinedCount === 0
          ? <Empty>You have not joined a community yet. <Link to="/communities">Find communities to join</Link> and their new discussions appear here.</Empty>
          : <Empty>No new discussions from other members yet.</Empty>
      ) : (
        <ul className="list">
          {data.items.map((p) => (
            <li className="row" key={p.id}>
              <Avatar text={initialsOf(p.author.name)} src={p.author.avatarUrl} />
              <div className="row-body">
                <strong><Link to={`/posts/${p.id}`} className="post-link">{p.title}</Link></strong>
                <small>
                  <Link to={`/members/${p.author.id}`}>{p.author.name}</Link>{p.author.isBot && <BotBadge />} · <Link to={`/communities/${p.community.id}`}>{p.community.name}</Link>
                  {p.parentCommunity && <> in <Link to={`/communities/${p.parentCommunity.id}`}>{p.parentCommunity.name}</Link></>}
                </small>
                <small className="muted">{p.replyCount} {p.replyCount === 1 ? 'reply' : 'replies'} · {timeAgo(p.createdAt)}</small>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function CommunitiesForYou({ items }) {
  return (
    <section className="card" aria-labelledby="dash-communities">
      <div className="card-head"><h3 id="dash-communities">Communities for You</h3><Link to="/communities" className="view-all">Discover</Link></div>
      <p className="card-sub">Based on your profession and skills</p>
      {items.length === 0 ? (
        <Empty>You have joined every community. Nothing new to suggest right now.</Empty>
      ) : (
        <ul className="list">
          {items.map((c) => (
            <li className="row" key={c.id}>
              <Avatar text={initialsOf(c.name)} />
              <div className="row-body">
                <strong><Link to={`/communities/${c.id}`} className="post-link">{c.name}</Link></strong>
                <small>{c.reason.text}</small>
                <small className="muted">{c.memberCount} {c.memberCount === 1 ? 'member' : 'members'} · {c.postCount} {c.postCount === 1 ? 'post' : 'posts'}</small>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

function JobsForYou({ data }) {
  const params = new URLSearchParams();
  if (data.category) params.set('category', data.category.key);
  if (data.workMode) params.set('mode', data.workMode);
  const basis = [data.category?.label, data.workMode && MODE_LABEL[data.workMode]].filter(Boolean).join(' · ');
  return (
    <section className="card dash-wide" aria-labelledby="dash-jobs">
      <div className="card-head"><h3 id="dash-jobs">Jobs for You</h3><Link to="/jobs" className="view-all">All jobs</Link></div>
      {!data.hasPreferences ? (
        <Empty>Choose a preferred job category and work mode in <Link to="/settings">Preferences</Link> to see matching jobs here.</Empty>
      ) : (
        <>
          <p className="card-sub">Matching your preferences: {basis}</p>
          {data.items.length === 0 ? (
            <Empty>No stored listings match these preferences right now. <Link to="/settings">Change your preferences</Link> or <Link to="/jobs">browse all jobs</Link>.</Empty>
          ) : (
            <>
              <div className="job-grid">{data.items.map((j) => <JobCard key={j.id} job={j} />)}</div>
              {data.total > data.items.length && <p className="dash-more"><Link to={`/jobs?${params}`}>See all {data.total} matching jobs <ArrowRight size={14} aria-hidden="true" /></Link></p>}
            </>
          )}
        </>
      )}
    </section>
  );
}

function JobSearch({ data }) {
  const a = data.applications;
  return (
    <section className="card" aria-labelledby="dash-search">
      <div className="card-head"><h3 id="dash-search">Your Job Search</h3></div>
      <div className="search-stats">
        <Link to="/saved-jobs" className="search-stat"><strong>{data.savedCount}</strong><span>Saved {data.savedCount === 1 ? 'job' : 'jobs'}</span></Link>
        <Link to="/applications" className="search-stat"><strong>{a.total}</strong><span>{a.total === 1 ? 'Application' : 'Applications'}</span></Link>
      </div>
      {a.total > 0 ? (
        <ul className="chips" aria-label="Applications by status">
          {APPLICATION_STATUSES.filter((s) => a[s.key] > 0).map((s) => <li key={s.key} className="pill pill-sample">{STATUS_LABEL[s.key]} {a[s.key]}</li>)}
        </ul>
      ) : (
        <Empty>You are not tracking any applications yet.</Empty>
      )}
      <div className="dash-links">
        <Link to="/saved-jobs">Saved Jobs <ArrowRight size={14} aria-hidden="true" /></Link>
        <Link to="/applications">My Applications <ArrowRight size={14} aria-hidden="true" /></Link>
      </div>
    </section>
  );
}

function Registrations({ data }) {
  return (
    <section className="card" aria-labelledby="dash-registrations">
      <div className="card-head"><h3 id="dash-registrations">Your Registrations</h3>{data.items.some((c) => c.isSample) && <SampleTag />}</div>
      <p className="card-sub">Upcoming courses and webinars</p>
      {data.items.length === 0 ? (
        <Empty>You are not registered for any upcoming course or webinar. <Link to="/courses">Browse what is on</Link>.</Empty>
      ) : (
        <ul className="list">
          {data.items.map((c) => (
            <li className="row" key={c.id}>
              <span className="date-chip" aria-hidden="true">{courseBadge(c)}</span>
              <div className="row-body">
                <strong><Link to={`/courses/${c.id}`} className="post-link">{c.title}</Link></strong>
                <small>{c.type === 'webinar' ? 'Webinar' : 'Course'}{c.organizer ? ` · ${c.organizer}` : ''}</small>
                <small className="muted">{courseNote(c)}</small>
              </div>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}

/**
 * The member's personal Home (Part 19). `personal` is the additive block of GET /api/home. Sections the member hid in Preferences are
 * not drawn (the data is still delivered, nothing is lost); a note says how many are hidden and where to bring them back.
 */
export default function PersonalDashboard({ personal }) {
  const { prefs } = usePreferences();
  const shown = (key) => prefs.homeSections[key] !== false;
  const hiddenCount = HOME_SECTIONS.filter((s) => !shown(s.key)).length;
  return (
    <div className="dash" aria-label="Your dashboard">
      <div className="dash-top">
        <WelcomePanel profile={personal.profile} />
        <ProfileStrength completion={personal.profile.completion} />
      </div>
      <div className="dash-grid">
        {shown('newInCommunities') && <NewInCommunities data={personal.newInCommunities} />}
        {shown('communitiesForYou') && <CommunitiesForYou items={personal.communitiesForYou} />}
        {shown('jobsForYou') && <JobsForYou data={personal.jobsForYou} />}
        {shown('jobSearch') && <JobSearch data={personal.jobSearch} />}
        {shown('registrations') && <Registrations data={personal.registrations} />}
      </div>
      {hiddenCount > 0 && (
        <p className="muted dash-hidden" role="note">
          {hiddenCount} {hiddenCount === 1 ? 'section is' : 'sections are'} hidden. <Link to="/settings">Show {hiddenCount === 1 ? 'it' : 'them'} in Preferences</Link>.
        </p>
      )}
    </div>
  );
}
