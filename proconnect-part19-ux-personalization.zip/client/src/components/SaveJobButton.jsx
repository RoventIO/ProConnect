import { useEffect, useState } from 'react';
import { Bookmark, BookmarkCheck } from 'lucide-react';
import { api } from '../api.js';

/**
 * Save / Saved toggle for one job. `savedId` is the id of the member's saved-job record (null when not saved).
 * The button changes only after the server confirms, shows a busy state meanwhile and reports a failure next to itself.
 * onChange(newSavedId) lets the parent keep its own copy in step.
 */
export default function SaveJobButton({ jobId, savedId: initial = null, title = 'this job', onChange, size = 'sm' }) {
  const [savedId, setSavedId] = useState(initial ?? null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  useEffect(() => setSavedId(initial ?? null), [initial]);

  const apply = (id) => {
    setSavedId(id);
    onChange?.(id);
  };

  async function toggle() {
    if (busy) return;
    setBusy(true);
    setError('');
    try {
      if (savedId) {
        try {
          await api(`/saved-jobs/${savedId}`, { method: 'DELETE' });
        } catch (e) {
          if (e.status !== 404) throw e; // already removed somewhere else: the goal is reached
        }
        apply(null);
      } else {
        try {
          const r = await api('/saved-jobs', { method: 'POST', body: { jobId } });
          apply(r.savedJob.id);
        } catch (e) {
          if (e.code === 'already_saved' && e.details?.savedId) apply(e.details.savedId); // saved in another tab: show the truth
          else throw e;
        }
      }
    } catch (e) {
      setError(e.code === 'job_not_found' ? 'This listing is no longer available, so it cannot be saved.' : e.message || 'Could not update your saved jobs. Try again.');
    } finally {
      setBusy(false);
    }
  }

  const Icon = savedId ? BookmarkCheck : Bookmark;
  return (
    <span className="save-job">
      <button
        type="button"
        className={`btn ${size === 'sm' ? 'btn-sm' : ''} ${savedId ? 'btn-joined' : 'btn-ghost'}`}
        aria-pressed={!!savedId}
        aria-busy={busy}
        disabled={busy}
        aria-label={savedId ? `Remove ${title} from saved jobs` : `Save ${title}`}
        onClick={toggle}
      >
        <Icon size={14} aria-hidden="true" /> {busy ? (savedId ? 'Removing…' : 'Saving…') : savedId ? 'Saved' : 'Save Job'}
      </button>
      {error && <small className="field-error save-job-error" role="alert">{error}</small>}
    </span>
  );
}
