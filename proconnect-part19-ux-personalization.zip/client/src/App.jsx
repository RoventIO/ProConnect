import { Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar.jsx';
import Header from './components/Header.jsx';
import { RequireAuth, GuestOnly } from './components/Guards.jsx';
import { useLayout } from './context/LayoutContext.jsx';
import { PreferencesProvider } from './context/PreferencesContext.jsx';
import Home from './pages/Home.jsx';
import SignIn from './pages/SignIn.jsx';
import SignUp from './pages/SignUp.jsx';
import Onboarding from './pages/Onboarding.jsx';
import Profile from './pages/Profile.jsx';
import Communities from './pages/Communities.jsx';
import CommunityDetail from './pages/CommunityDetail.jsx';
import PostDetail from './pages/PostDetail.jsx';
import Search from './pages/Search.jsx';
import Courses from './pages/Courses.jsx';
import CourseDetail from './pages/CourseDetail.jsx';
import News from './pages/News.jsx';
import NewsSources from './pages/NewsSources.jsx';
import Jobs from './pages/Jobs.jsx';
import JobDetail from './pages/JobDetail.jsx';
import SavedJobs from './pages/SavedJobs.jsx';
import Applications from './pages/Applications.jsx';
import Settings from './pages/Settings.jsx';
import Placeholder from './pages/Placeholder.jsx';

export default function App() {
  const { collapsed } = useLayout();
  // Skip link: the first thing a keyboard user can reach; it moves focus past the sidebar and header to the page content.
  const skipToContent = (e) => {
    e.preventDefault();
    const main = document.getElementById('main-content');
    if (main) {
      main.focus();
      if (typeof main.scrollIntoView === 'function') main.scrollIntoView();
    }
  };
  return (
    <PreferencesProvider>
    <a className="skip-link" href="#main-content" onClick={skipToContent}>Skip to content</a>
    <div className={`app ${collapsed ? 'collapsed' : ''}`}>
      <Sidebar />
      <div className="main">
        <Header />
        <main className="content" id="main-content" tabIndex={-1}>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/sign-in" element={<GuestOnly><SignIn /></GuestOnly>} />
            <Route path="/sign-up" element={<GuestOnly><SignUp /></GuestOnly>} />
            <Route path="/onboarding" element={<RequireAuth allowIncomplete><Onboarding /></RequireAuth>} />
            <Route path="/communities" element={<RequireAuth><Communities /></RequireAuth>} />
            <Route path="/communities/:id" element={<RequireAuth><CommunityDetail /></RequireAuth>} />
            <Route path="/courses" element={<RequireAuth><Courses /></RequireAuth>} />
            <Route path="/courses/:id" element={<RequireAuth><CourseDetail /></RequireAuth>} />
            <Route path="/news" element={<RequireAuth><News /></RequireAuth>} />
            <Route path="/jobs" element={<RequireAuth><Jobs /></RequireAuth>} />
            <Route path="/jobs/:id" element={<RequireAuth><JobDetail /></RequireAuth>} />
            <Route path="/settings" element={<RequireAuth><Settings /></RequireAuth>} />
            <Route path="/saved-jobs" element={<RequireAuth><SavedJobs /></RequireAuth>} />
            <Route path="/applications" element={<RequireAuth><Applications /></RequireAuth>} />
            <Route path="/news/sources" element={<RequireAuth><NewsSources /></RequireAuth>} />
            <Route path="/search" element={<RequireAuth><Search /></RequireAuth>} />
            <Route path="/posts/:id" element={<RequireAuth><PostDetail /></RequireAuth>} />
            <Route path="/profile" element={<RequireAuth><Profile self /></RequireAuth>} />
            <Route path="/members/:id" element={<RequireAuth><Profile /></RequireAuth>} />
            <Route path="*" element={<Placeholder title="Page not found" />} />
          </Routes>
        </main>
      </div>
    </div>
    </PreferencesProvider>
  );
}
