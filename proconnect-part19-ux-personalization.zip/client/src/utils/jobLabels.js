// Labels shared by the Jobs, Saved Jobs, Job details and My Applications pages.
export const MODE_LABEL = { remote: 'Remote', hybrid: 'Hybrid', on_site: 'On-site' };
export const TYPE_LABEL = { full_time: 'Full-time', part_time: 'Part-time', internship: 'Internship', contract: 'Contract' };
export const LEVEL_LABEL = { entry: 'Entry level', mid: 'Mid level', senior: 'Senior', management: 'Management' };

/** Application statuses, in the order of the pipeline, with the CSS class that colours the indicator. */
export const APPLICATION_STATUSES = [
  { key: 'applied', label: 'Applied' },
  { key: 'reviewing', label: 'Reviewing' },
  { key: 'interview', label: 'Interview' },
  { key: 'accepted', label: 'Accepted' },
  { key: 'rejected', label: 'Rejected' },
  { key: 'withdrawn', label: 'Withdrawn' },
];
export const STATUS_LABEL = Object.fromEntries(APPLICATION_STATUSES.map((s) => [s.key, s.label]));

/** ProConnect job category keys (same as the server's list) with their labels, for places that only know the saved key. */
export const JOB_CATEGORIES = [
  { key: 'it-software', label: 'IT & Software Engineering' },
  { key: 'design-creative', label: 'Design & Creative' },
  { key: 'marketing-sales', label: 'Marketing & Sales' },
  { key: 'business-management', label: 'Business & Management' },
  { key: 'finance-accounting', label: 'Finance & Accounting' },
  { key: 'education', label: 'Education' },
  { key: 'healthcare', label: 'Healthcare' },
  { key: 'engineering', label: 'Engineering' },
  { key: 'human-resources', label: 'Human Resources' },
  { key: 'customer-support', label: 'Customer Support' },
  { key: 'data-science', label: 'Data Science & Analytics' },
  { key: 'other', label: 'Other' },
];
export const JOB_CATEGORY_LABEL = Object.fromEntries(JOB_CATEGORIES.map((c) => [c.key, c.label]));
