// The local ProConnect picture shown when an article has no image, or when its image cannot be loaded.
// It is a static file in client/public, so it works without any external service.
export const DEFAULT_NEWS_IMAGE = '/news/proconnect-news-default.svg';
