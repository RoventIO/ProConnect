// Front-end checks for profile links. They mirror server/src/utils/links.js so members get an instant message;
// the server repeats every check and is the one that decides.

const parse = (raw, httpsOnly) => {
  if (typeof raw !== 'string') return null;
  const text = raw.trim();
  if (!text || text.length > 300 || /\s/.test(text)) return null;
  let u;
  try {
    u = new URL(text);
  } catch {
    return null;
  }
  if (u.protocol !== 'https:' && (httpsOnly || u.protocol !== 'http:')) return null;
  if (u.username || u.password || u.port) return null;
  return u;
};

const RESERVED = new Set(['about', 'account', 'apps', 'articles', 'blog', 'business', 'collections', 'contact', 'customer-stories', 'dashboard', 'enterprise', 'events', 'explore', 'features', 'gist', 'issues', 'login', 'logout', 'marketplace', 'new', 'notifications', 'orgs', 'organizations', 'pricing', 'pulls', 'readme', 'search', 'security', 'sessions', 'settings', 'signup', 'site', 'sponsors', 'stars', 'topics', 'trending', 'users', 'watching']);
const OWNER = /^[A-Za-z0-9](?:[A-Za-z0-9-]{0,38})$/;
const REPO = /^[A-Za-z0-9._-]{1,100}$/;
const ownerOk = (o) => OWNER.test(o) && !o.endsWith('-') && !o.includes('--') && !RESERVED.has(o.toLowerCase());

export const LINKEDIN_HINT = 'Enter a LinkedIn profile address such as https://www.linkedin.com/in/your-profile/';
export const GITHUB_PROFILE_HINT = 'Enter a GitHub profile address such as https://github.com/your-username';
export const GITHUB_REPO_HINT = 'Enter a GitHub repository address such as https://github.com/owner/repository';

/** Each check returns an error message, or '' when the address is acceptable. */
export function linkedinError(raw) {
  const u = parse(raw, true);
  const host = u?.hostname.toLowerCase();
  return u && (host === 'linkedin.com' || host.endsWith('.linkedin.com')) && /^\/in\/[^/]{2,100}\/?$/.test(u.pathname) ? '' : LINKEDIN_HINT;
}
export function githubProfileError(raw) {
  const u = parse(raw, true);
  const segs = u ? u.pathname.split('/').filter(Boolean) : [];
  return u && ['github.com', 'www.github.com'].includes(u.hostname.toLowerCase()) && segs.length === 1 && /^\/[^/]+\/?$/.test(u.pathname) && ownerOk(segs[0]) ? '' : GITHUB_PROFILE_HINT;
}
export function githubRepoError(raw) {
  const u = parse(raw, true);
  const segs = u ? u.pathname.split('/').filter(Boolean) : [];
  const repo = segs[1]?.replace(/\.git$/i, '');
  return u && ['github.com', 'www.github.com'].includes(u.hostname.toLowerCase()) && segs.length === 2 && /^\/[^/]+\/[^/]+\/?$/.test(u.pathname) && ownerOk(segs[0]) && REPO.test(repo) && repo !== '.' && repo !== '..' ? '' : GITHUB_REPO_HINT;
}
export function demoUrlError(raw) {
  const u = parse(raw, false);
  return u && u.hostname.includes('.') ? '' : 'Enter a full link starting with https://';
}

/** True for a GitHub repository address (decides whether a card shows the GitHub button or a generic link). */
export const isGithubRepo = (url) => !!url && githubRepoError(url) === '';

/** Short readable form of a profile link: "in/jane-doe" or "octocat". */
export const linkedinHandle = (url) => { try { return new URL(url).pathname.replace(/^\/|\/$/g, ''); } catch { return ''; } };
export const githubHandle = (url) => { try { return new URL(url).pathname.replace(/^\/|\/$/g, ''); } catch { return ''; } };
