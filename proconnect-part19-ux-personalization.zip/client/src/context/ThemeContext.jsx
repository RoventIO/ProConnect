import { createContext, useCallback, useContext, useEffect, useState } from 'react';

const ThemeContext = createContext(null);
const KEY = 'pc-theme-v2'; // keeps its name from Part 1; it now also accepts 'system'
const QUERY = '(prefers-color-scheme: dark)';
export const THEME_CHOICES = ['light', 'dark', 'system'];

const media = () => (typeof window !== 'undefined' && typeof window.matchMedia === 'function' ? window.matchMedia(QUERY) : null);
const systemIsDark = () => !!media()?.matches;

function readInitial() {
  try {
    const saved = localStorage.getItem(KEY);
    if (THEME_CHOICES.includes(saved)) return saved;
  } catch {
    /* storage unavailable */
  }
  return 'light'; // default theme matches the WAct reference; dark mode is one click away
}

/**
 * `themePreference` is what the member chose (light, dark or system); `theme` is what is actually shown (light or dark).
 * With "system" the shown theme follows the browser's prefers-color-scheme setting, live. The same rule runs in index.html
 * before React starts, so the page is painted in the right theme from the first frame.
 */
export function ThemeProvider({ children }) {
  const [themePreference, setThemePreference] = useState(readInitial);
  const [osDark, setOsDark] = useState(systemIsDark);

  useEffect(() => {
    const mq = media();
    if (!mq) return undefined;
    const onChange = (e) => setOsDark(e.matches);
    setOsDark(mq.matches);
    if (mq.addEventListener) mq.addEventListener('change', onChange);
    else if (mq.addListener) mq.addListener(onChange);
    return () => {
      if (mq.removeEventListener) mq.removeEventListener('change', onChange);
      else if (mq.removeListener) mq.removeListener(onChange);
    };
  }, []);

  const theme = themePreference === 'system' ? (osDark ? 'dark' : 'light') : themePreference;

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    try {
      localStorage.setItem(KEY, themePreference);
    } catch {
      /* ignore */
    }
  }, [theme, themePreference]);

  const choose = useCallback((next) => {
    if (!THEME_CHOICES.includes(next)) return;
    if (next === 'system') setOsDark(systemIsDark()); // read the browser setting at the moment "System" is chosen
    setThemePreference(next);
  }, []);
  // The header button flips what is shown right now and stores that as an explicit choice.
  const toggleTheme = useCallback(() => setThemePreference(theme === 'dark' ? 'light' : 'dark'), [theme]);

  return <ThemeContext.Provider value={{ theme, themePreference, setThemePreference: choose, toggleTheme }}>{children}</ThemeContext.Provider>;
}

export const useTheme = () => useContext(ThemeContext);
