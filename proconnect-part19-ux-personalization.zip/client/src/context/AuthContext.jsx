import { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { api } from '../api.js';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  // Restore the session (cookie) on first load.
  useEffect(() => {
    api('/auth/me')
      .then((d) => setUser(d.user))
      .catch(() => setUser(null))
      .finally(() => setLoading(false));
  }, []);

  const register = useCallback(async (values) => {
    const d = await api('/auth/register', { method: 'POST', body: values });
    setUser(d.user);
    return d.user;
  }, []);

  const login = useCallback(async (values) => {
    const d = await api('/auth/login', { method: 'POST', body: values });
    setUser(d.user);
    return d.user;
  }, []);

  // Signs out: asks the server to expire the session cookie, and clears the signed-in member from this page whatever the answer is,
  // so no private page keeps showing once the member chose to sign out. Returns { confirmed } (false when the server could not be
  // reached, in which case the cookie may still be valid until it expires; the caller tells the member).
  const logout = useCallback(async () => {
    let confirmed = true;
    try {
      await api('/auth/logout', { method: 'POST' });
    } catch {
      confirmed = false;
    } finally {
      setUser(null);
    }
    return { confirmed };
  }, []);

  const saveProfile = useCallback(async (values) => {
    const d = await api('/profile', { method: 'PUT', body: values });
    setUser(d.user);
    return d.user;
  }, []);

  return (
    <AuthContext.Provider value={{ user, loading, register, login, logout, saveProfile, updateUser: setUser }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
