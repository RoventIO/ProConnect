import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { api } from '../api.js';
import { useAuth } from './AuthContext.jsx';
import { useTheme } from './ThemeContext.jsx';

/** The personalized Home sections, in page order. Keys match the API. */
export const HOME_SECTIONS = [
  { key: 'newInCommunities', label: 'New in Your Communities', hint: 'Recent discussions from the communities you joined' },
  { key: 'communitiesForYou', label: 'Communities for You', hint: 'Suggestions based on your profession and skills' },
  { key: 'jobsForYou', label: 'Jobs for You', hint: 'Listings that match your job preferences' },
  { key: 'jobSearch', label: 'Your Job Search', hint: 'Saved jobs and application summary' },
  { key: 'registrations', label: 'Your Registrations', hint: 'Upcoming courses and webinars you registered for' },
];

export const DEFAULT_PREFERENCES = Object.freeze({
  theme: 'light',
  newsDefaultTab: 'all',
  jobCategory: null,
  jobWorkMode: null,
  homeSections: Object.freeze(Object.fromEntries(HOME_SECTIONS.map((s) => [s.key, true]))),
  persisted: false,
});

const PreferencesContext = createContext(null);

/**
 * Loads the signed-in member's saved preferences (GET /api/preferences) and saves changes (PUT /api/preferences).
 *  - Visitors and members without a finished profile never call the API and simply have the defaults.
 *  - When the member has saved a theme, it is applied after sign-in and on every refresh.
 *  - Saves are sent one after another, so a quick series of changes cannot overwrite each other out of order.
 *  - Signing out clears everything held here.
 * If the preferences cannot be loaded (for example the server is down) the defaults are used and the app keeps working.
 */
export function PreferencesProvider({ children }) {
  const { user, loading: authLoading } = useAuth();
  const { theme, setThemePreference } = useTheme();
  const [prefs, setPrefs] = useState(DEFAULT_PREFERENCES);
  const [loaded, setLoaded] = useState(false);
  const queue = useRef(Promise.resolve());
  const pending = useRef(0);
  const prefsRef = useRef(DEFAULT_PREFERENCES);
  prefsRef.current = prefs;
  const eligible = !!user?.profileCompleted;
  const userId = user?.id ?? null;

  useEffect(() => {
    let alive = true;
    queue.current = Promise.resolve();
    pending.current = 0;
    if (!eligible) {
      setPrefs(DEFAULT_PREFERENCES); // signed out: nothing of the previous member stays in memory
      setLoaded(!authLoading);
      return undefined;
    }
    setLoaded(false);
    api('/preferences')
      .then((d) => {
        if (!alive) return;
        setPrefs(d.preferences);
        if (d.preferences.persisted) setThemePreference(d.preferences.theme); // the member's saved theme wins after sign-in
      })
      .catch(() => { /* keep the defaults; the app works without them */ })
      .finally(() => alive && setLoaded(true));
    return () => { alive = false; };
  }, [eligible, userId, authLoading, setThemePreference]);

  /**
   * Saves a partial change. The screen updates at once; if the server refuses, the previous values come back and the error is thrown
   * so the caller can say what went wrong.
   */
  const save = useCallback((patch) => {
    if (!eligible) return Promise.resolve(null);
    const before = prefsRef.current; // only used to undo when this is the only save in flight
    setPrefs((p) => ({ ...p, ...patch, homeSections: patch.homeSections ? { ...p.homeSections, ...patch.homeSections } : p.homeSections }));
    pending.current += 1;
    const run = queue.current.then(async () => {
      try {
        const d = await api('/preferences', { method: 'PUT', body: patch });
        if (pending.current === 1) setPrefs(d.preferences);
        return d.preferences;
      } catch (err) {
        if (pending.current === 1) setPrefs(before);
        throw err;
      } finally {
        pending.current -= 1;
      }
    });
    queue.current = run.catch(() => {});
    return run;
  }, [eligible]);

  /** The theme control (Settings and the header button): applies the theme now, then stores it for signed-in members. */
  const chooseTheme = useCallback((next) => {
    setThemePreference(next);
    if (!eligible) return Promise.resolve(null);
    return save({ theme: next }).catch(() => null); // the theme is already applied on this device; a failed save is not shown as an error
  }, [eligible, save, setThemePreference]);

  const toggleTheme = useCallback(() => chooseTheme(theme === 'dark' ? 'light' : 'dark'), [chooseTheme, theme]);

  return <PreferencesContext.Provider value={{ prefs, loaded, save, chooseTheme, toggleTheme }}>{children}</PreferencesContext.Provider>;
}

// Outside the provider (a page rendered on its own) everything behaves as "no saved preferences"; nothing is saved.
export function usePreferences() {
  const ctx = useContext(PreferencesContext);
  const themeCtx = useTheme();
  if (ctx) return ctx;
  return {
    prefs: DEFAULT_PREFERENCES,
    loaded: true,
    save: async () => null,
    chooseTheme: async (next) => { themeCtx?.setThemePreference(next); return null; },
    toggleTheme: async () => { themeCtx?.toggleTheme(); return null; },
  };
}
