// Part 17 UI tests: the Jobs page and the Courses & Webinars additions, against a fake server (no network).
import './setup.js';
import React from 'react';
import { createRoot } from 'react-dom/client';
import { act } from 'react-dom/test-utils';
import { MemoryRouter, Routes, Route, useLocation } from 'react-router-dom';
import { FeedbackProvider } from '../src/components/Feedback.jsx';
import { AuthProvider } from '../src/context/AuthContext.jsx';
import { ThemeProvider } from '../src/context/ThemeContext.jsx';
import Jobs from '../src/pages/Jobs.jsx';
import Courses from '../src/pages/Courses.jsx';
import CourseDetail from '../src/pages/CourseDetail.jsx';

let n = 0, failed = 0;
const check = (name, cond) => { n++; if (!cond) failed++; console.log(cond ? 'PASS' : 'FAIL', name); };
const q = (s, r = document) => r.querySelector(s);
const qa = (s, r = document) => [...r.querySelectorAll(s)];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const flush = () => act(async () => { await sleep(0); });
const wait = (ms) => act(async () => { await sleep(ms); });
const click = (el) => act(async () => { el.dispatchEvent(new window.MouseEvent('click', { bubbles: true })); });
const byText = (t, scope = document, sel = 'button') => qa(sel, scope).find((b) => b.textContent.trim() === t || b.textContent.trim().startsWith(t));
const choose = (select, value) => act(async () => {
  Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, 'value').set.call(select, value);
  select.dispatchEvent(new window.Event('change', { bubbles: true }));
});
const typeInto = (el, value) => act(async () => {
  Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set.call(el, value);
  el.dispatchEvent(new window.Event('input', { bubbles: true }));
});

// ---------- fake server ----------
const calls = [];
const ago = (h) => new Date(Date.now() - h * 3600e3).toISOString();
const LABEL = { 'it-software': 'IT & Software Engineering', 'marketing-sales': 'Marketing & Sales', 'finance-accounting': 'Finance & Accounting', healthcare: 'Healthcare', other: 'Other' };
const mkJob = (id, o = {}) => ({
  id, title: `Job ${id}`, company: `Company ${id}`, logoUrl: null, location: 'Berlin', category: { key: o.cat || 'it-software', label: LABEL[o.cat || 'it-software'] },
  employmentType: null, experienceLevel: null, workMode: null, tags: [], summary: `Summary of job ${id}`, publishedAt: ago(id), firstSeenAt: ago(id),
  source: { key: o.src || 'arbeitnow', name: o.src === 'muse' ? 'The Muse' : 'Arbeitnow' }, applyUrl: `https://www.arbeitnow.com/jobs/${id}`, ...o.over,
});
let jobsDb;
let jobsMeta;
let failJobs = false;
let gate = null;
let admin = false;
const reset = () => {
  jobsDb = [
    mkJob(1, { over: { title: 'Senior Developer', company: 'Acme', workMode: 'remote', employmentType: 'full_time', experienceLevel: 'senior', tags: ['Go', 'SQL'] } }),
    mkJob(2, { cat: 'marketing-sales', over: { title: 'Sales Lead', company: 'Brightly', workMode: 'hybrid', employmentType: 'part_time', location: 'Munich' } }),
    mkJob(3, { cat: 'healthcare', src: 'muse', over: { title: 'Registered Nurse', company: 'CareCo', location: 'Austin, TX', experienceLevel: 'entry', applyUrl: 'https://www.themuse.com/jobs/careco/nurse' } }),
    mkJob(4, { cat: 'other', over: { title: 'Bare Minimum', company: 'Plain Co', location: null, summary: null, workMode: null, tags: [] } }),
    mkJob(5, { over: { title: 'Unsafe Link Job', applyUrl: 'javascript:alert(1)' } }),
    ...Array.from({ length: 9 }, (_, i) => mkJob(10 + i, { cat: 'finance-accounting', over: { title: `Accountant ${i}`, company: `Ledger ${i}` } })),
  ];
  jobsMeta = { refreshing: false, sources: [
    { key: 'arbeitnow', name: 'Arbeitnow', site: 'x', status: 'ok', message: 'ok', lastSyncAt: ago(2), lastOkAt: ago(2), stored: 13 },
    { key: 'muse', name: 'The Muse', site: 'x', status: 'ok', message: 'ok', lastSyncAt: ago(2), lastOkAt: ago(2), stored: 1 },
  ], fetchingEnabled: true };
  failJobs = false;
};
reset();
const json = (body, status = 200) => ({ ok: status < 400, status, json: async () => body });
function jobsResponse(sp) {
  const f = (name) => sp.get(name) || '';
  const apply = (skip) => jobsDb.filter((j) => {
    const text = `${j.title} ${j.company} ${j.tags.join(' ')} ${j.summary || ''}`.toLowerCase();
    return (!f('q') || text.includes(f('q').toLowerCase())) && (!f('location') || (j.location || '').toLowerCase().includes(f('location').toLowerCase()))
      && (skip === 'category' || !f('category') || j.category.key === f('category')) && (skip === 'mode' || !f('mode') || j.workMode === f('mode'))
      && (skip === 'type' || !f('type') || j.employmentType === f('type')) && (skip === 'level' || !f('level') || j.experienceLevel === f('level')) && (skip === 'source' || !f('source') || j.source.key === f('source'));
  });
  const count = (list, get) => list.reduce((a, j) => (get(j) ? { ...a, [get(j)]: (a[get(j)] || 0) + 1 } : a), {});
  const list = apply();
  const size = Number(f('pageSize')) || 12, page = Number(f('page')) || 1;
  const stored = jobsDb.length;
  return {
    jobs: list.slice((page - 1) * size, page * size), total: list.length, page, pageSize: size, pageCount: Math.max(Math.ceil(list.length / size), 1),
    facets: {
      categories: Object.entries(LABEL).map(([key, label]) => ({ key, label, count: apply('category').filter((j) => j.category.key === key).length })),
      modes: count(apply('mode'), (j) => j.workMode), types: count(apply('type'), (j) => j.employmentType), levels: count(apply('level'), (j) => j.experienceLevel), sources: count(apply('source'), (j) => j.source.key),
    },
    sources: jobsMeta.sources, totalStored: stored, lastUpdated: ago(2), refreshing: jobsMeta.refreshing, fetchingEnabled: jobsMeta.fetchingEnabled,
  };
}

// courses
const course = (id, o = {}) => ({
  id, title: `Course ${id}`, description: 'A demo.', type: 'course', category: 'Finance & Accounting', organizer: 'Org', isFree: true, priceLabel: 'Free', priceText: null,
  startsAt: new Date(Date.now() + 10 * 864e5).toISOString(), duration: '4 weeks', externalUrl: null, isSample: true, isPast: false, instructorName: 'Ada Example', instructorRole: 'Fictional trainer',
  deliveryMode: 'online', location: null, registrationDeadline: new Date(Date.now() + 8 * 864e5).toISOString(), image: `/courses/demo-${id}.svg`, registrationKind: 'demo', registrationOpen: true, ...o,
});
let courseDb;
let registered;
const resetCourses = () => {
  courseDb = [
    course(1, { title: 'Web Basics', category: 'Programming & IT', type: 'course', isFree: false, priceLabel: 'Paid', priceText: '$149' }),
    course(2, { title: 'Design Talk', category: 'Design & UX', type: 'webinar' }),
    course(3, { title: 'Hybrid Marketing', category: 'Marketing & Sales', deliveryMode: 'hybrid', location: 'Harbor Street Training Room, Yerevan' }),
    course(4, { title: 'Closed Webinar', type: 'webinar', registrationOpen: false }),
    course(5, { title: 'Real Listing', isSample: false, registrationKind: 'external', externalUrl: 'https://example.org/register', instructorName: null, instructorRole: null, deliveryMode: null, image: null, registrationOpen: false, category: 'Healthcare' }),
  ];
  registered = new Set();
};
resetCourses();

globalThis.fetch = async (input, opts = {}) => {
  const url = new URL(input, 'http://localhost');
  const method = opts.method || 'GET';
  calls.push(`${method} ${url.pathname}${url.search}`);
  const p = url.pathname, sp = url.searchParams;
  if (p === '/api/auth/me') return json({ user: { id: 9, name: 'Test', email: 't@example.com', profileCompleted: true, isAdmin: admin } });
  if (p === '/api/jobs' && method === 'GET') {
    if (gate) await gate;
    if (failJobs) return json({ error: { message: 'Jobs are temporarily unavailable.' } }, 500);
    return json(jobsResponse(sp));
  }
  if (p === '/api/jobs/refresh') { jobsMeta.refreshing = true; return json({ started: true }, 202); }
  if (p === '/api/courses') {
    let list = courseDb;
    if (sp.get('type')) list = list.filter((c) => c.type === sp.get('type'));
    if (sp.get('price')) list = list.filter((c) => (sp.get('price') === 'free') === c.isFree);
    if (sp.get('mode')) list = list.filter((c) => c.deliveryMode === sp.get('mode'));
    if (sp.get('category')) list = list.filter((c) => c.category === sp.get('category'));
    const cats = {};
    courseDb.forEach((c) => { cats[c.category] = (cats[c.category] || 0) + 1; });
    const modes = {};
    courseDb.forEach((c) => { if (c.deliveryMode) modes[c.deliveryMode] = (modes[c.deliveryMode] || 0) + 1; });
    return json({ courses: list, facets: { categories: Object.entries(cats).map(([name, count]) => ({ name, count })), modes } });
  }
  const reg = /^\/api\/courses\/(\d+)\/register$/.exec(p);
  if (reg) { const id = Number(reg[1]); if (method === 'POST') registered.add(id); else registered.delete(id); return json({ course: { ...courseDb.find((c) => c.id === id), registered: registered.has(id) } }, method === 'POST' ? 201 : 200); }
  const one = /^\/api\/courses\/(\d+)$/.exec(p);
  if (one) { const c = courseDb.find((x) => x.id === Number(one[1])); return c ? json({ course: { ...c, registered: registered.has(c.id) } }) : json({ error: { message: 'Course or webinar not found.' } }, 404); }
  return json({ error: { message: `unexpected ${p}` } }, 404);
};

const root = createRoot(document.getElementById('root'));
let mountId = 0;
function Where() { const l = useLocation(); window.__loc = l.pathname + l.search; return null; }
const mount = async (ui, path = '/') => {
  await act(async () => {
    root.render(<MemoryRouter key={++mountId} initialEntries={[path]}><ThemeProvider><AuthProvider><FeedbackProvider><Where />{ui}</FeedbackProvider></AuthProvider></ThemeProvider></MemoryRouter>);
  });
  await flush(); await flush();
};
const titles = () => qa('.job-card h3').map((h) => h.textContent);
const lastCall = () => calls.filter((c) => c.startsWith('GET /api/jobs?')).pop();

// ================= Jobs: loading, cards =================
let release;
gate = new Promise((r) => { release = r; });
await mount(<Jobs />, '/jobs');
check('a loading state is shown while the jobs load', !!q('.page-loading[role="status"]') && document.body.textContent.includes('Loading jobs'));
gate = null; release();
await flush(); await flush();
check('the page opens with a title and the newest-first note', q('.jobs-head h2').textContent === 'Jobs' && document.body.textContent.includes('newest first'));
check('the first request asks for page 1 with the default page size', calls.includes('GET /api/jobs?page=1&pageSize=12'));
check('the first 12 of 14 jobs are shown, with a Show more button', titles().length === 12 && !!byText('Show more jobs'));
const first = qa('.job-card')[0];
check('a card shows title, company, location, category, mode, type, level, tags, summary and source', first.textContent.includes('Senior Developer') && first.textContent.includes('Acme') && first.textContent.includes('Berlin')
  && first.textContent.includes('IT & Software Engineering') && first.textContent.includes('Remote') && first.textContent.includes('Full-time') && first.textContent.includes('Senior')
  && first.textContent.includes('Go') && first.textContent.includes('SQL') && first.textContent.includes('Summary of job 1') && first.textContent.includes('Source: Arbeitnow') && first.textContent.includes('Posted'));
const apply = q('a.btn', first);
check('Apply opens the original listing URL in a new tab, safely', apply.getAttribute('href') === 'https://www.arbeitnow.com/jobs/1' && apply.getAttribute('target') === '_blank' && apply.getAttribute('rel').includes('noopener') && apply.getAttribute('rel').includes('noreferrer'));
const bare = qa('.job-card').find((c) => c.textContent.includes('Bare Minimum'));
check('optional details that are missing are hidden, not invented', !bare.querySelector('.job-meta li svg[class*="map"]') && !bare.textContent.includes('Remote') && !bare.querySelector('.job-tags') && !bare.querySelector('.job-summary') && qa('.job-pills .pill', bare).length === 1);
const unsafe = qa('.job-card').find((c) => c.textContent.includes('Unsafe Link Job'));
check('an unsafe link never becomes an Apply button (the only link left on the card is the internal link to the job page)', !q('a[target], a[href^="javascript"], a[href^="http"]', unsafe) && !byText('Apply', unsafe, 'a'));
check('without a logo from the source the card shows initials, not a made-up image', !q('img.job-logo') && qa('.job-logo-initials').length === 12);
check('Show more is the only way to more: nothing else paginates', !byText('Next'));
await click(byText('Show more jobs'));
await flush();
check('Show more appends the rest without duplicates', titles().length === 14 && new Set(titles()).size === 14 && !byText('Show more jobs') && calls.includes('GET /api/jobs?page=2&pageSize=12'));
check('the muse listing names its source', qa('.job-card').find((c) => c.textContent.includes('Registered Nurse')).textContent.includes('Source: The Muse'));

// ================= Jobs: search and filters =================
await typeInto(q('input[type="search"]'), 'nurse');
await wait(450);
check('search waits for a pause in typing, then queries the server', lastCall().includes('q=nurse') && titles().join() === 'Registered Nurse');
check('a Clear filters action appears and shows the count', !!byText('Clear filters') && document.body.textContent.includes('1 job'));
await click(byText('Clear filters'));
await flush();
check('Clear filters empties the box and restores all jobs', q('input[type="search"]').value === '' && titles().length === 12 && !lastCall().includes('q='));
const options = qa('#job-category option').map((o) => o.textContent);
check('the category list offers only categories that have jobs (with counts)', options.includes('All categories') && options.some((o) => o.startsWith('Marketing & Sales (1)')) && options.some((o) => o.startsWith('Finance & Accounting (9)')) && !options.some((o) => o.startsWith('Education')));
await choose(q('#job-category'), 'marketing-sales');
await flush();
check('choosing a category filters the results', lastCall().includes('category=marketing-sales') && titles().join() === 'Sales Lead');
await click(byText('Clear filters'));
await flush();
await typeInto(q('#job-location'), 'austin');
await wait(450);
check('the location filter queries the server', lastCall().includes('location=austin') && titles().join() === 'Registered Nurse');
await click(byText('Clear filters'));
await flush();
const chipLabels = qa('.jobs-chip-rows .chip-btn').map((b) => b.textContent.replace(/\s+/g, ' ').trim());
check('work mode, type and level chips show only what exists in the data, with counts', chipLabels.includes('Remote 1') && chipLabels.includes('Hybrid 1') && !chipLabels.some((l) => l.startsWith('On-site')) && chipLabels.includes('Full-time 1') && chipLabels.includes('Part-time 1')
  && !chipLabels.some((l) => l.startsWith('Contract')) && !chipLabels.some((l) => l.startsWith('Internship')) && chipLabels.includes('Senior 1') && chipLabels.includes('Entry level 1') && !chipLabels.some((l) => l.startsWith('Management')));
await click(byText('Hybrid', document, '.chip-btn'));
await flush();
check('the Remote / Hybrid / On-site filter works and is marked pressed', lastCall().includes('mode=hybrid') && titles().join() === 'Sales Lead' && byText('Hybrid', document, '.chip-btn').getAttribute('aria-pressed') === 'true');
await click(byText('Hybrid', document, '.chip-btn'));
await flush();
check('pressing the chip again removes the filter', !lastCall().includes('mode=') && titles().length === 12);
await click(byText('Part-time', document, '.chip-btn'));
await flush();
check('the employment type filter works', lastCall().includes('type=part_time') && titles().join() === 'Sales Lead');
await click(byText('Clear filters'));
await click(byText('Senior', document, '.chip-btn'));
await flush();
check('the experience level filter works', lastCall().includes('level=senior') && titles().join() === 'Senior Developer');
await click(byText('Clear filters'));
await flush();
check('the Source filter is offered because two sources have listings, and works', !!q('#job-source') && (await choose(q('#job-source'), 'muse'), await flush(), titles().join() === 'Registered Nurse'));
await click(byText('Clear filters'));
await flush();
await typeInto(q('input[type="search"]'), 'zzz-nothing');
await wait(450);
check('no match gives a helpful empty state with a way out', document.body.textContent.includes('No jobs match your search') && !!q('.empty button'));
await click(q('.empty button'));
await flush();
check('the empty state button clears the filters', titles().length === 12);

// ================= Jobs: warnings, errors, empty store, admin =================
jobsMeta.sources[0] = { ...jobsMeta.sources[0], status: 'error', message: 'The source could not be reached.' };
await mount(<Jobs />, '/jobs');
check('when a source failed, stored jobs stay visible with a short notice', titles().length === 12 && document.body.textContent.includes('Arbeitnow could not be fully updated'));
check('a non-administrator has no Refresh button', !q('button[aria-label="Refresh job listings"]'));
failJobs = true;
await mount(<Jobs />, '/jobs');
check('a server error shows an alert with Try again, not a blank page', document.body.textContent.includes('Jobs are temporarily unavailable') && !!q('[role="alert"]') && !!byText('Try again'));
failJobs = false;
await click(byText('Try again'));
await flush();
check('Try again loads the jobs', titles().length === 12);
reset();
jobsDb = [];
jobsMeta.sources.forEach((s, i) => { s.stored = 0; s.status = 'error'; s.message = i ? 'The source answered with HTTP 403.' : 'The source could not be reached.'; });
await mount(<Jobs />, '/jobs');
check('with nothing stored the empty state explains it and lists each source status, without inventing jobs', document.body.textContent.includes('No job listings have been loaded yet') && document.body.textContent.includes('HTTP 403') && qa('.job-card').length === 0);
reset();
admin = true;
await mount(<Jobs />, '/jobs');
const refreshBtn = q('button[aria-label="Refresh job listings"]');
check('an administrator sees Refresh', !!refreshBtn);
await click(refreshBtn);
await flush();
check('Refresh posts to the API, and the page reports the background fetch', calls.includes('POST /api/jobs/refresh') && document.body.textContent.includes('Fetching new listings in the background'));
admin = false;

// ================= Courses & Webinars (Part 17) =================
await mount(<Courses />, '/courses');
check('the demo notice is visible on the list', document.body.textContent.includes('Demo content') && document.body.textContent.includes('fictional'));
check('every generated card is labelled Sample and the real one is not', qa('.course-card').filter((c) => c.textContent.includes('Sample')).length === 4);
const card = qa('.course-card')[0];
check('a card shows image, instructor, category, price', !!q('img.course-img', card) && card.textContent.includes('Ada Example, Fictional trainer') && card.textContent.includes('Programming & IT') && card.textContent.includes('Paid'));
check('Courses and Webinars tabs both have content', (await click(byText('Webinars', document, '.chip-btn')), await flush(), qa('.course-card').length === 2) && (await click(byText('Courses', document, '.chip-btn')), await flush(), qa('.course-card').length === 3));
await click(byText('Clear filters') || byText('All', document, '.chip-btn'));
await flush();
const catOptions = qa('select[aria-label="Filter by category"] option').map((o) => o.textContent);
check('the category filter lists the real categories with counts', catOptions.length === 6 && catOptions.some((o) => o.startsWith('Design & UX (1)')));
await choose(q('select[aria-label="Filter by category"]'), 'Design & UX');
await flush();
check('choosing a category queries the API and narrows the list', calls.includes('GET /api/courses?category=Design+%26+UX') && qa('.course-card h3').map((h) => h.textContent).join() === 'Design Talk');
await click(byText('Clear filters'));
await flush();
const formats = qa('[aria-label="Format"] .chip-btn').map((b) => b.textContent);
check('the format filter offers only formats that exist (Online and Hybrid, no In person)', formats.join() === 'Any format,Online,Hybrid');
await click(byText('Hybrid', document, '.chip-btn'));
await flush();
check('the format filter works', calls.includes('GET /api/courses?mode=hybrid') && qa('.course-card h3').map((h) => h.textContent).join() === 'Hybrid Marketing' && qa('.course-card')[0].textContent.includes('Harbor Street Training Room'));
await click(byText('Clear filters'));
await flush();

const detail = (id) => mount(<Routes><Route path="/courses/:id" element={<CourseDetail />} /></Routes>, `/courses/${id}`);
await detail(1);
check('the detail page shows instructor, delivery, deadline, price and the demo notice', ['Instructor', 'Ada Example, Fictional trainer', 'Online', 'Register by', '$149', 'not a real course'].every((t) => document.body.textContent.includes(t)));
check('demo registration is explained and no external link is offered', !q('.course-cta a') && !!byText('Register (demo)') && document.body.textContent.includes('nothing is sent to an organizer'));
await click(byText('Register (demo)'));
await flush(); await flush();
check('registering calls the API, confirms it is only a demo, and shows the state', calls.includes('POST /api/courses/1/register') && document.body.textContent.includes('Demo registration saved') && document.body.textContent.includes('You are registered (demo)'));
await click(byText('Cancel demo registration'));
await flush(); await flush();
check('the demo registration can be cancelled', calls.includes('DELETE /api/courses/1/register') && !!byText('Register (demo)'));
await detail(4);
check('a closed demo listing shows a disabled "Registration closed"', byText('Registration closed')?.disabled === true);
await detail(5);
check('a real listing keeps its organizer link and shows no demo notice or demo registration', q('.course-cta a')?.getAttribute('href') === 'https://example.org/register' && !byText('Register (demo)') && !document.body.textContent.includes('demonstration listing'));

console.log(`\n${n - failed}/${n} checks passed`);
process.exit(failed ? 1 : 0);
