import './setup.js';
import React from 'react';
import { createRoot } from 'react-dom/client';
import { act } from 'react-dom/test-utils';
import { MemoryRouter, Routes, Route, useLocation } from 'react-router-dom';
import NotificationBell from '../src/components/NotificationBell.jsx';
import Header from '../src/components/Header.jsx';
import { AuthProvider } from '../src/context/AuthContext.jsx';
import { ThemeProvider } from '../src/context/ThemeContext.jsx';

const results = [];
const check = (name, cond) => { results.push([cond ? 'PASS' : 'FAIL', name]); console.log(cond ? 'PASS' : 'FAIL', name); };
const click = (el) => act(async () => { el.dispatchEvent(new window.MouseEvent('click', { bubbles: true })); });
const q = (s) => document.querySelector(s);
const qa = (s) => [...document.querySelectorAll(s)];

const user = { id: 1, name: 'Test User', email: 't@x.io', profileCompleted: true, avatarUrl: null };
let items = [
  { id: 2, type: 'comment_reply', read: false, createdAt: new Date().toISOString(), actor: { id: 9, name: 'Ana Reply' }, community: { id: 1, name: 'Design & UX' }, post: { id: 5, title: 'A great thread' }, commentId: 77, link: '/posts/5#comment-77' },
  { id: 1, type: 'new_discussion', read: false, createdAt: new Date().toISOString(), actor: { id: 8, name: 'Ben Poster' }, community: { id: 1, name: 'Design & UX' }, post: { id: 4, title: 'Fresh discussion' }, commentId: null, link: '/posts/4' },
];
const calls = [];
globalThis.fetch = async (url, opts = {}) => {
  const method = opts.method || 'GET';
  calls.push(`${method} ${url}`);
  const unread = () => items.filter((n) => !n.read).length;
  let body = {};
  if (url.includes('/auth/me')) body = { user };
  else if (url.includes('/notifications/unread-count')) body = { unreadCount: unread() };
  else if (url.endsWith('/notifications/read-all')) { items = items.map((n) => ({ ...n, read: true })); body = { unreadCount: 0 }; }
  else if (/\/notifications\/\d+\/read$/.test(url)) { const id = Number(url.match(/notifications\/(\d+)/)[1]); items = items.map((n) => (n.id === id ? { ...n, read: true } : n)); body = { unreadCount: unread() }; }
  else if (url.includes('/notifications')) body = { notifications: items, unreadCount: unread() };
  return { ok: true, status: 200, json: async () => body };
};

function Where() { const l = useLocation(); return <span id="where">{l.pathname}{l.hash}</span>; }
const root = createRoot(document.getElementById('root'));
await act(async () => {
  root.render(
    <MemoryRouter initialEntries={['/']}>
      <ThemeProvider><AuthProvider>
        <Header /><Where />
      </AuthProvider></ThemeProvider>
    </MemoryRouter>
  );
});

// Placement: the bell is the element immediately before the avatar menu in the header actions.
const actions = q('.header-actions');
const kids = [...actions.children];
const bellIdx = kids.findIndex((k) => k.classList.contains('notif-menu'));
const avatarIdx = kids.findIndex((k) => k.classList.contains('avatar-menu'));
check('bell sits immediately to the left of the profile avatar', bellIdx !== -1 && avatarIdx === bellIdx + 1);
check('bell is a labelled button with an unread badge', q('.notif-btn')?.getAttribute('aria-label') === 'Notifications, 2 unread' && q('.notif-badge')?.textContent === '2');

await click(q('.notif-btn'));
check('clicking opens the panel with both notifications', qa('.notif-item').length === 2 && !!q('[role=dialog][aria-label=Notifications]'));
check('events read correctly (actor, community, discussion)', q('.notif-panel').textContent.includes('Ana Reply replied to your comment') && q('.notif-panel').textContent.includes('Ben Poster started a discussion in Design & UX') && q('.notif-panel').textContent.includes('Fresh discussion'));
check('unread items are visually distinct', qa('.notif-item.is-unread').length === 2 && q('.notif-item.is-unread .notif-dot'));

await click(q('.notif-mark'));
check('marking one as read updates item and badge', qa('.notif-item.is-unread').length === 1 && q('.notif-badge')?.textContent === '1' && calls.includes('POST /api/notifications/2/read'));

await click(qa('.notif-open')[1]);
check('opening an item navigates to its discussion', q('#where').textContent === '/posts/4' && !q('.notif-panel') && q('.notif-badge') === null);

await click(q('.notif-btn'));
check('read items are not marked unread', qa('.notif-item.is-unread').length === 0 && q('.notif-link').disabled === true);

items = [{ ...items[0], read: false }, { ...items[1], read: false }];
await click(q('.notif-btn')); await click(q('.notif-btn'));
await click(qa('.notif-open')[0]);
check('a reply notification links to the exact comment', q('#where').textContent === '/posts/5#comment-77');

items = [];
await click(q('.notif-btn'));
check('empty state is shown when there are no notifications', q('.notif-panel').textContent.includes('No notifications yet'));
await act(async () => { document.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); });
check('Escape closes the panel', !q('.notif-panel'));

const failed = results.filter((r) => r[0] === 'FAIL').length;
console.log(failed ? `${failed} FAILED` : `${results.length} checks passed`);
process.exit(failed ? 1 : 0);
