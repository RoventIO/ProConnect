// Part 7 UI tests. The API is MOCKED here (no server); the real server is covered by test/api.test.js and the browser run.
import './setup.js';
import fs from 'node:fs';
import React from 'react';
import { createRoot } from 'react-dom/client';
import { act } from 'react-dom/test-utils';
import { MemoryRouter, Routes, Route, useLocation } from 'react-router-dom';
import { FeedbackProvider } from '../src/components/Feedback.jsx';
import { AuthProvider } from '../src/context/AuthContext.jsx';
import CommunityDetail from '../src/pages/CommunityDetail.jsx';

const results = [];
const check = (name, cond) => { results.push([cond ? 'PASS' : 'FAIL', name]); console.log(cond ? 'PASS' : 'FAIL', name); };
const flush = async () => { for (let i = 0; i < 4; i++) await act(async () => { await new Promise((r) => setTimeout(r, 0)); }); };
const click = async (el) => { await act(async () => { el.dispatchEvent(new window.MouseEvent('click', { bubbles: true })); }); await flush(); };
const q = (s) => document.querySelector(s);
const qa = (s) => [...document.querySelectorAll(s)];
const btn = (t) => qa('button').find((b) => b.textContent.trim().includes(t));
const type = async (el, value) => {
  const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
  await act(async () => { el.dispatchEvent(new window.Event('input', { bubbles: true })); });
};

const PERMS = {
  admin: { canEdit: true, canEditCategory: true, canCreateSubcommunity: true, canDelete: true, canViewMembers: true, isLeader: false },
  leader: { canEdit: true, canEditCategory: false, canCreateSubcommunity: true, canDelete: false, canViewMembers: true, isLeader: true },
  subLeader: { canEdit: true, canEditCategory: false, canCreateSubcommunity: false, canDelete: false, canViewMembers: true, isLeader: true },
  member: { canEdit: false, canEditCategory: false, canCreateSubcommunity: false, canDelete: false, canViewMembers: true, isLeader: false },
  stranger: { canEdit: false, canEditCategory: false, canCreateSubcommunity: false, canDelete: false, canViewMembers: false, isLeader: false },
};
let who = 'admin';
let isSub = false;
const calls = [];
const community = () => ({
  id: isSub ? 12 : 3, name: isSub ? 'Frontend Development' : 'Software Development', description: 'A long and useful description of this community for the tests.',
  category: 'Software Development', memberCount: 4, postCount: 6, isMember: who !== 'stranger', canJoin: !isSub,
  parent: isSub ? { id: 3, name: 'Software Development' } : null,
  subcommunities: isSub ? [] : [{ id: 12, name: 'Frontend Development', slug: 'sd-frontend', description: 'Browsers, CSS and components.' }],
  permissions: PERMS[who === 'leader' && isSub ? 'subLeader' : who],
});
const json = (body, status = 200) => ({ ok: status < 400, status, json: async () => body });
globalThis.fetch = async (url, opts = {}) => {
  const method = opts.method || 'GET';
  const p = new URL(url, 'http://x');
  calls.push({ method, path: p.pathname + p.search, body: opts.body && typeof opts.body === 'string' ? JSON.parse(opts.body) : null });
  if (p.pathname === '/api/auth/me') return json({ user: { id: 1, name: 'Tester', profileCompleted: true, isAdmin: who === 'admin' } });
  if (/\/communities\/\d+\/members$/.test(p.pathname)) return json({ total: 5, members: [{ id: 9, name: 'Mia Lead', profession: 'Engineer', status: 'professional', isBot: false, isLeader: true, joinedAt: new Date().toISOString() }, { id: 10, name: 'Aiko Bot', profession: 'Frontend Engineer', status: null, isBot: true, isLeader: false, joinedAt: new Date().toISOString() }] });
  if (method === 'PUT' && /\/communities\/\d+$/.test(p.pathname)) return json({ community: community() });
  if (method === 'POST' && p.pathname === '/api/communities') return json({ community: { id: 99 } }, 201);
  if (method === 'DELETE') return json({ ok: true });
  if (/\/communities\/\d+$/.test(p.pathname)) return json({ community: community(), recentPosts: [] });
  return json({});
};

function Where() { const l = useLocation(); return <span id="where">{l.pathname}</span>; }
const root = createRoot(document.getElementById('root'));
let mounts = 0;
async function mount(role, sub = false) {
  who = role; isSub = sub; calls.length = 0;
  await act(async () => {
    root.render(
      <MemoryRouter initialEntries={[sub ? '/communities/12' : '/communities/3']} key={++mounts}>
        <AuthProvider><FeedbackProvider><Where /><Routes><Route path="/communities/:id" element={<CommunityDetail />} /><Route path="/communities" element={<span id="list">list</span>} /></Routes></FeedbackProvider></AuthProvider>
      </MemoryRouter>
    );
  });
  await flush();
}

// ---- who sees which buttons ----
await mount('admin');
check('administrator sees Edit, Add subcommunity and Delete', !!btn('Edit') && !!btn('Add subcommunity') && !!btn('Delete'));
await mount('leader');
check('a leader sees Edit and Add subcommunity but not Delete', !!btn('Edit') && !!btn('Add subcommunity') && !btn('Delete'));
await mount('leader', true);
check('on a subcommunity a leader can Edit but not add a subcommunity or delete', !!btn('Edit') && !btn('Add subcommunity') && !btn('Delete'));
check('a subcommunity names its main community', q('.back-link, a[href="/communities/3"]') !== null && document.body.textContent.includes('Software Development'));
await mount('member');
check('an ordinary member sees no management buttons but can open the member list', !btn('Edit') && !btn('Add subcommunity') && !btn('Delete') && !!btn('Show members'));
await mount('stranger');
check('someone who has not joined sees no member list and no management buttons', !btn('Show members') && !btn('Edit') && !btn('Delete'));

// ---- edit ----
await mount('admin');
check('subcommunities are listed with their descriptions', document.body.textContent.includes('Frontend Development') && document.body.textContent.includes('Browsers, CSS and components.') && !!q('a[href="/communities/12"]'));
await click(btn('Edit'));
check('the edit form is filled with the current values; administrators can edit the category', q('#name').value === 'Software Development' && !!q('#category') && q('#description').value.startsWith('A long and useful'));
await type(q('#name'), 'Software Engineering');
await click(btn('Save changes'));
const put = calls.find((c) => c.method === 'PUT');
check('saving sends only name, description and category to the community', put?.path === '/api/communities/3' && put.body.name === 'Software Engineering' && 'category' in put.body && !('parentId' in put.body) && !q('form[aria-label="Edit community"]'));
await mount('leader');
await click(btn('Edit'));
check('a leader has no category field and the form says who can change it', !q('#category') && document.body.textContent.includes('only administrators can change it'));
await click(btn('Save changes'));
check('a leader saves without sending a category', !('category' in calls.find((c) => c.method === 'PUT').body));

// ---- add subcommunity ----
await click(btn('Add subcommunity'));
check('the add form opens under the community', !!q('form[aria-label="Add subcommunity"]') && document.body.textContent.includes('Add a subcommunity to Software Development'));
await type(q('#sub-name'), 'Backend Development');
await type(q('#sub-description'), 'Servers, APIs and databases for the tests.');
await click(qa('button').filter((b) => b.textContent.trim() === 'Add subcommunity').pop());
const post = calls.find((c) => c.method === 'POST' && c.path === '/api/communities');
check('adding sends the parent community and no category', post?.body.parentId === 3 && post.body.name === 'Backend Development' && !('category' in post.body));

// ---- members ----
await mount('member');
await click(btn('Show members'));
check('the member list shows people, a Community Leader label and the Bot label, and requests the real endpoint', calls.some((c) => c.path.startsWith('/api/communities/3/members')) && document.body.textContent.includes('Mia Lead') && document.body.textContent.includes('Community Leader') && qa('.pill').some((p) => p.textContent === 'Bot'));
check('"Showing 2 of 5" with a way to load more', document.body.textContent.includes('Showing 2 of 5') && !!btn('Show more'));
await click(btn('Hide members'));
check('hiding the list removes it', !document.body.textContent.includes('Mia Lead'));

// ---- delete ----
await mount('admin');
await click(btn('Delete'));
const dialog = q('[role=dialog]');
check('the delete dialog says exactly what disappears', dialog && /1 subcommunity/.test(dialog.textContent) && /6 discussions/.test(dialog.textContent) && /4 memberships/.test(dialog.textContent) && /Member accounts are not deleted/.test(dialog.textContent));
await click(btn('Delete community'));
const del = calls.find((c) => c.method === 'DELETE');
check('confirming calls the API with confirm=true and returns to the directory', del?.path === '/api/communities/3?confirm=true' && q('#where').textContent === '/communities');
await mount('admin');
await click(btn('Delete'));
await click(btn('Cancel'));
check('cancelling deletes nothing', !calls.some((c) => c.method === 'DELETE'));

// ---- readability CSS is scoped to the community pages only ----
const css = fs.readFileSync('src/styles/global.css', 'utf8') /* run from the client folder, like npm test */;
const block = css.slice(css.indexOf('/* ---------- Readability')).replace(/\/\*[\s\S]*?\*\//g, '');
const selectors = [...block.matchAll(/(?:^|\})\s*([^{}@]+)\{/g)].map((m) => m[1].trim()).flatMap((s) => s.split(',').map((x) => x.trim())).filter(Boolean);
check('every readability rule is scoped to .communities or .community-page', selectors.length > 30 && selectors.every((s) => /^\.(communities|community-page)\b/.test(s)));
check('global typography is unchanged (body stays 14px, small stays 12px)', /body \{[^}]*font-size: 14px/.test(css) && /\nsmall \{ font-size: 12px/.test(css));
const px = (re) => Number((block.match(re) || [])[1]);
check('titles and body text are larger than before but moderate', px(/\.community-page \.community-title h2 \{ font-size: (\d+)px/) === 40 && px(/\.community-page \.post-text \{ font-size: (\d+(?:\.\d+)?)px/) === 17 && px(/\.communities \.community-card > p \{ font-size: (\d+(?:\.\d+)?)px/) === 15.5);
check('long names and descriptions wrap instead of overflowing', /\.community-page \.community-title h2 \{[^}]*overflow-wrap: anywhere/.test(block) && /\.community-page \.row-body strong \{[^}]*overflow-wrap: anywhere/.test(block) && /\.communities \.community-card h3 \{[^}]*overflow-wrap: anywhere/.test(block));
check('category pills wrap instead of pushing the page wider on phones', /\.communities \.pill, \.community-page \.pill \{[^}]*white-space: normal/.test(block));
check('the header wraps at tablet widths so no page scrolls sideways', /@media \(min-width: 761px\) and \(max-width: 1000px\) \{\s*\.header \{ flex-wrap: wrap; \}/.test(css));
check('there are tablet and phone adjustments', /@media \(max-width: 900px\)/.test(block) && /@media \(max-width: 600px\)/.test(block));

const failed = results.filter((r) => r[0] === 'FAIL').length;
console.log(failed ? `${failed} FAILED` : `${results.length} checks passed`);
process.exit(failed ? 1 : 0);
