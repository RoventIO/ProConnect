// Part 5 UI checks: profile links and My Work, rendered with the real components in jsdom against a MOCKED backend.
// The mock backend applies the REAL server validators (server/src/utils/links.js). This is not a real-browser test.
import './setup.js';
import React from 'react';
import { createRoot } from 'react-dom/client';
import { act } from 'react-dom/test-utils';
import { MemoryRouter, useLocation } from 'react-router-dom';
import App from '../src/App.jsx';
import { FeedbackProvider } from '../src/components/Feedback.jsx';
import { AuthProvider } from '../src/context/AuthContext.jsx';
import { LayoutProvider } from '../src/context/LayoutContext.jsx';
import { ThemeProvider } from '../src/context/ThemeContext.jsx';
import { checkDemoUrl, checkGithubProfile, checkGithubRepo, checkLinkedIn } from '../../server/src/utils/links.js';

let n = 0, failed = 0;
const check = (name, cond, info) => { n++; if (!cond) failed++; console.log(cond ? 'PASS' : 'FAIL', name); if (!cond && info) console.log('   detail:', typeof info === 'function' ? info() : info); };
const q = (s, r = document) => r.querySelector(s);
const qa = (s, r = document) => [...r.querySelectorAll(s)];
const flush = async () => { for (let i = 0; i < 4; i++) await act(async () => { await new Promise((r) => setTimeout(r, 0)); }); };
const click = (el) => act(async () => { el.dispatchEvent(new window.MouseEvent('click', { bubbles: true, cancelable: true })); });
const setValue = (el, value) => act(async () => {
  const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
  el.dispatchEvent(new window.Event('input', { bubbles: true }));
});
const submit = (form) => act(async () => { form.dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true })); });
const byText = (t, scope = document, sel = 'button') => qa(sel, scope).find((b) => b.textContent.trim() === t || b.textContent.trim().startsWith(t));

// ---------- mocked backend ----------
const json = (body, status = 200) => ({ ok: status < 400, status, json: async () => body });
const err = (status, message, fields) => json({ error: { code: 'validation_error', message, ...(fields ? { fields } : {}) } }, status);
const base = (id, name, extra = {}) => ({ id, name, profession: 'Developer', headline: 'Builds things', bio: 'A biography that is long enough.', skills: ['React'], location: 'Yerevan', yearsExperience: 2, profileCompleted: true, role: 'member', isAdmin: false, status: 'student', isOrganizer: false, isBot: false, avatarUrl: null, linkedinUrl: null, githubUrl: null, ...extra });
let users, items, session, calls, nextId;
const reset = () => {
  calls = [];
  nextId = 100;
  users = {
    1: base(1, 'Maya Chen', { email: 'maya@example.com' }),
    2: base(2, 'Daniel Okoro', { linkedinUrl: 'https://www.linkedin.com/in/daniel-okoro', githubUrl: 'https://github.com/daniel-okoro' }),
    3: base(3, 'Priya Nair', { linkedinUrl: 'https://www.linkedin.com/in/priya-nair' }),
    4: base(4, 'Lukas Brandt'),
  };
  const P = (id, over) => ({ id, kind: 'project', title: `Project ${id}`, subtitle: null, period: null, description: null, url: `https://github.com/someone/repo-${id}`, technologies: [], demoUrl: null, imageUrl: null, ...over });
  items = {
    1: [],
    2: [
      P(11, { title: 'Personal Portfolio Website', description: 'A responsive website showcasing my projects.', url: 'https://github.com/daniel-okoro/portfolio', technologies: ['HTML', 'CSS', 'JavaScript'], demoUrl: 'https://daniel.example.dev', imageUrl: '/api/uploads/' + 'a'.repeat(32) + '.png' }),
      P(12, { title: 'Bare minimum project', url: 'https://github.com/daniel-okoro/minimal' }),
      P(13, { title: 'Old portfolio link', subtitle: 'alexmorgan.design', url: 'https://example.com/alexmorgan.design' }),
      { id: 14, kind: 'experience', title: 'Junior Developer', subtitle: 'Acme', period: '2024', description: null, url: null, technologies: [], demoUrl: null, imageUrl: null },
    ],
    3: [], 4: [],
  };
};
const view = (u, self) => ({
  user: self ? { ...u, email: 'maya@example.com', memberSince: '2026-01-01T00:00:00Z' } : { ...Object.fromEntries(Object.entries(u).filter(([k]) => !['email', 'role', 'isOrganizer'].includes(k))), memberSince: '2026-01-01T00:00:00Z' },
  items: { experience: items[u.id].filter((i) => i.kind === 'experience'), education: [], projects: items[u.id].filter((i) => i.kind === 'project') },
  communities: [], recentPosts: [], stats: { communities: 0, discussions: 0, replies: 0 },
});
reset();
globalThis.fetch = async (input, opts = {}) => {
  const url = new URL(input, 'http://localhost');
  const method = opts.method || 'GET';
  calls.push(`${method} ${url.pathname}`);
  const body = typeof opts.body === 'string' ? JSON.parse(opts.body) : {};
  const p = url.pathname;
  if (p === '/api/auth/me') return json({ user: session ? users[session] : null });
  if (p === '/api/profile' && method === 'GET') return json(view(users[session], true));
  if (p === '/api/profile' && method === 'PUT') {
    const fields = {};
    for (const [k, check] of [['linkedinUrl', checkLinkedIn], ['githubUrl', checkGithubProfile]]) {
      if (body[k] === undefined) continue;
      if (String(body[k]).trim() === '') users[session][k] = null;
      else { const r = check(body[k]); if (r.ok) users[session][k] = r.value; else fields[k] = r.message; }
    }
    if (Object.keys(fields).length) return err(400, 'Please fix the highlighted fields.', fields);
    for (const k of ['profession', 'headline', 'bio', 'location']) if (body[k] !== undefined) users[session][k] = body[k];
    if (body.skills) users[session].skills = body.skills;
    return json({ user: users[session] });
  }
  const other = /^\/api\/users\/(\d+)$/.exec(p);
  if (other) return users[other[1]] ? json(view(users[other[1]], Number(other[1]) === session)) : json({ error: { message: 'Member not found.' } }, 404);
  if (p === '/api/profile/items' && method === 'POST') {
    const r = checkGithubRepo(body.url || '');
    const fields = {};
    if (!body.title) fields.title = 'Enter a title.';
    if (!r.ok) fields.url = r.message;
    if (Object.keys(fields).length) return err(400, 'Please fix the highlighted fields.', fields);
    const item = { id: nextId++, kind: 'project', title: body.title, subtitle: null, period: null, description: body.description || null, url: r.value, technologies: body.technologies || [], demoUrl: body.demoUrl ? checkDemoUrl(body.demoUrl).value : null, imageUrl: null };
    items[session].push(item);
    return json({ item }, 201);
  }
  const one = /^\/api\/profile\/items\/(\d+)(\/image)?$/.exec(p);
  if (one) {
    const it = items[session].find((x) => x.id === Number(one[1]));
    if (!it) return json({ error: { message: 'Entry not found.' } }, 404);
    if (one[2]) { it.imageUrl = method === 'DELETE' ? null : '/api/uploads/' + 'b'.repeat(32) + '.png'; return json({ item: it }); }
    if (method === 'DELETE') { items[session] = items[session].filter((x) => x !== it); return json({ ok: true }); }
    if (method === 'PUT') {
      const r = checkGithubRepo(body.url || '');
      if (!r.ok && body.url !== it.url) return err(400, 'Please fix the highlighted fields.', { url: r.message });
      Object.assign(it, { title: body.title, description: body.description || null, url: r.ok ? r.value : it.url, technologies: body.technologies || [], demoUrl: body.demoUrl || null });
      return json({ item: it });
    }
  }
  return json({ error: { message: 'unexpected ' + method + ' ' + p } }, 404);
};

const root = createRoot(document.getElementById('root'));
function Where() { const l = useLocation(); window.__loc = l.pathname; return null; }
let key = 0;
async function mount(path, userId) {
  session = userId;
  calls.length = 0;
  await act(async () => {
    root.render(
      <MemoryRouter key={++key} initialEntries={[path]}>
        <ThemeProvider><LayoutProvider><AuthProvider><FeedbackProvider><Where /><App /></FeedbackProvider></AuthProvider></LayoutProvider></ThemeProvider>
      </MemoryRouter>
    );
  });
  await flush();
}
const socialLinks = () => qa('.social-links a');
const cards = () => qa('.project-card');
const card = (title) => cards().find((c) => q('h4', c).textContent === title);

// =============== Public profile: LinkedIn and GitHub ===============
await mount('/members/2', 1);
const links = socialLinks();
check('both saved links appear in a dedicated social-links area of the profile header', !!q('.profile-head .social-links') && links.length === 2);
const li = links.find((a) => a.classList.contains('social-linkedin'));
const gh = links.find((a) => a.classList.contains('social-github'));
check('LinkedIn link points to the saved profile and opens safely in a new tab', li.getAttribute('href') === 'https://www.linkedin.com/in/daniel-okoro' && li.target === '_blank' && /noopener/.test(li.rel) && /noreferrer/.test(li.rel));
check('GitHub link points to the saved profile and opens safely in a new tab', gh.getAttribute('href') === 'https://github.com/daniel-okoro' && gh.target === '_blank' && /noopener/.test(gh.rel));
check('each link shows only its brand logo (local inline SVG): no text, username, domain or URL anywhere in the area', q('svg[data-brand="linkedin"]', li) && q('svg[data-brand="github"]', gh) && !q('svg[data-brand="github"]', li) && li.textContent.trim() === '' && gh.textContent.trim() === '' && q('.social-links').textContent.trim() === '' && !/daniel|okoro|linkedin\.com|github\.com|https?:|LinkedIn|GitHub/i.test(q('.social-links').textContent) && qa('.social-links *').every((el) => !el.classList.contains('social-text')));
check('the brand marks are real logo shapes (LinkedIn "in" square, GitHub octocat), not generic symbols', q('svg[data-brand="linkedin"] path', li).getAttribute('d').startsWith('M20.447 20.452') && q('svg[data-brand="github"] path', gh).getAttribute('d').startsWith('M12 .297c-6.63'));
check('no external image is used for the logos', qa('.social-links img').length === 0 && !/https?:\/\/[^"]*\.(png|svg|jpg)/.test(q('.social-links').innerHTML));
check('the accessible names are invisible labels, and the logos are focusable links', li.getAttribute('aria-label') === 'LinkedIn profile' && gh.getAttribute('aria-label') === 'GitHub profile' && q('svg', li).getAttribute('aria-hidden') === 'true' && li.tabIndex >= 0 && gh.tabIndex >= 0 && li.tagName === 'A' && gh.tagName === 'A');
check('another member\'s profile has no social hint or edit buttons', !q('.social-hint') && !byText('Edit Profile'));

await mount('/members/3', 1);
check('only the provided link is shown (LinkedIn only), the missing GitHub link leaves no empty or broken element', socialLinks().length === 1 && !!q('svg[data-brand="linkedin"]') && !q('svg[data-brand="github"]') && qa('.social-links a').every((a) => /^https:\/\//.test(a.getAttribute('href'))));
await mount('/members/4', 1);
check('a member with no links shows no social area at all', !q('.social-links') && !q('.social-link') && !q('svg[data-brand]'));
check('the page never prints "undefined" or "null" for missing data', !/undefined|null/.test(q('.profile').textContent));

// =============== Public profile: My Work ===============
await mount('/members/2', 1);
check('"My Work" is a clearly visible section with one card per project', q('#my-work-title').textContent === 'My Work' && cards().length === 3);
const full = card('Personal Portfolio Website');
check('a full card shows title, description, technology tags and a thumbnail', q('.project-desc', full).textContent.startsWith('A responsive website') && qa('.project-tech li', full).map((x) => x.textContent).join() === 'HTML,CSS,JavaScript' && q('.project-thumb img', full).getAttribute('src').startsWith('/api/uploads/'));
const repo = q('a.project-repo', full);
check('the repository link has the GitHub icon, says "View Repository" and opens the exact repository in a new tab', repo.textContent.includes('View Repository') && !!q('svg[data-brand="github"]', repo) && repo.getAttribute('href') === 'https://github.com/daniel-okoro/portfolio' && repo.target === '_blank' && /noopener/.test(repo.rel));
const demo = q('a.project-demo', full);
check('the optional Live Demo link appears when supplied', demo && demo.textContent.includes('Live Demo') && demo.getAttribute('href') === 'https://daniel.example.dev' && /noopener/.test(demo.rel));
const bare = card('Bare minimum project');
check('a project with only a title and repository shows no empty description, tags, thumbnail or demo', !q('.project-desc', bare) && !q('.project-tech', bare) && !q('.project-thumb', bare) && !q('.project-demo', bare) && !!q('a.project-repo', bare));
const legacy = card('Old portfolio link');
check('an older non-GitHub link is still shown as a plain link (no GitHub icon) with its older label', !!q('a.project-link', legacy) && !q('svg[data-brand="github"]', legacy) && legacy.textContent.includes('Open link') && legacy.textContent.includes('alexmorgan.design') && !q('a.project-repo', legacy));
check('visitors get no Add, Edit or Delete controls', !byText('Add Project') && qa('.project-card .icon-btn').length === 0);
check('experience entries do not leak into My Work', !cards().some((c) => c.textContent.includes('Junior Developer')) && qa('h3').some((h) => h.textContent === 'Work Experience'));
await click(q('.project-thumb img', full).parentElement.querySelector('img'));
await act(async () => { q('.project-thumb img', full).dispatchEvent(new window.Event('error')); });
check('a thumbnail that fails to load disappears instead of showing a broken image', !q('.project-thumb img', card('Personal Portfolio Website')));

await mount('/members/4', 1);
check('a member without projects shows a clean empty state without any Add button for visitors', !!q('.work-empty') && q('.work-empty').textContent.includes('has not shared any projects') && !byText('Add Project') && cards().length === 0);

// =============== Own profile: edit links ===============
reset();
await mount('/profile', 1);
check('own profile without links hides the social area completely (no hint, no empty icon)', !q('.social-hint') && !q('.social-links') && !q('.social-link') && !q('svg[data-brand]'));
await click(byText('Edit Profile'));
const lin = q('#linkedinUrl'), gi = q('#githubUrl');
check('the edit form has the two labelled inputs with the expected placeholders', lin && gi && q('label[for="linkedinUrl"]').textContent === 'LinkedIn Profile URL' && q('label[for="githubUrl"]').textContent === 'GitHub Profile URL' && lin.placeholder === 'https://www.linkedin.com/in/your-profile/' && gi.placeholder === 'https://github.com/your-username');
check('both inputs start empty for an account without links (nothing is invented)', lin.value === '' && gi.value === '');
calls.length = 0;
await setValue(lin, 'javascript:alert(1)');
await setValue(gi, 'https://gitlab.com/maya');
await submit(q('form.edit-card'));
await flush();
check('invalid links show a clear message under each field and nothing is sent', /LinkedIn profile address/.test(q('#linkedinUrl-error').textContent) && /GitHub profile address/.test(q('#githubUrl-error').textContent) && !calls.includes('PUT /api/profile'));
await setValue(lin, 'https://evil.com/in/maya');
await setValue(gi, 'https://github.com/maya/some-repo');
await submit(q('form.edit-card'));
await flush();
check('another domain or a repository address is rejected in the profile fields', !!q('#linkedinUrl-error') && !!q('#githubUrl-error') && !calls.includes('PUT /api/profile'));
await setValue(lin, 'https://www.linkedin.com/in/maya-chen/');
await setValue(gi, 'https://github.com/maya-chen');
await submit(q('form.edit-card'));
await flush();
check('valid links are saved through the API and appear immediately with their icons', calls.includes('PUT /api/profile') && users[1].linkedinUrl === 'https://www.linkedin.com/in/maya-chen' && users[1].githubUrl === 'https://github.com/maya-chen' && socialLinks().length === 2 && !q('form.edit-card') && !q('.social-hint'));
await mount('/profile', 1); // simulates refresh / signing in again
check('after a refresh the saved links are still there', socialLinks().length === 2 && socialLinks()[0].getAttribute('href') === 'https://www.linkedin.com/in/maya-chen');
await click(byText('Edit Profile'));
check('the form is pre-filled with the saved links', q('#linkedinUrl').value === 'https://www.linkedin.com/in/maya-chen' && q('#githubUrl').value === 'https://github.com/maya-chen');
await setValue(q('#githubUrl'), '');
await submit(q('form.edit-card'));
await flush();
check('emptying a field removes that link and its icon; the other stays', users[1].githubUrl === null && socialLinks().length === 1 && !q('svg[data-brand="github"]') && !!q('svg[data-brand="linkedin"]'));
check('existing profile content and status controls are intact', qa('h3').map((h) => h.textContent).includes('Biography') && qa('h3').map((h) => h.textContent).includes('Skills') && !!q('section[aria-label="Professional status"]') && qa('h3').map((h) => h.textContent).includes('Education'));

// =============== Own profile: My Work ===============
reset();
await mount('/profile', 1);
check('own empty My Work shows a friendly message and an "Add Project" action', q('.work-empty').textContent.includes('No projects yet') && !!byText('Add Project', q('.work-empty')));
await click(byText('Add Project', q('.work-empty')));
check('the form asks for title, description, GitHub repository, technologies, demo and an optional thumbnail', ['project-title', 'project-description', 'project-url', 'project-technologies', 'project-demo', 'project-image'].every((id) => !!q('#' + id)) && q('#project-url').placeholder === 'https://github.com/owner/repository' && q('label[for="project-url"]').textContent.includes('GitHub repository URL'));
calls.length = 0;
await submit(q('form.project-form'));
await flush();
check('a project needs a title and a repository address (messages shown, nothing sent)', !!q('#project-title-error') && !!q('#project-url-error') && !calls.some((c) => c.startsWith('POST')));
await setValue(q('#project-title'), 'Portfolio');
await setValue(q('#project-url'), 'https://example.com/me/portfolio');
await submit(q('form.project-form'));
await flush();
check('a repository address on another site is rejected with a clear message', /GitHub repository address/.test(q('#project-url-error').textContent) && !calls.some((c) => c.startsWith('POST')));
await setValue(q('#project-url'), 'javascript:alert(1)');
await submit(q('form.project-form'));
await flush();
check('javascript: addresses are rejected', !!q('#project-url-error') && !calls.some((c) => c.startsWith('POST')));
await setValue(q('#project-url'), 'https://github.com/maya-chen/portfolio');
await setValue(q('#project-description'), 'A responsive website.');
await setValue(q('#project-technologies'), 'HTML, CSS, JavaScript');
await setValue(q('#project-demo'), 'https://maya.example.dev');
await submit(q('form.project-form'));
await flush();
check('saving adds the card immediately with all details and closes the form', calls.includes('POST /api/profile/items') && cards().length === 1 && !q('form.project-form') && !q('.work-empty') && items[1].length === 1);
const mine = card('Portfolio');
check('the new card shows description, tags, repository and demo links', mine.textContent.includes('A responsive website.') && qa('.project-tech li', mine).length === 3 && q('a.project-repo', mine).getAttribute('href') === 'https://github.com/maya-chen/portfolio' && !!q('a.project-demo', mine));
await mount('/profile', 1);
check('the project is still there after a refresh', cards().length === 1);
check('the owner sees edit and delete buttons and an Add Project button in the header', !!q('[aria-label="Edit Portfolio"]') && !!q('[aria-label="Delete Portfolio"]') && !!q('.my-work .card-head .btn'));

await click(q('[aria-label="Edit Portfolio"]'));
check('editing opens the form pre-filled with the saved values', q('#project-title').value === 'Portfolio' && q('#project-url').value === 'https://github.com/maya-chen/portfolio' && q('#project-technologies').value === 'HTML, CSS, JavaScript');
await setValue(q('#project-title'), 'Portfolio v2');
await setValue(q('#project-url'), 'https://github.com/maya-chen/portfolio-v2');
await submit(q('form.project-form'));
await flush();
check('the update is saved and the new title and repository link show at once', calls.includes('PUT /api/profile/items/' + items[1][0].id) && !!card('Portfolio v2') && q('a.project-repo', card('Portfolio v2')).getAttribute('href') === 'https://github.com/maya-chen/portfolio-v2');

// thumbnail upload through the form
await click(q('[aria-label="Edit Portfolio v2"]'));
const fileInput = q('#project-image');
const pngFile = new window.File([new Uint8Array([1, 2, 3])], 'thumb.png', { type: 'image/png' });
await act(async () => { Object.defineProperty(fileInput, 'files', { value: [pngFile], configurable: true }); fileInput.dispatchEvent(new window.Event('change', { bubbles: true })); });
check('the chosen thumbnail is named in the form', q('.project-form').textContent.includes('Selected: thumb.png'));
await submit(q('form.project-form'));
await flush();
check('the thumbnail is uploaded after the project is saved and then shown', calls.some((c) => /POST \/api\/profile\/items\/\d+\/image/.test(c)) && !!q('.project-thumb img', card('Portfolio v2')));

// delete with confirmation
calls.length = 0;
await click(q('[aria-label="Delete Portfolio v2"]'));
await flush();
check('deleting asks for confirmation first and nothing is deleted yet', !!q('.modal') && q('.modal').textContent.includes('Delete "Portfolio v2"?') && !calls.some((c) => c.startsWith('DELETE')) && cards().length === 1);
await click(byText('Cancel', q('.modal')));
await flush();
check('cancelling keeps the project', !q('.modal') && cards().length === 1);
await click(q('[aria-label="Delete Portfolio v2"]'));
await flush();
await click(byText('Delete project', q('.modal')));
await flush();
check('confirming deletes it from the database and the list, and the empty state returns', calls.some((c) => c.startsWith('DELETE /api/profile/items/')) && items[1].length === 0 && cards().length === 0 && !!q('.work-empty'));

console.log(`\n${n - failed}/${n} checks passed`);
process.exit(failed ? 1 : 0);
