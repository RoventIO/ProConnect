// Part 4 UI checks: the News page and the Admin source page, run against the real components with a MOCKED backend (jsdom, not a real browser).
import './setup.js';
import React from 'react';
import { createRoot } from 'react-dom/client';
import { act } from 'react-dom/test-utils';
import { MemoryRouter, useLocation } from 'react-router-dom';
import App from '../src/App.jsx';
import { FeedbackProvider } from '../src/components/Feedback.jsx';
import { AuthProvider } from '../src/context/AuthContext.jsx';
import { LayoutProvider } from '../src/context/LayoutContext.jsx';
import { ThemeProvider } from '../src/context/ThemeContext.jsx';

let n = 0, failed = 0;
const check = (name, cond, info) => { n++; if (!cond) failed++; console.log(cond ? 'PASS' : 'FAIL', name); if (!cond && info) console.log('   detail:', typeof info === 'function' ? info() : info); };
const q = (s, r = document) => r.querySelector(s);
const qa = (s, r = document) => [...r.querySelectorAll(s)];
const flush = async () => { for (let i = 0; i < 4; i++) await act(async () => { await new Promise((r) => setTimeout(r, 0)); }); };
const click = (el) => act(async () => { el.dispatchEvent(new window.MouseEvent('click', { bubbles: true, cancelable: true })); });
const setValue = (el, value) => act(async () => {
  Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set.call(el, value);
  el.dispatchEvent(new window.Event('input', { bubbles: true }));
});
const submit = (form) => act(async () => { form.dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true })); });
const byText = (t, scope = document, sel = 'button') => qa(sel, scope).find((b) => b.textContent.trim() === t || b.textContent.trim().startsWith(t));

// ---------- fake backend ----------
const json = (body, status = 200) => ({ ok: status < 400, status, json: async () => body });
const MEMBER = { id: 1, name: 'Alex Morgan', email: 'alex@example.com', profession: 'Designer', avatarUrl: null, profileCompleted: true, isAdmin: false };
const ADMIN = { ...MEMBER, id: 9, name: 'Site Owner', isAdmin: true };
let session, calls, srv;
const iso = (hoursAgo) => new Date(Date.now() - hoursAgo * 3600e3).toISOString();
const art = (i, over = {}) => ({
  id: i, title: `Article ${i} headline`, summary: `Summary of article ${i}.`, url: `https://publisher${i}.example.com/story-${i}`,
  source: { id: 1, name: 'TechCrunch' }, publisher: 'TechCrunch', imageUrl: `https://cdn.example.com/img-${i}.jpg`,
  categories: [{ key: 'ai', label: 'AI & Machine Learning', basis: 'source tag "ai"' }], tags: ['AI'],
  publishedAt: iso(i), ingestedAt: iso(0.5), displayAt: iso(i), ...over,
});
const resetServer = () => {
  calls = [];
  srv = {
    all: [art(1), art(2, { summary: null, imageUrl: null, categories: [] }), art(3, { source: { id: 3, name: 'Hacker News' }, publisher: 'example.com', summary: '321 points · 45 comments on Hacker News', url: 'https://www.example.com/tiny-db' }), art(4, { url: 'javascript:alert(1)' }), art(5, { publishedAt: null, displayAt: iso(2) })],
    sync: { syncing: false, lastSyncAt: iso(1), sourceCount: 4, failedSources: [] },
    newsDown: false,
    interests: [], fromCommunities: [{ category: 'programming', label: 'Programming', communities: ['Software Development'] }],
    sources: [
      { id: 1, name: 'TechCrunch', kind: 'rss', url: 'https://techcrunch.com/feed/', enabled: true, builtin: true, urlEditable: true, lastSyncAt: iso(1), lastStatus: 'ok', lastMessage: '3 valid article(s), 3 new, 0 updated', lastFetched: 3, lastInserted: 3, articleCount: 3 },
      { id: 3, name: 'Hacker News', kind: 'hackernews', url: 'https://hn.algolia.com/api/v1/search?tags=front_page', enabled: true, builtin: true, urlEditable: false, lastSyncAt: iso(1), lastStatus: 'error', lastMessage: 'No complete answer within 10 s.', lastFetched: null, lastInserted: null, articleCount: 1 },
      { id: 7, name: 'Example Weekly', kind: 'rss', url: 'https://example.org/feed.xml', enabled: false, builtin: false, urlEditable: true, lastSyncAt: null, lastStatus: null, lastMessage: null, lastFetched: null, lastInserted: null, articleCount: 0 },
    ],
  };
};
resetServer();
globalThis.fetch = async (input, opts = {}) => {
  const url = new URL(input, 'http://localhost');
  const method = opts.method || 'GET';
  const key = `${method} ${url.pathname}${url.search}`;
  calls.push(key);
  const p = url.pathname, sp = url.searchParams;
  const body = opts.body ? JSON.parse(opts.body) : {};
  if (p === '/api/auth/me') return json({ user: session });
  if (p === '/api/news' && method === 'GET') {
    if (srv.newsDown) return json({ error: { code: 'server_error', message: 'Something went wrong on the server.' } }, 500);
    const cat = sp.get('category');
    let list = srv.all.filter((a) => a.id !== 4 || true);
    if (cat && !['all', 'for-you'].includes(cat)) list = list.filter((a) => a.categories.some((c) => c.key === cat));
    if (cat === 'for-you') list = srv.interests.length || srv.fromCommunities.length ? list.filter((a) => a.id === 1) : [];
    const limit = Number(sp.get('limit')), offset = Number(sp.get('offset'));
    const page = list.slice(offset, offset + limit);
    return json({ articles: page, total: list.length, limit, offset, hasMore: offset + page.length < list.length, category: cat, retentionHours: 72, sync: srv.sync });
  }
  if (p === '/api/news/interests' && method === 'GET') return json({ available: [{ key: 'ai', label: 'AI & Machine Learning' }, { key: 'programming', label: 'Programming' }, { key: 'cybersecurity', label: 'Cybersecurity' }, { key: 'startups', label: 'Startups' }], interests: srv.interests, fromCommunities: srv.fromCommunities });
  if (p === '/api/news/interests' && method === 'PUT') { srv.interests = body.interests; return json({ available: [{ key: 'ai', label: 'AI & Machine Learning' }, { key: 'programming', label: 'Programming' }, { key: 'cybersecurity', label: 'Cybersecurity' }, { key: 'startups', label: 'Startups' }], interests: srv.interests, fromCommunities: srv.fromCommunities }); }
  if (p === '/api/admin/news/sources' && method === 'GET') return json({ sources: srv.sources });
  if (p === '/api/admin/news/status') return json({ scheduler: { registered: true, intervalMinutes: 120, nextRunAt: iso(-1.5), running: false }, retentionHours: 72, lastRun: { reason: 'startup', finishedAt: iso(0.5), startedAt: iso(0.5), deleted: 2, totals: { inserted: 7 } } });
  if (p === '/api/admin/news/sources' && method === 'POST') {
    if (body.url === 'http://localhost/feed') return json({ error: { code: 'validation_error', message: 'Please fix the highlighted fields.', fields: { url: 'Local and private network addresses are not allowed.' } } }, 400);
    srv.sources.push({ id: 20, name: body.name, kind: 'rss', url: body.url, enabled: true, builtin: false, urlEditable: true, lastSyncAt: iso(0), lastStatus: 'ok', lastMessage: '2 valid article(s)', lastFetched: 2, lastInserted: 2, articleCount: 2 });
    return json({ source: srv.sources.at(-1), check: { status: 'ok', message: '2 valid article(s), 2 new, 0 updated' } }, 201);
  }
  const one = /^\/api\/admin\/news\/sources\/(\d+)$/.exec(p);
  if (one && method === 'PUT') { const s = srv.sources.find((x) => x.id === Number(one[1])); if ('enabled' in body) s.enabled = body.enabled; if (body.url) s.url = body.url; return json({ source: s }); }
  if (one && method === 'DELETE') { srv.sources = srv.sources.filter((x) => x.id !== Number(one[1])); return json({ ok: true, removedArticles: 0 }); }
  return json({ error: { message: 'unexpected ' + key } }, 404);
};

const root = createRoot(document.getElementById('root'));
function Where() { const l = useLocation(); window.__loc = l.pathname; return null; }
let mountId = 0;
async function mount(path, user) {
  session = user;
  calls.length = 0;
  await act(async () => {
    root.render(
      <MemoryRouter key={++mountId} initialEntries={[path]}>
        <ThemeProvider><LayoutProvider><AuthProvider><FeedbackProvider><Where /><App /></FeedbackProvider></AuthProvider></LayoutProvider></ThemeProvider>
      </MemoryRouter>
    );
  });
  await flush();
}
const cards = () => qa('.news-card');
const heads = () => cards().map((c) => q('h3', c).textContent);

// ================= News feed =================
await mount('/news', MEMBER);
check('the News link in the sidebar is active and the page loads stored articles from the backend', !!q('.sidebar a[href="/news"].active') && cards().length === 5, () => document.body.textContent.slice(0, 300));
check('the browser only talks to the ProConnect API, never to a news site', calls.every((c) => c.split(' ')[1].startsWith('/api/')), calls);
const first = cards()[0];
const firstLink = q('h3 a', first);
check('a card shows title, summary, publisher and a dated line', firstLink.textContent === 'Article 1 headline' && q('.news-summary', first).textContent === 'Summary of article 1.' && q('.news-source', first).textContent === 'TechCrunch' && !!q('time[datetime]', first) && /\d{4}/.test(q('time', first).textContent));
check('the title and "Read article" open the original publisher in a new tab, safely', firstLink.getAttribute('href') === 'https://publisher1.example.com/story-1' && firstLink.target === '_blank' && /noopener/.test(firstLink.rel) && q('a.news-read', first).getAttribute('href') === 'https://publisher1.example.com/story-1' && q('a.news-read', first).textContent.includes('Read article') && /noopener/.test(q('a.news-read', first).rel));
check('the category is shown and explains how it was assigned', q('.pill-accent', first).textContent === 'AI & Machine Learning' && /source tag/.test(q('.pill-accent', first).title));
check('the image uses the article image URL without leaking a referrer', q('.news-thumb img', first).getAttribute('src') === 'https://cdn.example.com/img-1.jpg' && q('.news-thumb img', first).getAttribute('referrerpolicy') === 'no-referrer');
const second = cards()[1];
check('an article without summary, image and category still renders cleanly (local default image, no empty paragraph)', !q('.news-summary', second) && !!q('.news-thumb-empty', second) && !q('.news-pills', second));
check('an article without an image shows the local ProConnect default, not an icon or a broken image', q('.news-thumb img', second)?.getAttribute('src') === '/news/proconnect-news-default.svg' && q('.news-thumb img', second)?.getAttribute('data-fallback') === 'default');
const hn = cards()[2];
check('for Hacker News the original publisher and the source are both shown', q('.news-source', hn).textContent === 'example.com' && q('.news-via', hn).textContent.trim() === 'via Hacker News');
const unsafe = cards()[3];
check('a non-web link (javascript:) is never turned into a link', !q('a', unsafe) && q('h3', unsafe).textContent === 'Article 4 headline');
const undated = cards()[4];
check('an article without a publication date says when it was added instead', /^Added /.test(q('time', undated).textContent));
await act(async () => { q('.news-thumb img', first).dispatchEvent(new window.Event('error')); });
check('a broken original image is replaced by the local default (no broken-image icon)', q('.news-thumb img', cards()[0])?.getAttribute('src') === '/news/proconnect-news-default.svg' && !!q('.news-thumb-empty', cards()[0]));
await act(async () => { q('.news-thumb img', cards()[0]).dispatchEvent(new window.Event('error')); });
check('the default image failing never triggers another swap (no loop); only a plain icon remains', !q('.news-thumb img', cards()[0]) && !!q('.news-thumb svg', cards()[0]));
check('other cards keep their own original images', q('.news-thumb img', cards()[2])?.getAttribute('src') === 'https://cdn.example.com/img-3.jpg');
check('the page tells how many articles from how many hours and when it was refreshed', /5 articles from the last 72 hours · last refreshed/.test(q('.result-note').textContent));
check('no Admin link for ordinary members', !byText('Manage sources', document, 'a'));

// ================= Tabs =================
const tabs = () => qa('.filters[aria-label="News category"] .chip-btn');
check('tabs are All News, For You, AI & Machine Learning, Programming, Cybersecurity, Startups', tabs().map((t) => t.textContent).join('|') === 'All News|For You|AI & Machine Learning|Programming|Cybersecurity|Startups');
check('All News is selected first', tabs()[0].getAttribute('aria-pressed') === 'true');
await click(byText('AI & Machine Learning', document, '.chip-btn'));
await flush();
check('choosing a category asks the backend for that category and marks the tab', calls.includes('GET /api/news?category=ai&limit=12&offset=0') && tabs()[2].getAttribute('aria-pressed') === 'true' && cards().length === 4, calls);
await click(byText('Cybersecurity', document, '.chip-btn'));
await flush();
check('a category without articles shows a helpful empty state with a way back', !!q('.empty') && q('.empty h3').textContent.includes('No articles in this category') && !!byText('Show all news'));
await click(byText('Show all news'));
await flush();
check('"Show all news" returns to All News', tabs()[0].getAttribute('aria-pressed') === 'true' && cards().length === 5);

// ================= For You =================
await click(byText('For You', document, '.chip-btn'));
await flush();
check('For You shows the topic picker and why communities contribute', !!q('.news-topics') && q('.news-topics').textContent.includes('Software Development') && qa('.news-topics .chip-btn').length === 4);
await click(byText('Cybersecurity', q('.news-topics'), '.chip-btn'));
await flush();
check('picking a topic saves it through the API and reloads the feed', calls.includes('PUT /api/news/interests') && byText('Cybersecurity', q('.news-topics'), '.chip-btn').getAttribute('aria-pressed') === 'true' && srv.interests.join() === 'cybersecurity' && calls.filter((c) => c.startsWith('GET /api/news?category=for-you')).length >= 2, calls);
srv.interests = []; srv.fromCommunities = [];
await click(byText('Programming', document, '.chip-btn'));
await click(byText('For You', document, '.chip-btn'));
await flush();
check('without topics or communities For You explains what to do instead of showing random news', q('.empty h3').textContent === 'Nothing to recommend yet' && /join communities/i.test(q('.news-topics').textContent));

// ================= Pagination =================
resetServer();
srv.all = Array.from({ length: 15 }, (_, i) => art(i + 1));
await mount('/news', MEMBER);
check('the first page holds 12 articles and offers "Load more"', cards().length === 12 && !!byText('Load more'));
await click(byText('Load more'));
await flush();
check('Load more appends the remaining articles and then disappears', cards().length === 15 && !byText('Load more') && new Set(heads()).size === 15 && calls.includes('GET /api/news?category=all&limit=12&offset=12'), calls);

// ================= Loading, errors, failures =================
resetServer();
srv.all = [];
await mount('/news', MEMBER);
check('nothing stored yet: explains that news is collected at startup and every 2 hours', q('.empty h3').textContent === 'No news has been stored yet' && /every 2 hours/.test(q('.empty').textContent) && cards().length === 0);
resetServer();
srv.all = [];
srv.sync = { syncing: false, lastSyncAt: iso(1), sourceCount: 4, failedSources: ['TechCrunch', 'Ars Technica', 'Hacker News', 'DEV Community'] };
await mount('/news', MEMBER);
check('when every source failed and nothing is stored the message says the sources could not be reached', /could not be reached/.test(q('.empty').textContent) && !!q('.news-warning'));
resetServer();
srv.sync = { syncing: false, lastSyncAt: iso(1), sourceCount: 4, failedSources: ['TechCrunch'] };
await mount('/news', MEMBER);
check('a failed source shows a warning but stored articles remain visible', /Some sources could not be refreshed: TechCrunch/.test(q('.news-warning').textContent) && cards().length === 5 && q('.news-warning').getAttribute('role') === 'status');
resetServer();
srv.newsDown = true;
await mount('/news', MEMBER);
check('a backend error shows a clear message and a retry button, not a blank page', q('.empty[role="alert"]').textContent.includes('News could not be loaded') && q('.empty').textContent.includes('Something went wrong'));
srv.newsDown = false;
await click(byText('Try again'));
await flush();
check('Try again reloads the feed', cards().length === 5 && !q('.empty'));

// ================= Access =================
resetServer();
await mount('/news', null);
check('visitors are sent to sign in', window.__loc === '/sign-in' && !calls.some((c) => c.startsWith('GET /api/news')));

// ================= Admin: manage sources =================
resetServer();
await mount('/news', ADMIN);
check('an Admin sees a "Manage sources" link on the News page', !!byText('Manage sources', document, 'a'));
await click(byText('Manage sources', document, 'a'));
await flush();
check('the Admin page lists every source with kind, enabled and last result', window.__loc === '/news/sources' && qa('.source-card').length === 3 && q('.source-card').textContent.includes('Working') && qa('.source-card')[1].textContent.includes('Failed') && qa('.source-card')[1].textContent.includes('No complete answer') && qa('.source-card')[2].textContent.includes('Not fetched yet'));
check('the page shows the scheduler: every 120 minutes with the next run', /Scheduled every 120 minutes/.test(q('#sync-title').parentElement.textContent) && /72 hours/.test(q('#sync-title').parentElement.textContent));
const cardOf = (name) => qa('.source-card').find((c) => q('h3', c).textContent === name);
check('built-in sources cannot be removed; API sources have no address editor; custom RSS ones can do both', !byText('Remove', cardOf('TechCrunch')) && !byText('Edit address', cardOf('Hacker News')) && !!byText('Edit address', cardOf('TechCrunch')) && !!byText('Remove', cardOf('Example Weekly')));
await click(q('button.chip-btn', cardOf('TechCrunch')));
await flush();
check('enabling/disabling sends the change to the backend and updates the card', calls.includes('PUT /api/admin/news/sources/1') && srv.sources[0].enabled === false && cardOf('TechCrunch').textContent.includes('Disabled'));
await click(byText('Edit address', cardOf('TechCrunch')));
await setValue(q('#url-1'), 'https://techcrunch.com/new-feed/');
await submit(q('.source-edit'));
await flush();
check('editing a feed address saves it', srv.sources[0].url === 'https://techcrunch.com/new-feed/' && !q('.source-edit'));

// add: rejected address
await setValue(q('#name'), 'Local thing');
await setValue(q('#url'), 'http://localhost/feed');
await submit(q('form[aria-labelledby="add-source-title"]'));
await flush();
check('an unsafe address is rejected and the reason is shown under the field', q('#url-error').textContent === 'Local and private network addresses are not allowed.' && srv.sources.length === 3);
await setValue(q('#name'), 'Good Feed');
await setValue(q('#url'), 'https://good.example.org/rss');
await submit(q('form[aria-labelledby="add-source-title"]'));
await flush();
check('a valid feed is added and the result of the first fetch is shown', srv.sources.length === 4 && /The first fetch worked/.test(q('.notice[role="status"]').textContent) && !!cardOf('Good Feed'));

// remove with confirmation
await click(byText('Remove', cardOf('Example Weekly')));
await flush();
check('removing a source asks for confirmation in an in-site dialog first', !!q('.modal') && q('.modal').textContent.includes('Remove Example Weekly?') && srv.sources.length === 4);
await click(byText('Cancel', q('.modal')));
await flush();
check('cancelling keeps the source', srv.sources.length === 4 && !q('.modal'));
await click(byText('Remove', cardOf('Example Weekly')));
await flush();
await click(byText('Remove source', q('.modal')));
await flush();
check('confirming removes it', !srv.sources.some((s) => s.name === 'Example Weekly') && !cardOf('Example Weekly'));

// non-admin cannot use the page (the backend enforces this too)
resetServer();
await mount('/news/sources', MEMBER);
check('a member opening the Admin page sees "Administrators only" and no source data is requested', q('[role="alert"] h2').textContent === 'Administrators only' && !calls.some((c) => c.includes('/admin/')) && qa('.source-card').length === 0, calls);

console.log(`\n${n - failed}/${n} checks passed`);
process.exit(failed ? 1 : 0);
