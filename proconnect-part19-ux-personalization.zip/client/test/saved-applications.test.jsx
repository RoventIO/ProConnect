// Part 18 UI tests: Save Job buttons, Job details, Saved Jobs and My Applications, against a fake server (no network).
import './setup.js';
import React from 'react';
import { createRoot } from 'react-dom/client';
import { act } from 'react-dom/test-utils';
import { MemoryRouter, Routes, Route, useLocation } from 'react-router-dom';
import { FeedbackProvider } from '../src/components/Feedback.jsx';
import { AuthProvider } from '../src/context/AuthContext.jsx';
import { ThemeProvider } from '../src/context/ThemeContext.jsx';
import Jobs from '../src/pages/Jobs.jsx';
import JobDetail from '../src/pages/JobDetail.jsx';
import SavedJobs from '../src/pages/SavedJobs.jsx';
import Applications from '../src/pages/Applications.jsx';

let n = 0, failed = 0;
const check = (name, cond) => { n++; if (!cond) failed++; console.log(cond ? 'PASS' : 'FAIL', name); };
const q = (s, r = document) => r.querySelector(s);
const qa = (s, r = document) => [...r.querySelectorAll(s)];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const flush = () => act(async () => { await sleep(0); });
const wait = (ms) => act(async () => { await sleep(ms); });
const click = (el) => act(async () => { el.dispatchEvent(new window.MouseEvent('click', { bubbles: true })); });
const byText = (t, scope = document, sel = 'button') => qa(sel, scope).find((b) => b.textContent.trim() === t || b.textContent.trim().startsWith(t));
const choose = (select, value) => act(async () => {
  Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, 'value').set.call(select, value);
  select.dispatchEvent(new window.Event('change', { bubbles: true }));
});
const typeInto = (el, value) => act(async () => {
  const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
  el.dispatchEvent(new window.Event('input', { bubbles: true }));
});
const submit = (form) => act(async () => { form.dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true })); });

// ---------- fake server ----------
const calls = [];
const bodies = [];
const ago = (h) => new Date(Date.now() - h * 3600e3).toISOString();
const LABEL = { 'it-software': 'IT & Software Engineering', healthcare: 'Healthcare', 'marketing-sales': 'Marketing & Sales' };
const mkJob = (id, o = {}) => ({
  id, title: `Job ${id}`, company: `Company ${id}`, logoUrl: null, location: 'Berlin', category: { key: o.cat || 'it-software', label: LABEL[o.cat || 'it-software'] },
  employmentType: null, experienceLevel: null, workMode: null, tags: [], summary: `Summary of job ${id}`, publishedAt: ago(id * 24), firstSeenAt: ago(id * 24),
  source: { key: 'arbeitnow', name: 'Arbeitnow' }, applyUrl: `https://www.arbeitnow.com/jobs/${id}`, savedId: null, applicationId: null, ...o.over,
});
let jobs, saved, apps, nextId, failSave, gateSave, failList, dupNext;
const reset = () => {
  jobs = [mkJob(1, { over: { title: 'Senior Developer', company: 'Acme', description: 'First paragraph.\nSecond paragraph.' } }), mkJob(2, { cat: 'healthcare', over: { title: 'Registered Nurse', company: 'CareCo' } }), mkJob(3, { over: { title: 'Tracked Job', company: 'Trackers' } })];
  saved = []; apps = []; nextId = 100; failSave = false; gateSave = null; failList = false; dupNext = false;
  calls.length = 0; bodies.length = 0;
};
reset();
const json = (body, status = 200) => ({ ok: status < 400, status, json: async () => body });
const err = (status, code, message, extra = {}) => json({ error: { code, message, ...extra } }, status);
const withFlags = (j) => ({ ...j, savedId: saved.find((s) => s.jobId === j.id)?.id ?? null, applicationId: apps.find((a) => a.jobId === j.id)?.id ?? null });
const savedShape = (s) => {
  const live = jobs.find((j) => j.id === s.jobId);
  const j = live || s.snapshot;
  return { id: s.id, savedAt: s.savedAt, availability: live ? 'available' : 'unavailable', job: { id: live?.id ?? null, title: j.title, company: j.company, location: j.location, workMode: null, employmentType: null, category: j.category, publishedAt: j.publishedAt, source: j.source, applyUrl: live ? j.applyUrl : null, lastKnownUrl: live ? null : s.snapshot.applyUrl } };
};
const summary = () => {
  const c = (s) => apps.filter((a) => a.status === s).length;
  return { total: apps.length, applied: c('applied'), reviewing: c('reviewing'), interview: c('interview'), rejected: c('rejected'), accepted: c('accepted'), withdrawn: c('withdrawn') };
};
const appShape = (a) => ({ id: a.id, title: a.title, company: a.company, url: a.url || null, appliedOn: a.appliedOn, status: a.status, notes: a.notes || null, createdAt: a.createdAt, updatedAt: a.updatedAt, tracking: { origin: 'self_reported', submittedViaProConnect: false }, job: a.jobId ? { id: a.jobId, available: !!jobs.find((j) => j.id === a.jobId), source: { key: 'arbeitnow', name: 'Arbeitnow' } } : null });

globalThis.fetch = async (input, opts = {}) => {
  const url = new URL(input, 'http://localhost');
  const method = opts.method || 'GET';
  const p = url.pathname, sp = url.searchParams;
  const body = opts.body ? JSON.parse(opts.body) : undefined;
  calls.push(`${method} ${p}${url.search}`);
  if (body) bodies.push({ method, path: p, body });
  if (p === '/api/auth/me') return json({ user: { id: 9, name: 'Test', email: 't@example.com', profileCompleted: true, isAdmin: false } });
  if (p === '/api/jobs' && method === 'GET') {
    const f = (k) => sp.get(k) || '';
    const list = jobs.filter((j) => !f('q') || `${j.title} ${j.company}`.toLowerCase().includes(f('q').toLowerCase()));
    return json({
      jobs: list.map(withFlags), total: list.length, page: 1, pageSize: 12, pageCount: 1,
      facets: { categories: Object.entries(LABEL).map(([key, label]) => ({ key, label, count: jobs.filter((j) => j.category.key === key).length })), modes: {}, types: {}, levels: {}, sources: {} },
      sources: [{ key: 'arbeitnow', name: 'Arbeitnow', site: 'x', status: 'ok', message: 'ok', lastSyncAt: ago(1), lastOkAt: ago(1), stored: jobs.length }], totalStored: jobs.length, lastUpdated: ago(1), refreshing: false, fetchingEnabled: true,
    });
  }
  const one = /^\/api\/jobs\/(\d+)$/.exec(p);
  if (one) { const j = jobs.find((x) => x.id === Number(one[1])); return j ? json({ job: { ...withFlags(j), description: j.description || null } }) : err(404, 'job_not_found', 'This job listing is no longer available.'); }

  if (p === '/api/saved-jobs' && method === 'POST') {
    if (gateSave) await gateSave;
    if (failSave) return err(500, 'server_error', 'Something went wrong on the server.');
    const j = jobs.find((x) => x.id === body.jobId);
    if (!j) return err(404, 'job_not_found', 'This job listing is no longer available, so it cannot be saved.');
    const dup = saved.find((s) => s.jobId === j.id);
    if (dup) return err(409, 'already_saved', 'You have already saved this job.', { details: { savedId: dup.id } });
    const s = { id: nextId++, jobId: j.id, savedAt: ago(2), snapshot: { ...j } };
    saved.unshift(s);
    return json({ savedJob: savedShape(s) }, 201);
  }
  if (p === '/api/saved-jobs' && method === 'GET') {
    if (failList) return err(500, 'server_error', 'Saved jobs could not be loaded.');
    const f = (k) => sp.get(k) || '';
    let list = saved.map((s) => ({ s, v: savedShape(s) }));
    if (f('q')) list = list.filter(({ v }) => `${v.job.title} ${v.job.company}`.toLowerCase().includes(f('q').toLowerCase()));
    if (f('category')) list = list.filter(({ v }) => v.job.category.key === f('category'));
    if (f('availability')) list = list.filter(({ v }) => v.availability === f('availability'));
    if (f('sort') === 'title') list = [...list].sort((a, b) => a.v.job.title.localeCompare(b.v.job.title));
    const counts = {};
    saved.forEach((s) => { const c = savedShape(s).job.category; counts[c.key] = (counts[c.key] || 0) + 1; });
    return json({ savedJobs: list.map(({ v }) => v), total: list.length, totalSaved: saved.length, unavailable: saved.filter((s) => !jobs.find((j) => j.id === s.jobId)).length, facets: { categories: Object.entries(counts).map(([key, count]) => ({ key, label: LABEL[key], count })) } });
  }
  const delSaved = /^\/api\/saved-jobs\/(\d+)$/.exec(p);
  if (delSaved && method === 'DELETE') {
    if (failSave) return err(500, 'server_error', 'Something went wrong on the server.');
    const i = saved.findIndex((s) => s.id === Number(delSaved[1]));
    if (i < 0) return err(404, 'not_found', 'This saved job was not found.');
    saved.splice(i, 1);
    return json({ ok: true });
  }

  if (p === '/api/job-applications' && method === 'GET') {
    const f = (k) => sp.get(k) || '';
    let list = apps.filter((a) => (!f('status') || a.status === f('status')) && (!f('q') || `${a.title} ${a.company}`.toLowerCase().includes(f('q').toLowerCase())));
    const key = f('sort') === 'updated' ? 'updatedAt' : 'appliedOn';
    list = [...list].sort((a, b) => (a[key] < b[key] ? -1 : a[key] > b[key] ? 1 : 0) * (f('dir') === 'asc' ? 1 : -1));
    return json({ applications: list.map(appShape), total: list.length, summary: summary() });
  }
  if (p === '/api/job-applications' && method === 'POST') {
    if (dupNext) return err(409, 'duplicate_application', 'You are already tracking this application.');
    const fields = {};
    const j = body.jobId ? jobs.find((x) => x.id === body.jobId) : null;
    if (body.jobId && !j) return err(404, 'job_not_found', 'This job listing is no longer available.');
    if (!j && !body.title) fields.title = 'Job title is required.';
    if (!j && !body.company) fields.company = 'Company is required.';
    if (body.url && !/^https?:\/\//.test(body.url)) fields.url = 'Enter a full link starting with https://';
    if (Object.keys(fields).length) return err(400, 'validation_error', 'Please fix the highlighted fields.', { fields });
    const a = { id: nextId++, jobId: j?.id || null, title: j ? j.title : body.title, company: j ? j.company : body.company, url: j ? j.applyUrl : body.url, appliedOn: body.appliedOn, status: body.status, notes: body.notes, createdAt: ago(1), updatedAt: ago(1) };
    apps.push(a);
    return json({ application: appShape(a), summary: summary() }, 201);
  }
  const oneApp = /^\/api\/job-applications\/(\d+)$/.exec(p);
  if (oneApp) {
    const a = apps.find((x) => x.id === Number(oneApp[1]));
    if (!a) return err(404, 'not_found', 'This application was not found.');
    if (method === 'PUT') { Object.assign(a, Object.fromEntries(Object.entries(body).map(([k, v]) => [k === 'notes' && v === '' ? 'notes' : k, v === '' ? null : v])), { updatedAt: new Date().toISOString() }); return json({ application: appShape(a), summary: summary() }); }
    if (method === 'DELETE') { apps.splice(apps.indexOf(a), 1); return json({ ok: true, summary: summary() }); }
    return json({ application: appShape(a) });
  }
  return err(404, 'not_found', `unexpected ${method} ${p}`);
};

const root = createRoot(document.getElementById('root'));
let mountId = 0;
function Where() { const l = useLocation(); window.__loc = l.pathname + l.search; return null; }
const mount = async (path) => {
  await act(async () => {
    root.render(
      <MemoryRouter key={++mountId} initialEntries={[path]}><ThemeProvider><AuthProvider><FeedbackProvider><Where />
        <Routes>
          <Route path="/jobs" element={<Jobs />} /><Route path="/jobs/:id" element={<JobDetail />} />
          <Route path="/saved-jobs" element={<SavedJobs />} /><Route path="/applications" element={<Applications />} />
        </Routes>
      </FeedbackProvider></AuthProvider></ThemeProvider></MemoryRouter>
    );
  });
  await flush(); await flush();
};
const card = (title) => qa('.job-card').find((c) => c.querySelector('h3').textContent === title);
const posts = (path) => bodies.filter((b) => b.method === 'POST' && b.path === path);
const dialog = () => q('[role="dialog"]');

// =============== Save Job on the Jobs list ===============
await mount('/jobs');
const nurse = card('Registered Nurse');
check('every job card has a Save Job button', qa('.job-card').length === 3 && qa('.job-card').every((c) => byText('Save Job', c)));
check('the Save Job button names the job for screen readers and is not pressed', byText('Save Job', nurse).getAttribute('aria-label') === 'Save Registered Nurse at CareCo' && byText('Save Job', nurse).getAttribute('aria-pressed') === 'false');
check('the job title is a link to the job page and Apply is still a separate external link', q('h3 a', nurse).getAttribute('href') === `/jobs/2` && q('a[target="_blank"]', nurse).getAttribute('href') === 'https://www.arbeitnow.com/jobs/2');

let release;
gateSave = new Promise((r) => { release = r; });
await click(byText('Save Job', nurse));
const busyBtn = q('.save-job button', nurse);
check('while saving, the button is disabled and says Saving…', busyBtn.disabled && busyBtn.textContent.includes('Saving…') && busyBtn.getAttribute('aria-busy') === 'true');
release(); gateSave = null;
await wait(10);
check('the request carries only the job id (never a user id)', JSON.stringify(posts('/api/saved-jobs')[0].body) === JSON.stringify({ jobId: 2 }));
const savedBtn = q('.save-job button', nurse);
check('after the server confirms, the button shows Saved immediately', savedBtn.textContent.includes('Saved') && savedBtn.getAttribute('aria-pressed') === 'true' && !savedBtn.disabled && saved.length === 1);

await click(savedBtn);
await wait(10);
check('pressing Saved removes it again with DELETE', calls.some((c) => c.startsWith('DELETE /api/saved-jobs/')) && byText('Save Job', nurse) && saved.length === 0);

failSave = true;
await click(byText('Save Job', nurse));
await wait(10);
check('a failed save shows an error next to the button and the button stays Save Job', !!q('.save-job-error[role="alert"]', nurse) && /went wrong/.test(q('.save-job-error', nurse).textContent) && !!byText('Save Job', nurse));
failSave = false;
// saved in another tab: the server answers already_saved, the button shows the true state
saved.unshift({ id: 777, jobId: 2, savedAt: ago(1), snapshot: { ...jobs[1] } });
await click(byText('Save Job', nurse));
await wait(10);
check('already_saved from the server is shown as Saved (no error)', !!byText('Saved', nurse) && !q('.save-job-error', nurse));
saved.length = 0;

// tracked marker and Apply
apps.push({ id: 500, jobId: 3, title: 'Tracked Job', company: 'Trackers', url: 'https://www.arbeitnow.com/jobs/3', appliedOn: '2026-10-01', status: 'applied', notes: '', createdAt: ago(1), updatedAt: ago(1) });
await mount('/jobs');
check('a job you already track shows a Tracked marker linking to My Applications', q('a.job-tracked', card('Tracked Job'))?.getAttribute('href') === '/applications' && !q('a.job-tracked', card('Senior Developer')));
calls.length = 0;
const applyLink = q('a[target="_blank"]', card('Senior Developer'));
await click(applyLink);
await wait(10);
check('clicking Apply only opens the employer page: no ProConnect request, nothing tracked', calls.length === 0 && apps.length === 1);
check('the Jobs page says ProConnect does not submit applications', /does not submit applications/.test(q('.jobs-head p').textContent));

// =============== Job details ===============
await mount('/jobs/1');
check('the job page shows title, company, description paragraphs and the source', q('h2').textContent === 'Senior Developer' && qa('.job-detail-body p').map((p) => p.textContent).join('|').startsWith('First paragraph.|Second paragraph.') && /Source: Arbeitnow/.test(q('.job-detail-body').textContent));
check('the job page has a Save Job button and the original Apply link', !!byText('Save Job', document, 'button') && q('a.btn[target="_blank"]').getAttribute('href') === 'https://www.arbeitnow.com/jobs/1');
check('the job page does not claim an application was sent and offers a manual way to track it', /does not submit applications and does not record that you applied/.test(q('.job-apply-note').textContent) && q('.job-track-link').getAttribute('href') === '/applications?add=1');
await click(byText('Save Job', document, 'button'));
await wait(10);
check('saving from the job page updates the button', !!byText('Saved', document, 'button') && saved.length === 1 && saved[0].jobId === 1);
saved.length = 0;
await mount('/jobs/3');
check('a job already tracked says so instead of offering to add it again', /already tracking this job/.test(q('.job-apply-note').textContent) && !q('.job-track-link'));
await mount('/jobs/999');
check('a job that no longer exists shows an explanation with links, not a crash', /no longer available/.test(q('.empty h3').textContent) && !!q('a[href="/saved-jobs"]') && !!q('a[href="/jobs"].btn'));

// =============== Saved Jobs page ===============
await mount('/saved-jobs');
check('with nothing saved the page shows a useful empty state with a way to browse jobs', /not saved any jobs yet/.test(q('.empty h3').textContent) && q('.empty a[href="/jobs"]') !== null && !q('.jobs-filters'));
saved.push(
  { id: 1, jobId: 1, savedAt: ago(5), snapshot: { ...jobs[0] } },
  { id: 2, jobId: 2, savedAt: ago(30), snapshot: { ...jobs[1] } },
  { id: 3, jobId: 55, savedAt: ago(100), snapshot: mkJob(55, { over: { title: 'Gone Designer', company: 'Vanished Ltd', applyUrl: 'https://www.arbeitnow.com/jobs/55' } }) },
);
await mount('/saved-jobs');
check('every saved job is listed as a card with title, company, location and source', qa('.job-card').length === 3 && card('Senior Developer').textContent.includes('Company 1') === false && card('Senior Developer').textContent.includes('Acme') && card('Senior Developer').textContent.includes('Berlin') && card('Senior Developer').textContent.includes('Source: Arbeitnow'));
check('each card shows its publication date and the date it was saved', qa('.job-card').every((c) => q('.job-meta time[title]', c) && /Saved\s+\w{3} \d+, \d{4}/.test(c.textContent) && /Posted/.test(c.textContent)));
check('each card has View Job and Remove from Saved', byText('View Job', card('Senior Developer'), 'a')?.getAttribute('href') === '/jobs/1' && !!byText('Remove from Saved', card('Senior Developer')));
check('the page shows only what the server returned for this member (three cards, count line)', /3 of 3 saved jobs/.test(q('.jobs-filter-foot').textContent));
const gone = card('Gone Designer');
check('a saved job that is gone shows No longer available, an explanation and no View Job or Apply button', /No longer available/.test(q('.pill-unavailable', gone).textContent) && /no longer in ProConnect/.test(q('.job-unavailable', gone).textContent) && !byText('View Job', gone, 'a') && !q('a.btn-primary', gone) && /Listing unavailable/.test(gone.textContent));
check('the last known link of a missing job is offered only as a link that may not work, never as an Apply button', /may no longer work/.test(q('.job-unavailable', gone).textContent) && q('.job-unavailable a', gone).getAttribute('href') === 'https://www.arbeitnow.com/jobs/55');
check('a notice counts the unavailable saved jobs and says they are kept', /1 saved job is no longer in the job feed/.test(q('.jobs-warning').textContent));
check('available jobs show an Available status', /Available/.test(q('.job-pills .pill-free', card('Senior Developer')).textContent));

calls.length = 0;
await typeInto(q('input[type="search"]'), 'nurse');
await wait(400);
check('searching by title or company asks the server and shows only matches', calls.some((c) => c.includes('/api/saved-jobs?') && c.includes('q=nurse')) && qa('.job-card').length === 1 && !!card('Registered Nurse'));
await typeInto(q('input[type="search"]'), 'zzzz');
await wait(400);
check('a search without matches shows a "no match" state with Clear filters (not the empty-library state)', /No saved jobs match/.test(q('.empty h3').textContent) && !!byText('Clear filters', q('.empty')));
await click(byText('Clear filters', q('.empty')));
await wait(400);
check('clearing the filters shows everything again', qa('.job-card').length === 3 && q('input[type="search"]').value === '');
await choose(q('#saved-category'), 'healthcare');
await wait(10);
check('the category filter narrows the list', qa('.job-card').length === 1 && calls.some((c) => c.includes('category=healthcare')));
await choose(q('#saved-category'), '');
await choose(q('#saved-sort'), 'title');
await wait(10);
check('sorting is sent to the server (most recently saved is the default)', calls.some((c) => c.includes('sort=title')) && qa('.job-card h3').map((h) => h.textContent).join('|') === 'Gone Designer|Registered Nurse|Senior Developer');
check('the sort control offers most recently saved', qa('#saved-sort option').some((o) => o.textContent === 'Most recently saved'));
await choose(q('#saved-status'), 'unavailable');
await wait(10);
check('the job status filter shows only unavailable saved jobs', qa('.job-card').length === 1 && !!card('Gone Designer'));
await choose(q('#saved-status'), '');
await choose(q('#saved-sort'), 'recent');
await wait(10);

calls.length = 0;
await click(byText('Remove from Saved', card('Registered Nurse')));
await flush();
check('Remove from Saved asks for confirmation in a site dialog first, nothing is deleted yet', !!dialog() && !calls.some((c) => c.startsWith('DELETE')) && saved.length === 3);
await click(byText('Cancel', dialog()));
await flush();
check('cancelling keeps the job', !dialog() && saved.length === 3);
await click(byText('Remove from Saved', card('Registered Nurse')));
await flush();
await click(byText('Remove', dialog()));
await wait(20);
check('confirming removes it on the server and the card disappears', calls.some((c) => c === 'DELETE /api/saved-jobs/2') && saved.length === 2 && !card('Registered Nurse') && qa('.job-card').length === 2);

failList = true;
await mount('/saved-jobs');
check('when the server fails, an error with Try again is shown and nothing is deleted', /could not be loaded/.test(q('.form-error').textContent) && !!byText('Try again', q('.form-error')) && saved.length === 2);
failList = false;
await click(byText('Try again', q('.form-error')));
await wait(10);
check('Try again reloads the list', qa('.job-card').length === 2);

// =============== My Applications ===============
apps.length = 0;
await mount('/applications');
check('with no applications there is an empty state with Add Application and Browse jobs', /not tracking any applications/.test(q('.empty h3').textContent) && !!byText('Add Application', q('.empty')) && q('.empty a[href="/jobs"]') !== null);
check('the page states that it is the member\'s own list and that ProConnect does not submit applications', /does not submit applications/.test(q('.apps-note').textContent) && /Clicking Apply never adds anything/.test(q('.apps-note').textContent));
check('the overview shows zeros for every status', qa('.apps-stat').map((c) => c.querySelector('strong').textContent).join(',') === '0,0,0,0,0,0');

// add one manually
await click(byText('Add Application', document.querySelector('.jobs-head')));
await flush();
check('Add Application opens an accessible dialog with focus inside it', !!dialog() && dialog().getAttribute('aria-modal') === 'true' && dialog().contains(document.activeElement));
check('the form offers a ProConnect job or an external job, the date (today by default), a status and notes', !!byText('A job from ProConnect', dialog()) && !!byText('Another job', dialog()) && q('#app-date').value.length === 10 && q('#app-date').max.length === 10 && qa('#app-status option').map((o) => o.textContent).join() === 'Applied,Reviewing,Interview,Accepted,Rejected,Withdrawn' && !!q('#app-notes'));
await click(byText('Another job', dialog()));
await click(byText('Add application', dialog()));
await flush();
check('submitting an empty manual form shows required-field errors and sends nothing', !!q('#app-title-error') && !!q('#app-company-error') && posts('/api/job-applications').length === 0 && q('#app-title').getAttribute('aria-invalid') === 'true');
await typeInto(q('#app-title'), 'Data Analyst');
await typeInto(q('#app-company'), 'Globex');
await typeInto(q('#app-url'), 'not-a-link');
await click(byText('Add application', dialog()));
await wait(10);
check('a server validation error for the link is shown on the field and the dialog stays open', /full link/.test(q('#app-url-error')?.textContent || '') && !!dialog());
await typeInto(q('#app-url'), 'https://careers.globex.example/42');
await typeInto(q('#app-notes'), 'Sent the CV');
await choose(q('#app-status'), 'reviewing');
await click(byText('Add application', dialog()));
await wait(20);
const sent = posts('/api/job-applications').pop().body;
check('the manual application is saved with title, company, link, date, status and notes (no user id)', sent.title === 'Data Analyst' && sent.company === 'Globex' && sent.url === 'https://careers.globex.example/42' && sent.status === 'reviewing' && sent.notes === 'Sent the CV' && /^\d{4}-\d{2}-\d{2}$/.test(sent.appliedOn) && !('userId' in sent) && !('jobId' in sent));
check('the dialog closes and the new application appears in the list', !dialog() && qa('.apps-row').length === 1 && q('.apps-row h3').textContent === 'Data Analyst');
check('the row shows applied date, last updated date, a status indicator with a text label, and that you track it yourself', !!q('.apps-row time[datetime]') && /Last updated/.test(q('.apps-row').textContent) && q('.apps-row .status-reviewing').textContent.trim() === 'Reviewing' && /Tracked by you/.test(q('.apps-row').textContent));
check('the overview counts come from the records', qa('.apps-stat').map((c) => c.querySelector('strong').textContent).join(',') === '1,0,1,0,0,0');

// add from a ProConnect job
await click(byText('Add Application', document.querySelector('.jobs-head')));
await flush();
await click(byText('A job from ProConnect', dialog()));
await typeInto(q('input[aria-label="Search ProConnect jobs"]'), 'nurse');
await wait(450);
check('searching ProConnect jobs inside the form lists matching jobs', qa('.app-result').length === 1 && /Registered Nurse/.test(q('.app-result').textContent));
await click(q('.app-result'));
await flush();
check('choosing a job shows it as the selected job and hides the manual fields', /Registered Nurse/.test(q('.app-picked').textContent) && !q('#app-title'));
await click(byText('Add application', dialog()));
await wait(20);
const linked = posts('/api/job-applications').pop().body;
check('an application linked to a ProConnect job sends its id, not typed title or company', linked.jobId === 2 && !('title' in linked) && !('company' in linked) && linked.status === 'applied');
check('the list now has two applications and the counts follow', qa('.apps-row').length === 2 && qa('.apps-stat').map((c) => c.querySelector('strong').textContent).join(',') === '2,1,1,0,0,0');

// not choosing a job
await click(byText('Add Application', document.querySelector('.jobs-head')));
await flush();
await click(byText('A job from ProConnect', dialog()));
await click(byText('Add application', dialog()));
await flush();
check('submitting without choosing a job explains what to do and sends nothing', /Choose a job/.test(dialog().textContent) && posts('/api/job-applications').length === 3);
await click(byText('Cancel', dialog()));
await flush();

// duplicate
await click(byText('Add Application', document.querySelector('.jobs-head')));
await flush();
await click(byText('Another job', dialog()));
await typeInto(q('#app-title'), 'Data Analyst');
await typeInto(q('#app-company'), 'Globex');
dupNext = true;
await click(byText('Add application', dialog()));
await wait(20);
check('a duplicate application is refused with a clear message and the dialog stays open', /already tracking this application/.test(q('.app-form .form-error').textContent) && !!dialog());
dupNext = false;
await click(byText('Cancel', dialog()));
await flush();
check('Escape closes the dialog too', await (async () => { await click(byText('Add Application', document.querySelector('.jobs-head'))); await flush(); document.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); await flush(); return !dialog(); })());

// from a job page: /applications?add=1
await mount('/applications?add=1');
await wait(20);
check('arriving from a job page opens the form with that job selected, once, and cleans the address', !!dialog() && /Senior Developer/.test(q('.app-picked')?.textContent || '') && window.__loc === '/applications');
await click(byText('Cancel', dialog()));
await flush();
await mount('/applications?add=999');
await wait(20);
check('a job that no longer exists falls back to manual entry with an explanation', /no longer available/.test(q('.app-form .form-error')?.textContent || '') && !!q('#app-title'));
await click(byText('Cancel', dialog()));
await flush();

// filters, sorting, quick status
await mount('/applications');
apps.push(
  { id: 901, jobId: null, title: 'Older Applied', company: 'Initech', url: '', appliedOn: '2026-09-01', status: 'applied', notes: '', createdAt: ago(900), updatedAt: ago(900) },
  { id: 902, jobId: null, title: 'Interview Role', company: 'Hooli', url: '', appliedOn: '2026-10-20', status: 'interview', notes: '', createdAt: ago(10), updatedAt: ago(10) },
  { id: 903, jobId: null, title: 'Rejected Role', company: 'Umbrella', url: '', appliedOn: '2026-08-01', status: 'rejected', notes: '', createdAt: ago(300), updatedAt: ago(300) },
);
await mount('/applications');
check('the overview shows Total, Applied, Reviewing, Interviews, Accepted and Rejected from the records', qa('.apps-stat').map((c) => c.querySelector('span').textContent).join('|') === 'Total applications|Applied|Reviewing|Interviews|Accepted|Rejected' && qa('.apps-stat').map((c) => c.querySelector('strong').textContent).join(',') === '5,2,1,1,0,1');
await click(q('.apps-stat-interview'));
await wait(10);
check('clicking a number filters the list by that status', qa('.apps-row').length === 1 && q('.apps-row h3').textContent === 'Interview Role' && q('.apps-stat-interview').getAttribute('aria-pressed') === 'true' && q('.apps-stat-applied').getAttribute('aria-pressed') === 'false' && qa('.apps-stat').map((c) => c.querySelector('strong').textContent).join(',') === '5,2,1,1,0,1');
await click(q('.apps-stat-interview'));
await wait(10);
await choose(q('#apps-status'), 'rejected');
await wait(10);
check('the status filter works and the overview does not change with it', qa('.apps-row').length === 1 && q('.apps-row h3').textContent === 'Rejected Role' && calls.some((c) => c.includes('status=rejected')));
await choose(q('#apps-status'), '');
await wait(10);
check('default order is the application date, newest first', qa('.apps-row h3').map((h) => h.textContent)[0] === 'Registered Nurse' || qa('.apps-row h3').map((h) => h.textContent).includes('Interview Role'));
await choose(q('#apps-sort'), 'applied-asc');
await wait(10);
check('sorting by application date (oldest first) is sent to the server and applied', calls.some((c) => c.includes('sort=applied') && c.includes('dir=asc')) && qa('.apps-row h3')[0].textContent === 'Rejected Role');
await choose(q('#apps-sort'), 'updated-desc');
await wait(10);
check('sorting by last updated is sent to the server', calls.some((c) => c.includes('sort=updated') && c.includes('dir=desc')) && qa('#apps-sort option').length === 4);
await typeInto(q('input[aria-label^="Search applications"]'), 'hooli');
await wait(400);
check('searching by title or company filters the list', qa('.apps-row').length === 1 && /Hooli/.test(q('.apps-row').textContent));
await typeInto(q('input[aria-label^="Search applications"]'), 'nothing-like-this');
await wait(400);
check('no matching application shows a "no match" state with Clear filters', /No applications match/.test(q('.empty h3').textContent));
await click(byText('Clear filters', q('.empty')));
await wait(400);

// quick status change
const row = () => qa('.apps-row').find((r) => r.querySelector('h3').textContent === 'Older Applied');
calls.length = 0;
await choose(q('select.apps-status-select', row()), 'accepted');
await wait(20);
check('changing the status in a row saves only the status', bodies.filter((b) => b.method === 'PUT').pop().body.status === 'accepted' && Object.keys(bodies.filter((b) => b.method === 'PUT').pop().body).join() === 'status');
check('the indicator and the overview follow the change', q('.status-pill', row()).textContent.trim() === 'Accepted' && qa('.apps-stat').map((c) => c.querySelector('strong').textContent).join(',') === '5,1,1,1,1,1');

// edit
await click(byText('Edit', row()));
await flush();
check('Edit opens the form with the saved values', dialog().querySelector('h3').textContent === 'Edit application' && q('#app-title').value === 'Older Applied' && q('#app-company').value === 'Initech' && q('#app-date').value === '2026-09-01' && q('#app-status').value === 'accepted');
await typeInto(q('#app-notes'), 'Phone screen on Tuesday');
await click(byText('Save changes', dialog()));
await wait(20);
const edit = bodies.filter((b) => b.method === 'PUT').pop().body;
check('saving an edit sends the changed notes and keeps the rest', edit.notes === 'Phone screen on Tuesday' && edit.title === 'Older Applied' && edit.status === 'accepted' && !dialog() && /Phone screen/.test(row().textContent));
await click(q('h3 .link-btn', row()));
await flush();
check('clicking the title opens the application too', !!dialog() && q('#app-title').value === 'Older Applied');
await click(byText('Cancel', dialog()));
await flush();

// delete
await click(byText('Delete', row()));
await flush();
check('Delete asks for confirmation and says it does not affect the employer', !!dialog() && /does not affect the employer/.test(dialog().textContent) && apps.some((a) => a.id === 901));
await click(byText('Delete', dialog()));
await wait(20);
check('confirming deletes the application and updates the numbers', !apps.some((a) => a.id === 901) && !row() && qa('.apps-stat').map((c) => c.querySelector('strong').textContent).join(',') === '4,1,1,1,0,1');

console.log(`\n${n - failed}/${n} checks passed`);
process.exit(failed ? 1 : 0);
