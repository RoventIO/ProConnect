// Part 19 UI tests: theme (Light / Dark / System), Preferences page, personalized Home, URL filters, News default tab,
// Jobs "Use my preferences", account menu and Log Out, skip link, page titles and profile deep links.
// Run against the real <App /> and a fake server (no network).
import './setup.js';
import React from 'react';
import { createRoot } from 'react-dom/client';
import { act } from 'react-dom/test-utils';
import { MemoryRouter, useLocation, useNavigate } from 'react-router-dom';
import App from '../src/App.jsx';
import { ThemeProvider } from '../src/context/ThemeContext.jsx';
import { LayoutProvider } from '../src/context/LayoutContext.jsx';
import { AuthProvider } from '../src/context/AuthContext.jsx';
import { FeedbackProvider } from '../src/components/Feedback.jsx';

let n = 0, failed = 0;
const check = (name, cond, info) => { n++; if (!cond) failed++; console.log(cond ? 'PASS' : 'FAIL', name); if (!cond && info) console.log('   detail:', typeof info === 'function' ? info() : info); };
const q = (s, r = document) => r.querySelector(s);
const qa = (s, r = document) => [...r.querySelectorAll(s)];
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const flush = async () => { for (let i = 0; i < 4; i++) await act(async () => { await sleep(0); }); };
const wait = (ms) => act(async () => { await sleep(ms); });
const click = (el) => act(async () => { el.dispatchEvent(new window.MouseEvent('click', { bubbles: true, cancelable: true })); });
const key = (el, k) => act(async () => { el.dispatchEvent(new window.KeyboardEvent('keydown', { key: k, bubbles: true, cancelable: true })); });
const choose = (select, value) => act(async () => {
  Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, 'value').set.call(select, value);
  select.dispatchEvent(new window.Event('change', { bubbles: true }));
});
const typeInto = (el, value) => act(async () => {
  Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set.call(el, value);
  el.dispatchEvent(new window.Event('input', { bubbles: true }));
});
const text = () => document.body.textContent;
const h3s = () => qa('h3').map((h) => h.textContent.trim());
const theme = () => document.documentElement.getAttribute('data-theme');
const btn = (label, scope = document) => qa('button', scope).find((b) => b.textContent.trim() === label || b.textContent.trim().startsWith(label));

// ---------- a controllable prefers-color-scheme ----------
let osDark = false;
const mqListeners = new Set();
window.matchMedia = (query) => ({ get matches() { return osDark; }, media: query, addEventListener: (t, f) => mqListeners.add(f), removeEventListener: (t, f) => mqListeners.delete(f) });
const setOsDark = (v) => act(async () => { osDark = v; [...mqListeners].forEach((f) => f({ matches: v })); });

// ---------- fake server ----------
const MEMBER = { id: 1, name: 'Alex Morgan', email: 'alex@example.com', profession: 'Product Designer', avatarUrl: null, profileCompleted: true, isAdmin: false, status: 'professional', headline: 'Designer', bio: 'Bio', skills: ['UX'], location: 'London', yearsExperience: 5, linkedinUrl: null, githubUrl: null, isBot: false, isOrganizer: false };
const DEFAULT_PREFS = { theme: 'light', newsDefaultTab: 'all', jobCategory: null, jobWorkMode: null, homeSections: { newInCommunities: true, communitiesForYou: true, jobsForYou: true, jobSearch: true, registrations: true }, persisted: false };
const ITEMS = [
  ['profession', 'Add your profession', true, '/profile?edit=basics'], ['headline', 'Write a headline', true, '/profile?edit=basics'], ['bio', 'Write a short biography', true, '/profile?edit=basics'],
  ['skills', 'List at least 3 skills', false, '/profile?edit=basics'], ['location', 'Add your location', true, '/profile?edit=basics'], ['experience-years', 'Add your years of experience', true, '/profile?edit=basics'],
  ['photo', 'Upload a profile photo', false, '/profile?edit=photo'], ['links', 'Add a LinkedIn or GitHub link', false, '/profile?edit=basics'], ['experience', 'Add a work experience', false, '/profile?add=experience'],
  ['education', 'Add your education', true, '/profile?add=education'], ['project', 'Add a project to My Work', false, '/profile?add=project'], ['community', 'Join a community', true, '/communities'],
].map(([k, label, done, href]) => ({ key: k, label, done, href }));
const mkJob = (id) => ({ id, title: `Preferred Job ${id}`, company: `Company ${id}`, logoUrl: null, location: 'Berlin', category: { key: 'it-software', label: 'IT & Software Engineering' }, employmentType: null, experienceLevel: null, workMode: 'remote', tags: [], summary: 'Summary', publishedAt: new Date().toISOString(), firstSeenAt: new Date().toISOString(), source: { key: 'arbeitnow', name: 'Arbeitnow' }, applyUrl: `https://www.arbeitnow.com/jobs/${id}`, savedId: null, applicationId: null });
const personalFixture = () => ({
  profile: { name: 'Alex Morgan', profession: 'Product Designer', status: 'professional', completion: { percent: 58, completed: 7, total: 12, items: ITEMS } },
  newInCommunities: { joinedCount: 2, items: [{ id: 91, title: 'Fresh discussion in Backend', createdAt: new Date().toISOString(), replyCount: 2, author: { id: 7, name: 'Sara Kim', isBot: false, avatarUrl: null }, community: { id: 11, name: 'Backend' }, parentCommunity: { id: 1, name: 'Software Development' } }] },
  communitiesForYou: [{ id: 5, name: 'Design & UX', category: 'Design', description: 'd', memberCount: 4, postCount: 9, reason: { kind: 'profession', text: 'Matches your profession: Product Designer' } }],
  jobsForYou: { hasPreferences: true, category: { key: 'it-software', label: 'IT & Software Engineering' }, workMode: 'remote', total: 7, items: [mkJob(31), mkJob(32)] },
  jobSearch: { savedCount: 3, applications: { total: 2, applied: 1, reviewing: 0, interview: 1, accepted: 0, rejected: 0, withdrawn: 0 } },
  registrations: { total: 1, items: [{ id: 41, title: 'Registered Webinar', type: 'webinar', organizer: 'Org', startsAt: '2099-03-01T10:00:00.000Z', duration: null, isSample: true, priceLabel: 'Free', registered: true, deliveryMode: 'online' }] },
});

let S; // the fake server's state
let hits, newsCalls, jobsCalls, courseCalls, prefPuts;
const resetServer = () => {
  S = { session: null, prefs: { ...DEFAULT_PREFS, homeSections: { ...DEFAULT_PREFS.homeSections } }, failPut: false, failLogout: false, personal: personalFixture(), sessionPrefsPersisted: false };
  hits = []; newsCalls = []; jobsCalls = []; courseCalls = []; prefPuts = [];
};
const json = (body, status = 200) => ({ ok: status < 400, status, json: async () => body });
const CATS = ['it-software', 'design-creative', 'healthcare', 'finance-accounting'].map((k) => ({ key: k, label: { 'it-software': 'IT & Software Engineering', 'design-creative': 'Design & Creative', healthcare: 'Healthcare', 'finance-accounting': 'Finance & Accounting' }[k], count: 3 }));
globalThis.fetch = async (input, opts = {}) => {
  const url = new URL(input, 'http://localhost');
  const method = opts.method || 'GET';
  const p = url.pathname;
  hits.push(`${method} ${p}`);
  const body = typeof opts.body === 'string' ? JSON.parse(opts.body) : {};
  if (p === '/api/auth/me') return json({ user: S.session });
  if (p === '/api/auth/logout') { if (S.failLogout) throw new TypeError('Failed to fetch'); S.session = null; return json({ ok: true }); }
  if (p === '/api/stats') { const w = { count: 0, points: [0, 0, 0, 0, 0, 0, 0] }; return json({ totals: { communities: 6, professionals: 5, discussions: 6, replies: 5 }, week: { memberships: w, professionals: w, discussions: w, replies: w } }); }
  if (p === '/api/home') return json({ trending: [{ id: 1, title: 'A trending discussion', createdAt: new Date().toISOString(), replyCount: 2, author: { id: 3, name: 'Sara Kim', profession: 'Engineer', avatarUrl: null }, community: { id: 1, name: 'Backend' } }], courses: [], popularCommunities: [{ id: 1, name: 'Software Development', memberCount: 2, postCount: 1 }], ...(S.personal ? { personal: S.personal } : {}) });
  if (p === '/api/preferences' && method === 'GET') return json({ preferences: S.prefs });
  if (p === '/api/preferences' && method === 'PUT') {
    prefPuts.push(body);
    if (S.failPut) return json({ error: { code: 'server_error', message: 'The preferences could not be saved.' } }, 500);
    S.prefs = { ...S.prefs, ...body, homeSections: { ...S.prefs.homeSections, ...(body.homeSections || {}) }, persisted: true };
    return json({ preferences: S.prefs });
  }
  if (p === '/api/news/interests') return json({ available: [{ key: 'ai', label: 'AI & Machine Learning' }], interests: [], fromCommunities: [] });
  if (p === '/api/news') { newsCalls.push(url.search); return json({ articles: [], total: 0, limit: 12, offset: 0, hasMore: false, category: url.searchParams.get('category'), retentionHours: 72, sync: { syncing: false, lastSyncAt: null, sourceCount: 1, failedSources: [] } }); }
  if (p === '/api/jobs') { jobsCalls.push(url.search); return json({ jobs: [], total: 0, page: 1, pageSize: 12, pageCount: 1, facets: { categories: CATS, modes: { remote: 2, hybrid: 2, on_site: 1 }, types: {}, levels: {}, sources: {} }, sources: [], totalStored: 5, lastUpdated: null, refreshing: false, fetchingEnabled: true }); }
  if (p === '/api/communities') return json({ categories: ['Design', 'Technology'], communities: [{ id: 1, name: 'Software Development', description: 'Code', category: 'Technology', memberCount: 2, postCount: 1, isMember: false, subcommunities: [] }, { id: 2, name: 'Design & UX', description: 'Design things', category: 'Design', memberCount: 3, postCount: 4, isMember: false, subcommunities: [] }] });
  if (p === '/api/courses') { courseCalls.push(url.search); return json({ courses: [], facets: { categories: [{ name: 'Finance', count: 2 }, { name: 'Design', count: 1 }], modes: { online: 1, hybrid: 1 } } }); }
  if (p === '/api/profile' && method === 'GET') return json({ user: { ...MEMBER, memberSince: '2026-01-01T00:00:00Z' }, items: { experience: [], education: [], projects: [] }, communities: [], recentPosts: [], stats: { communities: 0, discussions: 0, replies: 0 } });
  if (p.startsWith('/api/saved-jobs') || p.startsWith('/api/job-applications')) return json({ savedJobs: [], applications: [], total: 0, totalSaved: 0, unavailable: 0, facets: { categories: [] }, summary: { total: 0, applied: 0, reviewing: 0, interview: 0, accepted: 0, rejected: 0, withdrawn: 0 } });
  return json({ error: { message: 'unexpected ' + p } }, 404);
};

const root = createRoot(document.getElementById('root'));
function Where() { const l = useLocation(); const nav = useNavigate(); window.__loc = l.pathname; window.__search = l.search; window.__nav = nav; return null; }
let mountId = 0;
async function mount(entries, { user = null, storage = {}, keepStorage = false } = {}) {
  if (!keepStorage) { localStorage.clear(); for (const [k, v] of Object.entries(storage)) localStorage.setItem(k, v); }
  document.documentElement.setAttribute('data-theme', 'light');
  S.session = user; hits = []; newsCalls = []; jobsCalls = []; courseCalls = []; prefPuts = [];
  const list = Array.isArray(entries) ? entries : [entries];
  await act(async () => {
    root.render(
      <MemoryRouter key={++mountId} initialEntries={list} initialIndex={list.length - 1}>
        <ThemeProvider><LayoutProvider><AuthProvider><FeedbackProvider><Where /><App /></FeedbackProvider></AuthProvider></LayoutProvider></ThemeProvider>
      </MemoryRouter>
    );
  });
  await flush();
}
const go = (to) => act(async () => { window.__nav(to); });
const back = () => act(async () => { window.__nav(-1); });
const lastCall = (list) => list[list.length - 1] || '';
const withPrefs = (over) => { S.prefs = { ...DEFAULT_PREFS, homeSections: { ...DEFAULT_PREFS.homeSections }, persisted: true, ...over }; };

// ================= Theme: Light, Dark, System =================
resetServer();
await mount('/');
check('the default theme is light and the storage key keeps its name (pc-theme-v2)', theme() === 'light' && localStorage.getItem('pc-theme-v2') === 'light');
await mount('/', { storage: { 'pc-theme-v2': 'dark' } });
check('a saved dark choice is applied from the existing key', theme() === 'dark' && localStorage.getItem('pc-theme-v2') === 'dark');
await mount('/', { storage: { 'pc-theme-v2': 'nonsense' } });
check('an unknown stored value falls back to light', theme() === 'light');

osDark = false;
await mount('/', { storage: { 'pc-theme-v2': 'system' } });
check('System with a light browser setting shows light and stores "system"', theme() === 'light' && localStorage.getItem('pc-theme-v2') === 'system');
await setOsDark(true);
check('System follows the browser setting live (now dark)', theme() === 'dark' && localStorage.getItem('pc-theme-v2') === 'system');
await setOsDark(false);
check('...and back to light', theme() === 'light');
osDark = true;
await mount('/', { storage: { 'pc-theme-v2': 'system' } });
check('System with a dark browser setting starts dark', theme() === 'dark');
osDark = false;
await mount('/', { storage: { 'pc-theme-v2': 'dark' } });
await setOsDark(true); await setOsDark(false);
check('an explicit Dark choice ignores browser changes', theme() === 'dark');

// the header toggle keeps working in every mode
resetServer();
osDark = true;
await mount('/', { storage: { 'pc-theme-v2': 'system' } });
await click(q('.theme-btn'));
check('the header toggle in System mode flips what is shown (dark -> light) and stores an explicit choice', theme() === 'light' && localStorage.getItem('pc-theme-v2') === 'light');
await click(q('.theme-btn'));
check('...and flips back', theme() === 'dark' && localStorage.getItem('pc-theme-v2') === 'dark');
check('a visitor changing the theme saves nothing on the server', !hits.some((h) => h.includes('/api/preferences')));
osDark = false;

// ================= Saved theme after sign-in =================
resetServer();
withPrefs({ theme: 'dark' });
await mount('/', { user: MEMBER, storage: { 'pc-theme-v2': 'light' } });
check('after sign-in the member\'s saved theme is applied (and remembered on this device)', theme() === 'dark' && localStorage.getItem('pc-theme-v2') === 'dark');
resetServer(); // nothing saved yet: persisted = false, theme default light
await mount('/', { user: MEMBER, storage: { 'pc-theme-v2': 'dark' } });
check('a member who never saved a theme keeps the one chosen on this device', theme() === 'dark');
check('and nothing is written just because they signed in', prefPuts.length === 0);
withPrefs({ theme: 'system' });
osDark = true;
await mount('/', { user: MEMBER });
check('a saved "system" theme follows the browser', theme() === 'dark' && localStorage.getItem('pc-theme-v2') === 'system');
osDark = false;
resetServer();
await mount('/', { user: MEMBER });
await click(q('.theme-btn'));
await flush();
check('the header toggle saves the theme for a signed-in member', prefPuts.length === 1 && prefPuts[0].theme === 'dark' && S.prefs.persisted === true, () => JSON.stringify(prefPuts));
S.failPut = true;
await click(q('.theme-btn'));
await flush();
check('if saving fails the theme still changes on this device and the page keeps working', theme() === 'light' && !!q('.header'));

// ================= Preferences page =================
resetServer();
await mount('/settings');
check('visitors cannot open Preferences (sent to Sign In)', window.__loc === '/sign-in');
await mount('/settings', { user: MEMBER });
check('Preferences opens for a member with the header title "Preferences" and a matching tab title', window.__loc === '/settings' && q('.header-title h1').textContent === 'Preferences' && document.title === 'Preferences · ProConnect', () => document.title);
check('it offers theme, news, job and Home section settings', ['Appearance', 'News', 'Jobs', 'Home page sections'].every((t) => h3s().includes(t)));
check('the theme choices are Light, Dark and System', qa('input[name="theme"]').map((i) => i.value).join() === 'light,dark,system');
check('every control has a visible text label', qa('.settings input, .settings select').every((el) => el.closest('label') || q(`label[for="${el.id}"]`)));
check('radio groups are fieldsets with legends', qa('fieldset legend').map((l) => l.textContent).join('|') === 'Theme|Default News tab|Preferred work mode');

await click(q('input[name="theme"][value="dark"]'));
await flush();
check('choosing Dark applies it at once and saves it', theme() === 'dark' && prefPuts.at(-1)?.theme === 'dark' && q('input[name="theme"][value="dark"]').checked);
check('a confirmation is announced politely', /saved/i.test(q('.pref-status').textContent) && q('.pref-status').getAttribute('aria-live') === 'polite');
osDark = true;
await click(q('input[name="theme"][value="system"]'));
await flush();
check('choosing System follows the browser and saves "system"', theme() === 'dark' && prefPuts.at(-1)?.theme === 'system' && localStorage.getItem('pc-theme-v2') === 'system');
await setOsDark(false);
check('...and follows it when it changes', theme() === 'light');
await click(q('input[name="theme"][value="light"]'));
await flush();
check('choosing Light saves "light"', theme() === 'light' && prefPuts.at(-1)?.theme === 'light');

await click(q('input[name="news-tab"][value="for-you"]'));
await flush();
check('the default News tab can be set to For You', prefPuts.at(-1)?.newsDefaultTab === 'for-you' && S.prefs.newsDefaultTab === 'for-you');
const cat = q('#pref-job-category');
check('the job category list has "No preference" and the 12 ProConnect categories', cat.options.length === 13 && cat.options[0].textContent === 'No preference');
await choose(cat, 'healthcare');
await flush();
check('a preferred job category is saved', prefPuts.at(-1)?.jobCategory === 'healthcare');
await click(q('input[name="work-mode"][value="on_site"]'));
await flush();
check('a preferred work mode is saved (On-site is stored as on_site)', prefPuts.at(-1)?.jobWorkMode === 'on_site');
check('the work mode choices are No preference, Remote, Hybrid, On-site', qa('input[name="work-mode"]').map((i) => i.parentElement.textContent.trim().split(/\s+/)[0]).join() === 'No,Remote,Hybrid,On-site');
await click(q('input[name="work-mode"][value="none"]'));
await choose(cat, '');
await flush();
check('"No preference" clears them (null)', prefPuts.at(-2)?.jobWorkMode === null && prefPuts.at(-1)?.jobCategory === null);

const sw = (label) => qa('.pref-switch').find((l) => l.textContent.includes(label)).querySelector('input');
check('all five Home sections are switches, on by default', qa('input[role="switch"]').length === 5 && qa('input[role="switch"]').every((i) => i.checked));
await click(sw('Jobs for You'));
await flush();
check('a Home section can be hidden (saved as false)', JSON.stringify(prefPuts.at(-1)) === JSON.stringify({ homeSections: { jobsForYou: false } }) && !sw('Jobs for You').checked && /1 hidden/.test(text()));
await click(sw('Jobs for You'));
await flush();
check('and shown again', prefPuts.at(-1).homeSections.jobsForYou === true && sw('Jobs for You').checked);

// settings survive a refresh (a fresh mount reads them from the server)
await click(sw('Your Registrations'));
await flush();
await mount('/settings', { user: MEMBER, keepStorage: true });
check('after a refresh the saved choices are shown again', q('input[name="news-tab"][value="for-you"]').checked && !sw('Your Registrations').checked && sw('Your Job Search').checked && q('input[name="theme"][value="light"]').checked);

// a refused save undoes the change and says so
S.failPut = true;
await click(sw('Your Job Search'));
await flush();
check('when saving fails the switch goes back and the error is announced', sw('Your Job Search').checked && /could not be saved/i.test(q('.pref-status').textContent) && q('.pref-status').getAttribute('role') === 'alert');
S.failPut = false;

// ================= Personalized Home =================
resetServer();
await mount('/', { user: MEMBER });
const headings = h3s();
check('the member Home keeps the three existing sections with their exact headings', ['Trending Discussions', 'Courses & Webinars', 'Popular Communities'].every((t) => headings.includes(t)));
check('and adds the personalized sections with the specified headings', ['New in Your Communities', 'Communities for You', 'Jobs for You', 'Your Job Search', 'Your Registrations', 'Profile strength'].every((t) => headings.includes(t)), () => headings.join(' | '));
check('the dashboard comes first, then the introduction and the existing sections', q('.home').firstElementChild.classList.contains('dash') && q('.home').children[1].classList.contains('hero'));
check('only one /api/home request serves the whole page', hits.filter((h) => h === 'GET /api/home').length === 1);
check('the welcome panel greets the member by first name with profession and status', /Alex/.test(q('.dash-welcome h2').textContent) && q('.dash-role').textContent === 'Product Designer · Professional' && /58% complete/.test(q('.dash-welcome').textContent));
const bar = q('[role="progressbar"]');
check('profile strength is a progress bar with the real percentage', bar.getAttribute('aria-valuenow') === '58' && /58%/.test(q('.strength-percent').textContent));
const todo = qa('.strength-list:not(.is-done) a');
check('the checklist lists the missing steps as links to the right profile sections', todo.length === 5 && todo.map((a) => a.getAttribute('href')).join() === '/profile?edit=basics,/profile?edit=photo,/profile?edit=basics,/profile?add=experience,/profile?add=project', () => todo.map((a) => a.getAttribute('href')).join());
check('completed steps are listed separately', /7 completed/.test(q('.strength-done summary').textContent) && qa('.strength-list.is-done li').length === 7);
check('New in Your Communities shows recent content with its subcommunity and main community', /Fresh discussion in Backend/.test(text()) && !!q('a[href="/communities/11"]') && !!q('a[href="/communities/1"]') && !!q('a[href="/posts/91"]'));
check('Communities for You explains each recommendation', /Matches your profession: Product Designer/.test(text()) && !!q('a[href="/communities/5"]'));
check('Jobs for You reuses the job cards and shows what the preferences are', /Preferred Job 31/.test(text()) && /Preferred Job 32/.test(text()) && /IT & Software Engineering · Remote/.test(text()) && qa('.dash-wide .job-card').length === 2);
check('it links to the Jobs page with the same filters', q('.dash-more a')?.getAttribute('href') === '/jobs?category=it-software&mode=remote' && /See all 7 matching jobs/.test(q('.dash-more a').textContent));
check('Your Job Search shows saved jobs and the application summary with links', /3\s*Saved jobs/.test(text()) && /2\s*Applications/.test(text()) && !!q('.search-stat[href="/saved-jobs"]') && !!q('.search-stat[href="/applications"]') && /Applied 1/.test(text()) && /Interview 1/.test(text()));
check('Your Registrations lists the real upcoming registration', /Registered Webinar/.test(text()) && !!q('a[href="/courses/41"]'));

S.personal.jobsForYou = { hasPreferences: false, category: null, workMode: null, total: 0, items: [] };
S.personal.registrations = { total: 0, items: [] };
S.personal.newInCommunities = { joinedCount: 0, items: [] };
await mount('/', { user: MEMBER });
check('with no job preferences the section asks the member to choose them (nothing is guessed)', /Choose a preferred job category and work mode/.test(text()) && !!q('.dash-wide a[href="/settings"]') && qa('.dash-wide .job-card').length === 0);
check('with no registrations nothing is invented', /not registered for any upcoming course or webinar/.test(text()) && !/Registered Webinar/.test(text()));
check('with no joined communities the section explains how to get content', /not joined a community yet/.test(text()));
S.personal.jobsForYou = { hasPreferences: true, category: { key: 'healthcare', label: 'Healthcare' }, workMode: null, total: 0, items: [] };
await mount('/', { user: MEMBER });
check('preferences that match nothing say so honestly', /No stored listings match these preferences/.test(text()));

// hiding sections
resetServer();
withPrefs({ homeSections: { newInCommunities: true, communitiesForYou: true, jobsForYou: false, jobSearch: true, registrations: false } });
await mount('/', { user: MEMBER });
check('hidden sections are not shown', !h3s().includes('Jobs for You') && !h3s().includes('Your Registrations') && h3s().includes('Your Job Search') && h3s().includes('New in Your Communities'));
check('the existing sections cannot be hidden', ['Trending Discussions', 'Courses & Webinars', 'Popular Communities'].every((t) => h3s().includes(t)));
check('a note says how many are hidden and links to Preferences', /2 sections are hidden/.test(q('.dash-hidden').textContent) && q('.dash-hidden a').getAttribute('href') === '/settings');
await mount('/', { user: MEMBER, keepStorage: true });
check('the choice is restored after a refresh or sign-in (read from the server)', !h3s().includes('Jobs for You') && h3s().includes('Communities for You'));

// older server without `personal`
resetServer();
S.personal = null;
await mount('/', { user: MEMBER });
check('a response without `personal` still shows the earlier Home and no dashboard', !q('.dash') && ['Trending Discussions', 'Courses & Webinars', 'Popular Communities'].every((t) => h3s().includes(t)));

// visitor Home
resetServer();
await mount('/');
check('Visitor Home has no dashboard and asks for no member data', !q('.dash') && !hits.some((h) => h.includes('/api/home') || h.includes('/api/preferences')) && /are for members/.test(text()) && !!q('.hero') && !!q('.tiles') && !!q('.card.locked'));

// ================= URL state: News =================
resetServer();
withPrefs({ newsDefaultTab: 'for-you' });
await mount('/news', { user: MEMBER });
check('News opens on the saved default tab when the address names none', newsCalls.length === 1 && /category=for-you/.test(newsCalls[0]) && btn('For You').getAttribute('aria-pressed') === 'true', () => JSON.stringify(newsCalls));
check('applying the default does not rewrite the address', window.__search === '');
await mount('/news?tab=all', { user: MEMBER });
check('an explicit ?tab= in the address beats the saved default', /category=all/.test(lastCall(newsCalls)) && !newsCalls.some((c) => /for-you/.test(c)) && btn('All News').getAttribute('aria-pressed') === 'true');
await mount('/news?tab=ai', { user: MEMBER });
check('a direct link to another tab opens that tab', /category=ai/.test(lastCall(newsCalls)) && btn('AI & Machine Learning').getAttribute('aria-pressed') === 'true');
await mount('/news?tab=bogus', { user: MEMBER });
check('an unknown tab in the address is ignored (the saved default applies)', /category=for-you/.test(lastCall(newsCalls)));
await mount('/news', { user: MEMBER });
await click(btn('All News'));
await flush();
check('picking a tab writes it to the address, even "All News" while the default is For You', window.__search === '?tab=all' && /category=all/.test(lastCall(newsCalls)));
await click(btn('Programming'));
await flush();
check('another tab changes the address', window.__search === '?tab=programming');
await back();
await flush();
check('Back returns to the previous tab', window.__search === '?tab=all' && btn('All News').getAttribute('aria-pressed') === 'true');
await go('/news'); await flush();
check('opening /news again (no tab) goes back to the saved default', btn('For You').getAttribute('aria-pressed') === 'true');
resetServer();
await mount('/news', { user: MEMBER });
check('with no saved default, News opens on All News', /category=all/.test(lastCall(newsCalls)) && newsCalls.length === 1);
check('the News header title is "News"', q('.header-title h1').textContent === 'News' && document.title === 'News · ProConnect');

// ================= URL state: Jobs =================
resetServer();
await mount('/jobs?category=it-software&mode=remote&q=dev&location=Berlin', { user: MEMBER });
const j0 = new URLSearchParams(lastCall(jobsCalls));
check('a direct Jobs link applies every filter in the address', j0.get('category') === 'it-software' && j0.get('mode') === 'remote' && j0.get('q') === 'dev' && j0.get('location') === 'Berlin', () => lastCall(jobsCalls));
check('the boxes and chips show the filters from the address', q('input[type="search"][aria-label^="Search jobs"]').value === 'dev' && q('#job-location').value === 'Berlin' && q('#job-category').value === 'it-software' && btn('Remote').getAttribute('aria-pressed') === 'true');
await mount('/jobs?mode=bogus&type=nope&level=x', { user: MEMBER });
check('values that are not real options are ignored', !/mode=|type=|level=/.test(lastCall(jobsCalls)));
await mount('/jobs', { user: MEMBER });
await click(btn('Hybrid'));
await flush();
check('a chip writes its filter to the address', window.__search === '?mode=hybrid' && /mode=hybrid/.test(lastCall(jobsCalls)));
await choose(q('#job-category'), 'healthcare');
await flush();
check('a category writes to the address too', new URLSearchParams(window.__search).get('category') === 'healthcare' && new URLSearchParams(window.__search).get('mode') === 'hybrid');
await back();
await flush();
check('Back restores the previous filters (the category goes away)', window.__search === '?mode=hybrid' && !/category=/.test(lastCall(jobsCalls)) && q('#job-category').value === '');
await typeInto(q('input[type="search"][aria-label^="Search jobs"]'), 'nurse');
await wait(450);
check('typing in the search box reaches the address after a short pause', new URLSearchParams(window.__search).get('q') === 'nurse' && /q=nurse/.test(lastCall(jobsCalls)));
await click(btn('Clear filters'));
await flush();
check('Clear filters empties the address filters', window.__search === '' && q('input[type="search"][aria-label^="Search jobs"]').value === '');
check('the Jobs header title is "Jobs"', q('.header-title h1').textContent === 'Jobs' && document.title === 'Jobs · ProConnect');

// ---- Use my preferences ----
resetServer();
await mount('/jobs', { user: MEMBER });
check('Jobs has a "Use my preferences" control; with nothing saved it is disabled and points to Preferences', btn('Use my preferences')?.disabled === true && !!q('.jobs-prefs a[href="/settings"]'));
resetServer();
withPrefs({ jobCategory: 'healthcare', jobWorkMode: 'hybrid' });
await mount('/jobs', { user: MEMBER });
check('saved job preferences are NOT applied silently on load', !/category=|mode=/.test(lastCall(jobsCalls)) && window.__search === '');
check('the control says what it will apply', !btn('Use my preferences').disabled && /Healthcare · Hybrid/.test(q('#jobs-prefs-hint').textContent));
await typeInto(q('input[type="search"][aria-label^="Search jobs"]'), 'nurse');
await wait(450);
await click(btn('Use my preferences'));
await flush();
const sp = new URLSearchParams(window.__search);
check('pressing it applies the saved category and work mode', sp.get('category') === 'healthcare' && sp.get('mode') === 'hybrid' && /category=healthcare/.test(lastCall(jobsCalls)) && /mode=hybrid/.test(lastCall(jobsCalls)));
check('and leaves the member\'s other filters untouched', sp.get('q') === 'nurse');
check('and confirms what it did', /Applied your preferences: Healthcare, Hybrid/.test(text()));
await back();
await flush();
check('Back undoes it (Back/Forward work with it)', !new URLSearchParams(window.__search).get('category') && new URLSearchParams(window.__search).get('q') === 'nurse');
resetServer();
withPrefs({ jobCategory: null, jobWorkMode: 'remote' });
await mount('/jobs?category=finance-accounting', { user: MEMBER });
await click(btn('Use my preferences'));
await flush();
check('with only a work mode saved, only the work mode is applied and the chosen category stays', new URLSearchParams(window.__search).get('mode') === 'remote' && new URLSearchParams(window.__search).get('category') === 'finance-accounting');

// ================= URL state: Communities and Courses =================
resetServer();
await mount('/communities?category=Design&q=ux', { user: MEMBER });
check('Communities applies the category and keyword from the address', btn('Design').getAttribute('aria-pressed') === 'true' && q('input[aria-label="Filter communities"]').value === 'ux');
await click(btn('Technology'));
await flush();
check('a category chip writes to the address and keeps the keyword', window.__search === '?category=Technology&q=ux');
await back();
await flush();
check('Back restores the previous category', btn('Design').getAttribute('aria-pressed') === 'true' && window.__search === '?category=Design&q=ux');
await click(btn('All professions'));
await flush();
check('"All professions" removes the category from the address', window.__search === '?q=ux');
await typeInto(q('input[aria-label="Filter communities"]'), 'soft');
await wait(400);
check('typing a keyword reaches the address', window.__search === '?q=soft');
await mount('/communities?category=Nonsense', { user: MEMBER });
check('an unknown category in the address counts as All', btn('All professions').getAttribute('aria-pressed') === 'true');

resetServer();
await mount('/courses?type=webinar&price=free&mode=online&category=Finance&q=data', { user: MEMBER });
const c0 = new URLSearchParams(lastCall(courseCalls));
check('Courses applies every filter from the address', c0.get('type') === 'webinar' && c0.get('price') === 'free' && c0.get('mode') === 'online' && c0.get('category') === 'Finance' && c0.get('q') === 'data', () => lastCall(courseCalls));
check('the controls show them', btn('Webinars').getAttribute('aria-pressed') === 'true' && btn('Free').getAttribute('aria-pressed') === 'true' && q('input[aria-label="Filter courses and webinars"]').value === 'data');
await click(btn('Courses'));
await flush();
check('a chip updates the address', new URLSearchParams(window.__search).get('type') === 'course' && new URLSearchParams(window.__search).get('price') === 'free');
await back();
await flush();
check('Back restores the previous type', new URLSearchParams(window.__search).get('type') === 'webinar');
await mount('/courses?type=bogus&price=cheap', { user: MEMBER });
check('invalid values are ignored', !/type=|price=/.test(lastCall(courseCalls)));

// ================= Account menu and Log Out =================
resetServer();
await mount('/', { user: MEMBER });
await click(q('.avatar-btn'));
const items = qa('[role="menuitem"]');
check('the account menu lists My Profile, Saved Jobs, My Applications, Preferences and Log Out in that order', items.map((i) => i.textContent.trim()).join('|') === 'My Profile|Saved Jobs|My Applications|Preferences|Log Out');
check('the links go to the right pages', ['/profile', '/saved-jobs', '/applications', '/settings'].every((h, i) => items[i].getAttribute('href') === h));
check('Log Out is a real button, the last item, visually separated', items[4].tagName === 'BUTTON' && !!q('.dropdown-sep'));
check('the menu is labelled for screen readers and the button reports its state', q('[role="menu"]').getAttribute('aria-label') === 'Account' && q('.avatar-btn').getAttribute('aria-expanded') === 'true' && q('.avatar-btn').getAttribute('aria-haspopup') === 'menu');
check('opening the menu moves focus to its first item', document.activeElement === items[0]);
await key(document.activeElement, 'ArrowDown');
check('ArrowDown moves to the next item', document.activeElement === items[1]);
await key(document.activeElement, 'End');
check('End moves to Log Out', document.activeElement === items[4]);
await key(document.activeElement, 'ArrowDown');
check('ArrowDown wraps around to the first item', document.activeElement === items[0]);
await key(document.activeElement, 'ArrowUp');
check('ArrowUp wraps back to Log Out', document.activeElement === items[4]);
await key(document.activeElement, 'Escape');
check('Escape closes the menu and returns focus to the avatar button', !q('[role="menu"]') && document.activeElement === q('.avatar-btn'));
await key(q('.avatar-btn'), 'ArrowDown');
check('ArrowDown on the avatar button opens the menu', !!q('[role="menu"]'));
await click(qa('[role="menuitem"]')[3]);
await flush();
check('choosing Preferences opens the Preferences page and closes the menu', window.__loc === '/settings' && !q('[role="menu"]'));
await click(q('.avatar-btn'));
await click(qa('[role="menuitem"]')[1]);
await flush();
check('Saved Jobs from the menu opens Saved Jobs', window.__loc === '/saved-jobs');
await click(q('.avatar-btn'));
await click(qa('[role="menuitem"]')[2]);
await flush();
check('My Applications from the menu opens My Applications', window.__loc === '/applications');
await click(q('.avatar-btn'));
await click(qa('[role="menuitem"]')[0]);
await flush();
check('My Profile from the menu opens the profile', window.__loc === '/profile');
await click(q('.avatar-btn'));
await click(q('body'));
await act(async () => { document.body.dispatchEvent(new window.MouseEvent('mousedown', { bubbles: true })); });
check('clicking outside closes the menu', !q('[role="menu"]'));

// ---- Log Out ----
resetServer();
await mount(['/jobs', '/profile'], { user: MEMBER });
check('before signing out the private profile page is shown', !!q('.profile') && !!q('.avatar-btn'));
await click(q('.avatar-btn'));
await click(btn('Log Out'));
await flush();
check('Log Out calls the existing logout endpoint (no second one is used)', hits.filter((h) => h === 'POST /api/auth/logout').length === 1 && !hits.some((h) => /logout|signout|sign-out/.test(h) && h !== 'POST /api/auth/logout'));
check('it ends the session: the header shows Sign In / Sign Up and no avatar or account menu', !!q('.header a[href="/sign-in"]') && !q('.avatar-btn') && !q('[role="menu"]'));
check('it returns to the public Home page', window.__loc === '/' && !!q('.hero') && /are for members/.test(text()));
check('no private page or data is left on screen', !q('.profile') && !text().includes('alex@example.com') && !q('.dash'));
check('the sidebar goes back to the visitor items', qa('.sidebar .nav-item .nav-label').map((e) => e.textContent.trim()).join('|') === 'Home|Communities|News|Courses & Webinars|Jobs');
const afterLogout = hits.length;
await back();
await flush();
check('Back after signing out does not show the earlier private page: the visitor is sent to Sign In', window.__loc === '/sign-in' && !q('.jobs') && /Sign in or create an account to continue/.test(text()));
check('and no private data was requested after signing out', !hits.slice(afterLogout).some((h) => /\/api\/(jobs|profile|home|preferences|saved-jobs|job-applications)/.test(h)), () => hits.slice(afterLogout).join());
await go('/settings'); await flush();
check('Preferences stays protected after signing out', window.__loc === '/sign-in');
check('signing out does not touch the stored preferences', S.prefs && JSON.stringify(Object.keys(S.prefs)).length > 0 && S.session === null);
const prefsBefore = JSON.stringify(S.prefs);
check('signing out saved nothing', prefPuts.length === 0 && JSON.stringify(S.prefs) === prefsBefore);

// sign-out while the server cannot be reached
resetServer();
S.failLogout = true;
await mount('/profile', { user: MEMBER });
await click(q('.avatar-btn'));
await click(btn('Log Out'));
await flush();
check('if the server cannot be reached the member is still signed out on this device', !q('.avatar-btn') && window.__loc === '/' && !q('.profile'));
check('...and is told the session could not be ended on the server', /server could not be reached/i.test(document.body.textContent));

// signed-in again: preferences are loaded for the new member, and not for a visitor
resetServer();
await mount('/', { user: MEMBER });
check('a signed-in member\'s preferences are requested', hits.includes('GET /api/preferences'));
await click(q('.avatar-btn'));
await click(btn('Log Out'));
await flush();
hits = [];
await go('/settings'); await flush();
check('a signed-out visitor never triggers a preferences request', !hits.some((h) => h.includes('/api/preferences')));

// ================= Skip link, titles =================
resetServer();
await mount('/', { user: MEMBER });
const skip = q('#root').firstElementChild;
check('the first element on the page is a "Skip to content" link', skip.tagName === 'A' && skip.textContent === 'Skip to content' && skip.getAttribute('href') === '#main-content' && skip.classList.contains('skip-link'));
check('it targets the main landmark, which can receive focus', q('main#main-content')?.getAttribute('tabindex') === '-1');
await click(skip);
check('activating it moves focus to the main content (no address change)', document.activeElement === q('#main-content') && window.__loc === '/' && window.__search === '');
const titles = { '/news': ['News', 'News · ProConnect'], '/jobs': ['Jobs', 'Jobs · ProConnect'], '/news/sources': ['News Sources', 'News Sources · ProConnect'], '/settings': ['Preferences', 'Preferences · ProConnect'], '/saved-jobs': ['Saved Jobs', 'Saved Jobs · ProConnect'], '/applications': ['My Applications', 'My Applications · ProConnect'], '/profile': ['My Profile', 'My Profile · ProConnect'], '/communities': ['Communities', 'Communities · ProConnect'], '/courses': ['Courses & Webinars', 'Courses & Webinars · ProConnect'] };
for (const [path, [h1, doc]] of Object.entries(titles)) {
  await go(path); await flush();
  check(`${path} has the page title "${h1}" in the header and "${doc}" in the browser tab`, q('.header-title h1').textContent === h1 && document.title === doc, () => `${q('.header-title h1').textContent} / ${document.title}`);
}
await go('/'); await flush();
check('Home keeps the "Home" title', q('.header-title h1').textContent === 'Home' && document.title === 'Home · ProConnect');

// ================= Profile deep links from the strength checklist =================
resetServer();
await mount('/profile?edit=basics', { user: MEMBER });
check('/profile?edit=basics opens the profile editor and then cleans the address', !!q('#profession') && window.__search === '', () => window.__search);
await mount('/profile?add=project', { user: MEMBER });
check('/profile?add=project opens the project form', !!q('#project-title') && window.__search === '');
await mount('/profile?add=experience', { user: MEMBER });
check('/profile?add=experience opens the experience form', !!q('#title-experience'));
await mount('/profile?add=education', { user: MEMBER });
check('/profile?add=education opens the education form', !!q('#title-education'));
await mount('/profile?edit=photo', { user: MEMBER });
check('/profile?edit=photo focuses the photo button', document.activeElement?.closest('.photo-controls') !== null && document.activeElement?.textContent.includes('photo'));
await mount('/profile', { user: MEMBER });
check('the plain profile opens nothing extra', !q('#profession') && !q('#project-title'));

console.log(failed ? `\n${failed} of ${n} checks failed` : `\nAll ${n} checks passed`);
process.exit(failed ? 1 : 0);
