# ProConnect

Professional networking and knowledge-sharing platform (academic prototype).

## Build progress
- [x] Part 1: client foundation, WAct-inspired design system (light + dark), header, collapsible sidebar, Home, Sign In / Sign Up screens
- [x] Part 2: SQLite database, Express API skeleton, demonstration data
- [x] Part 3: sign up / sign in / sign out, session cookie, onboarding profile, protected content
- [x] Part 4: Home data from the database, My Profile (view and edit), other members' profiles
- [x] Part 4b: profile photo upload (JPG/PNG/WebP, max 2 MB), search field fix
- [x] Part 5: Communities (browse, filter, details, join/leave, admin create/delete)
- [x] Part 5b: styled confirmation dialogs and notifications (no browser pop-ups), clearer Join/Joined button
- [x] Part 6: Discussions and replies with emoji, images, GIFs and voice messages
- [x] Part 7: Search and filters, Courses & Webinars, My Communities / Discover Communities, themed voice player and scrollbars
- [x] Part 8: final testing and fixes (see ACCEPTANCE.md)

## Requirements
Node.js 22.13 or newer (Node 24 is fine). No database program to install: the database is a single SQLite file
created in `server/data/` using Node's built-in `node:sqlite`.

## Run (two terminals)

Terminal 1, backend:
```bash
cd server
npm install
npm run seed     # creates the database and loads demonstration data (safe to repeat, resets it)
npm run dev      # API on http://localhost:4000
```

Terminal 2, frontend:
```bash
cd client
npm install
npm run dev      # site on http://localhost:5173
```

Check the API: open http://localhost:4000/api/health

## Tests and checks
```bash
cd server && npm test        # 57 API tests (temporary database)
cd server && npm run e2e     # 42-step run of the PRD user journeys against a real server
cd client && npm test        # 146 checks of the real UI in a simulated browser (jsdom)
cd client && npm run build   # production build
```
`ACCEPTANCE.md` maps every item of the PRD checklist to its evidence and lists what still needs a person in a real browser.

## Demo content and test accounts

There are no ordinary demo user accounts. Communities are populated by clearly labelled **community bots**, and one administrator account is provided for testing.

Load or top up the demo content (safe to repeat; it never wipes anything and never creates duplicates):
```bash
cd server
npm run seed:demo
```
It does five things, in this order:
1. Creates the test administrator if it is missing (never changes an existing one).
2. Removes the six earlier demo accounts (`student@`, `beginner@`, `professional@`, `leader@`, `organizer@`, `admin@` at `proconnect.example`) if they still exist. Their discussions and replies are kept and handed to a bot-labelled "ProConnect Demo Archive" account. `admin@proconnect.example` is removed only while it still has the old demo password and another administrator exists; otherwise it is kept. Other users and their content are never touched.
3. Creates the IT community directory: 12 main communities and 72 subcommunities (Software Development, Programming Languages, Web Development, AI and Machine Learning, Cybersecurity, Data and Databases, Cloud and DevOps, IT Infrastructure and Networking, Quality Assurance and Testing, UI/UX and Product Design, Product and Project Management, Other IT Specializations).
4. Creates 40 bot accounts (name, profession and skills vary; each profile says it is an automated bot).
5. Adds 3 discussions with 3 replies each to every community and subcommunity, written by different bots.

`npm run seed:demo -- --cleanup-only` only runs steps 1 and 2. `npm run seed -- --reset` is the only command that wipes the database; run `npm run seed:demo` after it.

**Administrator for testing**

| Email (used as the username) | Password |
|---|---|
| `owner.admin@proconnect.example` | `ProConnect-Owner-2026-Vk7Q` |

Change the password if you keep the data: `npm run make-admin -- owner.admin@proconnect.example --password "YourNewPassword1"`. To recover or create any other administrator the same way, use that command with the account's email. To make an existing account an administrator, run `npm run make-admin -- you@example.com`.

**How the bots work.** Bots are ordinary rows with `is_bot = 1`. They cannot sign in (no usable password), have no administrator, leader or organizer rights, and show a "Bot" label next to their name everywhere. Their text comes from curated, hand-checked entries in `server/src/db/botContent.js`, combined with varied phrasing in `server/src/db/demoData.js`. Nothing is generated when the app starts, no external service is used, and there is no background activity. Every row is looked up by a natural key (email, slug, community plus title, post plus author plus text) before it is inserted, so repeating the command adds nothing. To extend the content, add entries or bots to `botContent.js` and run `npm run seed:demo` again; only the new items are created.

You can also use Sign Up: choose Student or Beginner, complete the profile step, and change the choice later under **My Profile → Status**.

## API
Public:
- `GET /api/health`, `GET /api/stats` (aggregate numbers only)
- `POST /api/auth/register`, `POST /api/auth/login`, `POST /api/auth/logout`, `GET /api/auth/me`

Signed-in:
- `PUT /api/profile` (basic profile; profession, bio, skills required)

Signed-in and profile completed (otherwise 401 / 403 `profile_incomplete`):
- `GET /api/profile`, `POST /api/profile/items`, `PUT|DELETE /api/profile/items/:id` (experience, education, projects/links; own entries only)
- `POST /api/profile/avatar` (multipart field `avatar`), `DELETE /api/profile/avatar`
- `GET /api/uploads/:file` (images are only served to signed-in members)
- `GET /api/users/:id` (another member's permitted profile, never the email)
- `GET /api/home` (trending discussions, upcoming courses, popular communities)
- `POST /api/communities/:id/posts` (members), `GET|PUT|DELETE /api/posts/:id`, `POST /api/posts/:id/comments`, `PUT|DELETE /api/comments/:id`
- `GET /api/communities`, `GET /api/communities/:id`, `POST|DELETE /api/communities/:id/join` (main communities only)
- `POST /api/communities`, `DELETE /api/communities/:id` (administrators only)
- `GET /api/courses`, `GET /api/courses/:id`

Sessions use an httpOnly cookie (JWT, 7 days). For anything beyond local use, set `JWT_SECRET` in the environment.

## Search and filters
Header search (Enter) opens `/search?q=...`. It looks through communities (name, description, category and subcommunity names),
discussions (title, text, author name), people (name, profession, headline, bio, skills, location; only members with a completed
profile, never emails) and courses/webinars (title, description, organizer, category). Results come from the database.
Filters and what they apply to:
- Content type (tabs): All, Communities, Discussions, People, Courses & Webinars
- Profession (a member's profession): people and discussions (by author)
- Topic (a subcommunity such as Backend): communities that contain it, and discussions posted in it
- Community (a main community): communities, discussions, and people who are members
A type a chosen filter cannot apply to is hidden and the page says so. Each type shows up to 20 results.
Professions and topics are not separate result types: professions are found through people and community categories,
topics through subcommunity names and the Topic filter.

## Courses & Webinars
`/courses` lists courses and webinars (type, Free/Paid, date, organizer) with type, price and keyword filters; `/courses/:id` shows the
details and an external registration link when one exists. Upcoming events come first, then undated courses, then past events.
All listings are demonstration data (`is_sample`) and are labelled "Sample"; the detail page says they are not real opportunities.
Payments are not processed: the link goes to the organizer's own site. There is no publishing workflow yet (PRD P1/P2); listings come from the seed data.

## Communities page
"My Communities" (top) lists the communities the signed-in member has joined, read from the `memberships` table, so it is the same after a refresh
or a later sign-in. "Discover Communities" (below) lists the ones not joined yet, with category and keyword filters. Joining moves a card up, leaving moves it down.

## Discussions
- Members of a main community can start discussions there (subcommunities follow their parent) and reply.
- A message can contain text with emoji, up to 4 images or GIFs (JPG, PNG, WebP, GIF, 5 MB each) and one voice message
  (recorded in the browser, up to 2 minutes). Voice recording needs microphone permission and works on localhost.
- Authors can edit text and delete their own discussions and replies; administrators can delete any.
- Searching for GIFs inside the app (Giphy/Tenor) is not included; GIF files can be uploaded.

## Keeping your data between versions
The database lives in `server/data/proconnect.db` and uploaded images in `server/data/uploads/`. When you unzip a newer version, copy your old `server/data` folder
into the new `server/` folder instead of running `npm run seed` (seed resets everything).

## Where things live
- `server/src/db/schema.sql`   tables (users, profile_items, communities, memberships, posts, comments, courses)
- `server/src/db/seed.js`      demonstration data
- `server/src/routes/`         API routes
- `client/src/styles/`         theme.css (all colors) and global.css
- `client/src/pages/`          Home, Profile, Sign In/Up, Onboarding

## Roles and permissions (Part 1)

| Label | How it is stored | Who can change it |
|---|---|---|
| Visitor | not signed in | n/a |
| Student / Beginner | `users.status` | the member (`PUT /api/profile/status`) |
| Professional | `users.status = 'professional'` | Admin only (`PUT /api/admin/users/:id/professional`) |
| Community Leader | `community_leaders` table (per community) | Admin only (`PUT/DELETE /api/admin/communities/:id/leaders/:userId`) |
| Authorized Organizer | `users.is_organizer` (courses and webinars) | Admin only (`PUT /api/admin/users/:id/organizer`) |
| Admin | `users.role = 'admin'` | `npm run make-admin -- email` |

Shared checks live in `server/src/utils/permissions.js` and `requireOrganizer` / `requireAdmin` in `server/src/middleware/auth.js`.
Demo data: Alex Morgan leads Design & UX, Sara Kim is an Authorized Organizer, the admin account is `admin@proconnect.example`.
