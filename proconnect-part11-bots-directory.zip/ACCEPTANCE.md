# ProConnect: PRD acceptance checklist (PRD section 16.1)

Evidence legend
- **Server tests** `cd server && npm test` (45 tests, real API against a temporary database)
- **E2E** `cd server && npm run e2e` (42 checks: a real server process, PRD journeys 10.1 to 10.5, restart persistence)
- **UI tests** `cd client && npm test` (146 checks in a simulated browser: the real `<App />` shell, pages, composer)
- **Browser** = needs a person in a real browser. Nobody has run these yet, so they are marked *not yet verified*.

| # | PRD checklist item | Status | Evidence |
|---|---|---|---|
| 1 | Sign Up and Sign In validate input and support the auth states | Verified | Server tests, E2E, UI tests (`shell`): messages, duplicate email, wrong password, header states, Log Out |
| 2 | A visitor opening internal content is asked to register or sign in and complete the minimum profile | Verified | Server tests (401 / 403 `profile_incomplete`), UI tests (redirect to Sign In with explanation for 6 protected pages; incomplete profile goes to setup), E2E |
| 3 | A signed-in user can open and edit their own basic profile | API verified, page UI not yet verified | Server tests and E2E cover saving fields, experience, education, links and validation. The Profile page's edit forms are not covered by a UI test: Browser check needed |
| 4 | Communities can be browsed and opened; creation is not open to every member | Verified | Server tests (403 for members, admin-only create and delete), UI tests (button hidden for members; My Communities / Discover), E2E |
| 5 | A user can publish a post, read posts and add a comment in the right community | API verified, composer verified, post page not yet verified | Server tests, E2E (text, emoji, image, GIF, voice; membership required), UI tests (composer). The post page itself (`PostDetail`) has no UI test: Browser check needed |
| 6 | A user can edit or delete their own post or comment | API verified, page UI not yet verified | Server tests and E2E (author only, admin can delete, files removed). Edit and delete buttons on the post page: Browser check needed |
| 7 | Search and filters return relevant data | Verified | Server tests (all four types, three filters, empty results, Armenian/Cyrillic/Greek case-insensitivity), E2E, UI tests (tabs, counts, filters, empty state, header search) |
| 8 | Courses and webinars show Free/Paid and an external link when provided | Verified | Server tests, E2E, UI tests (list, filters, detail, safe link handling, sample notice) |
| 9 | Dark and light themes are usable, **dark is the default** | **Not met as shipped** | Switching and the moon/sun icons are verified (UI tests). The default theme is currently **light**, matching the WAct design you chose. The PRD says dark. One-line change in `client/src/context/ThemeContext.jsx` (`return 'light'` to `'dark'`). Colours and readability: Browser check needed |
| 10 | The sidebar collapses and expands in both themes and keeps the layout | Behaviour verified, appearance not yet verified | UI tests (toggle, tooltips, state kept, still present, works with either theme). Layout and overlap: Browser check needed |
| 11 | Only News and Jobs have "Soon" labels, and there is no Chats item | Verified | UI tests: exactly two, inert, nowhere else on the page |
| 12 | The UI is in English and follows the visual direction | English verified, look not yet verified | Static scan found no non-English text in the source; rendered pages checked. Visual direction (WAct style replaced the PRD's Dribbble reference at your request): Browser check needed |
| 13 | The demo distinguishes implemented from sample or future functionality | Verified | Course listings carry a "Sample" label and a notice. News and Jobs are "Soon". The Home quote tile is labelled "Sample quote". Home numbers come from the database |

## Not implemented on purpose (PRD P1/P2 or deferred)
Notifications, news, jobs, credential verification and status badges, community-creation requests, course publishing workflows,
integrated payments, AI moderation, password reset and email verification (no email is sent).

Private chat is permanently out of scope (PRD v2.0) and has been removed from the project.

## Extras requested beyond the PRD
Profile photos, images and GIF uploads, voice messages and emoji in discussions and replies, an admin account for managing communities.

## Known limitations
- Each search type returns at most 20 results and community pages show the newest 20 discussions (no pagination).
- Attachments cannot be added or removed when editing a post or reply; edit changes the text only. Deleting is permanent (no undo).
- Searching for GIFs inside the app (Giphy or Tenor) is not included; GIF files can be uploaded.
- `node:sqlite` is an experimental Node feature (the warning is silenced). Needs Node 22.13 or newer.
- `react-router-dom` 6.x has two moderate advisories (open redirect through user-controlled link targets, and server-side rendering). The app uses client-side routing only and never builds a link from user input. The fix is a major upgrade to v7 and has not been done.
- No rate limiting, no CSRF token beyond SameSite cookies, the JWT secret has a development default and all seeded accounts share one password. Fine for a local demonstration, not for a public site.
- Voice recording needs microphone permission and a modern browser (Chrome, Edge, Firefox or Safari) on localhost or HTTPS.

## Manual browser checks still to do (about 15 minutes)
1. Sign Up with a new email, complete the profile, and confirm Home shows discussions after that.
2. Switch dark and light on Home, Communities, a community, a discussion, Courses and Search. Look for unreadable text.
3. Collapse and expand the sidebar on each of those pages in both themes.
4. In a community you joined: write a discussion with an emoji, an image, a GIF and a voice message. Open it, play the voice message, open an image.
5. Reply with text and with a voice message. Edit and delete your own discussion and reply. Confirm another account cannot.
6. Refresh the page after each step and confirm everything is still there. Restart the backend and check again.
7. Join and leave a community and watch it move between My Communities and Discover Communities.
8. Search for "design" and for an Armenian word that appears in a discussion you wrote. Try each filter and open a result of each type.
9. Open a course and a webinar. Check Free/Paid, the Sample notice and the registration link.
10. Sign out and open `/communities` and `/search` to see the Sign In prompt.
11. Resize the window to a tablet and a phone width and look for broken layouts.
