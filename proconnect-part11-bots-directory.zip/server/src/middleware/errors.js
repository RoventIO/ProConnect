import { HttpError } from '../utils/httpError.js';

/** Turns a file-upload problem into a message that matches the limits of the place where the file was sent. */
function uploadProblem(err) {
  const field = err.field;
  if (err.code === 'LIMIT_FILE_SIZE') {
    const limit = field === 'avatar' ? 'The profile photo can be up to 2 MB.'
      : field === 'voice' ? 'The voice message is too large. The maximum size is 5 MB.'
      : 'Each image can be up to 5 MB.';
    return { status: 413, code: 'file_too_large', message: limit };
  }
  if (err.code === 'LIMIT_UNEXPECTED_FILE' || err.code === 'LIMIT_FILE_COUNT') {
    const message = field === 'images' ? 'You can attach up to 4 images.'
      : field === 'voice' ? 'You can attach only one voice message.'
      : 'Send a single image.';
    return { status: 400, code: 'too_many_files', message };
  }
  return { status: 400, code: 'upload_error', message: 'The upload could not be processed. Check the files and try again.' };
}

export function notFound(req, res) {
  res.status(404).json({ error: { code: 'not_found', message: `No route for ${req.method} ${req.originalUrl}` } });
}

// eslint-disable-next-line no-unused-vars
export function errorHandler(err, req, res, next) {
  if (err instanceof HttpError) {
    return res.status(err.status).json({ error: { code: err.code, message: err.message, ...(err.fields ? { fields: err.fields } : {}) } });
  }
  if (err.name === 'MulterError') {
    const { status, code, message } = uploadProblem(err);
    return res.status(status).json({ error: { code, message } });
  }
  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: { code: 'invalid_json', message: 'Request body is not valid JSON.' } });
  }
  console.error(err);
  return res.status(500).json({ error: { code: 'server_error', message: 'Something went wrong on the server.' } });
}
