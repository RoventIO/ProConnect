import jwt from 'jsonwebtoken';
import { config } from '../config.js';
import { getDb } from '../db/index.js';
import { HttpError } from '../utils/httpError.js';
import { canPublishListings } from '../utils/permissions.js';

export const COOKIE = 'pc_token';
const WEEK_MS = 7 * 24 * 60 * 60 * 1000;
const cookieOptions = { httpOnly: true, sameSite: 'lax', secure: config.isProd };

export function issueSession(res, userId) {
  const token = jwt.sign({ sub: userId }, config.jwtSecret, { expiresIn: '7d' });
  res.cookie(COOKIE, token, { ...cookieOptions, maxAge: WEEK_MS });
}

export function clearSession(res) {
  res.clearCookie(COOKIE, cookieOptions);
}

/** Reads the session cookie and attaches the current user (if any) to req.user. Never throws. */
export function loadUser(req, res, next) {
  const token = req.cookies?.[COOKIE];
  if (token) {
    try {
      const { sub } = jwt.verify(token, config.jwtSecret);
      req.user = getDb().prepare('SELECT * FROM users WHERE id = ?').get(sub) || null;
    } catch {
      req.user = null; // expired or tampered token: treat as signed out
    }
  }
  next();
}

export function requireAuth(req, res, next) {
  if (!req.user) throw new HttpError(401, 'Please sign in to continue.', 'unauthenticated');
  next();
}

/** Visitors and members without the minimum professional profile cannot see internal content (FR-01). */
export function requireOnboarded(req, res, next) {
  if (!req.user.profile_completed) {
    throw new HttpError(403, 'Complete your professional profile to access ProConnect content.', 'profile_incomplete');
  }
  next();
}

/** Community creation and removal are reserved for administrators (PRD FR-03, business rule 6). */
export function requireAdmin(req, res, next) {
  if (req.user?.role !== 'admin') {
    throw new HttpError(403, 'Only administrators can do this.', 'forbidden');
  }
  next();
}

/** Publishing courses and webinars needs the Authorized Organizer permission (PRD FR-06). Nothing else grants it. */
export function requireOrganizer(req, res, next) {
  if (!canPublishListings(req.user)) {
    throw new HttpError(403, 'Only authorized organizers can publish courses and webinars.', 'forbidden');
  }
  next();
}
