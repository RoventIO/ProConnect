import { getDb } from '../db/index.js';

/** Professional status labels (PRD section 5). Community Leader, Authorized Organizer and Admin are permissions, not statuses. */
export const SELF_SELECTABLE_STATUSES = ['student', 'beginner'];
export const STATUSES = [...SELF_SELECTABLE_STATUSES, 'professional'];

export const isAdmin = (user) => user?.role === 'admin';

/** Authorized Organizer permission: granted by an Admin only, covers both courses and webinars. Leaders, Professionals and Admins do not get it implicitly. */
export const canPublishListings = (user) => !!user && !!user.is_organizer;

/**
 * True when the user leads this community, or leads its parent (a parent's leader also leads its subcommunities).
 * Being an Admin does not make someone a leader; check isAdmin separately where Admins are allowed.
 */
export function isLeaderOf(user, communityId, db = getDb()) {
  if (!user || !Number.isInteger(communityId)) return false;
  return !!db
    .prepare(
      `SELECT 1 FROM community_leaders cl
        WHERE cl.user_id = ?
          AND (cl.community_id = ? OR cl.community_id = (SELECT parent_id FROM communities WHERE id = ?))`
    )
    .get(user.id, communityId, communityId);
}

/** Subcommunities: Admin anywhere, or the leader of that exact parent community. Top-level communities are Admin-only. */
export function canCreateSubcommunity(user, parentId, db = getDb()) {
  if (isAdmin(user)) return true;
  if (!user || !Number.isInteger(parentId)) return false;
  return !!db.prepare('SELECT 1 FROM community_leaders WHERE user_id = ? AND community_id = ?').get(user.id, parentId);
}
