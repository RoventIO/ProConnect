export class HttpError extends Error {
  constructor(status, message, code = 'error', fields) {
    super(message);
    this.status = status;
    this.code = code;
    this.fields = fields; // optional { fieldName: 'message' } for form validation
  }
}

export const validationError = (fields) =>
  new HttpError(400, 'Please fix the highlighted fields.', 'validation_error', fields);

/** Lets async route handlers forward rejected promises to the Express error handler. */
export const asyncHandler = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

export const badRequest = (msg, code = 'bad_request') => new HttpError(400, msg, code);
export const notFoundError = (msg = 'Not found') => new HttpError(404, msg, 'not_found');

/** Parses a positive integer route parameter or throws 400. */
export function parseId(value, label = 'id') {
  const n = Number(value);
  if (!Number.isInteger(n) || n <= 0) throw badRequest(`Invalid ${label}.`, 'invalid_id');
  return n;
}
