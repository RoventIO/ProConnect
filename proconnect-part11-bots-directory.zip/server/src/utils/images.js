import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { config } from '../config.js';
import { HttpError } from './httpError.js';

/** Only file names we generated ourselves are ever read from disk (blocks path tricks). */
export const FILE_RE = /^[a-f0-9]{32}\.(jpg|png|webp|gif|webm|ogg|m4a|mp3|wav)$/;
export const CONTENT_TYPES = {
  jpg: 'image/jpeg',
  png: 'image/png',
  webp: 'image/webp',
  gif: 'image/gif',
  webm: 'audio/webm',
  ogg: 'audio/ogg',
  m4a: 'audio/mp4',
  mp3: 'audio/mpeg',
  wav: 'audio/wav',
};
export const MAX_IMAGE_BYTES = 2 * 1024 * 1024; // profile photos
export const MAX_ATTACHMENT_BYTES = 5 * 1024 * 1024; // images and voice messages in discussions

const ascii = (buf, from, to) => buf.subarray(from, to).toString('ascii');

/** Identifies the real file type from the first bytes. The client's claimed type and file name are not trusted. */
function sniffImage(buf) {
  if (buf.length < 12) return null;
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'jpg';
  if (buf.subarray(0, 8).equals(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]))) return 'png';
  if (ascii(buf, 0, 4) === 'RIFF' && ascii(buf, 8, 12) === 'WEBP') return 'webp';
  if (ascii(buf, 0, 6) === 'GIF87a' || ascii(buf, 0, 6) === 'GIF89a') return 'gif';
  return null;
}

function sniffAudio(buf) {
  if (buf.length < 12) return null;
  if (buf[0] === 0x1a && buf[1] === 0x45 && buf[2] === 0xdf && buf[3] === 0xa3) return 'webm'; // Chrome, Edge, Firefox
  if (ascii(buf, 0, 4) === 'OggS') return 'ogg'; // Firefox
  if (ascii(buf, 4, 8) === 'ftyp') return 'm4a'; // Safari
  if (ascii(buf, 0, 4) === 'RIFF' && ascii(buf, 8, 12) === 'WAVE') return 'wav';
  if (ascii(buf, 0, 3) === 'ID3' || (buf[0] === 0xff && (buf[1] & 0xe0) === 0xe0)) return 'mp3';
  return null;
}

const MESSAGES = {
  image: 'Upload a JPG, PNG, GIF or WebP image.',
  audio: 'That voice message format is not supported. Record it again.',
};

/** Validates and stores an uploaded image or voice message under a random name. Returns the file name. */
export function saveMedia(buffer, kind = 'image') {
  const ext = (kind === 'audio' ? sniffAudio : sniffImage)(buffer);
  if (!ext) throw new HttpError(400, MESSAGES[kind], 'unsupported_type');
  fs.mkdirSync(config.uploadDir, { recursive: true });
  const name = `${crypto.randomBytes(16).toString('hex')}.${ext}`;
  fs.writeFileSync(path.join(config.uploadDir, name), buffer, { flag: 'wx' });
  return name;
}

export const saveImage = (buffer) => saveMedia(buffer, 'image');

export function deleteImage(name) {
  if (!name || !FILE_RE.test(name)) return;
  try {
    fs.unlinkSync(path.join(config.uploadDir, name));
  } catch {
    /* already gone */
  }
}
export const deleteMedia = deleteImage;

export function clearUploads() {
  try {
    for (const f of fs.readdirSync(config.uploadDir)) deleteImage(f);
  } catch {
    /* folder does not exist yet */
  }
}

export const imageUrl = (name) => (name ? `/api/uploads/${name}` : null);
