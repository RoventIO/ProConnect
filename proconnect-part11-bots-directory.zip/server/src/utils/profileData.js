import { publicUser } from './user.js';

const shapeItem = (i) => ({
  id: i.id,
  kind: i.kind,
  title: i.title,
  subtitle: i.subtitle,
  period: i.period,
  description: i.description,
  url: i.url,
});

/** Member-facing user data: never includes the email address, role or organizer permission. */
function memberView(row) {
  const { email, role, isOrganizer, ...rest } = publicUser(row); // eslint-disable-line no-unused-vars
  return { ...rest, memberSince: row.created_at };
}

/** Everything the My Profile / member profile pages need. `self` also exposes the email. */
export function buildProfile(db, row, { self = false } = {}) {
  const id = row.id;
  const items = db.prepare('SELECT * FROM profile_items WHERE user_id = ? ORDER BY id').all(id).map(shapeItem);

  const communities = db
    .prepare(
      `SELECT c.id, c.name, c.category,
              (SELECT COUNT(*) FROM memberships m2 JOIN users u2 ON u2.id = m2.user_id WHERE m2.community_id = c.id AND u2.role <> 'admin') AS member_count,
              (SELECT MAX(p.created_at) FROM posts p
                 WHERE p.community_id = c.id OR p.community_id IN (SELECT id FROM communities WHERE parent_id = c.id)) AS last_activity
         FROM memberships m JOIN communities c ON c.id = m.community_id
        WHERE m.user_id = ? ORDER BY m.joined_at`
    )
    .all(id)
    .map((c) => ({ id: c.id, name: c.name, category: c.category, memberCount: c.member_count, lastActivity: c.last_activity }));

  const recentPosts = db
    .prepare(
      `SELECT p.id, p.title, p.created_at, c.id AS community_id, c.name AS community_name,
              (SELECT COUNT(*) FROM comments x WHERE x.post_id = p.id) AS comment_count
         FROM posts p JOIN communities c ON c.id = p.community_id
        WHERE p.author_id = ? ORDER BY p.created_at DESC LIMIT 5`
    )
    .all(id)
    .map((p) => ({ id: p.id, title: p.title, createdAt: p.created_at, commentCount: p.comment_count, community: { id: p.community_id, name: p.community_name } }));

  const count = (sql) => db.prepare(sql).get(id).n;
  return {
    user: self ? { ...publicUser(row), memberSince: row.created_at } : memberView(row),
    items: {
      experience: items.filter((i) => i.kind === 'experience'),
      education: items.filter((i) => i.kind === 'education'),
      projects: items.filter((i) => i.kind === 'project'),
    },
    communities,
    recentPosts,
    stats: {
      communities: communities.length,
      discussions: count('SELECT COUNT(*) AS n FROM posts WHERE author_id = ?'),
      replies: count('SELECT COUNT(*) AS n FROM comments WHERE author_id = ?'),
    },
  };
}

export { shapeItem };
