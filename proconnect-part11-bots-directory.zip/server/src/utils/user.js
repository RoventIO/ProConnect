import { imageUrl } from './images.js';

/** The user shape that is safe to send to the browser (never includes the password hash). */
export function publicUser(row) {
  let skills = [];
  try {
    skills = JSON.parse(row.skills || '[]');
  } catch {
    skills = [];
  }
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    avatarUrl: imageUrl(row.avatar_file),
    profession: row.profession,
    headline: row.headline,
    bio: row.bio,
    skills,
    location: row.location,
    yearsExperience: row.years_experience,
    profileCompleted: !!row.profile_completed,
    role: row.role,
    isAdmin: row.role === 'admin',
    status: row.status,
    isOrganizer: !!row.is_organizer,
    isBot: !!row.is_bot,
  };
}
