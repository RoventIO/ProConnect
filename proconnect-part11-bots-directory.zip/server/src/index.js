import { createApp } from './app.js';
import { getDb } from './db/index.js';
import { config } from './config.js';

if (config.isProd && config.jwtSecret === 'dev-only-secret-change-me') {
  console.warn('WARNING: set the JWT_SECRET environment variable before running in production.');
}

const db = getDb();
const hasData = db.prepare('SELECT COUNT(*) AS n FROM communities').get().n > 0;
if (!hasData) console.log('Database is empty. Run "npm run seed" to load demonstration data.');

createApp().listen(config.port, () => {
  console.log(`ProConnect API running at http://localhost:${config.port}`);
});
