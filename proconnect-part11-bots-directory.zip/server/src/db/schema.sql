-- ProConnect conceptual data model (PRD section 12), P0 entities.
-- Deferred (P1/P2): notifications, credential reviews, status assignments, news, jobs.

CREATE TABLE IF NOT EXISTS users (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  name                TEXT    NOT NULL,
  email               TEXT    NOT NULL UNIQUE COLLATE NOCASE,
  password_hash       TEXT    NOT NULL,
  profession          TEXT,
  headline            TEXT,
  bio                 TEXT,
  skills              TEXT    NOT NULL DEFAULT '[]',   -- JSON array of strings
  location            TEXT,
  years_experience    INTEGER,
  avatar_file         TEXT,                        -- profile photo file name in the uploads folder
  profile_completed   INTEGER NOT NULL DEFAULT 0,      -- 1 once minimum profile is filled (gates content, FR-01)
  role                TEXT    NOT NULL DEFAULT 'member' CHECK (role IN ('member', 'admin')),
  status              TEXT    NOT NULL DEFAULT 'beginner',  -- 'student' | 'beginner' (self-selected) | 'professional' (Admin only)
  is_bot              INTEGER NOT NULL DEFAULT 0,      -- 1 for clearly labelled demo bot accounts; they cannot sign in and hold no permissions
  is_organizer        INTEGER NOT NULL DEFAULT 0,      -- Authorized Organizer permission, granted by an Admin (courses and webinars)
  created_at          TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at          TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);

-- Work experience, education and portfolio projects / external links (FR-02).
CREATE TABLE IF NOT EXISTS profile_items (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind        TEXT    NOT NULL CHECK (kind IN ('experience', 'education', 'project')),
  title       TEXT    NOT NULL,
  subtitle    TEXT,
  period      TEXT,
  description TEXT,
  url         TEXT
);
CREATE INDEX IF NOT EXISTS idx_profile_items_user ON profile_items(user_id);

CREATE TABLE IF NOT EXISTS communities (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT    NOT NULL,
  slug        TEXT    NOT NULL UNIQUE,
  description TEXT    NOT NULL DEFAULT '',
  category    TEXT    NOT NULL,
  parent_id   INTEGER REFERENCES communities(id) ON DELETE SET NULL,   -- subcommunity support (FR-03)
  created_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  status      TEXT    NOT NULL DEFAULT 'approved' CHECK (status IN ('pending', 'approved', 'rejected')),
  created_at  TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_communities_parent ON communities(parent_id);
CREATE INDEX IF NOT EXISTS idx_communities_category ON communities(category);

-- Community Leader assignments: a leader's authority is limited to these communities (and their subcommunities).
CREATE TABLE IF NOT EXISTS community_leaders (
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  community_id INTEGER NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
  assigned_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
  assigned_at  TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  PRIMARY KEY (user_id, community_id)
);
CREATE INDEX IF NOT EXISTS idx_community_leaders_community ON community_leaders(community_id);

CREATE TABLE IF NOT EXISTS memberships (
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  community_id INTEGER NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
  joined_at    TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  PRIMARY KEY (user_id, community_id)
);
CREATE INDEX IF NOT EXISTS idx_memberships_community ON memberships(community_id);

CREATE TABLE IF NOT EXISTS posts (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  author_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  community_id INTEGER NOT NULL REFERENCES communities(id) ON DELETE CASCADE,
  title        TEXT    NOT NULL,
  content      TEXT    NOT NULL,
  created_at   TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at   TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_posts_community ON posts(community_id, created_at);
CREATE INDEX IF NOT EXISTS idx_posts_author ON posts(author_id);

CREATE TABLE IF NOT EXISTS comments (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id    INTEGER NOT NULL REFERENCES posts(id) ON DELETE CASCADE,
  author_id  INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content    TEXT    NOT NULL,
  created_at TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  updated_at TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_comments_post ON comments(post_id, created_at);

CREATE TABLE IF NOT EXISTS courses (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  title           TEXT    NOT NULL,
  description     TEXT    NOT NULL DEFAULT '',
  type            TEXT    NOT NULL CHECK (type IN ('course', 'webinar')),
  category        TEXT,
  organizer       TEXT,
  is_free         INTEGER NOT NULL DEFAULT 1,
  price_text      TEXT,                       -- display only; ProConnect does not process payments (FR-16)
  starts_at       TEXT,                       -- ISO date-time for scheduled events
  duration        TEXT,
  external_url    TEXT,
  approval_status TEXT    NOT NULL DEFAULT 'approved' CHECK (approval_status IN ('pending', 'approved', 'rejected')),
  is_sample       INTEGER NOT NULL DEFAULT 0, -- demonstration listing, not a verified live opportunity (rule 14)
  publisher_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at      TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
);
CREATE INDEX IF NOT EXISTS idx_courses_type ON courses(type);

-- Files attached to a post or a comment: images (JPG, PNG, WebP, GIF) and voice messages.
CREATE TABLE IF NOT EXISTS attachments (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  post_id      INTEGER REFERENCES posts(id) ON DELETE CASCADE,
  comment_id   INTEGER REFERENCES comments(id) ON DELETE CASCADE,
  owner_id     INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind         TEXT    NOT NULL CHECK (kind IN ('image', 'audio')),
  file         TEXT    NOT NULL,              -- name in the uploads folder (never a user-supplied name)
  duration_sec INTEGER,                       -- voice messages only
  position     INTEGER NOT NULL DEFAULT 0,
  created_at   TEXT    NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
  CHECK ((post_id IS NULL) <> (comment_id IS NULL))
);
CREATE INDEX IF NOT EXISTS idx_attachments_post ON attachments(post_id);
CREATE INDEX IF NOT EXISTS idx_attachments_comment ON attachments(comment_id);
