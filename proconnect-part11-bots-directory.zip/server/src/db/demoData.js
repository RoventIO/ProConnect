import path from 'node:path';
import fs from 'node:fs';
import { pathToFileURL } from 'node:url';
import bcrypt from 'bcryptjs';
import { getDb, transaction } from './index.js';
import { DEMO_PASSWORD } from './seed.js';
import { ensureAdmin } from './makeAdmin.js';
import { AREAS, BOTS, DIRECTORY } from './botContent.js';

/**
 * Demo content system. Everything here is deterministic and idempotent: rows are looked up by natural keys
 * (email, slug, community + title, post + author + text) before anything is inserted, so running it again never
 * duplicates content and never touches rows it did not create. Nothing is generated when the application starts.
 */

// The administrator account for manual testing. Created only when missing; an existing account is never changed.
export const OWNER_ADMIN = { email: 'owner.admin@proconnect.example', password: 'ProConnect-Owner-2026-Vk7Q', name: 'Site Owner' };

// The earlier ordinary-looking demo accounts that the bot system replaces (exact emails only).
export const LEGACY_DEMO_EMAILS = [
  'student@proconnect.example', 'beginner@proconnect.example', 'professional@proconnect.example',
  'leader@proconnect.example', 'organizer@proconnect.example',
];
export const LEGACY_DEMO_ADMIN_EMAIL = 'admin@proconnect.example';

export const BOT_DOMAIN = 'bots.proconnect.example';
const UNUSABLE_HASH = '!bot-account-cannot-sign-in'; // not a valid bcrypt hash, so no password can ever match

const slugify = (s) => s.toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
const hash = (s) => {
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) h = Math.imul(h ^ s.charCodeAt(i), 0x01000193);
  return h >>> 0;
};
const pick = (arr, seed) => arr[hash(seed) % arr.length];
const fill = (t, v) => t.replace(/\{(\w+)\}/g, (_, k) => v[k]);
const ago = (hours) => new Date(Date.now() - hours * 3600e3).toISOString();

// ---- phrasing pools. A variant is chosen per community, so neighbouring communities do not read alike ----
const T = {
  ask: [
    'I am fairly new to this and keep seeing {t0}, {t1} and {t2} mentioned. Where would you start, and what can wait?',
    'Looking for advice from people who work with this. I have been reading about {t0} and {t1}, but I am not sure what order makes sense. How did you learn it?',
    'Short question for the group: if you were starting over today, would you begin with {t0}, or with something else? I have a little time each week and want to spend it well.',
    'I have done a few tutorials and want to move toward real projects. {t0} and {t1} come up a lot. What would you focus on first?',
  ],
  answerA: [
    'I would begin with {t0}. {c1} That one idea clears up a surprising amount of early confusion.',
    'Start with {t0}, and keep the first project small. {c1}',
    'For me {t0} was the right first step. {c1} After that, {t1} makes more sense.',
  ],
  answerB: [
    'Agree with the above. Once {t0} feels comfortable, try {t1}; {t2} can wait until you have a real use for it.',
    'It is also worth reading the official documentation for {t1}. It is usually clearer than people expect, and it keeps you away from outdated blog posts.',
    'A practical tip: build something tiny with {t0}, write down what confused you, then go back and fill those gaps. {t2} is useful, but later.',
  ],
  thanks: [
    'Thanks, that gives me a concrete order to follow. I will start with {t0} this week.',
    'This is really helpful, especially the point about keeping the first project small. I will report back.',
    'Appreciate the pointers. I will try {t0} first and look at {t1} afterwards.',
  ],
  explain: [
    'Something that took me a while to internalize: {c2} Hopefully that saves someone a bit of time.',
    'Sharing a short explanation I wish I had read earlier. {c2}',
    'A quick note for newcomers. {c2} Happy to go deeper if anyone is interested.',
  ],
  askMore: [
    'Could you give an example where this matters in a real project? I understand the idea but I am not sure when I would run into it.',
    'Thanks for writing this down. Is there a good way to practice it, or does it only become clear on real work?',
    'This makes sense. How would you explain it to someone who has only just started?',
  ],
  explainAnswer: [
    'Good question. A common place it shows up: {pit}',
    'Here is a concrete case. {pit}',
    'You usually notice it when something goes wrong. For example: {pit}',
  ],
  explainExtra: [
    'If you want to experiment, {t1} is a reasonable place to try this out. Start with a small example and change one thing at a time.',
    'To add to this: {t0} is a good way to see the effect yourself. It is worth ten minutes before reading more theory.',
  ],
  lessonTitle: [
    'A mistake worth avoiding with {t0}',
    'Lessons from a project using {t0}',
    'Something that bit us when working with {t0}',
    'A pitfall to watch for with {t0}',
    'What I learned the hard way with {t0}',
  ],
  lessonBody: [
    'On one of our projects using {t0} we ran into this: {pit} We now note it in our team checklist so the next person does not repeat it.',
    'Sharing a lesson from a project. {pit} It was an easy fix once we understood it, but it cost us some time first.',
    'Not a question this time, just an experience report. {pit} We caught it in review, and I wish we had caught it earlier.',
  ],
  lessonAgree: [
    'This matches my experience too, especially when working with {t1}. Writing it into a checklist is a good idea.',
    'Thanks for sharing this. I have seen the same thing, and it is the kind of detail that rarely appears in tutorials.',
  ],
  lessonAsk: [
    'How did you notice it in the first place: tests, logs, or a user report?',
    'Did you find it yourselves, or did someone outside the team point it out?',
  ],
  lessonReply: [
    'Mostly during review. Afterwards we added it to our checklist so it gets caught earlier.',
    'A teammate spotted it while debugging something else, which is why we now review that area more carefully.',
    'It showed up during testing first, and then we found the same cause in two other places.',
  ],
};

/** Builds the three discussions of one community from its curated entry. Same input, same output, every time. */
export function composeDiscussions(entry, slug, authorKeys, recent = false) {
  const [A, B, C, D] = authorKeys;
  const v = { t0: entry.tools[0], t1: entry.tools[1], t2: entry.tools[2], c1: entry.c1[1], c2: entry.c2[1], pit: entry.pit };
  const p = (pool, role) => fill(pick(pool, `${slug}:${role}`), v);
  const when = (role, base) => base + (hash(`${slug}:${role}:t`) % (recent ? 12 : 360));
  const gap = (role, i) => (1 + (hash(`${slug}:${role}:g${i}`) % (recent ? 1 : 4))) * (i + 1) * (recent ? 0.25 : 1);

  // A main community's own discussions are recent, so they stay visible above its subcommunities' older ones.
  const [b1, b2, b3] = recent ? [8, 6, 5] : [40, 34, 30];
  const h1 = when('p1', b1), h2 = when('p2', b2), h3 = when('p3', b3);
  return [
    {
      title: entry.q, body: p(T.ask, 'ask'), by: A, hours: h1,
      comments: [
        { by: B, text: p(T.answerA, 'answerA'), hours: h1 - gap('p1', 0) },
        { by: C, text: p(T.answerB, 'answerB'), hours: h1 - gap('p1', 1) },
        { by: A, text: p(T.thanks, 'thanks'), hours: h1 - gap('p1', 2) },
      ],
    },
    {
      title: entry.c2[0], body: p(T.explain, 'explain'), by: B, hours: h2,
      comments: [
        { by: C, text: p(T.askMore, 'askMore'), hours: h2 - gap('p2', 0) },
        { by: B, text: p(T.explainAnswer, 'explainAnswer'), hours: h2 - gap('p2', 1) },
        { by: D, text: p(T.explainExtra, 'explainExtra'), hours: h2 - gap('p2', 2) },
      ],
    },
    {
      title: p(T.lessonTitle, 'lessonTitle'), body: p(T.lessonBody, 'lessonBody'), by: C, hours: h3,
      comments: [
        { by: D, text: p(T.lessonAgree, 'lessonAgree'), hours: h3 - gap('p3', 0) },
        { by: A, text: p(T.lessonAsk, 'lessonAsk'), hours: h3 - gap('p3', 1) },
        { by: C, text: p(T.lessonReply, 'lessonReply'), hours: h3 - gap('p3', 2) },
      ],
    },
  ];
}

const botEmail = (handle) => `${handle}@${BOT_DOMAIN}`;
const botKey = (b) => b[1];

function insertBot(db, { name, email, profession, headline, bio, skills, location, years }) {
  return Number(
    db.prepare(
      `INSERT INTO users (name, email, password_hash, profession, headline, bio, skills, location, years_experience, profile_completed, status, role, is_bot)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, 'beginner', 'member', 1)`
    ).run(name, email, UNUSABLE_HASH, profession, headline, bio, JSON.stringify(skills), location, years).lastInsertRowid
  );
}

// ---------------------------------------------------------------------------------------------------------------
// Removes the six earlier demo accounts. Content they wrote is kept: it is handed to a bot-labelled archive account,
// because other members may have replied to it. Memberships, profile entries and permissions of those accounts go.
// The admin@ account is only removed while it still has the demo password AND another administrator exists, so a
// real administrator can never be locked out or deleted by this command.
// ---------------------------------------------------------------------------------------------------------------
export function removeLegacyDemoAccounts() {
  const report = { removed: [], keptAdmin: null, contentHandedOver: { posts: 0, comments: 0 } };
  transaction((db) => {
    const targets = [];
    for (const email of LEGACY_DEMO_EMAILS) {
      const u = db.prepare('SELECT id, email, is_bot, role FROM users WHERE email = ?').get(email);
      if (u && !u.is_bot && u.role !== 'admin') targets.push(u);
    }
    const adminRow = db.prepare('SELECT id, email, password_hash, role, is_bot FROM users WHERE email = ?').get(LEGACY_DEMO_ADMIN_EMAIL);
    if (adminRow && adminRow.role === 'admin' && !adminRow.is_bot) {
      const stillDemoPassword = bcrypt.compareSync(DEMO_PASSWORD, adminRow.password_hash);
      const otherAdmin = db.prepare("SELECT 1 FROM users WHERE role = 'admin' AND id <> ?").get(adminRow.id);
      if (stillDemoPassword && otherAdmin) targets.push(adminRow);
      else report.keptAdmin = !stillDemoPassword ? 'kept: its password was changed, so it is treated as a real administrator account' : 'kept: it is the only administrator account';
    }
    if (!targets.length) return;

    let archive = db.prepare('SELECT id FROM users WHERE email = ?').get(botEmail('demo.archive'));
    if (!archive) {
      archive = { id: insertBot(db, { name: 'ProConnect Demo Archive', email: botEmail('demo.archive'), profession: 'Archived demo content',
        headline: 'Community bot · holds discussions from retired demo accounts', bio: 'Automated community bot. It only holds posts and replies that were written by earlier demo accounts, so other members\' conversations stay intact. Not a real person.',
        skills: [], location: null, years: null }) };
    }
    for (const u of targets) {
      report.contentHandedOver.posts += db.prepare('UPDATE posts SET author_id = ? WHERE author_id = ?').run(archive.id, u.id).changes;
      report.contentHandedOver.comments += db.prepare('UPDATE comments SET author_id = ? WHERE author_id = ?').run(archive.id, u.id).changes;
      db.prepare('UPDATE attachments SET owner_id = ? WHERE owner_id = ?').run(archive.id, u.id);
      const avatar = db.prepare('SELECT avatar_file FROM users WHERE id = ?').get(u.id)?.avatar_file;
      db.prepare('DELETE FROM users WHERE id = ?').run(u.id); // cascades: memberships, leader assignments, profile entries
      report.removed.push(u.email);
      void avatar; // demo accounts never had a photo; nothing on disk to remove
    }
  });
  return report;
}

/** Owner administrator for manual testing: created once, never modified afterwards. Returns 1 when it was created. */
export function ensureOwnerAdmin() {
  if (getDb().prepare('SELECT 1 FROM users WHERE email = ?').get(OWNER_ADMIN.email)) return 0;
  ensureAdmin(OWNER_ADMIN.email, OWNER_ADMIN.password, OWNER_ADMIN.name);
  return 1;
}

/** Adds the directory, the bots and their discussions. Safe to run any number of times. */
export function ensureDemoData() {
  const created = { owner: 0, bots: 0, communities: 0, subcommunities: 0, memberships: 0, posts: 0, comments: 0 };

  created.owner = ensureOwnerAdmin();

  transaction((db) => {
    // ---- bots ----
    const botId = {};
    const findUser = db.prepare('SELECT id FROM users WHERE email = ?');
    for (const b of BOTS) {
      const [name, handle, profession, areas, skills, location] = b;
      const email = botEmail(handle);
      const found = findUser.get(email);
      if (found) { botId[botKey(b)] = found.id; continue; }
      const areaNames = areas.map((a) => AREAS[a]);
      botId[botKey(b)] = insertBot(db, {
        name, email, profession, headline: `Community bot · ${profession}`,
        bio: `Automated community bot that posts curated demo discussions about ${areaNames.join(', ')}. Not a real person; it exists so the communities are active in a demo.`,
        skills: skills.split(', '), location, years: 3 + (hash(handle) % 12),
      });
      created.bots++;
    }

    // ---- communities ----
    const bySlug = db.prepare('SELECT id FROM communities WHERE slug = ?');
    const byNameParent = db.prepare('SELECT id FROM communities WHERE name = ? COLLATE NOCASE AND parent_id IS ?');
    const insCommunity = db.prepare('INSERT INTO communities (name, slug, description, category, parent_id, created_by) VALUES (?, ?, ?, ?, ?, NULL)');
    const ensureCommunity = (name, slug, desc, category, parent, kind) => {
      const found = bySlug.get(slug) || byNameParent.get(name, parent);
      if (found) return found.id;
      created[kind]++;
      return Number(insCommunity.run(name, slug, desc, category, parent).lastInsertRowid);
    };

    const insMember = db.prepare('INSERT OR IGNORE INTO memberships (user_id, community_id) VALUES (?, ?)');
    const findPost = db.prepare('SELECT id FROM posts WHERE community_id = ? AND title = ?');
    const insPost = db.prepare('INSERT INTO posts (author_id, community_id, title, content, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)');
    const findComment = db.prepare('SELECT 1 FROM comments WHERE post_id = ? AND author_id = ? AND content = ?');
    const insComment = db.prepare('INSERT INTO comments (post_id, author_id, content, created_at, updated_at) VALUES (?, ?, ?, ?, ?)');

    const populate = (entry, communityId, slug, area, recent = false) => {
      const candidates = BOTS.filter((b) => b[3].includes(area)).sort((x, y) => hash(`${slug}:${x[1]}`) - hash(`${slug}:${y[1]}`)).slice(0, 4);
      const keys = candidates.map(botKey);
      for (const k of keys) created.memberships += insMember.run(botId[k], communityId).changes;
      for (const d of composeDiscussions(entry, slug, keys, recent)) {
        let post = findPost.get(communityId, d.title);
        if (!post) {
          const t = ago(d.hours);
          post = { id: Number(insPost.run(botId[d.by], communityId, d.title, d.body, t, t).lastInsertRowid) };
          created.posts++;
        }
        for (const c of d.comments) {
          if (findComment.get(post.id, botId[c.by], c.text)) continue;
          const t = ago(Math.max(c.hours, 0.5));
          insComment.run(post.id, botId[c.by], c.text, t, t);
          created.comments++;
        }
      }
    };

    for (const dir of DIRECTORY) {
      const topSlug = slugify(dir.top.name);
      const topId = ensureCommunity(dir.top.name, topSlug, dir.top.desc, dir.top.name, null, 'communities');
      populate(dir.top, topId, topSlug, dir.area, true);
      // Every bot with this specialty joins the main community.
      for (const b of BOTS) if (b[3].includes(dir.area)) created.memberships += insMember.run(botId[botKey(b)], topId).changes;
      for (const sub of dir.subs) {
        const slug = `${topSlug}-${slugify(sub.name)}`;
        const subId = ensureCommunity(sub.name, slug, sub.desc, dir.top.name, topId, 'subcommunities');
        populate(sub, subId, slug, dir.area);
      }
    }
  });
  return created;
}

const isMain = process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href;
if (isMain) {
  const cleanupOnly = process.argv.includes('--cleanup-only');
  if (ensureOwnerAdmin()) console.log(`Created the administrator account ${OWNER_ADMIN.email}.`); // first, so the old admin@ demo account is never the only administrator
  const removal = removeLegacyDemoAccounts();
  console.log('Old demo accounts removed:', removal.removed.length ? removal.removed.join(', ') : 'none (already gone)');
  if (removal.keptAdmin) console.log(`${LEGACY_DEMO_ADMIN_EMAIL} ${removal.keptAdmin}`);
  if (removal.contentHandedOver.posts || removal.contentHandedOver.comments) console.log('Their discussions and replies were kept and now belong to the "ProConnect Demo Archive" bot:', removal.contentHandedOver);
  if (!cleanupOnly) {
    const created = ensureDemoData();
    console.log('Directory and bot content checked. Newly created (all 0 means it was already complete):', created);
    console.log(`Administrator for manual testing: ${OWNER_ADMIN.email} (see the README for the password).`);
  }
  void fs;
}
