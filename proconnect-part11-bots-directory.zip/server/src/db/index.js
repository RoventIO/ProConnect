import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';
import { config } from '../config.js';

const here = path.dirname(fileURLToPath(import.meta.url));
let db;

/** Case folding for every script. Upper-casing first also unifies special letters such as the Armenian ligature "և" with "եւ". */
const fold = (v) => String(v).normalize('NFC').toUpperCase().toLowerCase();

/** Adds columns introduced after the first release to databases created earlier. */
function migrate(d) {
  const userCols = d.prepare('PRAGMA table_info(users)').all().map((c) => c.name);
  if (!userCols.includes('avatar_file')) d.exec('ALTER TABLE users ADD COLUMN avatar_file TEXT');
  if (!userCols.includes('is_bot')) d.exec('ALTER TABLE users ADD COLUMN is_bot INTEGER NOT NULL DEFAULT 0');
  if (!userCols.includes('is_organizer')) d.exec('ALTER TABLE users ADD COLUMN is_organizer INTEGER NOT NULL DEFAULT 0');
  // Earlier builds stored free-text statuses. Keep professional ones, map everything else to the agreed labels.
  d.exec(`UPDATE users SET status = 'professional' WHERE status IN ('experienced_professional')`);
  d.exec(`UPDATE users SET status = 'beginner' WHERE status NOT IN ('student', 'beginner', 'professional')`);
}

/** Opens the database once, enforces foreign keys and makes sure the schema exists. */
export function getDb() {
  if (!db) {
    if (config.dbPath !== ':memory:') fs.mkdirSync(path.dirname(config.dbPath), { recursive: true });
    db = new DatabaseSync(config.dbPath);
    db.exec('PRAGMA foreign_keys = ON;');
    // SQLite's LIKE ignores letter case only for English letters. ulike(text, needle) is a case-insensitive
    // "contains" for every script (Armenian, Cyrillic, Greek...), used by search and list filters.
    db.function('ulike', { deterministic: true }, (text, needle) => {
      if (text == null || needle == null) return 0;
      return fold(text).includes(fold(needle)) ? 1 : 0;
    });
    db.exec(fs.readFileSync(path.join(here, 'schema.sql'), 'utf8'));
    migrate(db);
  }
  return db;
}

/** Runs fn inside a transaction; rolls back if it throws. */
export function transaction(fn) {
  const d = getDb();
  d.exec('BEGIN');
  try {
    const result = fn(d);
    d.exec('COMMIT');
    return result;
  } catch (err) {
    d.exec('ROLLBACK');
    throw err;
  }
}
