import path from 'node:path';
import { pathToFileURL } from 'node:url';
import bcrypt from 'bcryptjs';
import { getDb, transaction } from './index.js';
import { clearUploads } from '../utils/images.js';

export const DEMO_PASSWORD = 'ProConnect123!';

export const ago = (hours) => new Date(Date.now() - hours * 3600 * 1000).toISOString();

export const COMMUNITIES = [
  { name: 'Software Development', category: 'Technology', description: 'Architecture, code quality, tooling, and career growth for engineers.', subs: ['Frontend', 'Backend', 'DevOps'] },
  { name: 'Healthcare Professionals', category: 'Healthcare', description: 'Clinical practice, health informatics, and peer case discussions.', subs: ['Nursing', 'Health Informatics'] },
  { name: 'Design & UX', category: 'Design', description: 'Research, interaction design, and design systems in practice.', subs: ['UX Research', 'Design Systems'] },
  { name: 'Finance & Accounting', category: 'Finance', description: 'Reporting, audit, and analysis questions from working finance teams.', subs: ['Audit', 'Financial Analysis'] },
  { name: 'Teachers & Educators', category: 'Education', description: 'Classroom methods, curriculum ideas, and professional development.', subs: ['Primary', 'Higher Education'] },
  { name: 'Product Management', category: 'Technology', description: 'Roadmaps, prioritization, and stakeholder communication.', subs: ['Discovery', 'Growth'] },
];

export const USERS = [
  { key: 'admin', name: 'ProConnect Admin', email: 'admin@proconnect.example', profession: 'Platform Administrator', headline: 'ProConnect administration', location: 'Yerevan, Armenia', years: 10, status: 'beginner', role: 'admin',
    bio: 'Administrator account for testing: can create and remove communities and subcommunities.',
    skills: ['Community Management', 'Moderation'] },
  { key: 'alex', name: 'Alex Morgan', email: 'alex.morgan@example.com', profession: 'Product Designer', headline: 'Senior Product Designer · Design & UX', location: 'London, United Kingdom', years: 9, status: 'professional',
    bio: 'Product designer focused on complex, data-heavy tools. I enjoy mentoring early-career designers and sharing practical lessons from shipping design systems at scale.',
    skills: ['Product Design', 'UX Research', 'Design Systems', 'Prototyping', 'Mentoring'] },
  { key: 'sara', name: 'Sara Kim', email: 'sara.kim@example.com', profession: 'Software Engineer', headline: 'Senior Software Engineer', location: 'Berlin, Germany', years: 11, status: 'professional',
    bio: 'Backend engineer who cares about maintainable systems and humane code review.', skills: ['Node.js', 'System Design', 'Code Review'] },
  { key: 'daniel', name: 'Dr. Daniel Reyes', email: 'daniel.reyes@example.com', profession: 'Physician', headline: 'Physician exploring health informatics', location: 'Madrid, Spain', years: 8, status: 'professional',
    bio: 'Clinician interested in the bridge between patient care and data.', skills: ['Clinical Practice', 'Health Informatics'] },
  { key: 'laura', name: 'Laura Bennett', email: 'laura.bennett@example.com', profession: 'Product Designer', headline: 'Freelance Product Designer', location: 'Toronto, Canada', years: 6, status: 'professional',
    bio: 'Independent designer working with early-stage teams.', skills: ['UI Design', 'Freelancing', 'Branding'] },
  { key: 'thomas', name: 'Thomas Nguyen', email: 'thomas.nguyen@example.com', profession: 'Project Manager', headline: 'Project Manager', location: 'Sydney, Australia', years: 7, status: 'professional',
    bio: 'Delivery lead who enjoys untangling complex programmes.', skills: ['Project Management', 'Agile', 'Stakeholders'] },
];

export const PROFILE_ITEMS = [
  ['alex', 'experience', 'Senior Product Designer', 'Northvale Software', '2021 – Present', 'Leads design for the analytics platform', null],
  ['alex', 'experience', 'Product Designer', 'Brightline Studio', '2017 – 2021', 'Web and mobile products for fintech clients', null],
  ['alex', 'education', 'MA Interaction Design', 'Royal College of Art', '2014 – 2016', 'Distinction', null],
  ['alex', 'education', 'BA Graphic Design', 'University of Leeds', '2010 – 2013', 'First-class honours', null],
  ['alex', 'project', 'Portfolio website', 'alexmorgan.design', null, null, 'https://example.com/alexmorgan.design'],
  ['alex', 'project', 'Case study: Analytics redesign', 'alexmorgan.design/analytics', null, null, 'https://example.com/alexmorgan.design/analytics'],
];

// [community name, author key, title, content, hours ago]
export const POSTS = [
  ['Backend', 'sara', 'How do you structure code reviews on a small team?', 'We are a team of five and reviews either take days or get rubber-stamped. How do you keep them fast and still useful? Interested in checklists, review size limits, and ownership rules.', 2],
  ['Health Informatics', 'daniel', 'Moving from clinical practice into health informatics', 'After eight years as a physician I want to work on clinical data systems. Which skills and certifications helped you make the switch?', 5],
  ['Design Systems', 'laura', 'Practical tips for negotiating freelance design contracts', 'What clauses do you always include? I am especially unsure about revision limits and kill fees.', 20],
  ['Product Management', 'thomas', 'Which certifications actually matter for project managers?', 'There are dozens of certifications. Which ones changed how you work or helped you get hired?', 22],
  ['Design & UX', 'alex', 'Design tokens in practice', 'Sharing how we structured colour, spacing and typography tokens so that dark and light themes share one source of truth.', 24],
  ['Design & UX', 'alex', 'How do you structure design critiques?', 'Our critiques drift into personal taste. What format keeps feedback specific and actionable?', 2],
];

// [post title prefix, author key, content, hours ago]
export const COMMENTS = [
  ['How do you structure code reviews', 'alex', 'We cap pull requests at roughly 300 changed lines and rotate a named reviewer each week.', 1],
  ['How do you structure code reviews', 'thomas', 'A short checklist in the PR template helped us a lot.', 1],
  ['Moving from clinical practice', 'sara', 'Learning SQL and FHIR basics gave me the clearest overlap with clinical work.', 4],
  ['Design tokens in practice', 'laura', 'Great write-up. Did you generate tokens from one JSON source?', 12],
  ['Which certifications', 'sara', 'In my experience a good track record mattered more than any certificate.', 20],
];

export const MEMBERSHIPS = {
  alex: ['Design & UX', 'Product Management', 'Software Development'],
  sara: ['Software Development'],
  daniel: ['Healthcare Professionals'],
  laura: ['Design & UX'],
  thomas: ['Product Management'],
};

export const iso = (y, m, d, h = 0) => new Date(Date.UTC(y, m - 1, d, h)).toISOString();

export const COURSES = [
  { title: 'Scaling Engineering Teams', type: 'webinar', category: 'Software Development', organizer: 'Priya Shah, VP Engineering', free: 1, starts: iso(2026, 10, 22, 18), duration: 'Live · 60 min', description: 'How engineering organisations keep quality and speed as they grow past their first fifty people.' },
  { title: 'Product Management Fundamentals', type: 'course', category: 'Product Management', organizer: 'Daniel Cho, Group PM', free: 0, price: 'Paid', duration: '6 weeks · Self-paced with mentors · Certificate included', description: 'Discovery, prioritisation and stakeholder communication, taught through real product cases.' },
  { title: 'Data Storytelling for Analysts', type: 'webinar', category: 'Data & Analytics', organizer: 'Marcus Hale, Data Lead', free: 1, starts: iso(2026, 10, 29, 17), duration: 'Live · 240 seats left', description: 'Turn analysis into narratives that decision makers act on.' },
  { title: 'Clinical Research Essentials', type: 'course', category: 'Healthcare', organizer: 'Dr. Elena Park', free: 0, price: 'Paid', starts: iso(2026, 11, 5, 9), duration: '4 weeks', description: 'Study design, ethics and reporting fundamentals for clinical research teams.' },
  { title: 'Designing Accessible Interfaces', type: 'webinar', category: 'Design & UX', organizer: 'Nora Ellis, Accessibility Lead', free: 1, starts: iso(2026, 11, 12, 19), duration: 'Live · 75 min', description: 'Practical accessibility patterns for forms, navigation and data-heavy screens.' },
  { title: 'Financial Modeling for Teams', type: 'course', category: 'Finance & Accounting', organizer: 'Samuel Rowe, CFA', free: 0, price: 'Paid', duration: '8 weeks · Self-paced', description: 'Build reliable three-statement models that non-finance colleagues can follow.' },
];

/** Wipes demonstration tables and loads sample content. Safe to run repeatedly. */
export function seedDatabase() {
  const passwordHash = bcrypt.hashSync(DEMO_PASSWORD, 10);
  clearUploads(); // the database is reset, so previously uploaded images would be orphans

  transaction((db) => {
    for (const t of ['comments', 'posts', 'community_leaders', 'memberships', 'profile_items', 'courses']) db.exec(`DELETE FROM ${t}`);
    db.exec('DELETE FROM communities WHERE parent_id IS NOT NULL');
    db.exec('DELETE FROM communities');
    db.exec('DELETE FROM users');
    db.exec("DELETE FROM sqlite_sequence");

    const userId = {};
    const insUser = db.prepare(
      `INSERT INTO users (name, email, password_hash, profession, headline, bio, skills, location, years_experience, profile_completed, status, role)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?, ?)`
    );
    for (const u of USERS) {
      userId[u.key] = insUser.run(u.name, u.email, passwordHash, u.profession, u.headline, u.bio, JSON.stringify(u.skills), u.location, u.years, u.status, u.role || 'member').lastInsertRowid;
    }

    const communityId = {};
    const insCommunity = db.prepare('INSERT INTO communities (name, slug, description, category, parent_id, created_by) VALUES (?, ?, ?, ?, ?, ?)');
    const slug = (s) => s.toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    for (const c of COMMUNITIES) {
      const parent = insCommunity.run(c.name, slug(c.name), c.description, c.category, null, null).lastInsertRowid;
      communityId[c.name] = parent;
      for (const s of c.subs) {
        communityId[s] = insCommunity.run(s, `${slug(c.name)}-${slug(s)}`, `${s} discussions within ${c.name}.`, c.category, parent, null).lastInsertRowid;
      }
    }

    const insItem = db.prepare('INSERT INTO profile_items (user_id, kind, title, subtitle, period, description, url) VALUES (?, ?, ?, ?, ?, ?, ?)');
    for (const [k, kind, title, subtitle, period, description, url] of PROFILE_ITEMS) insItem.run(userId[k], kind, title, subtitle, period, description, url);

    const insMember = db.prepare('INSERT INTO memberships (user_id, community_id) VALUES (?, ?)');
    for (const [k, names] of Object.entries(MEMBERSHIPS)) for (const n of names) insMember.run(userId[k], communityId[n]);

    // Demonstration permissions: Alex leads Design & UX; Sara is an Authorized Organizer (granted by the admin account).
    db.prepare('INSERT INTO community_leaders (user_id, community_id, assigned_by) VALUES (?, ?, ?)').run(userId.alex, communityId['Design & UX'], userId.admin);
    db.prepare('UPDATE users SET is_organizer = 1 WHERE id = ?').run(userId.sara);

    const postId = {};
    const insPost = db.prepare('INSERT INTO posts (author_id, community_id, title, content, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?)');
    for (const [community, author, title, content, hours] of POSTS) {
      const t = ago(hours);
      postId[title] = insPost.run(userId[author], communityId[community], title, content, t, t).lastInsertRowid;
    }

    const insComment = db.prepare('INSERT INTO comments (post_id, author_id, content, created_at, updated_at) VALUES (?, ?, ?, ?, ?)');
    for (const [prefix, author, content, hours] of COMMENTS) {
      const title = Object.keys(postId).find((t) => t.startsWith(prefix));
      const t = ago(hours);
      insComment.run(postId[title], userId[author], content, t, t);
    }

    const insCourse = db.prepare(
      `INSERT INTO courses (title, description, type, category, organizer, is_free, price_text, starts_at, duration, external_url, is_sample)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)`
    );
    for (const c of COURSES) {
      insCourse.run(c.title, c.description, c.type, c.category, c.organizer, c.free, c.price ?? null, c.starts ?? null, c.duration ?? null, `https://example.com/${slug(c.title)}`);
    }
  });

  const db = getDb();
  const count = (t) => db.prepare(`SELECT COUNT(*) AS n FROM ${t}`).get().n;
  return { users: count('users'), communities: count('communities'), posts: count('posts'), comments: count('comments'), courses: count('courses') };
}

const isMain = process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href;
if (isMain) {
  if (!process.argv.includes('--reset')) {
    console.log('This command DELETES all users, communities and discussions and loads fresh sample data.');
    console.log('To add the demo accounts and sample content without deleting anything, run:  npm run seed:demo');
    console.log('To really start from scratch, run:  npm run seed -- --reset');
    process.exit(1);
  }
  const summary = seedDatabase();
  console.log('Seeded demonstration data:', summary);
  console.log(`Now run "npm run seed:demo" to add the demo accounts (password ${DEMO_PASSWORD}) and extra sample content.`);
}
