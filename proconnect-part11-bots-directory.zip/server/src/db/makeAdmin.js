import path from 'node:path';
import { pathToFileURL } from 'node:url';
import bcrypt from 'bcryptjs';
import { getDb } from './index.js';

/** Promotes (or demotes) an existing account. Returns the user row, or null if the email is unknown. */
export function setAdmin(email, makeAdmin = true) {
  const db = getDb();
  const user = db.prepare('SELECT id, name FROM users WHERE email = ?').get(String(email).trim().toLowerCase());
  if (!user) return null;
  db.prepare('UPDATE users SET role = ? WHERE id = ?').run(makeAdmin ? 'admin' : 'member', user.id);
  return user;
}

/**
 * Recovery for a database whose admin account is missing or has a different password: creates the account when the
 * email is unknown (already onboarded, so it can sign in straight away), or resets the password of the existing one,
 * and makes it an administrator. Never touches any other row.
 */
export function ensureAdmin(email, password, name = 'ProConnect Admin') {
  const db = getDb();
  const clean = String(email).trim().toLowerCase();
  const hash = bcrypt.hashSync(password, 10);
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(clean);
  if (existing) {
    db.prepare("UPDATE users SET role = 'admin', password_hash = ? WHERE id = ?").run(hash, existing.id);
    return { created: false };
  }
  db.prepare(
    `INSERT INTO users (name, email, password_hash, profession, headline, bio, skills, profile_completed, role)
     VALUES (?, ?, ?, 'Platform Administrator', 'ProConnect administration', 'Administrator account.', '["Administration"]', 1, 'admin')`
  ).run(name, clean, hash);
  return { created: true };
}

const isMain = process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href;
if (isMain) {
  const args = process.argv.slice(2);
  const remove = args.includes('--remove');
  const pwAt = args.indexOf('--password');
  const password = pwAt >= 0 ? args[pwAt + 1] : null;
  const email = args.find((a, i) => !a.startsWith('--') && i !== pwAt + 1);
  if (!email) {
    console.log('Usage: npm run make-admin -- you@example.com   (add --remove to take admin rights away, or --password "NewPassword1" to create the account or reset its password)');
    process.exit(1);
  }
  if (pwAt >= 0) {
    if (!password || password.length < 8) {
      console.log('Give a password of at least 8 characters after --password.');
      process.exit(1);
    }
    const { created } = ensureAdmin(email, password);
    console.log(`${created ? 'Created' : 'Updated'} the administrator account ${email}. Sign in with that email and the password you gave.`);
    process.exit(0);
  }
  const user = setAdmin(email, !remove);
  if (!user) {
    console.log(`No account found for ${email}. Sign up first, then run this command again.`);
    process.exit(1);
  }
  console.log(`${user.name} (${email}) is now ${remove ? 'a regular member' : 'an administrator'}. Refresh the page in your browser to see the change.`);
}
