import express from 'express';
import cors from 'cors';
import cookieParser from 'cookie-parser';
import { config } from './config.js';
import health from './routes/health.js';
import auth from './routes/auth.js';
import profile from './routes/profile.js';
import communities from './routes/communities.js';
import courses from './routes/courses.js';
import stats from './routes/stats.js';
import home from './routes/home.js';
import users from './routes/users.js';
import uploads from './routes/uploads.js';
import posts, { commentsRouter } from './routes/posts.js';
import search from './routes/search.js';
import admin from './routes/admin.js';
import { loadUser, requireAuth, requireOnboarded } from './middleware/auth.js';
import { notFound, errorHandler } from './middleware/errors.js';

export function createApp() {
  const app = express();
  app.use(cors({ origin: config.clientOrigin, credentials: true }));
  app.use(express.json({ limit: '100kb' }));
  app.use(cookieParser());
  app.use(loadUser);

  app.use('/api/health', health);
  app.use('/api/auth', auth);
  app.use('/api/stats', stats); // aggregate numbers only, safe for visitors
  app.use('/api/profile', profile);

  // Internal content: only signed-in members with the minimum professional profile (PRD FR-01).
  app.use('/api/communities', requireAuth, requireOnboarded, communities);
  app.use('/api/courses', requireAuth, requireOnboarded, courses);
  app.use('/api/home', requireAuth, requireOnboarded, home);
  app.use('/api/users', requireAuth, requireOnboarded, users);
  app.use('/api/uploads', requireAuth, requireOnboarded, uploads);
  app.use('/api/search', requireAuth, requireOnboarded, search);
  app.use('/api/posts', requireAuth, requireOnboarded, posts);
  app.use('/api/comments', requireAuth, requireOnboarded, commentsRouter);
  app.use('/api/admin', requireAuth, requireOnboarded, admin);

  app.use(notFound);
  app.use(errorHandler);
  return app;
}
