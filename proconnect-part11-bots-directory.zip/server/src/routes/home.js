import { Router } from 'express';
import { getDb } from '../db/index.js';
import { COUNTS } from './communities.js';
import { shapeCourse } from './courses.js';
import { imageUrl } from '../utils/images.js';

const router = Router();

// GET /api/home: trending discussions, upcoming learning and popular communities for signed-in members.
router.get('/', (req, res) => {
  const db = getDb();

  const trending = db
    .prepare(
      `SELECT p.id, p.title, p.created_at, u.id AS author_id, u.name AS author_name, u.profession AS author_profession, u.avatar_file AS author_avatar, u.is_bot AS author_is_bot,
              c.id AS community_id, c.name AS community_name,
              (SELECT COUNT(*) FROM comments x WHERE x.post_id = p.id) AS reply_count
         FROM posts p JOIN users u ON u.id = p.author_id JOIN communities c ON c.id = p.community_id
        ORDER BY reply_count DESC, p.created_at DESC LIMIT 4`
    )
    .all()
    .map((p) => ({
      id: p.id,
      title: p.title,
      createdAt: p.created_at,
      replyCount: p.reply_count,
      author: { id: p.author_id, name: p.author_name, profession: p.author_profession, isBot: !!p.author_is_bot, avatarUrl: imageUrl(p.author_avatar) },
      community: { id: p.community_id, name: p.community_name },
    }));

  const now = new Date().toISOString();
  const courses = db
    .prepare(
      `SELECT * FROM courses WHERE approval_status = 'approved'
        ORDER BY CASE WHEN starts_at IS NULL THEN 1 WHEN starts_at >= ? THEN 0 ELSE 2 END, starts_at LIMIT 4`
    )
    .all(now)
    .map(shapeCourse);

  const popular = db
    .prepare(`SELECT c.id, c.name, ${COUNTS} FROM communities c WHERE c.parent_id IS NULL AND c.status = 'approved' ORDER BY member_count DESC, c.name LIMIT 3`)
    .all()
    .map((c) => ({ id: c.id, name: c.name, memberCount: c.member_count, postCount: c.post_count }));

  res.json({ trending, courses, popularCommunities: popular });
});

export default router;
