import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { getDb } from '../db/index.js';
import { HttpError, asyncHandler, validationError } from '../utils/httpError.js';
import { publicUser } from '../utils/user.js';
import { issueSession, clearSession } from '../middleware/auth.js';
import { SELF_SELECTABLE_STATUSES } from '../utils/permissions.js';

const router = Router();
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
// Used so that unknown emails take as long to reject as wrong passwords.
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 10);

const str = (v) => (typeof v === 'string' ? v.trim() : '');

router.post(
  '/register',
  asyncHandler(async (req, res) => {
    const name = str(req.body?.name);
    const email = str(req.body?.email).toLowerCase();
    const password = typeof req.body?.password === 'string' ? req.body.password : '';

    // Student or Beginner, chosen at sign-up. Anything else (Professional included) is refused; Beginner when omitted.
    const status = req.body?.status === undefined ? 'beginner' : str(req.body.status).toLowerCase();

    const fields = {};
    if (!SELF_SELECTABLE_STATUSES.includes(status)) fields.status = 'Choose Student or Beginner.';
    if (name.length < 2 || name.length > 80) fields.name = 'Enter your full name (2 to 80 characters).';
    if (!email) fields.email = 'Enter your email address.';
    else if (!EMAIL_RE.test(email) || email.length > 254) fields.email = 'Enter a valid email address.';
    if (password.length < 8) fields.password = 'Use at least 8 characters.';
    else if (password.length > 128) fields.password = 'Use 128 characters or fewer.';
    if (Object.keys(fields).length) throw validationError(fields);

    const db = getDb();
    if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email)) {
      throw new HttpError(409, 'An account with this email already exists.', 'email_taken', {
        email: 'An account with this email already exists.',
      });
    }

    const hash = await bcrypt.hash(password, 10);
    let id;
    try {
      id = db.prepare('INSERT INTO users (name, email, password_hash, status) VALUES (?, ?, ?, ?)').run(name, email, hash, status).lastInsertRowid;
    } catch (err) {
      if (String(err.message).includes('UNIQUE')) {
        throw new HttpError(409, 'An account with this email already exists.', 'email_taken', {
          email: 'An account with this email already exists.',
        });
      }
      throw err;
    }
    issueSession(res, Number(id));
    const user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
    res.status(201).json({ user: publicUser(user) });
  })
);

router.post(
  '/login',
  asyncHandler(async (req, res) => {
    const email = str(req.body?.email).toLowerCase();
    const password = typeof req.body?.password === 'string' ? req.body.password : '';
    const fields = {};
    if (!email) fields.email = 'Enter your email address.';
    if (!password) fields.password = 'Enter your password.';
    if (Object.keys(fields).length) throw validationError(fields);

    const row = getDb().prepare('SELECT * FROM users WHERE email = ?').get(email);
    const ok = await bcrypt.compare(password, row ? row.password_hash : DUMMY_HASH);
    if (!row || !ok || row.is_bot) throw new HttpError(401, 'Incorrect email or password.', 'invalid_credentials');

    issueSession(res, row.id);
    res.json({ user: publicUser(row) });
  })
);

router.post('/logout', (req, res) => {
  clearSession(res);
  res.json({ ok: true });
});

// Returns { user: null } for visitors so the browser does not log an error on first load.
router.get('/me', (req, res) => {
  res.json({ user: req.user ? publicUser(req.user) : null });
});

export default router;
