import { Router } from 'express';
import { getDb } from '../db/index.js';
import { badRequest, notFoundError, parseId } from '../utils/httpError.js';
import { requireAdmin } from '../middleware/auth.js';

// Every route here is Admin-only (PRD section 5.6). The guard runs on the server, not just in the interface.
const router = Router();
router.use(requireAdmin);

function targetUser(db, req) {
  const user = db.prepare('SELECT id, name FROM users WHERE id = ?').get(parseId(req.params.id, 'member id'));
  if (!user) throw notFoundError('Member not found.');
  return user;
}

function booleanFlag(body, name) {
  if (typeof body?.[name] !== 'boolean') throw badRequest(`${name} must be true or false.`);
  return body[name];
}

const TOUCH = "updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')";

// PUT /api/admin/users/:id/organizer { granted: true | false }: grant or revoke Authorized Organizer (courses and webinars).
router.put('/users/:id/organizer', (req, res) => {
  const db = getDb();
  const user = targetUser(db, req);
  const granted = booleanFlag(req.body, 'granted');
  db.prepare(`UPDATE users SET is_organizer = ?, ${TOUCH} WHERE id = ?`).run(granted ? 1 : 0, user.id);
  res.json({ user: { id: user.id, isOrganizer: granted } });
});

// PUT /api/admin/users/:id/professional { granted: true | false }: the only way Professional status is set.
// The application and evidence review that leads here comes in a later part.
router.put('/users/:id/professional', (req, res) => {
  const db = getDb();
  const user = targetUser(db, req);
  const granted = booleanFlag(req.body, 'granted');
  const status = granted ? 'professional' : 'beginner';
  db.prepare(`UPDATE users SET status = ?, ${TOUCH} WHERE id = ?`).run(status, user.id);
  res.json({ user: { id: user.id, status } });
});

function approvedCommunity(db, req) {
  const c = db.prepare("SELECT id, name FROM communities WHERE id = ? AND status = 'approved'").get(parseId(req.params.id, 'community id'));
  if (!c) throw notFoundError('Community not found.');
  return c;
}

// PUT /api/admin/communities/:id/leaders/:userId: assign a Community Leader to this community.
router.put('/communities/:id/leaders/:userId', (req, res) => {
  const db = getDb();
  const community = approvedCommunity(db, req);
  const user = db.prepare('SELECT id FROM users WHERE id = ?').get(parseId(req.params.userId, 'member id'));
  if (!user) throw notFoundError('Member not found.');
  db.prepare('INSERT OR IGNORE INTO community_leaders (user_id, community_id, assigned_by) VALUES (?, ?, ?)').run(user.id, community.id, req.user.id);
  res.json({ leader: { userId: user.id, communityId: community.id } });
});

// DELETE /api/admin/communities/:id/leaders/:userId: remove that assignment.
router.delete('/communities/:id/leaders/:userId', (req, res) => {
  const db = getDb();
  const community = approvedCommunity(db, req);
  const result = db.prepare('DELETE FROM community_leaders WHERE user_id = ? AND community_id = ?').run(parseId(req.params.userId, 'member id'), community.id);
  if (!result.changes) throw notFoundError('That member is not a leader of this community.');
  res.json({ ok: true });
});

export default router;
