import { Router } from 'express';
import { getDb } from '../db/index.js';

const router = Router();

function lastDays(n) {
  const out = [];
  for (let i = n - 1; i >= 0; i--) out.push(new Date(Date.now() - i * 86400000).toISOString().slice(0, 10));
  return out;
}

// table and column are fixed constants below (never user input).
function weekly(db, table, column, days) {
  const rows = db
    .prepare(`SELECT substr(${column}, 1, 10) AS d, COUNT(*) AS n FROM ${table} WHERE substr(${column}, 1, 10) >= ? GROUP BY d`)
    .all(days[0]);
  const byDay = new Map(rows.map((r) => [r.d, r.n]));
  const points = days.map((d) => byDay.get(d) || 0);
  return { count: points.reduce((a, b) => a + b, 0), points };
}

// GET /api/stats: public, aggregate numbers only (no member or discussion content).
router.get('/', (req, res) => {
  const db = getDb();
  const one = (sql) => db.prepare(sql).get().n;
  const days = lastDays(7);
  res.json({
    totals: {
      communities: one("SELECT COUNT(*) AS n FROM communities WHERE parent_id IS NULL AND status = 'approved'"),
      professionals: one('SELECT COUNT(*) AS n FROM users WHERE profile_completed = 1'),
      discussions: one('SELECT COUNT(*) AS n FROM posts'),
      replies: one('SELECT COUNT(*) AS n FROM comments'),
    },
    week: {
      memberships: weekly(db, 'memberships', 'joined_at', days),
      professionals: weekly(db, 'users', 'created_at', days),
      discussions: weekly(db, 'posts', 'created_at', days),
      replies: weekly(db, 'comments', 'created_at', days),
    },
  });
});

export default router;
