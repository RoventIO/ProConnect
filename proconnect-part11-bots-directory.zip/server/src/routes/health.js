import { Router } from 'express';
import { getDb } from '../db/index.js';

const router = Router();

router.get('/', (req, res) => {
  getDb().prepare('SELECT 1').get();
  res.json({ status: 'ok', database: 'connected', time: new Date().toISOString() });
});

export default router;
