import { Router } from 'express';
import { getDb } from '../db/index.js';
import { notFoundError, parseId } from '../utils/httpError.js';
import { buildProfile } from '../utils/profileData.js';

const router = Router();

// GET /api/users/:id: another member's permitted profile information (no email).
router.get('/:id', (req, res) => {
  const id = parseId(req.params.id, 'member id');
  const row = getDb().prepare('SELECT * FROM users WHERE id = ? AND profile_completed = 1').get(id);
  if (!row) throw notFoundError('Member not found.');
  res.json(buildProfile(getDb(), row, { self: row.id === req.user.id }));
});

export default router;
