import { Router } from 'express';
import { config } from '../config.js';
import { FILE_RE, CONTENT_TYPES } from '../utils/images.js';
import { notFoundError } from '../utils/httpError.js';

const router = Router();

// GET /api/uploads/:file: images are internal content, so this route sits behind sign-in (see app.js).
router.get('/:file', (req, res, next) => {
  const { file } = req.params;
  if (!FILE_RE.test(file)) return next(notFoundError('Image not found.'));
  res.type(CONTENT_TYPES[file.split('.').pop()]);
  res.set('X-Content-Type-Options', 'nosniff');
  res.set('Cache-Control', 'private, max-age=3600');
  res.sendFile(file, { root: config.uploadDir, dotfiles: 'deny' }, (err) => {
    if (err) next(notFoundError('Image not found.'));
  });
});

export default router;
