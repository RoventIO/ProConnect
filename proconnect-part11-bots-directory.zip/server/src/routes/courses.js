import { Router } from 'express';
import { getDb } from '../db/index.js';
import { badRequest, notFoundError, parseId } from '../utils/httpError.js';

const router = Router();

export const shapeCourse = (c) => ({
  id: c.id,
  title: c.title,
  description: c.description,
  type: c.type,
  category: c.category,
  organizer: c.organizer,
  isFree: !!c.is_free,
  priceLabel: c.is_free ? 'Free' : 'Paid',
  priceText: c.price_text,
  startsAt: c.starts_at,
  duration: c.duration,
  externalUrl: c.external_url,
  isSample: !!c.is_sample,
  isPast: c.starts_at ? new Date(c.starts_at).getTime() < Date.now() : false,
});

// GET /api/courses?type=webinar&price=free&q=data
router.get('/', (req, res) => {
  const where = ["approval_status = 'approved'"];
  const params = [];
  if (req.query.type) {
    if (!['course', 'webinar'].includes(req.query.type)) throw badRequest("type must be 'course' or 'webinar'.");
    where.push('type = ?');
    params.push(req.query.type);
  }
  if (req.query.price) {
    if (!['free', 'paid'].includes(req.query.price)) throw badRequest("price must be 'free' or 'paid'.");
    where.push('is_free = ?');
    params.push(req.query.price === 'free' ? 1 : 0);
  }
  if (req.query.q) {
    where.push('(ulike(title, ?) OR ulike(description, ?) OR ulike(organizer, ?) OR ulike(category, ?))');
    params.push(...Array(4).fill(String(req.query.q)));
  }
  const rows = getDb()
    .prepare(
      `SELECT * FROM courses WHERE ${where.join(' AND ')}
        ORDER BY CASE WHEN starts_at IS NULL THEN 1 WHEN starts_at >= ? THEN 0 ELSE 2 END, starts_at, title`
    )
    .all(...params, new Date().toISOString());
  res.json({ courses: rows.map(shapeCourse) });
});

router.get('/:id', (req, res) => {
  const id = parseId(req.params.id, 'course id');
  const row = getDb().prepare("SELECT * FROM courses WHERE id = ? AND approval_status = 'approved'").get(id);
  if (!row) throw notFoundError('Course or webinar not found.');
  res.json({ course: shapeCourse(row) });
});

export default router;
