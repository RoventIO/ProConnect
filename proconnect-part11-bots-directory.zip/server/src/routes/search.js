import { Router } from 'express';
import { getDb } from '../db/index.js';
import { badRequest } from '../utils/httpError.js';
import { COUNTS, IS_MEMBER, shape as shapeCommunity } from './communities.js';
import { shapeCourse } from './courses.js';
import { imageUrl } from '../utils/images.js';

const router = Router();
const LIMIT = 20;

const str = (v) => (typeof v === 'string' ? v.trim() : '');

function idParam(value, label) {
  if (value === undefined || value === '') return null;
  const n = Number(value);
  if (!Number.isInteger(n) || n <= 0) throw badRequest(`Invalid ${label}.`, 'invalid_filter');
  return n;
}

// GET /api/search/options: values for the Profession, Topic and Community filters.
router.get('/options', (req, res) => {
  const db = getDb();
  res.json({
    professions: db
      .prepare("SELECT DISTINCT profession FROM users WHERE profile_completed = 1 AND profession IS NOT NULL AND profession != '' ORDER BY profession COLLATE NOCASE")
      .all()
      .map((r) => r.profession),
    topics: db
      .prepare(
        `SELECT s.id, s.name, p.id AS parent_id, p.name AS parent_name FROM communities s JOIN communities p ON p.id = s.parent_id
          WHERE s.status = 'approved' ORDER BY p.name, s.name`
      )
      .all()
      .map((t) => ({ id: t.id, name: t.name, parent: { id: t.parent_id, name: t.parent_name } })),
    communities: db
      .prepare("SELECT id, name FROM communities WHERE parent_id IS NULL AND status = 'approved' ORDER BY name")
      .all(),
  });
});

/**
 * GET /api/search?q=&profession=&topic=&community=
 * Always returns every content type that the filters allow, so the page can show counts per type.
 *   Profession (member profession text): people and discussions (by author)
 *   Topic (a subcommunity id):           communities (that contain it) and discussions posted in it
 *   Community (a main community id):     communities, discussions, and people who are members
 * Types a chosen filter cannot apply to are left out and listed in `excluded`.
 */
router.get('/', (req, res) => {
  const db = getDb();
  const q = str(req.query.q);
  const profession = str(req.query.profession);
  const topic = idParam(req.query.topic, 'topic');
  const community = idParam(req.query.community, 'community');
  if (q.length > 100) throw badRequest('Search text must be 100 characters or fewer.', 'query_too_long');
  if (profession.length > 80) throw badRequest('Invalid profession.', 'invalid_filter');

  const empty = () => ({ items: [], total: 0 });
  const out = { query: { q, profession, topic, community }, needsQuery: false, results: { communities: empty(), posts: empty(), people: empty(), courses: empty() }, excluded: [] };
  if (!q && !profession && !topic && !community) {
    out.needsQuery = true;
    return res.json(out);
  }

  const applies = {
    communities: !profession,
    posts: true,
    people: !topic,
    courses: !profession && !topic && !community,
  };
  out.excluded = Object.keys(applies).filter((t) => !applies[t]);
  const pattern = q; // matched by ulike(): case-insensitive in every script, and % or _ are plain characters

  // Runs the list query and the count query with the same conditions.
  const run = (type, fromSql, selectSql, where, params, orderSql, orderParams = []) => {
    const w = where.length ? `WHERE ${where.join(' AND ')}` : '';
    const total = db.prepare(`SELECT COUNT(*) AS n ${fromSql} ${w}`).get(...params).n;
    const rows = db.prepare(`SELECT ${selectSql} ${fromSql} ${w} ORDER BY ${orderSql} LIMIT ${LIMIT}`).all(...params, ...orderParams);
    return { rows, total };
  };

  // ---- communities (main communities; subcommunities are matched through their parent) ----
  if (applies.communities) {
    const where = ["c.parent_id IS NULL", "c.status = 'approved'"];
    const params = [];
    if (q) {
      where.push(`(ulike(c.name, ?) OR ulike(c.description, ?) OR ulike(c.category, ?) OR EXISTS (SELECT 1 FROM communities s WHERE s.parent_id = c.id AND ulike(s.name, ?)))`);
      params.push(pattern, pattern, pattern, pattern);
    }
    if (community) {
      where.push('c.id = ?');
      params.push(community);
    }
    if (topic) {
      where.push('EXISTS (SELECT 1 FROM communities s WHERE s.parent_id = c.id AND s.id = ?)');
      params.push(topic);
    }
    const w = `WHERE ${where.join(' AND ')}`;
    const total = db.prepare(`SELECT COUNT(*) AS n FROM communities c ${w}`).get(...params).n;
    const rows = db
      .prepare(`SELECT c.*, ${COUNTS}, ${IS_MEMBER} FROM communities c ${w} ORDER BY (ulike(c.name, ?)) DESC, member_count DESC, c.name LIMIT ${LIMIT}`)
      .all(req.user.id, ...params, pattern);
    const subs = db.prepare("SELECT id, name, slug, parent_id FROM communities WHERE parent_id IS NOT NULL AND status = 'approved' ORDER BY name").all();
    out.results.communities = {
      total,
      items: rows.map((c) => shapeCommunity(c, subs.filter((s) => s.parent_id === c.id).map((s) => ({ id: s.id, name: s.name, slug: s.slug })))),
    };
  }

  // ---- discussions ----
  {
    const where = [];
    const params = [];
    if (q) {
      where.push(`(ulike(p.title, ?) OR ulike(p.content, ?) OR ulike(u.name, ?))`);
      params.push(pattern, pattern, pattern);
    }
    if (profession) {
      where.push('u.profession = ? COLLATE NOCASE');
      params.push(profession);
    }
    if (topic) {
      where.push('p.community_id = ?');
      params.push(topic);
    }
    if (community) {
      where.push('(p.community_id = ? OR p.community_id IN (SELECT id FROM communities WHERE parent_id = ?))');
      params.push(community, community);
    }
    const { rows, total } = run(
      'posts',
      'FROM posts p JOIN users u ON u.id = p.author_id JOIN communities c ON c.id = p.community_id',
      `p.id, p.title, substr(p.content, 1, 160) AS excerpt, p.created_at, u.id AS author_id, u.name AS author_name,
       u.profession AS author_profession, u.avatar_file AS author_avatar, u.is_bot AS author_is_bot, c.id AS community_id, c.name AS community_name,
       (SELECT COUNT(*) FROM comments x WHERE x.post_id = p.id) AS reply_count,
       (SELECT COUNT(*) FROM attachments a WHERE a.post_id = p.id AND a.kind = 'image') AS image_count,
       (SELECT COUNT(*) FROM attachments a WHERE a.post_id = p.id AND a.kind = 'audio') AS voice_count`,
      where,
      params,
      `(ulike(p.title, ?)) DESC, p.created_at DESC`,
      [pattern]
    );
    out.results.posts = {
      total,
      items: rows.map((p) => ({
        id: p.id,
        title: p.title,
        excerpt: p.excerpt,
        createdAt: p.created_at,
        replyCount: p.reply_count,
        imageCount: p.image_count,
        hasVoice: p.voice_count > 0,
        author: { id: p.author_id, name: p.author_name, profession: p.author_profession, isBot: !!p.author_is_bot, avatarUrl: imageUrl(p.author_avatar) },
        community: { id: p.community_id, name: p.community_name },
      })),
    };
  }

  // ---- people (members with a completed profile; never their email) ----
  if (applies.people) {
    const where = ['u.profile_completed = 1', "u.role <> 'admin'"]; // administrators are not listed as ordinary members
    const params = [];
    if (q) {
      where.push(`(ulike(u.name, ?) OR ulike(u.profession, ?) OR ulike(u.headline, ?) OR ulike(u.bio, ?) OR ulike(u.skills, ?) OR ulike(u.location, ?))`);
      params.push(...Array(6).fill(pattern));
    }
    if (profession) {
      where.push('u.profession = ? COLLATE NOCASE');
      params.push(profession);
    }
    if (community) {
      where.push('EXISTS (SELECT 1 FROM memberships m WHERE m.user_id = u.id AND m.community_id = ?)');
      params.push(community);
    }
    const { rows, total } = run(
      'people',
      'FROM users u',
      'u.id, u.name, u.profession, u.headline, u.location, u.skills, u.avatar_file, substr(u.bio, 1, 140) AS bio_excerpt',
      where,
      params,
      `(ulike(u.name, ?)) DESC, u.name COLLATE NOCASE`,
      [pattern]
    );
    out.results.people = {
      total,
      items: rows.map((u) => {
        let skills = [];
        try { skills = JSON.parse(u.skills || '[]'); } catch { skills = []; }
        return { id: u.id, name: u.name, profession: u.profession, headline: u.headline, location: u.location, skills, bioExcerpt: u.bio_excerpt, avatarUrl: imageUrl(u.avatar_file) };
      }),
    };
  }

  // ---- courses and webinars ----
  if (applies.courses) {
    const where = ["approval_status = 'approved'"];
    const params = [];
    if (q) {
      where.push(`(ulike(title, ?) OR ulike(description, ?) OR ulike(organizer, ?) OR ulike(category, ?))`);
      params.push(pattern, pattern, pattern, pattern);
    }
    const { rows, total } = run(
      'courses',
      'FROM courses',
      '*',
      where,
      params,
      `CASE WHEN starts_at IS NULL THEN 1 WHEN starts_at >= ? THEN 0 ELSE 2 END, (ulike(title, ?)) DESC, starts_at, title`,
      [new Date().toISOString(), pattern]
    );
    out.results.courses = { total, items: rows.map(shapeCourse) };
  }

  res.json(out);
});

export default router;
