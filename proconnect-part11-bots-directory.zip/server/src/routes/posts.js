import { Router } from 'express';
import multer from 'multer';
import { getDb, transaction } from '../db/index.js';
import { HttpError, notFoundError, parseId, validationError } from '../utils/httpError.js';
import { saveMedia, deleteMedia, imageUrl, MAX_ATTACHMENT_BYTES } from '../utils/images.js';

const router = Router();
const commentsRouter = Router();

const MAX_IMAGES = 4;
const TITLE_MAX = 150;
const POST_MAX = 5000;
const COMMENT_MAX = 2000;
const MAX_VOICE_SECONDS = 600;

/** Accepts multipart (text + files) as well as plain JSON. Files are checked by their real content later. */
export const attachmentUpload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_ATTACHMENT_BYTES, files: MAX_IMAGES + 1 },
}).fields([
  { name: 'images', maxCount: MAX_IMAGES },
  { name: 'voice', maxCount: 1 },
]);

const str = (v) => (typeof v === 'string' ? v.trim() : '');
const authorOf = (r) => ({ id: r.author_id, name: r.author_name, profession: r.author_profession, isBot: !!r.author_is_bot, avatarUrl: imageUrl(r.author_avatar) });
const shapeAttachment = (a) => ({ id: a.id, kind: a.kind, url: imageUrl(a.file), durationSec: a.duration_sec });

/** Membership of the main community decides who may write; subcommunities follow their parent. */
export function membership(db, userId, communityId) {
  const c = db.prepare("SELECT id, name, parent_id FROM communities WHERE id = ? AND status = 'approved'").get(communityId);
  if (!c) return null;
  const topId = c.parent_id ?? c.id;
  const top = c.parent_id ? db.prepare('SELECT id, name FROM communities WHERE id = ?').get(c.parent_id) : c;
  const isMember = !!db.prepare('SELECT 1 FROM memberships WHERE user_id = ? AND community_id = ?').get(userId, topId);
  return { community: c, top, isMember };
}

function requireMember(db, userId, communityId) {
  const m = membership(db, userId, communityId);
  if (!m) throw notFoundError('Community not found.');
  if (!m.isMember) throw new HttpError(403, `Join ${m.top.name} to take part in its discussions.`, 'not_member');
  return m;
}

/** Writes the uploaded files for a post or comment. Call inside a transaction; `saved` collects names for cleanup. */
function storeAttachments(db, req, ownerId, target, saved) {
  const images = req.files?.images || [];
  const voice = req.files?.voice?.[0];
  const insert = db.prepare(
    'INSERT INTO attachments (post_id, comment_id, owner_id, kind, file, duration_sec, position) VALUES (?, ?, ?, ?, ?, ?, ?)'
  );
  let position = 0;
  for (const f of images) {
    const file = saveMedia(f.buffer, 'image');
    saved.push(file);
    insert.run(target.postId ?? null, target.commentId ?? null, ownerId, 'image', file, null, position++);
  }
  if (voice) {
    const file = saveMedia(voice.buffer, 'audio');
    saved.push(file);
    let seconds = Number.parseInt(req.body?.voiceDuration, 10);
    seconds = Number.isFinite(seconds) ? Math.min(Math.max(seconds, 1), MAX_VOICE_SECONDS) : null;
    insert.run(target.postId ?? null, target.commentId ?? null, ownerId, 'audio', file, seconds, position++);
  }
}

const fileCount = (req) => (req.files?.images?.length || 0) + (req.files?.voice?.length || 0);

function attachmentsFor(db, postId) {
  const rows = db
    .prepare(
      `SELECT * FROM attachments
        WHERE post_id = ? OR comment_id IN (SELECT id FROM comments WHERE post_id = ?)
        ORDER BY position, id`
    )
    .all(postId, postId);
  const byPost = [];
  const byComment = new Map();
  for (const a of rows) {
    if (a.post_id) byPost.push(shapeAttachment(a));
    else {
      if (!byComment.has(a.comment_id)) byComment.set(a.comment_id, []);
      byComment.get(a.comment_id).push(shapeAttachment(a));
    }
  }
  return { byPost, byComment };
}

/** Files that belong to the given posts (and their comments), used before rows are deleted. */
export function filesForPosts(db, postIds) {
  if (postIds.length === 0) return [];
  const marks = postIds.map(() => '?').join(',');
  return db
    .prepare(
      `SELECT file FROM attachments
        WHERE post_id IN (${marks}) OR comment_id IN (SELECT id FROM comments WHERE post_id IN (${marks}))`
    )
    .all(...postIds, ...postIds)
    .map((r) => r.file);
}

const POST_SELECT = `
  SELECT p.*, u.name AS author_name, u.profession AS author_profession, u.avatar_file AS author_avatar, u.is_bot AS author_is_bot
    FROM posts p JOIN users u ON u.id = p.author_id`;

function shapePost(db, row, user, attachments) {
  const m = membership(db, user.id, row.community_id);
  const isAuthor = row.author_id === user.id;
  const isAdmin = user.role === 'admin';
  return {
    id: row.id,
    title: row.title,
    content: row.content,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    edited: row.updated_at !== row.created_at,
    author: authorOf(row),
    community: { id: m.community.id, name: m.community.name, parent: m.community.parent_id ? { id: m.top.id, name: m.top.name } : null },
    attachments,
    commentCount: db.prepare('SELECT COUNT(*) AS n FROM comments WHERE post_id = ?').get(row.id).n,
    canComment: m.isMember,
    canEdit: isAuthor,
    canDelete: isAuthor || isAdmin,
  };
}

function validatePostText(title, content, hasAttachments) {
  const fields = {};
  if (title.length < 3) fields.title = 'Give your discussion a title (at least 3 characters).';
  else if (title.length > TITLE_MAX) fields.title = `Keep the title under ${TITLE_MAX} characters.`;
  if (!content && !hasAttachments) fields.content = 'Write something or attach an image or voice message.';
  else if (content.length > POST_MAX) fields.content = `Keep the text under ${POST_MAX} characters.`;
  if (Object.keys(fields).length) throw validationError(fields);
}

/** POST /api/communities/:id/posts (mounted from the communities router) */
export function createPost(req, res) {
  const db = getDb();
  const communityId = parseId(req.params.id, 'community id');
  requireMember(db, req.user.id, communityId);

  const title = str(req.body?.title);
  const content = str(req.body?.content);
  validatePostText(title, content, fileCount(req) > 0);

  const saved = [];
  let postId;
  try {
    postId = transaction((d) => {
      const id = d.prepare('INSERT INTO posts (author_id, community_id, title, content) VALUES (?, ?, ?, ?)')
        .run(req.user.id, communityId, title, content).lastInsertRowid;
      storeAttachments(d, req, req.user.id, { postId: id }, saved);
      return id;
    });
  } catch (err) {
    saved.forEach(deleteMedia);
    throw err;
  }
  const row = db.prepare(`${POST_SELECT} WHERE p.id = ?`).get(postId);
  res.status(201).json({ post: shapePost(db, row, req.user, attachmentsFor(db, postId).byPost) });
}

// GET /api/posts/:id: the discussion with its comments and attachments.
router.get('/:id', (req, res) => {
  const db = getDb();
  const id = parseId(req.params.id, 'post id');
  const row = db.prepare(`${POST_SELECT} WHERE p.id = ?`).get(id);
  if (!row) throw notFoundError('Discussion not found.');
  const { byPost, byComment } = attachmentsFor(db, id);
  const isAdmin = req.user.role === 'admin';

  const comments = db
    .prepare(
      `SELECT c.*, u.name AS author_name, u.profession AS author_profession, u.avatar_file AS author_avatar, u.is_bot AS author_is_bot
         FROM comments c JOIN users u ON u.id = c.author_id WHERE c.post_id = ? ORDER BY c.created_at, c.id`
    )
    .all(id)
    .map((c) => ({
      id: c.id,
      content: c.content,
      createdAt: c.created_at,
      updatedAt: c.updated_at,
      edited: c.updated_at !== c.created_at,
      author: authorOf(c),
      attachments: byComment.get(c.id) || [],
      canEdit: c.author_id === req.user.id,
      canDelete: c.author_id === req.user.id || isAdmin,
    }));

  res.json({ post: shapePost(db, row, req.user, byPost), comments });
});

// PUT /api/posts/:id: only the author can edit the text.
router.put('/:id', (req, res) => {
  const db = getDb();
  const id = parseId(req.params.id, 'post id');
  const row = db.prepare('SELECT * FROM posts WHERE id = ?').get(id);
  if (!row) throw notFoundError('Discussion not found.');
  if (row.author_id !== req.user.id) throw new HttpError(403, 'You can only edit your own discussions.', 'forbidden');

  const title = str(req.body?.title);
  const content = str(req.body?.content);
  const hasFiles = db.prepare('SELECT COUNT(*) AS n FROM attachments WHERE post_id = ?').get(id).n > 0;
  validatePostText(title, content, hasFiles);

  db.prepare("UPDATE posts SET title = ?, content = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(title, content, id);
  const updated = db.prepare(`${POST_SELECT} WHERE p.id = ?`).get(id);
  res.json({ post: shapePost(db, updated, req.user, attachmentsFor(db, id).byPost) });
});

// DELETE /api/posts/:id: the author or an administrator.
router.delete('/:id', (req, res) => {
  const db = getDb();
  const id = parseId(req.params.id, 'post id');
  const row = db.prepare('SELECT * FROM posts WHERE id = ?').get(id);
  if (!row) throw notFoundError('Discussion not found.');
  if (row.author_id !== req.user.id && req.user.role !== 'admin') {
    throw new HttpError(403, 'You can only delete your own discussions.', 'forbidden');
  }
  const files = filesForPosts(db, [id]);
  db.prepare('DELETE FROM posts WHERE id = ?').run(id);
  files.forEach(deleteMedia);
  res.json({ ok: true });
});

// POST /api/posts/:id/comments
router.post('/:id/comments', attachmentUpload, (req, res) => {
  const db = getDb();
  const postId = parseId(req.params.id, 'post id');
  const post = db.prepare('SELECT * FROM posts WHERE id = ?').get(postId);
  if (!post) throw notFoundError('Discussion not found.');
  requireMember(db, req.user.id, post.community_id);

  const content = str(req.body?.content);
  if (!content && fileCount(req) === 0) throw validationError({ content: 'Write a reply or attach an image or voice message.' });
  if (content.length > COMMENT_MAX) throw validationError({ content: `Keep the reply under ${COMMENT_MAX} characters.` });

  const saved = [];
  let commentId;
  try {
    commentId = transaction((d) => {
      const id = d.prepare('INSERT INTO comments (post_id, author_id, content) VALUES (?, ?, ?)').run(postId, req.user.id, content).lastInsertRowid;
      storeAttachments(d, req, req.user.id, { commentId: id }, saved);
      return id;
    });
  } catch (err) {
    saved.forEach(deleteMedia);
    throw err;
  }
  res.status(201).json({ comment: { id: commentId } });
});

// ---- Editing and deleting comments: /api/comments/:id ----

commentsRouter.put('/:id', (req, res) => {
  const db = getDb();
  const id = parseId(req.params.id, 'comment id');
  const row = db.prepare('SELECT * FROM comments WHERE id = ?').get(id);
  if (!row) throw notFoundError('Reply not found.');
  if (row.author_id !== req.user.id) throw new HttpError(403, 'You can only edit your own replies.', 'forbidden');

  const content = str(req.body?.content);
  const hasFiles = db.prepare('SELECT COUNT(*) AS n FROM attachments WHERE comment_id = ?').get(id).n > 0;
  if (!content && !hasFiles) throw validationError({ content: 'A reply cannot be empty.' });
  if (content.length > COMMENT_MAX) throw validationError({ content: `Keep the reply under ${COMMENT_MAX} characters.` });

  db.prepare("UPDATE comments SET content = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(content, id);
  res.json({ ok: true });
});

commentsRouter.delete('/:id', (req, res) => {
  const db = getDb();
  const id = parseId(req.params.id, 'comment id');
  const row = db.prepare('SELECT * FROM comments WHERE id = ?').get(id);
  if (!row) throw notFoundError('Reply not found.');
  if (row.author_id !== req.user.id && req.user.role !== 'admin') {
    throw new HttpError(403, 'You can only delete your own replies.', 'forbidden');
  }
  const files = db.prepare('SELECT file FROM attachments WHERE comment_id = ?').all(id).map((r) => r.file);
  db.prepare('DELETE FROM comments WHERE id = ?').run(id);
  files.forEach(deleteMedia);
  res.json({ ok: true });
});

export { commentsRouter };
export default router;
