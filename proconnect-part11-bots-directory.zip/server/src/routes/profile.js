import { Router } from 'express';
import multer from 'multer';
import { getDb } from '../db/index.js';
import { notFoundError, parseId, validationError } from '../utils/httpError.js';
import { publicUser } from '../utils/user.js';
import { buildProfile, shapeItem } from '../utils/profileData.js';
import { requireAuth, requireOnboarded } from '../middleware/auth.js';
import { SELF_SELECTABLE_STATUSES } from '../utils/permissions.js';
import { HttpError } from '../utils/httpError.js';
import { saveImage, deleteImage, MAX_IMAGE_BYTES } from '../utils/images.js';

const router = Router();
router.use(requireAuth);

// Images are held in memory, checked by their real content, then written under a random name.
const avatarUpload = multer({ storage: multer.memoryStorage(), limits: { fileSize: MAX_IMAGE_BYTES, files: 1 } }).single('avatar');

const str = (v) => (typeof v === 'string' ? v.trim() : '');

function parseSkills(input) {
  const list = Array.isArray(input) ? input : typeof input === 'string' ? input.split(',') : [];
  const seen = new Set();
  const out = [];
  for (const item of list) {
    const s = str(item);
    if (s && !seen.has(s.toLowerCase())) {
      seen.add(s.toLowerCase());
      out.push(s);
    }
  }
  return out;
}

// GET /api/profile: the signed-in member's own full profile.
router.get('/', requireOnboarded, (req, res) => {
  res.json(buildProfile(getDb(), req.user, { self: true }));
});

/**
 * PUT /api/profile: saves the member's own basic profile. Used for onboarding and later edits.
 * Minimum profile (unlocks content): profession, short bio, at least one skill.
 */
router.put('/', (req, res) => {
  const body = req.body || {};
  const profession = str(body.profession);
  const headline = str(body.headline);
  const bio = str(body.bio);
  const location = str(body.location);
  const skills = parseSkills(body.skills);
  let years = null;
  if (body.yearsExperience !== undefined && body.yearsExperience !== null && body.yearsExperience !== '') {
    years = Number(body.yearsExperience);
  }

  const fields = {};
  if (profession.length < 2 || profession.length > 80) fields.profession = 'Enter your profession (2 to 80 characters).';
  if (bio.length < 10) fields.bio = 'Write a short biography (at least 10 characters).';
  else if (bio.length > 1000) fields.bio = 'Keep your biography under 1000 characters.';
  if (skills.length < 1) fields.skills = 'Add at least one skill, separated by commas.';
  else if (skills.length > 15) fields.skills = 'Add no more than 15 skills.';
  else if (skills.some((s) => s.length > 40)) fields.skills = 'Each skill must be 40 characters or fewer.';
  if (headline.length > 120) fields.headline = 'Keep your headline under 120 characters.';
  if (location.length > 80) fields.location = 'Keep your location under 80 characters.';
  if (years !== null && (!Number.isInteger(years) || years < 0 || years > 60)) {
    fields.yearsExperience = 'Enter whole years between 0 and 60.';
  }
  if (Object.keys(fields).length) throw validationError(fields);

  const db = getDb();
  db.prepare(
    `UPDATE users SET profession = ?, headline = ?, bio = ?, skills = ?, location = ?, years_experience = ?,
            profile_completed = 1, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')
      WHERE id = ?`
  ).run(profession, headline || null, bio, JSON.stringify(skills), location || null, years, req.user.id);

  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)) });
});

/**
 * PUT /api/profile/status { status }: Student or Beginner, chosen freely (no approval).
 * Professional is refused here: only an Admin can grant it (PRD FR-13). Role and permissions are never accepted from this route.
 */
router.put('/status', requireOnboarded, (req, res) => {
  const status = str(req.body?.status).toLowerCase();
  if (status === 'professional') {
    throw new HttpError(403, 'Professional status needs Admin approval. It cannot be selected here.', 'professional_requires_admin');
  }
  if (!SELF_SELECTABLE_STATUSES.includes(status)) {
    throw validationError({ status: 'Choose Student or Beginner.' });
  }
  if (req.user.status === 'professional') {
    throw new HttpError(403, 'Your Professional status can only be changed by an Admin.', 'professional_requires_admin');
  }
  const db = getDb();
  db.prepare("UPDATE users SET status = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(status, req.user.id);
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)) });
});

// ---- Profile photo ----

router.post('/avatar', requireOnboarded, avatarUpload, (req, res) => {
  if (!req.file) throw validationError({ avatar: 'Choose an image to upload.' });
  const fileName = saveImage(req.file.buffer);
  const db = getDb();
  const previous = req.user.avatar_file;
  db.prepare("UPDATE users SET avatar_file = ?, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(fileName, req.user.id);
  deleteImage(previous);
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)) });
});

router.delete('/avatar', requireOnboarded, (req, res) => {
  const db = getDb();
  deleteImage(req.user.avatar_file);
  db.prepare("UPDATE users SET avatar_file = NULL, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') WHERE id = ?").run(req.user.id);
  res.json({ user: publicUser(db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id)) });
});

// ---- Experience, education and portfolio items (FR-02) ----

const KINDS = ['experience', 'education', 'project'];
const MAX_ITEMS_PER_KIND = 20;

function parseItem(body = {}) {
  const item = {
    kind: str(body.kind),
    title: str(body.title),
    subtitle: str(body.subtitle),
    period: str(body.period),
    description: str(body.description),
    url: str(body.url),
  };
  const fields = {};
  if (!item.title) fields.title = 'Enter a title.';
  else if (item.title.length > 120) fields.title = 'Keep the title under 120 characters.';
  if (item.subtitle.length > 120) fields.subtitle = 'Keep this under 120 characters.';
  if (item.period.length > 60) fields.period = 'Keep the period under 60 characters.';
  if (item.description.length > 500) fields.description = 'Keep the description under 500 characters.';
  if (item.url) {
    let ok = false;
    try {
      const u = new URL(item.url);
      ok = (u.protocol === 'http:' || u.protocol === 'https:') && item.url.length <= 300;
    } catch {
      ok = false;
    }
    if (!ok) fields.url = 'Enter a full link starting with http:// or https://';
  }
  return { item, fields };
}

router.post('/items', requireOnboarded, (req, res) => {
  const { item, fields } = parseItem(req.body);
  if (!KINDS.includes(item.kind)) fields.kind = 'Choose experience, education or project.';
  if (Object.keys(fields).length) throw validationError(fields);

  const db = getDb();
  const n = db.prepare('SELECT COUNT(*) AS n FROM profile_items WHERE user_id = ? AND kind = ?').get(req.user.id, item.kind).n;
  if (n >= MAX_ITEMS_PER_KIND) throw validationError({ title: `You can add up to ${MAX_ITEMS_PER_KIND} entries in this section.` });

  const id = db
    .prepare('INSERT INTO profile_items (user_id, kind, title, subtitle, period, description, url) VALUES (?, ?, ?, ?, ?, ?, ?)')
    .run(req.user.id, item.kind, item.title, item.subtitle || null, item.period || null, item.description || null, item.url || null).lastInsertRowid;
  res.status(201).json({ item: shapeItem(db.prepare('SELECT * FROM profile_items WHERE id = ?').get(id)) });
});

// Members can only change their own entries; someone else's entry looks like it does not exist.
router.put('/items/:id', requireOnboarded, (req, res) => {
  const id = parseId(req.params.id, 'item id');
  const db = getDb();
  const existing = db.prepare('SELECT * FROM profile_items WHERE id = ? AND user_id = ?').get(id, req.user.id);
  if (!existing) throw notFoundError('Entry not found.');
  const { item, fields } = parseItem({ ...req.body, kind: existing.kind });
  if (Object.keys(fields).length) throw validationError(fields);
  db.prepare('UPDATE profile_items SET title = ?, subtitle = ?, period = ?, description = ?, url = ? WHERE id = ?')
    .run(item.title, item.subtitle || null, item.period || null, item.description || null, item.url || null, id);
  res.json({ item: shapeItem(db.prepare('SELECT * FROM profile_items WHERE id = ?').get(id)) });
});

router.delete('/items/:id', requireOnboarded, (req, res) => {
  const id = parseId(req.params.id, 'item id');
  const result = getDb().prepare('DELETE FROM profile_items WHERE id = ? AND user_id = ?').run(id, req.user.id);
  if (!result.changes) throw notFoundError('Entry not found.');
  res.json({ ok: true });
});

export default router;
