import { Router } from 'express';
import { getDb, transaction } from '../db/index.js';
import { HttpError, notFoundError, parseId, validationError } from '../utils/httpError.js';
import { requireAdmin } from '../middleware/auth.js';
import { canCreateSubcommunity } from '../utils/permissions.js';
import { slugify } from '../utils/slug.js';
import { deleteMedia } from '../utils/images.js';
import { attachmentUpload, createPost, filesForPosts } from './posts.js';

const router = Router();

export const COUNTS = `
  (SELECT COUNT(DISTINCT m.user_id) FROM memberships m JOIN users mu ON mu.id = m.user_id
     WHERE mu.role <> 'admin' AND (m.community_id = c.id OR m.community_id IN (SELECT id FROM communities WHERE parent_id = c.id))) AS member_count,
  (SELECT COUNT(*) FROM posts p
     WHERE p.community_id = c.id OR p.community_id IN (SELECT id FROM communities WHERE parent_id = c.id)) AS post_count`;

export const IS_MEMBER = '(SELECT COUNT(*) FROM memberships mm WHERE mm.user_id = ? AND mm.community_id = c.id) AS is_member';

export const shape = (c, children = []) => ({
  id: c.id,
  name: c.name,
  slug: c.slug,
  description: c.description,
  category: c.category,
  parentId: c.parent_id ?? null,
  memberCount: c.member_count,
  postCount: c.post_count,
  isMember: !!c.is_member,
  subcommunities: children,
});

const str = (v) => (typeof v === 'string' ? v.trim() : '');

// GET /api/communities?category=Technology&q=design
router.get('/', (req, res) => {
  const db = getDb();
  const where = ['c.parent_id IS NULL', "c.status = 'approved'"];
  const params = [req.user.id];
  if (req.query.category) {
    where.push('c.category = ?');
    params.push(String(req.query.category));
  }
  if (req.query.q) {
    where.push('(ulike(c.name, ?) OR ulike(c.description, ?))');
    params.push(String(req.query.q), String(req.query.q));
  }
  const rows = db
    .prepare(`SELECT c.*, ${COUNTS}, ${IS_MEMBER} FROM communities c WHERE ${where.join(' AND ')} ORDER BY member_count DESC, c.name`)
    .all(...params);
  const kids = db
    .prepare("SELECT id, name, slug, parent_id FROM communities WHERE parent_id IS NOT NULL AND status = 'approved' ORDER BY name")
    .all();
  const byParent = new Map();
  for (const k of kids) {
    if (!byParent.has(k.parent_id)) byParent.set(k.parent_id, []);
    byParent.get(k.parent_id).push({ id: k.id, name: k.name, slug: k.slug });
  }
  const categories = db
    .prepare("SELECT DISTINCT category FROM communities WHERE parent_id IS NULL AND status = 'approved' ORDER BY category")
    .all()
    .map((r) => r.category);
  res.json({ categories, communities: rows.map((c) => shape(c, byParent.get(c.id) || [])) });
});

// POST /api/communities: administrators create communities and subcommunities. A Community Leader may create
// subcommunities under the community they lead, and nothing else. Top-level creation stays Admin-only.
router.post('/', (req, res) => {
  const db = getDb();
  const requestedParent = req.body?.parentId ? Number(req.body.parentId) : null;
  if (!canCreateSubcommunity(req.user, requestedParent, db)) {
    throw new HttpError(403, 'Only administrators can do this.', 'forbidden');
  }
  const name = str(req.body?.name);
  const description = str(req.body?.description);
  let category = str(req.body?.category);
  const parentId = req.body?.parentId ? Number(req.body.parentId) : null;

  const fields = {};
  if (name.length < 2 || name.length > 60) fields.name = 'Enter a name (2 to 60 characters).';
  if (description.length < 10 || description.length > 300) fields.description = 'Describe the community in 10 to 300 characters.';

  let parent = null;
  if (parentId !== null) {
    parent = Number.isInteger(parentId)
      ? db.prepare("SELECT * FROM communities WHERE id = ? AND parent_id IS NULL AND status = 'approved'").get(parentId)
      : null;
    if (!parent) fields.parentId = 'Choose an existing main community.';
    else category = parent.category; // subcommunities inherit their parent's category
  } else if (category.length < 2 || category.length > 40) {
    fields.category = 'Enter a category (2 to 40 characters).';
  }
  if (Object.keys(fields).length) throw validationError(fields);

  const duplicate = db
    .prepare('SELECT 1 FROM communities WHERE name = ? COLLATE NOCASE AND parent_id IS ?')
    .get(name, parent ? parent.id : null);
  if (duplicate) {
    throw new HttpError(409, 'A community with this name already exists here.', 'name_taken', {
      name: 'A community with this name already exists here.',
    });
  }

  const base = parent ? `${parent.slug}-${slugify(name)}` : slugify(name) || 'community';
  let slug = base;
  for (let i = 2; db.prepare('SELECT 1 FROM communities WHERE slug = ?').get(slug); i++) slug = `${base}-${i}`;

  const id = db
    .prepare('INSERT INTO communities (name, slug, description, category, parent_id, created_by) VALUES (?, ?, ?, ?, ?, ?)')
    .run(name, slug, description, category, parent ? parent.id : null, req.user.id).lastInsertRowid;
  const row = db.prepare(`SELECT c.*, ${COUNTS}, ${IS_MEMBER} FROM communities c WHERE c.id = ?`).get(req.user.id, id);
  res.status(201).json({ community: shape(row) });
});

// GET /api/communities/:id
router.get('/:id', (req, res) => {
  const db = getDb();
  const id = parseId(req.params.id, 'community id');
  const c = db.prepare(`SELECT c.*, ${COUNTS}, ${IS_MEMBER} FROM communities c WHERE c.id = ? AND c.status = 'approved'`).get(req.user.id, id);
  if (!c) throw notFoundError('Community not found.');

  const children = db
    .prepare("SELECT id, name, slug FROM communities WHERE parent_id = ? AND status = 'approved' ORDER BY name")
    .all(id);
  const parent = c.parent_id ? db.prepare('SELECT id, name, slug FROM communities WHERE id = ?').get(c.parent_id) : null;

  // Members join main communities only; a subcommunity counts as joined when its parent is.
  const memberOf = parent
    ? !!db.prepare('SELECT 1 FROM memberships WHERE user_id = ? AND community_id = ?').get(req.user.id, parent.id)
    : !!c.is_member;

  const posts = db
    .prepare(
      `SELECT p.id, p.title, p.created_at, u.id AS author_id, u.name AS author_name, u.profession AS author_profession,
              u.avatar_file AS author_avatar, u.is_bot AS author_is_bot, cm.id AS community_id, cm.name AS community_name,
              (SELECT COUNT(*) FROM comments x WHERE x.post_id = p.id) AS comment_count,
              substr(p.content, 1, 160) AS excerpt,
              (SELECT COUNT(*) FROM attachments a WHERE a.post_id = p.id AND a.kind = 'image') AS image_count,
              (SELECT COUNT(*) FROM attachments a WHERE a.post_id = p.id AND a.kind = 'audio') AS voice_count
         FROM posts p
         JOIN users u ON u.id = p.author_id
         JOIN communities cm ON cm.id = p.community_id
        WHERE p.community_id = ? OR p.community_id IN (SELECT id FROM communities WHERE parent_id = ?)
        ORDER BY p.created_at DESC LIMIT 20`
    )
    .all(id, id)
    .map((p) => ({
      id: p.id,
      title: p.title,
      createdAt: p.created_at,
      commentCount: p.comment_count,
      excerpt: p.excerpt,
      imageCount: p.image_count,
      hasVoice: p.voice_count > 0,
      author: { id: p.author_id, name: p.author_name, profession: p.author_profession, isBot: !!p.author_is_bot, avatarUrl: p.author_avatar ? `/api/uploads/${p.author_avatar}` : null },
      community: { id: p.community_id, name: p.community_name },
    }));

  res.json({
    community: { ...shape(c, children), isMember: memberOf, canJoin: !parent, parent },
    recentPosts: posts,
  });
});

function joinTarget(db, req) {
  const id = parseId(req.params.id, 'community id');
  const c = db.prepare("SELECT * FROM communities WHERE id = ? AND status = 'approved'").get(id);
  if (!c) throw notFoundError('Community not found.');
  if (c.parent_id) {
    const parent = db.prepare('SELECT name FROM communities WHERE id = ?').get(c.parent_id);
    throw new HttpError(400, `Join the main community "${parent.name}" instead. Subcommunities open automatically.`, 'not_joinable');
  }
  return c;
}

function membershipState(db, userId, id) {
  const row = db.prepare(`SELECT ${COUNTS}, ${IS_MEMBER} FROM communities c WHERE c.id = ?`).get(userId, id);
  return { id, isMember: !!row.is_member, memberCount: row.member_count };
}

// POST /api/communities/:id/join (safe to repeat)
router.post('/:id/join', (req, res) => {
  const db = getDb();
  const c = joinTarget(db, req);
  db.prepare('INSERT OR IGNORE INTO memberships (user_id, community_id) VALUES (?, ?)').run(req.user.id, c.id);
  res.json({ community: membershipState(db, req.user.id, c.id) });
});

// POST /api/communities/:id/posts: members start a discussion (text, images, GIFs, voice message)
router.post('/:id/posts', attachmentUpload, createPost);

// DELETE /api/communities/:id/join
router.delete('/:id/join', (req, res) => {
  const db = getDb();
  const c = joinTarget(db, req);
  db.prepare('DELETE FROM memberships WHERE user_id = ? AND community_id = ?').run(req.user.id, c.id);
  res.json({ community: membershipState(db, req.user.id, c.id) });
});

// DELETE /api/communities/:id (administrators only): removes the community, its subcommunities and all their discussions.
router.delete('/:id', requireAdmin, (req, res) => {
  const id = parseId(req.params.id, 'community id');
  const db = getDb();
  if (!db.prepare('SELECT 1 FROM communities WHERE id = ?').get(id)) throw notFoundError('Community not found.');
  // Collect uploaded files first; the rows disappear through cascading deletes.
  const ids = [id, ...db.prepare('SELECT id FROM communities WHERE parent_id = ?').all(id).map((r) => r.id)];
  const marks = ids.map(() => '?').join(',');
  const postIds = db.prepare(`SELECT id FROM posts WHERE community_id IN (${marks})`).all(...ids).map((r) => r.id);
  const files = filesForPosts(db, postIds);
  transaction((d) => {
    d.prepare('DELETE FROM communities WHERE parent_id = ?').run(id);
    d.prepare('DELETE FROM communities WHERE id = ?').run(id);
  });
  files.forEach(deleteMedia);
  res.json({ ok: true });
});

export default router;
