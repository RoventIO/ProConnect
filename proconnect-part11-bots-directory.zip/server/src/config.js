import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));

export const config = {
  port: Number(process.env.PORT) || 4000,
  // Use PROCONNECT_DB=:memory: for throwaway databases (tests).
  dbPath: process.env.PROCONNECT_DB || path.join(here, '..', 'data', 'proconnect.db'),
  // Uploaded images (profile photos now, post images later). Never served without a signed-in session.
  uploadDir: process.env.PROCONNECT_UPLOADS || path.join(here, '..', 'data', 'uploads'),
  clientOrigin: process.env.CLIENT_ORIGIN || 'http://localhost:5173',
  isProd: process.env.NODE_ENV === 'production',
  // Set JWT_SECRET in the environment for anything beyond local demonstration.
  jwtSecret: process.env.JWT_SECRET || 'dev-only-secret-change-me',
};
