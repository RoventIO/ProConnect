import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

process.env.PROCONNECT_DB = ':memory:';
process.env.PROCONNECT_UPLOADS = fs.mkdtempSync(path.join(os.tmpdir(), 'pc-uploads-'));

import test, { before, after } from 'node:test';
import assert from 'node:assert/strict';

const { createApp } = await import('../src/app.js');
const { seedDatabase, DEMO_PASSWORD } = await import('../src/db/seed.js');
const { getDb } = await import('../src/db/index.js');

let server;
let base;

before(async () => {
  seedDatabase();
  server = createApp().listen(0);
  await new Promise((r) => server.once('listening', r));
  base = `http://127.0.0.1:${server.address().port}`;
});
after(() => server.close());

/** A tiny browser: keeps the session cookie between requests. */
function browser() {
  let cookie = '';
  return {
    cookie: () => cookie,
    async request(method, path, body) {
      const res = await fetch(base + path, {
        method,
        headers: { 'Content-Type': 'application/json', ...(cookie ? { Cookie: cookie } : {}) },
        body: body ? JSON.stringify(body) : undefined,
      });
      const set = res.headers.getSetCookie().map((c) => c.split(';')[0]).find((c) => c.startsWith('pc_token='));
      if (set) cookie = set === 'pc_token=' ? '' : set;
      return { status: res.status, body: await res.json(), setCookie: res.headers.getSetCookie().join('; ') };
    },
  };
}
const as = (b) => ({ get: (p) => b.request('GET', p), post: (p, d) => b.request('POST', p, d), put: (p, d) => b.request('PUT', p, d), request: (m, p, d) => b.request(m, p, d), cookie: () => b.cookie() });

const newBrowser = () => as(browser());
async function signedInAsAlex() {
  const b = newBrowser();
  const r = await b.post('/api/auth/login', { email: 'alex.morgan@example.com', password: DEMO_PASSWORD });
  assert.equal(r.status, 200);
  return b;
}

test('health reports a connected database', async () => {
  const { status, body } = await newBrowser().get('/api/health');
  assert.equal(status, 200);
  assert.equal(body.database, 'connected');
});

test('visitors get 401 on internal content', async () => {
  const v = newBrowser();
  for (const p of ['/api/communities', '/api/communities/1', '/api/courses']) {
    const r = await v.get(p);
    assert.equal(r.status, 401, p);
    assert.equal(r.body.error.code, 'unauthenticated');
  }
});

test('/auth/me returns null user for visitors', async () => {
  const r = await newBrowser().get('/api/auth/me');
  assert.equal(r.status, 200);
  assert.equal(r.body.user, null);
});

test('registration validates fields and rejects duplicate emails', async () => {
  const b = newBrowser();
  const bad = await b.post('/api/auth/register', { name: 'A', email: 'nope', password: 'short' });
  assert.equal(bad.status, 400);
  assert.deepEqual(Object.keys(bad.body.error.fields).sort(), ['email', 'name', 'password']);

  const dup = await b.post('/api/auth/register', { name: 'Someone Else', email: 'ALEX.MORGAN@example.com', password: 'longenough1' });
  assert.equal(dup.status, 409);
  assert.equal(dup.body.error.code, 'email_taken');
});

test('full journey: register, onboarding gate, profile, access, logout', async () => {
  const b = newBrowser();
  const reg = await b.post('/api/auth/register', { name: 'Nina Park', email: 'nina@example.com', password: 'correct-horse-9' });
  assert.equal(reg.status, 201);
  assert.equal(reg.body.user.profileCompleted, false);
  assert.ok(!('password_hash' in reg.body.user) && !('passwordHash' in reg.body.user));
  assert.match(reg.setCookie, /HttpOnly/i);

  // Password is stored hashed, never in plain text.
  const stored = getDb().prepare("SELECT password_hash FROM users WHERE email = 'nina@example.com'").get();
  assert.notEqual(stored.password_hash, 'correct-horse-9');
  assert.match(stored.password_hash, /^\$2[aby]\$/);

  // Signed in but without a profile: content is still locked.
  const locked = await b.get('/api/communities');
  assert.equal(locked.status, 403);
  assert.equal(locked.body.error.code, 'profile_incomplete');

  // Incomplete profile is rejected with field messages.
  const incomplete = await b.put('/api/profile', { profession: 'Nurse', bio: 'short', skills: '' });
  assert.equal(incomplete.status, 400);
  assert.deepEqual(Object.keys(incomplete.body.error.fields).sort(), ['bio', 'skills']);

  const ok = await b.put('/api/profile', {
    profession: 'Nurse',
    bio: 'Emergency nurse interested in clinical informatics.',
    skills: 'Triage, Patient care, triage',
    yearsExperience: '5',
  });
  assert.equal(ok.status, 200);
  assert.equal(ok.body.user.profileCompleted, true);
  assert.deepEqual(ok.body.user.skills, ['Triage', 'Patient care']);

  const open = await b.get('/api/communities');
  assert.equal(open.status, 200);

  const out = await b.post('/api/auth/logout');
  assert.equal(out.status, 200);
  assert.equal((await b.get('/api/communities')).status, 401);
});

test('login fails with a generic message for wrong password and unknown email', async () => {
  const b = newBrowser();
  const wrong = await b.post('/api/auth/login', { email: 'alex.morgan@example.com', password: 'wrong-password' });
  const unknown = await b.post('/api/auth/login', { email: 'ghost@example.com', password: 'whatever123' });
  assert.equal(wrong.status, 401);
  assert.equal(unknown.status, 401);
  assert.equal(wrong.body.error.message, unknown.body.error.message);
});

test('a tampered session cookie is treated as signed out', async () => {
  const res = await fetch(base + '/api/auth/me', { headers: { Cookie: 'pc_token=not.a.real.token' } });
  assert.equal((await res.json()).user, null);
});

test('communities list contains top-level communities with subcommunities', async () => {
  const b = await signedInAsAlex();
  const { body } = await b.get('/api/communities');
  assert.equal(body.communities.length, 6);
  const sd = body.communities.find((c) => c.name === 'Software Development');
  assert.deepEqual(sd.subcommunities.map((s) => s.name), ['Backend', 'DevOps', 'Frontend']);
});

test('community detail, filters and errors', async () => {
  const b = await signedInAsAlex();
  const design = (await b.get('/api/communities?category=Design')).body.communities;
  assert.deepEqual(design.map((c) => c.name), ['Design & UX']);
  const sd = (await b.get('/api/communities')).body.communities.find((c) => c.name === 'Software Development');
  const detail = await b.get(`/api/communities/${sd.id}`);
  assert.ok(detail.body.recentPosts.some((p) => p.title.startsWith('How do you structure code reviews')));
  assert.equal((await b.get('/api/communities/9999')).status, 404);
  assert.equal((await b.get('/api/communities/abc')).body.error.code, 'invalid_id');
});

test('courses expose free/paid labels and filters', async () => {
  const b = await signedInAsAlex();
  const all = (await b.get('/api/courses')).body.courses;
  assert.equal(all.length, 6);
  assert.ok(all.every((c) => c.priceLabel === 'Free' || c.priceLabel === 'Paid'));
  assert.equal((await b.get('/api/courses?price=free&type=webinar')).body.courses.length, 3);
  assert.equal((await b.get('/api/courses?type=bogus')).status, 400);
});

test('unknown routes return JSON 404', async () => {
  const r = await newBrowser().get('/api/nope');
  assert.equal(r.status, 404);
  assert.equal(r.body.error.code, 'not_found');
});

test('schema rejects orphan posts', () => {
  assert.throws(() => getDb().prepare("INSERT INTO posts (author_id, community_id, title, content) VALUES (9999, 9999, 't', 'c')").run());
});

test('public stats expose aggregate numbers only', async () => {
  const r = await newBrowser().get('/api/stats');
  assert.equal(r.status, 200);
  assert.equal(r.body.totals.communities, 6);
  assert.equal(r.body.totals.professionals, 7); // 6 seeded accounts (incl. admin) + Nina from the earlier journey test
  assert.equal(r.body.week.discussions.points.length, 7);
  assert.ok(!JSON.stringify(r.body).includes('@'));
});

test('home data is for members only and contains real content', async () => {
  assert.equal((await newBrowser().get('/api/home')).status, 401);
  const b = await signedInAsAlex();
  const { body } = await b.get('/api/home');
  assert.equal(body.trending.length, 4);
  assert.equal(body.trending[0].replyCount, 2);
  assert.ok(body.courses.length > 0 && body.courses.every((c) => c.isSample));
  assert.equal(body.popularCommunities.length, 3);
});

test('my profile returns details, communities, posts and stats', async () => {
  const b = await signedInAsAlex();
  const { status, body } = await b.get('/api/profile');
  assert.equal(status, 200);
  assert.equal(body.user.email, 'alex.morgan@example.com');
  assert.equal(body.items.experience.length, 2);
  assert.equal(body.items.education.length, 2);
  assert.equal(body.items.projects.length, 2);
  assert.equal(body.stats.communities, 3);
  assert.ok(body.stats.discussions >= 2);
  assert.ok(body.recentPosts.length >= 2);
});

test('other members see permitted information only', async () => {
  const b = await signedInAsAlex();
  const sara = getDb().prepare("SELECT id FROM users WHERE email = 'sara.kim@example.com'").get();
  const { status, body } = await b.get(`/api/users/${sara.id}`);
  assert.equal(status, 200);
  assert.equal(body.user.name, 'Sara Kim');
  assert.ok(!('email' in body.user) && !('role' in body.user));
  assert.equal((await b.get('/api/users/9999')).status, 404);
  assert.equal((await newBrowser().get(`/api/users/${sara.id}`)).status, 401);
});

test('profile items: add, edit, delete, validation and ownership', async () => {
  const alex = await signedInAsAlex();
  const bad = await alex.post('/api/profile/items', { kind: 'project', title: '', url: 'javascript:alert(1)' });
  assert.equal(bad.status, 400);
  assert.deepEqual(Object.keys(bad.body.error.fields).sort(), ['title', 'url']);
  assert.equal((await alex.post('/api/profile/items', { kind: 'nonsense', title: 'x' })).status, 400);

  const created = await alex.post('/api/profile/items', { kind: 'project', title: 'Open source icons', subtitle: 'GitHub', url: 'https://github.com/example/icons' });
  assert.equal(created.status, 201);
  const id = created.body.item.id;

  const edited = await alex.put(`/api/profile/items/${id}`, { title: 'Open source icon set', url: 'https://github.com/example/icons' });
  assert.equal(edited.body.item.title, 'Open source icon set');
  assert.equal(edited.body.item.kind, 'project'); // kind cannot be changed

  // Another member cannot edit or delete Alex's entry.
  const other = newBrowser();
  await other.post('/api/auth/login', { email: 'sara.kim@example.com', password: DEMO_PASSWORD });
  assert.equal((await other.put(`/api/profile/items/${id}`, { title: 'Hijacked' })).status, 404);
  assert.equal((await other.request('DELETE', `/api/profile/items/${id}`)).status, 404);

  assert.equal((await alex.request('DELETE', `/api/profile/items/${id}`)).status, 200);
  assert.equal((await alex.request('DELETE', `/api/profile/items/${id}`)).status, 404);
});

test('editing basic profile fields persists and keeps validation', async () => {
  const b = await signedInAsAlex();
  const bad = await b.put('/api/profile', { profession: 'Designer', bio: 'too short', skills: 'A', yearsExperience: '-3' });
  assert.deepEqual(Object.keys(bad.body.error.fields).sort(), ['bio', 'yearsExperience']);
  const ok = await b.put('/api/profile', { profession: 'Product Designer', headline: 'Lead Designer', bio: 'Designer who mentors early-career colleagues.', skills: ['Design Systems', 'Mentoring'], yearsExperience: 10, location: 'London' });
  assert.equal(ok.body.user.headline, 'Lead Designer');
  assert.equal((await b.get('/api/profile')).body.user.yearsExperience, 10);
});

// ---- Image uploads ----
const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');
const upload = (b, bytes, name = 'photo.png', type = 'image/png') => {
  const fd = new FormData();
  fd.append('avatar', new Blob([bytes], { type }), name);
  return fetch(base + '/api/profile/avatar', { method: 'POST', headers: { Cookie: b.cookie() }, body: fd });
};

test('profile photo: upload, serve to members only, replace and remove', async () => {
  const alex = await signedInAsAlex();
  const res = await upload(alex, PNG);
  assert.equal(res.status, 200);
  const { user } = await res.json();
  assert.match(user.avatarUrl, /^\/api\/uploads\/[a-f0-9]{32}\.png$/);

  const img = await fetch(base + user.avatarUrl, { headers: { Cookie: alex.cookie() } });
  assert.equal(img.status, 200);
  assert.equal(img.headers.get('content-type'), 'image/png');
  assert.equal(img.headers.get('x-content-type-options'), 'nosniff');
  assert.equal((await fetch(base + user.avatarUrl)).status, 401); // visitors cannot fetch it

  // Other members see the photo on Alex's profile.
  const sara = newBrowser();
  await sara.post('/api/auth/login', { email: 'sara.kim@example.com', password: DEMO_PASSWORD });
  const alexRow = getDb().prepare("SELECT id FROM users WHERE email = 'alex.morgan@example.com'").get();
  assert.equal((await sara.get(`/api/users/${alexRow.id}`)).body.user.avatarUrl, user.avatarUrl);

  // Replacing deletes the old file from disk.
  const oldFile = user.avatarUrl.split('/').pop();
  const second = await (await upload(alex, PNG)).json();
  assert.notEqual(second.user.avatarUrl, user.avatarUrl);
  assert.equal(fs.existsSync(path.join(process.env.PROCONNECT_UPLOADS, oldFile)), false);

  const removed = await alex.request('DELETE', '/api/profile/avatar');
  assert.equal(removed.body.user.avatarUrl, null);
  assert.equal(fs.readdirSync(process.env.PROCONNECT_UPLOADS).length, 0);
});

test('profile photo: rejects fake images, oversized files and unsafe file names', async () => {
  const alex = await signedInAsAlex();
  const fake = await upload(alex, Buffer.from('<script>alert(1)</script> not an image at all'), 'evil.png', 'image/png');
  assert.equal(fake.status, 400);
  assert.equal((await fake.json()).error.code, 'unsupported_type');

  const svg = await upload(alex, Buffer.from('<svg xmlns="http://www.w3.org/2000/svg"></svg>'), 'x.svg', 'image/svg+xml');
  assert.equal(svg.status, 400);

  const big = Buffer.concat([PNG, Buffer.alloc(2 * 1024 * 1024 + 10)]);
  const tooBig = await upload(alex, big);
  assert.equal(tooBig.status, 413);
  assert.equal((await tooBig.json()).error.code, 'file_too_large');

  assert.equal((await fetch(base + '/api/uploads/..%2F..%2Fetc%2Fpasswd', { headers: { Cookie: alex.cookie() } })).status, 404);
  assert.equal((await fetch(base + '/api/uploads/notours.png', { headers: { Cookie: alex.cookie() } })).status, 404);
  assert.equal((await fetch(base + '/api/profile/avatar', { method: 'POST', headers: { Cookie: alex.cookie() } })).status, 400);
});

// ---- Communities: joining and administration ----
const { setAdmin } = await import('../src/db/makeAdmin.js');
const loginAs = async (email) => {
  const b = newBrowser();
  const r = await b.post('/api/auth/login', { email, password: DEMO_PASSWORD });
  assert.equal(r.status, 200);
  return b;
};
const communityByName = async (b, name) => (await b.get('/api/communities')).body.communities.find((c) => c.name === name);

test('members can join and leave main communities; joining is idempotent', async () => {
  const thomas = await loginAs('thomas.nguyen@example.com');
  const fin = await communityByName(thomas, 'Finance & Accounting');
  assert.equal(fin.isMember, false);
  assert.equal(fin.memberCount, 0);

  const joined = await thomas.post(`/api/communities/${fin.id}/join`);
  assert.equal(joined.body.community.isMember, true);
  assert.equal(joined.body.community.memberCount, 1);
  const again = await thomas.post(`/api/communities/${fin.id}/join`);
  assert.equal(again.body.community.memberCount, 1); // no duplicate membership

  assert.equal((await communityByName(thomas, 'Finance & Accounting')).isMember, true);
  assert.equal((await thomas.get(`/api/communities/${fin.id}`)).body.community.isMember, true);
  assert.ok((await thomas.get('/api/profile')).body.communities.some((c) => c.name === 'Finance & Accounting'));

  const left = await thomas.request('DELETE', `/api/communities/${fin.id}/join`);
  assert.equal(left.body.community.isMember, false);
  assert.equal(left.body.community.memberCount, 0);
  assert.equal((await thomas.request('DELETE', `/api/communities/${fin.id}/join`)).status, 200); // leaving twice is harmless
});

test('subcommunities cannot be joined directly but follow their parent', async () => {
  const alex = await signedInAsAlex();
  const sd = await communityByName(alex, 'Software Development');
  const backend = sd.subcommunities.find((s) => s.name === 'Backend');
  const r = await alex.post(`/api/communities/${backend.id}/join`);
  assert.equal(r.status, 400);
  assert.equal(r.body.error.code, 'not_joinable');
  const detail = (await alex.get(`/api/communities/${backend.id}`)).body.community;
  assert.equal(detail.canJoin, false);
  assert.equal(detail.isMember, true); // Alex joined Software Development
  assert.equal(detail.parent.name, 'Software Development');
});

test('visitors cannot join and unknown communities return 404', async () => {
  assert.equal((await newBrowser().post('/api/communities/1/join')).status, 401);
  const alex = await signedInAsAlex();
  assert.equal((await alex.post('/api/communities/9999/join')).status, 404);
});

test('only administrators can create or delete communities', async () => {
  const alex = await signedInAsAlex();
  const body = { name: 'Legal Professionals', category: 'Legal', description: 'Contracts, compliance and courtroom practice.' };
  assert.equal((await alex.post('/api/communities', body)).status, 403);
  assert.equal((await alex.request('DELETE', '/api/communities/1')).status, 403);
  assert.equal((await newBrowser().post('/api/communities', body)).status, 401);
});

test('the seeded admin can create, validate, nest and delete communities', async () => {
  const admin = await loginAs('admin@proconnect.example');
  assert.equal((await admin.get('/api/auth/me')).body.user.isAdmin, true);

  const bad = await admin.post('/api/communities', { name: 'X', description: 'short', category: '' });
  assert.deepEqual(Object.keys(bad.body.error.fields).sort(), ['category', 'description', 'name']);

  const created = await admin.post('/api/communities', { name: 'Legal Professionals', category: 'Legal', description: 'Contracts, compliance and courtroom practice.' });
  assert.equal(created.status, 201);
  assert.equal(created.body.community.slug, 'legal-professionals');
  const legalId = created.body.community.id;

  const dup = await admin.post('/api/communities', { name: 'legal professionals', category: 'Legal', description: 'Duplicate name in a different case.' });
  assert.equal(dup.status, 409);

  assert.equal((await admin.post('/api/communities', { name: 'Sub', description: 'Parent that does not exist.', parentId: 9999 })).status, 400);
  const sub = await admin.post('/api/communities', { name: 'Contract Law', category: 'ignored', description: 'Drafting and negotiating contracts.', parentId: legalId });
  assert.equal(sub.status, 201);
  assert.equal(sub.body.community.category, 'Legal'); // inherited from the parent
  assert.equal(sub.body.community.parentId, legalId);

  const list = (await admin.get('/api/communities')).body;
  assert.ok(list.categories.includes('Legal'));
  assert.deepEqual(list.communities.find((c) => c.id === legalId).subcommunities.map((s) => s.name), ['Contract Law']);

  // Deleting a main community also removes its subcommunities.
  assert.equal((await admin.request('DELETE', `/api/communities/${legalId}`)).status, 200);
  assert.equal((await admin.get(`/api/communities/${sub.body.community.id}`)).status, 404);
  assert.equal((await admin.request('DELETE', `/api/communities/${legalId}`)).status, 404);
});

test('make-admin promotes an existing account and can demote it again', async () => {
  const email = 'thomas.nguyen@example.com';
  assert.ok(setAdmin(email, true));
  const b = await loginAs(email);
  assert.equal((await b.get('/api/auth/me')).body.user.role, 'admin');
  assert.ok(setAdmin(email, false));
  assert.equal((await b.get('/api/auth/me')).body.user.role, 'member');
  assert.equal(setAdmin('nobody@example.com'), null);
});

// ---- Discussions: posts, comments, images, GIFs, voice messages, emoji ----
const GIF = Buffer.concat([Buffer.from('GIF89a'), Buffer.alloc(40)]);
const WEBM = Buffer.concat([Buffer.from([0x1a, 0x45, 0xdf, 0xa3]), Buffer.alloc(200, 7)]);
const uploadsCount = () => fs.readdirSync(process.env.PROCONNECT_UPLOADS).length;

/** Sends multipart form data with the member's session cookie. */
async function form(b, method, route, fields = {}, files = []) {
  const fd = new FormData();
  for (const [k, v] of Object.entries(fields)) fd.append(k, v);
  for (const [name, buf, filename, type] of files) fd.append(name, new Blob([buf], { type }), filename);
  const res = await fetch(base + route, { method, headers: { Cookie: b.cookie() }, body: fd });
  return { status: res.status, body: await res.json() };
}
const communityId = async (b, name) => (await communityByName(b, name)).id;

test('only community members can start discussions', async () => {
  const thomas = await loginAs('thomas.nguyen@example.com'); // member of Product Management only
  const sd = await communityId(thomas, 'Software Development');
  const denied = await thomas.post(`/api/communities/${sd}/posts`, { title: 'Hello world', content: 'Not a member' });
  assert.equal(denied.status, 403);
  assert.equal(denied.body.error.code, 'not_member');
  assert.equal((await newBrowser().post(`/api/communities/${sd}/posts`, { title: 'Hello', content: 'x' })).status, 401);
  assert.equal((await thomas.post('/api/communities/9999/posts', { title: 'Hello', content: 'x' })).status, 404);
});

test('discussion text is validated and emoji are stored intact', async () => {
  const alex = await signedInAsAlex();
  const pm = await communityId(alex, 'Product Management');
  const bad = await alex.post(`/api/communities/${pm}/posts`, { title: 'Hi', content: '' });
  assert.equal(bad.status, 400);
  assert.deepEqual(Object.keys(bad.body.error.fields).sort(), ['content', 'title']);

  const ok = await alex.post(`/api/communities/${pm}/posts`, { title: 'Roadmap tips 🚀', content: 'Great question 👍🎉 — here are my thoughts.' });
  assert.equal(ok.status, 201);
  assert.equal(ok.body.post.title, 'Roadmap tips 🚀');
  const read = await alex.get(`/api/posts/${ok.body.post.id}`);
  assert.equal(read.body.post.content, 'Great question 👍🎉 — here are my thoughts.');
  assert.equal(read.body.post.canEdit, true);
  await alex.request('DELETE', `/api/posts/${ok.body.post.id}`);
});

test('a discussion can carry images, a GIF and a voice message that members can open', async () => {
  const alex = await signedInAsAlex();
  const ux = await communityId(alex, 'Design & UX');
  const before = uploadsCount();
  const res = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Design critique day', content: 'See the attached', voiceDuration: '12' }, [
    ['images', PNG, 'one.png', 'image/png'],
    ['images', GIF, 'move.gif', 'image/gif'],
    ['voice', WEBM, 'voice.webm', 'audio/webm'],
  ]);
  assert.equal(res.status, 201);
  assert.equal(uploadsCount(), before + 3);
  const { attachments } = res.body.post;
  assert.deepEqual(attachments.map((a) => a.kind), ['image', 'image', 'audio']);
  assert.equal(attachments[2].durationSec, 12);

  const gif = await fetch(base + attachments[1].url, { headers: { Cookie: alex.cookie() } });
  assert.equal(gif.headers.get('content-type'), 'image/gif');
  const voice = await fetch(base + attachments[2].url, { headers: { Cookie: alex.cookie(), Range: 'bytes=0-9' } });
  assert.equal(voice.status, 206); // seeking in the voice player works
  assert.equal(voice.headers.get('content-type'), 'audio/webm');
  assert.equal((await fetch(base + attachments[0].url)).status, 401); // visitors cannot open attachments

  // Listing shows a summary.
  const detail = await alex.get(`/api/communities/${ux}`);
  const listed = detail.body.recentPosts.find((p) => p.id === res.body.post.id);
  assert.equal(listed.imageCount, 2);
  assert.equal(listed.hasVoice, true);
  assert.equal(listed.excerpt, 'See the attached');

  await alex.request('DELETE', `/api/posts/${res.body.post.id}`);
  assert.equal(uploadsCount(), before); // files removed with the post
});

test('an image-only discussion is allowed, fake files are rejected without leaving anything behind', async () => {
  const alex = await signedInAsAlex();
  const ux = await communityId(alex, 'Design & UX');
  const before = uploadsCount();
  const postsBefore = getDb().prepare('SELECT COUNT(*) AS n FROM posts').get().n;

  const imageOnly = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Just a picture' }, [['images', PNG, 'a.png', 'image/png']]);
  assert.equal(imageOnly.status, 201);
  await alex.request('DELETE', `/api/posts/${imageOnly.body.post.id}`);

  // The second file is not an image: the whole post must be rejected and the first file removed again.
  const mixed = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Broken upload', content: 'x' }, [
    ['images', PNG, 'ok.png', 'image/png'],
    ['images', Buffer.from('<script>alert(1)</script> definitely not an image'), 'bad.png', 'image/png'],
  ]);
  assert.equal(mixed.status, 400);
  assert.equal(mixed.body.error.code, 'unsupported_type');
  assert.equal(uploadsCount(), before);
  assert.equal(getDb().prepare('SELECT COUNT(*) AS n FROM posts').get().n, postsBefore);

  const badVoice = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Bad voice', content: 'x' }, [['voice', Buffer.from('not audio at all, just text'), 'v.webm', 'audio/webm']]);
  assert.equal(badVoice.status, 400);

  const five = Array.from({ length: 5 }, (_, i) => ['images', PNG, `${i}.png`, 'image/png']);
  const tooMany = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Too many pictures', content: 'x' }, five);
  assert.equal(tooMany.status, 400);
  assert.equal(uploadsCount(), before);
});

test('replies: members only, text, image, GIF or voice, listed in order', async () => {
  const alex = await signedInAsAlex();
  const sd = await communityId(alex, 'Software Development');
  const post = (await alex.post(`/api/communities/${sd}/posts`, { title: 'Reply test thread', content: 'Say something' })).body.post;

  const thomas = await loginAs('thomas.nguyen@example.com'); // not a member of Software Development
  const denied = await thomas.post(`/api/posts/${post.id}/comments`, { content: 'Let me in' });
  assert.equal(denied.status, 403);
  assert.equal((await thomas.get(`/api/posts/${post.id}`)).body.post.canComment, false);

  assert.equal((await alex.post(`/api/posts/${post.id}/comments`, { content: '   ' })).status, 400);
  assert.equal((await alex.post(`/api/posts/${post.id}/comments`, { content: 'First reply 😀' })).status, 201);
  assert.equal((await form(alex, 'POST', `/api/posts/${post.id}/comments`, {}, [['images', GIF, 'party.gif', 'image/gif']])).status, 201);
  assert.equal((await form(alex, 'POST', `/api/posts/${post.id}/comments`, { voiceDuration: '5' }, [['voice', WEBM, 'v.webm', 'audio/webm']])).status, 201);

  const { comments } = (await alex.get(`/api/posts/${post.id}`)).body;
  assert.equal(comments.length, 3);
  assert.equal(comments[0].content, 'First reply 😀');
  assert.equal(comments[1].attachments[0].kind, 'image');
  assert.equal(comments[2].attachments[0].kind, 'audio');
  assert.ok(comments.every((c) => c.canEdit && c.canDelete));
  await alex.request('DELETE', `/api/posts/${post.id}`);
});

test('editing and deleting: authors edit, authors and admins delete, others are refused', async () => {
  const alex = await signedInAsAlex();
  const sara = await loginAs('sara.kim@example.com'); // member of Software Development
  const admin = await loginAs('admin@proconnect.example');
  const sd = await communityId(alex, 'Software Development');
  const before = uploadsCount();

  const post = (await form(sara, 'POST', `/api/communities/${sd}/posts`, { title: 'Original title', content: 'Original text' }, [['images', PNG, 'p.png', 'image/png']])).body.post;
  const reply = await form(sara, 'POST', `/api/posts/${post.id}/comments`, { content: 'My reply' }, [['images', PNG, 'c.png', 'image/png']]);
  assert.equal(reply.status, 201);
  assert.equal(uploadsCount(), before + 2);

  // Alex is a member but not the author.
  assert.equal((await alex.put(`/api/posts/${post.id}`, { title: 'Hijacked', content: 'x' })).status, 403);
  assert.equal((await alex.put(`/api/comments/${reply.body.comment.id}`, { content: 'Hijacked' })).status, 403);
  assert.equal((await alex.request('DELETE', `/api/posts/${post.id}`)).status, 403);
  assert.equal((await alex.request('DELETE', `/api/comments/${reply.body.comment.id}`)).status, 403);

  const edited = await sara.put(`/api/posts/${post.id}`, { title: 'Better title', content: 'Better text 🙂' });
  assert.equal(edited.status, 200);
  assert.equal(edited.body.post.edited, true);
  assert.equal(edited.body.post.attachments.length, 1);
  assert.equal((await sara.put(`/api/posts/${post.id}`, { title: 'x', content: '' })).status, 400);
  assert.equal((await sara.put(`/api/comments/${reply.body.comment.id}`, { content: 'Edited reply' })).status, 200);
  assert.equal((await sara.get(`/api/posts/${post.id}`)).body.comments[0].edited, true);

  // An administrator can moderate: deleting the post removes the reply and every file.
  const adminView = (await admin.get(`/api/posts/${post.id}`)).body;
  assert.equal(adminView.post.canDelete, true);
  assert.equal(adminView.post.canEdit, false);
  assert.equal((await admin.request('DELETE', `/api/posts/${post.id}`)).status, 200);
  assert.equal(uploadsCount(), before);
  assert.equal((await sara.get(`/api/posts/${post.id}`)).status, 404);
});

test('deleting a community removes its discussions and their uploaded files', async () => {
  const admin = await loginAs('admin@proconnect.example');
  const before = uploadsCount();
  const made = await admin.post('/api/communities', { name: 'Temporary Lab', category: 'Testing', description: 'A community created only for a test.' });
  const id = made.body.community.id;
  await admin.post(`/api/communities/${id}/join`);
  const post = (await form(admin, 'POST', `/api/communities/${id}/posts`, { title: 'Lab post', content: 'with a file' }, [['images', PNG, 'l.png', 'image/png']])).body.post;
  await form(admin, 'POST', `/api/posts/${post.id}/comments`, { content: 'and a reply' }, [['voice', WEBM, 'v.webm', 'audio/webm']]);
  assert.equal(uploadsCount(), before + 2);
  assert.equal((await admin.request('DELETE', `/api/communities/${id}`)).status, 200);
  assert.equal(uploadsCount(), before);
  assert.equal((await admin.get(`/api/posts/${post.id}`)).status, 404);
});

// ---- Search and filters ----
const searchFor = async (b, params) => (await b.get(`/api/search?${new URLSearchParams(params)}`)).body;
const ids = (r) => r.items.map((i) => i.name || i.title);

test('search is for members only and asks for a query when empty', async () => {
  assert.equal((await newBrowser().get('/api/search?q=design')).status, 401);
  const alex = await signedInAsAlex();
  const r = await searchFor(alex, {});
  assert.equal(r.needsQuery, true);
  assert.equal(r.results.posts.total, 0);
});

test('a keyword finds communities, discussions, people and courses', async () => {
  const alex = await signedInAsAlex();
  const r = await searchFor(alex, { q: 'design' });
  assert.ok(ids(r.results.communities).includes('Design & UX'));
  assert.ok(r.results.posts.items.some((p) => p.title === 'Design tokens in practice'));
  assert.ok(r.results.people.items.some((p) => p.name === 'Laura Bennett')); // profession: Product Designer
  assert.ok(ids(r.results.courses).includes('Designing Accessible Interfaces'));
  assert.deepEqual(r.excluded, []);
  // Title/name matches come first.
  assert.equal(r.results.communities.items[0].name, 'Design & UX');
});

test('search is case-insensitive, finds skills and subcommunities, and treats % and _ literally', async () => {
  const alex = await signedInAsAlex();
  assert.ok((await searchFor(alex, { q: 'DESIGN SYSTEMS' })).results.people.items.some((p) => p.name === 'Alex Morgan')); // skill
  assert.ok(ids((await searchFor(alex, { q: 'backend' })).results.communities).includes('Software Development')); // subcommunity name
  for (const q of ['%', '_', '\\']) {
    const r = await searchFor(alex, { q });
    assert.equal(r.results.communities.total + r.results.posts.total + r.results.people.total + r.results.courses.total, 0, `literal ${q}`);
  }
  assert.equal((await alex.get(`/api/search?q=${'x'.repeat(101)}`)).status, 400);
});

test('Profession filter narrows people and discussions and hides types it cannot apply to', async () => {
  const alex = await signedInAsAlex();
  const r = await searchFor(alex, { profession: 'Physician' });
  assert.deepEqual(ids(r.results.people), ['Dr. Daniel Reyes']);
  assert.deepEqual(r.results.posts.items.map((p) => p.author.name), ['Dr. Daniel Reyes']);
  assert.deepEqual(r.excluded.sort(), ['communities', 'courses']);
  assert.equal(r.results.courses.total, 0);
  const withText = await searchFor(alex, { q: 'informatics', profession: 'Physician' });
  assert.equal(withText.results.posts.total, 1);
});

test('Topic and Community filters work together with keywords', async () => {
  const alex = await signedInAsAlex();
  const opts = (await alex.get('/api/search/options')).body;
  assert.ok(opts.professions.includes('Physician'));
  const backend = opts.topics.find((t) => t.name === 'Backend');
  assert.equal(backend.parent.name, 'Software Development');
  const ux = opts.communities.find((c) => c.name === 'Design & UX');

  const byTopic = await searchFor(alex, { topic: backend.id });
  assert.deepEqual(ids(byTopic.results.communities), ['Software Development']);
  assert.ok(byTopic.results.posts.items.every((p) => p.community.name === 'Backend'));
  assert.deepEqual(byTopic.excluded.sort(), ['courses', 'people']);

  const byCommunity = await searchFor(alex, { community: ux.id });
  assert.deepEqual(ids(byCommunity.results.communities), ['Design & UX']);
  assert.ok(byCommunity.results.posts.total >= 2);
  assert.deepEqual(ids(byCommunity.results.people).sort(), ['Alex Morgan', 'Laura Bennett']); // members of Design & UX
  assert.deepEqual(byCommunity.excluded, ['courses']);

  const both = await searchFor(alex, { q: 'critiques', community: ux.id, profession: 'Product Designer' });
  assert.deepEqual(both.results.posts.items.map((p) => p.title), ['How do you structure design critiques?']);
  assert.equal((await alex.get('/api/search?topic=abc')).status, 400);
  assert.equal((await searchFor(alex, { topic: 99999 })).results.posts.total, 0);
});

test('search results never expose emails or incomplete profiles', async () => {
  const alex = await signedInAsAlex();
  const incomplete = newBrowser();
  await incomplete.post('/api/auth/register', { name: 'Hidden Zelda', email: 'zelda@example.com', password: 'longenough1' });
  const r = await searchFor(alex, { q: 'zelda' });
  assert.equal(r.results.people.total, 0);
  const people = await searchFor(alex, { q: 'alex' });
  assert.ok(people.results.people.total >= 1);
  assert.ok(!JSON.stringify(people).includes('@example.com'));
});

test('search finds text in new discussions immediately and respects the 20 item limit', async () => {
  const alex = await signedInAsAlex();
  const ux = await communityId(alex, 'Design & UX');
  const made = [];
  for (let i = 0; i < 22; i++) made.push((await alex.post(`/api/communities/${ux}/posts`, { title: `Zebra topic ${i}`, content: 'zebra' })).body.post.id);
  const r = await searchFor(alex, { q: 'zebra' });
  assert.equal(r.results.posts.total, 22);
  assert.equal(r.results.posts.items.length, 20);
  for (const id of made) await alex.request('DELETE', `/api/posts/${id}`);
  assert.equal((await searchFor(alex, { q: 'zebra' })).results.posts.total, 0);
});

test('courses are ordered upcoming, then undated, then past, and past events are flagged', async () => {
  const alex = await signedInAsAlex();
  const db = getDb();
  const insert = db.prepare("INSERT INTO courses (title, type, is_free, starts_at, approval_status) VALUES (?, 'webinar', 1, ?, 'approved')");
  const day = 86400000;
  const past = insert.run('ZZ past webinar', new Date(Date.now() - 10 * day).toISOString()).lastInsertRowid;
  const upcoming = insert.run('ZZ upcoming webinar', new Date(Date.now() + 10 * day).toISOString()).lastInsertRowid;
  const undated = insert.run('ZZ undated webinar', null).lastInsertRowid;
  try {
    const { courses } = (await alex.get('/api/courses?q=ZZ')).body;
    assert.deepEqual(courses.map((c) => c.title), ['ZZ upcoming webinar', 'ZZ undated webinar', 'ZZ past webinar']);
    assert.deepEqual(courses.map((c) => c.isPast), [false, false, true]);
    // Search uses the same order.
    const found = (await searchFor(alex, { q: 'ZZ' })).results.courses.items.map((c) => c.title);
    assert.deepEqual(found, ['ZZ upcoming webinar', 'ZZ undated webinar', 'ZZ past webinar']);
  } finally {
    for (const id of [past, upcoming, undated]) db.prepare('DELETE FROM courses WHERE id = ?').run(id);
  }
});

test('"My Communities" data is per signed-in user, stored in the database and survives a new sign-in', async () => {
  const joinedNames = async (b) => (await b.get('/api/communities')).body.communities.filter((c) => c.isMember).map((c) => c.name).sort();
  const alex = await signedInAsAlex();
  const sara = await loginAs('sara.kim@example.com');
  assert.deepEqual(await joinedNames(alex), ['Design & UX', 'Product Management', 'Software Development']);
  assert.deepEqual(await joinedNames(sara), ['Software Development']); // a different user sees a different list

  const edu = await communityId(sara, 'Teachers & Educators');
  await sara.post(`/api/communities/${edu}/join`);
  assert.deepEqual(await joinedNames(sara), ['Software Development', 'Teachers & Educators']);
  assert.deepEqual(await joinedNames(alex), ['Design & UX', 'Product Management', 'Software Development']); // Alex unaffected

  // The membership is a database row, so a brand-new session (like a later sign-in) sees it too.
  const saraAgain = await loginAs('sara.kim@example.com');
  assert.deepEqual(await joinedNames(saraAgain), ['Software Development', 'Teachers & Educators']);
  const sarasId = getDb().prepare("SELECT id FROM users WHERE email = 'sara.kim@example.com'").get().id;
  assert.equal(getDb().prepare('SELECT COUNT(*) AS n FROM memberships WHERE user_id = ? AND community_id = ?').get(sarasId, edu).n, 1);

  await saraAgain.request('DELETE', `/api/communities/${edu}/join`);
  assert.deepEqual(await joinedNames(await loginAs('sara.kim@example.com')), ['Software Development']);
});

test('search ignores letter case in every script, not only English (Armenian, Cyrillic, Greek)', async () => {
  const alex = await signedInAsAlex();
  const ux = await communityId(alex, 'Design & UX');
  const texts = [
    ['Բարև աշխարհ', 'Ողջույն բոլորին, սա հայերեն գրառում է'], // Armenian
    ['Привет мир', 'Это сообщение на русском языке'], // Cyrillic
    ['Γειά σου κόσμε', 'Ένα μήνυμα στα ελληνικά'], // Greek
  ];
  const made = [];
  for (const [title, content] of texts) made.push((await alex.post(`/api/communities/${ux}/posts`, { title, content })).body.post.id);
  try {
    const found = async (q) => (await searchFor(alex, { q })).results.posts.items.map((p) => p.title);
    assert.deepEqual(await found('բար'), ['Բարև աշխարհ']); // lower-case query, capital letter in the text
    assert.deepEqual(await found('ԲԱՐԵՒ'), ['Բարև աշխարհ']); // upper-case query (capital form of the letter "և" is ԵՒ)
    assert.deepEqual(await found('բարեւ'), ['Բարև աշխարհ']); // the two-letter spelling of the same word
    assert.deepEqual(await found('ՀԱՅԵՐԵՆ'), ['Բարև աշխարհ']); // inside the text
    assert.deepEqual(await found('при'), ['Привет мир']);
    assert.deepEqual(await found('ΓΕΙΆ'), ['Γειά σου κόσμε']);
    assert.deepEqual(await found('design'), (await found('DESIGN'))); // English still works
  } finally {
    for (const id of made) await alex.request('DELETE', `/api/posts/${id}`);
  }
});

test('list filters on communities and courses are case-insensitive too', async () => {
  const alex = await signedInAsAlex();
  assert.ok((await alex.get('/api/communities?q=DESIGN')).body.communities.some((c) => c.name === 'Design & UX'));
  assert.ok((await alex.get('/api/courses?q=ACCESSIBLE')).body.courses.some((c) => c.title === 'Designing Accessible Interfaces'));
});

test('upload problems explain the real limit of the place they happened in', async () => {
  const alex = await signedInAsAlex();
  const ux = await communityId(alex, 'Design & UX');
  const before = uploadsCount();

  const five = Array.from({ length: 5 }, (_, i) => ['images', PNG, `${i}.png`, 'image/png']);
  const many = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Too many images', content: 'x' }, five);
  assert.equal(many.status, 400);
  assert.equal(many.body.error.code, 'too_many_files');
  assert.equal(many.body.error.message, 'You can attach up to 4 images.');

  const twoVoices = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Two voices', content: 'x' }, [['voice', WEBM, 'a.webm', 'audio/webm'], ['voice', WEBM, 'b.webm', 'audio/webm']]);
  assert.equal(twoVoices.body.error.message, 'You can attach only one voice message.');

  const sixMb = Buffer.concat([PNG, Buffer.alloc(5 * 1024 * 1024 + 10)]);
  const bigImage = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Huge image', content: 'x' }, [['images', sixMb, 'big.png', 'image/png']]);
  assert.equal(bigImage.status, 413);
  assert.equal(bigImage.body.error.message, 'Each image can be up to 5 MB.'); // the post limit, not the 2 MB profile-photo limit

  const bigVoice = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'Huge voice', content: 'x' }, [['voice', Buffer.concat([WEBM, Buffer.alloc(5 * 1024 * 1024 + 10)]), 'big.webm', 'audio/webm']]);
  assert.equal(bigVoice.body.error.message, 'The voice message is too large. The maximum size is 5 MB.');

  const threeMb = Buffer.concat([PNG, Buffer.alloc(3 * 1024 * 1024)]);
  const okPost = await form(alex, 'POST', `/api/communities/${ux}/posts`, { title: 'A 3 MB image is fine in a post', content: 'x' }, [['images', threeMb, 'ok.png', 'image/png']]);
  assert.equal(okPost.status, 201); // 3 MB is allowed for posts
  await alex.request('DELETE', `/api/posts/${okPost.body.post.id}`);
  const avatar = await upload(alex, threeMb); // but not for a profile photo
  assert.equal(avatar.status, 413);
  assert.equal((await avatar.json()).error.message, 'The profile photo can be up to 2 MB.');
  assert.equal(uploadsCount(), before); // nothing was left behind
});

// ---- Part 1: roles and permissions ----
const perms = await import('../src/utils/permissions.js');
const { requireOrganizer } = await import('../src/middleware/auth.js');
const userRow = (email) => getDb().prepare('SELECT * FROM users WHERE email = ?').get(email);

/** Registers and onboards a throwaway member. */
async function newMember(email) {
  const b = newBrowser();
  assert.equal((await b.post('/api/auth/register', { name: 'Test Member', email, password: 'correct-horse-9' })).status, 201);
  assert.equal((await b.put('/api/profile', { profession: 'Tester', bio: 'Checks permissions carefully.', skills: 'Testing' })).status, 200);
  return b;
}

test('Student and Beginner are self-selected; Professional and unknown values are refused', async () => {
  const m = await newMember('status.member@example.com');
  assert.equal((await m.get('/api/auth/me')).body.user.status, 'beginner');
  const s = await m.put('/api/profile/status', { status: 'student' });
  assert.equal(s.status, 200);
  assert.equal(s.body.user.status, 'student');
  assert.equal((await m.put('/api/profile/status', { status: 'Beginner' })).body.user.status, 'beginner');

  const pro = await m.put('/api/profile/status', { status: 'professional' });
  assert.equal(pro.status, 403);
  assert.equal(pro.body.error.code, 'professional_requires_admin');
  for (const bad of ['admin', 'community_leader', 'organizer', '', undefined]) {
    assert.equal((await m.put('/api/profile/status', { status: bad })).status, 400, String(bad));
  }
  assert.equal((await m.get('/api/auth/me')).body.user.status, 'beginner');
  assert.equal((await newBrowser().put('/api/profile/status', { status: 'student' })).status, 401);

  // An approved Professional cannot quietly drop the status through the ordinary route.
  const sara = await loginAs('sara.kim@example.com');
  assert.equal((await sara.put('/api/profile/status', { status: 'student' })).status, 403);
  assert.equal(userRow('sara.kim@example.com').status, 'professional');
});

test('ordinary profile and sign-up requests cannot set role, status or organizer permission', async () => {
  const evil = { role: 'admin', status: 'professional', isOrganizer: true, is_organizer: 1, isAdmin: true, communityLeader: true };
  const b = newBrowser();
  const refused = await b.post('/api/auth/register', { name: 'Sneaky One', email: 'sneaky@example.com', password: 'correct-horse-9', ...evil });
  assert.equal(refused.status, 400); // status 'professional' is not a choice at sign-up
  assert.ok(refused.body.error.fields.status);
  assert.equal(userRow('sneaky@example.com'), undefined);
  const { status: _s, ...evilWithoutStatus } = evil; // eslint-disable-line no-unused-vars
  const reg = await b.post('/api/auth/register', { name: 'Sneaky One', email: 'sneaky@example.com', password: 'correct-horse-9', ...evilWithoutStatus });
  assert.equal(reg.status, 201);
  const upd = await b.put('/api/profile', { profession: 'Tester', bio: 'Tries to promote themselves.', skills: 'Testing', ...evil });
  assert.equal(upd.status, 200);
  const row = userRow('sneaky@example.com');
  assert.equal(row.role, 'member');
  assert.equal(row.status, 'beginner');
  assert.equal(row.is_organizer, 0);
  const me = (await b.get('/api/auth/me')).body.user;
  assert.deepEqual([me.isAdmin, me.isOrganizer, me.status], [false, false, 'beginner']);

  // Profile items and the member view never carry privileged fields.
  const other = (await b.get(`/api/users/${userRow('sara.kim@example.com').id}`)).body.user;
  assert.ok(!('role' in other) && !('isOrganizer' in other) && !('email' in other));
});

test('administrative endpoints reject visitors, members, leaders and organizers', async () => {
  const target = userRow('laura.bennett@example.com').id;
  const community = getDb().prepare("SELECT id FROM communities WHERE name = 'Design & UX'").get().id;
  const calls = [
    ['PUT', `/api/admin/users/${target}/organizer`, { granted: true }],
    ['PUT', `/api/admin/users/${target}/professional`, { granted: true }],
    ['PUT', `/api/admin/communities/${community}/leaders/${target}`],
    ['DELETE', `/api/admin/communities/${community}/leaders/${target}`],
  ];
  for (const [method, path, body] of calls) {
    assert.equal((await newBrowser().request(method, path, body)).status, 401, `visitor ${path}`);
    for (const email of ['laura.bennett@example.com', 'alex.morgan@example.com', 'sara.kim@example.com']) { // member, community leader, organizer
      const r = await (await loginAs(email)).request(method, path, body);
      assert.equal(r.status, 403, `${email} ${method} ${path}`);
      assert.equal(r.body.error.code, 'forbidden');
    }
  }
  const row = userRow('laura.bennett@example.com');
  assert.deepEqual([row.is_organizer, row.status], [0, 'professional']); // nothing changed
});

test('an Admin grants and revokes Authorized Organizer and Professional status', async () => {
  await newMember('grantee@example.com');
  const id = userRow('grantee@example.com').id;
  const admin = await loginAs('admin@proconnect.example');
  assert.equal((await admin.put(`/api/admin/users/${id}/organizer`, { granted: 'yes' })).status, 400);
  assert.equal((await admin.put('/api/admin/users/9999/organizer', { granted: true })).status, 404);

  assert.equal(userRow('grantee@example.com').is_organizer, 0);
  assert.equal((await admin.put(`/api/admin/users/${id}/organizer`, { granted: true })).status, 200);
  assert.equal(userRow('grantee@example.com').is_organizer, 1);
  assert.equal(perms.canPublishListings(userRow('grantee@example.com')), true);
  assert.equal((await admin.put(`/api/admin/users/${id}/organizer`, { granted: false })).status, 200);
  assert.equal(perms.canPublishListings(userRow('grantee@example.com')), false);

  assert.equal((await admin.put(`/api/admin/users/${id}/professional`, { granted: true })).body.user.status, 'professional');
  assert.equal(userRow('grantee@example.com').status, 'professional');
  assert.equal((await admin.put(`/api/admin/users/${id}/professional`, { granted: false })).body.user.status, 'beginner');
});

test('Community Leader authority is limited to the communities they lead', async () => {
  const db = getDb();
  const idOf = (name) => db.prepare('SELECT id FROM communities WHERE name = ?').get(name).id;
  const alexRow = userRow('alex.morgan@example.com'); // leads Design & UX in the demo data
  const design = idOf('Design & UX');
  const uxResearch = idOf('UX Research'); // a subcommunity of Design & UX
  const software = idOf('Software Development');

  assert.equal(perms.isLeaderOf(alexRow, design), true);
  assert.equal(perms.isLeaderOf(alexRow, uxResearch), true); // a parent's leader also leads its subcommunities
  assert.equal(perms.isLeaderOf(alexRow, software), false);
  assert.equal(perms.isLeaderOf(alexRow, idOf('Backend')), false);
  assert.equal(perms.isLeaderOf(userRow('admin@proconnect.example'), design), false); // Admin is not implicitly a leader

  const alex = await loginAs('alex.morgan@example.com');
  const sub = { name: 'Interaction Design', description: 'Motion, micro-interactions and flows.' };
  assert.equal((await alex.post('/api/communities', { ...sub, parentId: software })).status, 403); // someone else's parent
  assert.equal((await alex.post('/api/communities', { ...sub, category: 'Design' })).status, 403); // top-level stays Admin-only
  assert.equal((await alex.post('/api/communities', { ...sub, parentId: uxResearch })).status, 403); // a subcommunity is not a parent they lead
  const made = await alex.post('/api/communities', { ...sub, parentId: design });
  assert.equal(made.status, 201);
  assert.equal(made.body.community.parentId, design);
  assert.equal((await alex.request('DELETE', `/api/communities/${made.body.community.id}`)).status, 403);

  // A leader gets no organizer permission and no admin rights.
  assert.equal(perms.canPublishListings(alexRow), false);
  assert.equal((await alex.get('/api/auth/me')).body.user.isAdmin, false);

  // The Admin assigns and removes leaders; removal ends the authority immediately.
  const admin = await loginAs('admin@proconnect.example');
  const laura = userRow('laura.bennett@example.com');
  assert.equal((await admin.put(`/api/admin/communities/${software}/leaders/${laura.id}`)).status, 200);
  assert.equal((await admin.put(`/api/admin/communities/${software}/leaders/${laura.id}`)).status, 200); // repeatable
  const lauraB = await loginAs('laura.bennett@example.com');
  assert.equal((await lauraB.post('/api/communities', { ...sub, name: 'Platform Engineering', parentId: software })).status, 201);
  assert.equal((await lauraB.post('/api/communities', { ...sub, name: 'Other Design', parentId: design })).status, 403);
  assert.equal((await admin.request('DELETE', `/api/admin/communities/${software}/leaders/${laura.id}`)).status, 200);
  assert.equal((await lauraB.post('/api/communities', { ...sub, name: 'Late Attempt', parentId: software })).status, 403);
  assert.equal((await admin.request('DELETE', `/api/admin/communities/${software}/leaders/${laura.id}`)).status, 404);
  assert.equal((await admin.put(`/api/admin/communities/9999/leaders/${laura.id}`)).status, 404);
});

test('only Authorized Organizers pass the publishing check; Leaders, Professionals and Admins do not get it implicitly', () => {
  const check = (email) => requireOrganizer({ user: userRow(email) }, {}, () => {});
  assert.doesNotThrow(() => check('sara.kim@example.com')); // organizer in the demo data
  for (const email of ['alex.morgan@example.com', 'admin@proconnect.example', 'daniel.reyes@example.com']) {
    assert.throws(() => check(email), (e) => e.status === 403 && e.code === 'forbidden', email); // leader, admin, plain professional
  }
  assert.throws(() => requireOrganizer({ user: null }, {}, () => {}), (e) => e.status === 403);
});

test('Admin accounts are not counted or listed as ordinary community participants', async () => {
  const admin = await loginAs('admin@proconnect.example');
  const design = getDb().prepare("SELECT id FROM communities WHERE name = 'Design & UX'").get().id;
  const before = (await admin.get(`/api/communities/${design}`)).body.community.memberCount;
  assert.equal((await admin.post(`/api/communities/${design}/join`)).status, 200);
  assert.equal((await admin.get(`/api/communities/${design}`)).body.community.memberCount, before);
  const people = (await admin.get('/api/search?q=Administrator&type=people')).body;
  assert.ok(!JSON.stringify(people).includes('admin@proconnect.example'));
  assert.ok(!(people.results?.people?.items || []).some((p) => p.name === 'ProConnect Admin'));
});

test('make-admin --password creates or repairs an admin account without touching other data', async () => {
  const { ensureAdmin } = await import('../src/db/makeAdmin.js');
  const users = () => getDb().prepare('SELECT COUNT(*) AS n FROM users').get().n;
  const before = users();
  assert.deepEqual(ensureAdmin('recovered.admin@example.com', 'Recovered123'), { created: true });
  const b = newBrowser();
  const r = await b.post('/api/auth/login', { email: 'recovered.admin@example.com', password: 'Recovered123' });
  assert.equal(r.status, 200);
  assert.equal(r.body.user.isAdmin, true);
  assert.equal((await b.get('/api/communities')).status, 200); // already onboarded
  assert.deepEqual(ensureAdmin('recovered.admin@example.com', 'Changed12345'), { created: false });
  assert.equal((await newBrowser().post('/api/auth/login', { email: 'recovered.admin@example.com', password: 'Recovered123' })).status, 401);
  assert.equal(users(), before + 1);
});

// ---- Part 9: status at sign-up, demo accounts, repeatable demo seed ----
test('sign-up saves Student or Beginner, defaults to Beginner and refuses anything else', async () => {
  for (const [email, sent, saved] of [['su1@example.com', 'student', 'student'], ['su2@example.com', 'beginner', 'beginner'], ['su3@example.com', undefined, 'beginner']]) {
    const r = await newBrowser().post('/api/auth/register', { name: 'Sign Up Test', email, password: 'correct-horse-9', ...(sent ? { status: sent } : {}) });
    assert.equal(r.status, 201, email);
    assert.equal(r.body.user.status, saved);
    assert.equal(userRow(email).status, saved);
  }
  for (const bad of ['professional', 'admin', 'Community Leader', '']) {
    const r = await newBrowser().post('/api/auth/register', { name: 'Sign Up Test', email: 'bad@example.com', password: 'correct-horse-9', status: bad });
    assert.equal(r.status, 400, String(bad));
    assert.ok(r.body.error.fields.status);
  }
  assert.equal(userRow('bad@example.com'), undefined);
});

test('bots: a broad IT directory with labelled, unprivileged, non-login bot participants, created repeatably', async () => {
  const demo = await import('../src/db/demoData.js');
  const db = getDb();
  const count = (sql) => db.prepare(sql).get().n;
  const sizes = () => ['users', 'communities', 'memberships', 'posts', 'comments'].map((t) => count(`SELECT COUNT(*) AS n FROM ${t}`));
  const realBefore = count("SELECT COUNT(*) AS n FROM users WHERE is_bot = 0");

  const first = demo.ensureDemoData();
  assert.equal(first.bots, 40);
  assert.equal(first.subcommunities, 72);
  assert.ok(first.communities >= 11); // 12 main areas; Software Development already existed in the sample data
  const afterFirst = sizes();
  assert.deepEqual(Object.values(demo.ensureDemoData()), [0, 0, 0, 0, 0, 0, 0]); // second run creates nothing
  assert.deepEqual(sizes(), afterFirst);
  assert.equal(count("SELECT COUNT(*) AS n FROM users WHERE is_bot = 0"), realBefore + 1); // only the owner administrator is new

  // Every directory community has several discussions with replies from different bots, on topic.
  const dirs = (await import('../src/db/botContent.js')).DIRECTORY;
  const slugify = (x) => x.toLowerCase().replace(/&/g, 'and').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
  for (const d of dirs) {
    for (const e of [d.top, ...d.subs]) {
      const c = db.prepare('SELECT id FROM communities WHERE slug = ?').get(e === d.top ? slugify(e.name) : `${slugify(d.top.name)}-${slugify(e.name)}`);
      assert.ok(c, e.name);
      assert.ok(count(`SELECT COUNT(*) AS n FROM posts WHERE community_id = ${c.id}`) >= 3, `${e.name} has discussions`);
      assert.ok(count(`SELECT COUNT(DISTINCT cm.author_id) AS n FROM comments cm JOIN posts p ON p.id = cm.post_id WHERE p.community_id = ${c.id}`) >= 3, `${e.name} has replies from several bots`);
    }
  }
  assert.ok(count('SELECT COUNT(*) AS n FROM communities WHERE parent_id IS NULL') >= 12);

  // Bots are labelled, cannot sign in and carry no privileges.
  const bots = db.prepare('SELECT * FROM users WHERE is_bot = 1').all();
  assert.ok(bots.length >= 40);
  for (const b of bots) {
    assert.equal(b.role, 'member');
    assert.equal(b.is_organizer, 0);
    assert.ok(/bot/i.test(b.headline) && /bot/i.test(b.bio), b.name);
    assert.equal(db.prepare('SELECT COUNT(*) AS n FROM community_leaders WHERE user_id = ?').get(b.id).n, 0);
  }
  const bot = bots.find((b) => b.email.endsWith('@bots.proconnect.example'));
  assert.equal((await newBrowser().post('/api/auth/login', { email: bot.email, password: 'anything' })).status, 401);
  assert.equal((await newBrowser().post('/api/auth/login', { email: bot.email, password: '!bot-account-cannot-sign-in' })).status, 401);

  // The API tells the interface who is a bot.
  const viewer = await loginAs('sara.kim@example.com');
  const community = db.prepare("SELECT id FROM communities WHERE name = 'Kubernetes'").get().id;
  const list = (await viewer.get(`/api/communities/${community}`)).body;
  assert.ok(JSON.stringify(list).includes('"isBot":true'));
  const profile = (await viewer.get(`/api/users/${bot.id}`)).body.user;
  assert.equal(profile.isBot, true);
  assert.ok(!('email' in profile) && !('role' in profile));
});

test('the owner administrator signs in; cleanup removes the old demo accounts but never real users or their content', async () => {
  const demo = await import('../src/db/demoData.js');
  const db = getDb();
  const owner = await newBrowser();
  const r = await owner.post('/api/auth/login', { email: demo.OWNER_ADMIN.email, password: demo.OWNER_ADMIN.password });
  assert.equal(r.status, 200);
  assert.equal(r.body.user.isAdmin, true);
  assert.equal((await owner.put('/api/admin/users/1/organizer', { granted: false })).status, 200);

  // Re-create two of the old demo accounts plus a real member's reply under one of their posts.
  const hash = userRow('sara.kim@example.com').password_hash.length ? (await import('bcryptjs')).default.hashSync('ProConnect123!', 4) : '';
  const add = db.prepare("INSERT INTO users (name, email, password_hash, profile_completed, role, status) VALUES (?, ?, ?, 1, 'member', 'student')");
  add.run('Old Student', 'student@proconnect.example', hash);
  add.run('Old Leader', 'leader@proconnect.example', hash);
  const legacy = userRow('student@proconnect.example').id;
  const community = db.prepare("SELECT id FROM communities WHERE name = 'Python'").get().id;
  const post = Number(db.prepare('INSERT INTO posts (author_id, community_id, title, content) VALUES (?, ?, ?, ?)').run(legacy, community, 'Old demo discussion', 'Kept for the replies below.').lastInsertRowid);
  db.prepare('INSERT INTO comments (post_id, author_id, content) VALUES (?, ?, ?)').run(post, userRow('sara.kim@example.com').id, 'A real member replied here.');
  const users = () => db.prepare('SELECT COUNT(*) AS n FROM users').get().n;
  const before = users();

  // admin@ still has the demo password and another administrator exists, so it goes too; a changed password keeps it.
  const report = demo.removeLegacyDemoAccounts();
  assert.deepEqual(report.removed.sort(), ['admin@proconnect.example', 'leader@proconnect.example', 'student@proconnect.example']);
  assert.equal(users(), before - 3 + 1); // three accounts removed, one bot-labelled archive account added
  assert.equal(userRow('student@proconnect.example'), undefined);
  assert.ok(userRow('sara.kim@example.com') && userRow('alex.morgan@example.com') && userRow(demo.OWNER_ADMIN.email));
  const kept = db.prepare("SELECT p.title, u.is_bot FROM posts p JOIN users u ON u.id = p.author_id WHERE p.id = ?").get(post);
  assert.deepEqual([kept.title, kept.is_bot], ['Old demo discussion', 1]);
  assert.equal(db.prepare('SELECT COUNT(*) AS n FROM comments WHERE post_id = ?').get(post).n, 1);
  assert.deepEqual(demo.removeLegacyDemoAccounts().removed, []); // repeatable
});

test('a changed-password admin@ account and a sole administrator are never removed', async () => {
  const demo = await import('../src/db/demoData.js');
  const db = getDb();
  const bcryptjs = (await import('bcryptjs')).default;
  db.prepare("INSERT INTO users (name, email, password_hash, profile_completed, role) VALUES ('Real Admin', 'admin@proconnect.example', ?, 1, 'admin')").run(bcryptjs.hashSync('My-own-password-1', 4));
  const r = demo.removeLegacyDemoAccounts();
  assert.deepEqual(r.removed, []);
  assert.ok(r.keptAdmin.includes('password was changed'));
  assert.ok(userRow('admin@proconnect.example'));
});
