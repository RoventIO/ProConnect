// End-to-end acceptance run against a real server process and a throw-away database (PRD section 10 journeys).
// Usage: npm run e2e   (does not touch your own data folder)
import { spawn, spawnSync } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'proconnect-e2e-'));
const PORT = String(4300 + Math.floor(Math.random() * 500));
const env = { ...process.env, PORT, PROCONNECT_DB: path.join(tmp, 'e2e.db'), PROCONNECT_UPLOADS: path.join(tmp, 'uploads') };
const base = `http://127.0.0.1:${PORT}`;
const PASSWORD = 'ProConnect123!';

const seed = spawnSync(process.execPath, ['--disable-warning=ExperimentalWarning', 'src/db/seed.js', '--reset'], { cwd: ROOT, env });
if (seed.status !== 0) { console.error(seed.stderr.toString()); process.exit(1); }

let server;
const start = async () => {
  server = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', 'src/index.js'], { cwd: ROOT, env, stdio: 'ignore' });
  for (let i = 0; i < 60; i++) { try { if ((await fetch(`${base}/api/health`)).ok) return; } catch { /* not up yet */ } await new Promise((r) => setTimeout(r, 100)); }
  throw new Error('The server did not start');
};
const stop = async () => { server.kill(); await new Promise((r) => setTimeout(r, 300)); };

const PNG = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');
const GIF = Buffer.concat([Buffer.from('GIF89a'), Buffer.alloc(40)]);
const WEBM = Buffer.concat([Buffer.from([0x1a, 0x45, 0xdf, 0xa3]), Buffer.alloc(200, 7)]);

/** A tiny browser with its own cookie jar. */
const person = () => {
  let cookie = '';
  const call = async (method, route, body, files) => {
    const headers = cookie ? { Cookie: cookie } : {};
    let payload;
    if (files) { payload = new FormData(); for (const [k, v] of Object.entries(body || {})) payload.append(k, v); for (const [n, b, f, t] of files) payload.append(n, new Blob([b], { type: t }), f); }
    else if (body) { headers['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
    const res = await fetch(base + route, { method, headers, body: payload });
    const set = res.headers.getSetCookie().map((c) => c.split(';')[0]).find((c) => c.startsWith('pc_token='));
    if (set) cookie = set === 'pc_token=' ? '' : set;
    const type = res.headers.get('content-type') || '';
    return { status: res.status, type, body: type.includes('json') ? await res.json() : Buffer.from(await res.arrayBuffer()) };
  };
  return { get: (r) => call('GET', r), post: (r, b, f) => call('POST', r, b, f), put: (r, b) => call('PUT', r, b), del: (r) => call('DELETE', r), cookie: () => cookie };
};

const results = [];
const ok = (name, cond, detail = '') => { results.push(cond); console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}${detail ? `  (${detail})` : ''}`); };
const section = (t) => console.log(`\n${t}`);

try {
  await start();

  section('10.1 Visitor to member');
  const nina = person();
  ok('a visitor cannot read communities, courses, search or discussions (401)', (await Promise.all(['/api/communities', '/api/courses', '/api/search?q=a', '/api/posts/1', '/api/home'].map((r) => nina.get(r)))).every((r) => r.status === 401));
  ok('registration validates input', (await nina.post('/api/auth/register', { name: 'N', email: 'bad', password: '1' })).body.error.code === 'validation_error');
  const reg = await nina.post('/api/auth/register', { name: 'Nina Park', email: 'nina@example.com', password: 'correct-horse-9' });
  ok('a valid registration creates an account without a completed profile', reg.status === 201 && reg.body.user.profileCompleted === false);
  ok('the same email cannot be registered twice', (await person().post('/api/auth/register', { name: 'Other', email: 'NINA@example.com', password: 'correct-horse-9' })).status === 409);
  const locked = await nina.get('/api/communities');
  ok('content stays locked until the minimum profile exists (403)', locked.status === 403 && locked.body.error.code === 'profile_incomplete');
  const prof = await nina.put('/api/profile', { profession: 'Nurse', bio: 'Emergency nurse curious about clinical data.', skills: 'Triage, Patient care', yearsExperience: 5, location: 'Yerevan' });
  ok('the minimum profile unlocks the platform', prof.status === 200 && (await nina.get('/api/communities')).status === 200);

  section('10.2 Find and join a community');
  const found = (await nina.get('/api/search?q=healthcare')).body;
  const health = found.results.communities.items.find((c) => c.name === 'Healthcare Professionals');
  ok('search finds the community from real data', !!health && health.isMember === false);
  ok('the community detail page loads', (await nina.get(`/api/communities/${health.id}`)).status === 200);
  ok('a member cannot create a community', (await nina.post('/api/communities', { name: 'Mine', category: 'X', description: 'Not allowed for members.' })).status === 403);
  ok('joining works and the member list updates', (await nina.post(`/api/communities/${health.id}/join`)).body.community.memberCount === 2);
  const mine = (await nina.get('/api/communities')).body.communities.filter((c) => c.isMember).map((c) => c.name);
  ok('"My Communities" contains it, and only it', mine.join() === 'Healthcare Professionals');

  section('10.3 Share experience (post, image, GIF, voice, emoji, reply, edit, delete)');
  const sub = health.subcommunities[0];
  const post = await nina.post(`/api/communities/${health.id}/posts`, { title: 'Night shift handover tips 🌙', content: 'What works for you? Sharing my checklist 👍' }, [['images', PNG, 'a.png', 'image/png'], ['images', GIF, 'b.gif', 'image/gif'], ['voice', WEBM, 'v.webm', 'audio/webm']]);
  ok('a discussion with emoji, an image, a GIF and a voice message is saved', post.status === 201 && post.body.post.attachments.length === 3);
  const postId = post.body.post.id;
  ok('posting in a community the member has not joined is refused', (await nina.post(`/api/communities/${(await nina.get('/api/communities')).body.communities.find((c) => !c.isMember).id}/posts`, { title: 'Not a member here', content: 'x' })).status === 403);
  ok('empty submissions are rejected with field messages', Object.keys((await nina.post(`/api/communities/${health.id}/posts`, { title: '', content: '' })).body.error.fields).sort().join() === 'content,title');
  const dan = person();
  await dan.post('/api/auth/login', { email: 'daniel.reyes@example.com', password: PASSWORD }); // member of Healthcare Professionals
  const seen = await dan.get(`/api/posts/${postId}`);
  ok('another member reads it with the author, text and attachments', seen.body.post.author.name === 'Nina Park' && seen.body.post.content.includes('👍') && seen.body.post.attachments.length === 3);
  const fileUrl = seen.body.post.attachments[0].url;
  ok('attachments open for members but not for visitors', (await dan.get(fileUrl)).status === 200 && (await person().get(fileUrl)).status === 401);
  ok('another member can reply with text', (await dan.post(`/api/posts/${postId}/comments`, { content: 'Great checklist! 🙏' })).status === 201);
  ok('a reply can carry an image and a voice message', (await dan.post(`/api/posts/${postId}/comments`, {}, [['images', PNG, 'r.png', 'image/png'], ['voice', WEBM, 'r.webm', 'audio/webm']])).status === 201);
  ok('an empty reply is rejected', (await dan.post(`/api/posts/${postId}/comments`, { content: '  ' })).status === 400);
  ok("others cannot edit or delete the author's post", (await dan.put(`/api/posts/${postId}`, { title: 'Hijack', content: 'x' })).status === 403 && (await dan.del(`/api/posts/${postId}`)).status === 403);
  ok('the author can edit (marked edited)', (await nina.put(`/api/posts/${postId}`, { title: 'Night shift handover tips', content: 'Updated text' })).body.post.edited === true);
  const thread = (await nina.get(`/api/posts/${postId}`)).body;
  ok('replies are listed with their attachments', thread.comments.length === 2 && thread.comments[1].attachments.length === 2);
  ok('replies of others cannot be deleted by the post author', (await nina.del(`/api/comments/${thread.comments[0].id}`)).status === 403);

  section('10.4 Courses and webinars');
  const courses = (await nina.get('/api/courses')).body.courses;
  ok('listings show type and a Free or Paid label', courses.length > 0 && courses.every((c) => ['Free', 'Paid'].includes(c.priceLabel) && ['course', 'webinar'].includes(c.type)), `${courses.filter((c) => c.type === 'webinar').length} webinars, ${courses.filter((c) => c.type === 'course').length} courses`);
  ok('the filters narrow the list', (await nina.get('/api/courses?price=paid&type=course')).body.courses.every((c) => !c.isFree && c.type === 'course'));
  const paid = courses.find((c) => !c.isFree);
  const detail = (await nina.get(`/api/courses/${paid.id}`)).body.course;
  ok('a listing opens with description, organizer, duration and an external link', !!(detail.description && detail.organizer && detail.duration && /^https?:/.test(detail.externalUrl)));
  ok('every listing is flagged as sample data (not presented as real)', courses.every((c) => c.isSample === true));

  section('10.5 Update profile');
  ok('the member adds a project with an external link', (await nina.post('/api/profile/items', { kind: 'project', title: 'Handover checklist', url: 'https://example.com/checklist' })).status === 201);
  ok('unsafe links are refused', (await nina.post('/api/profile/items', { kind: 'project', title: 'Bad', url: 'javascript:alert(1)' })).status === 400);
  ok('profile edits are validated', (await nina.put('/api/profile', { profession: 'Nurse', bio: 'short', skills: 'x' })).status === 400);
  const mineProfile = (await nina.get('/api/profile')).body;
  ok('the saved profile is returned, including the project', mineProfile.user.profession === 'Nurse' && mineProfile.items.projects.length === 1 && mineProfile.stats.discussions === 1);
  const others = (await dan.get(`/api/users/${mineProfile.user.id}`)).body;
  ok("other members see the profile but never the email address", others.user.name === 'Nina Park' && !('email' in others.user) && !JSON.stringify(others).includes('nina@example.com'));
  ok('members cannot change each other\'s entries', (await dan.put(`/api/profile/items/${mineProfile.items.projects[0].id}`, { title: 'Hijack' })).status === 404);

  section('Search and filters on the new data');
  const s1 = (await nina.get('/api/search?q=handover')).body.results;
  ok('the new discussion is searchable immediately', s1.posts.items.some((p) => p.id === postId));
  ok('Profession filter finds the new member', (await nina.get('/api/search?profession=Nurse')).body.results.people.items.some((p) => p.name === 'Nina Park'));
  ok('an unmatched search returns empty results for every type', Object.values((await nina.get('/api/search?q=zzzznomatch')).body.results).every((r) => r.total === 0));

  section('Persistence across a server restart');
  await stop(); await start();
  const nina2 = person();
  ok('the account still signs in', (await nina2.post('/api/auth/login', { email: 'nina@example.com', password: 'correct-horse-9' })).status === 200);
  const again = (await nina2.get(`/api/posts/${postId}`)).body;
  ok('the discussion, replies and attachments survived', again.post.title === 'Night shift handover tips' && again.comments.length === 2 && again.post.attachments.length === 3);
  const img = await nina2.get(again.post.attachments[0].url);
  ok('the uploaded image is served from disk byte for byte', img.status === 200 && img.body.length === PNG.length && img.type === 'image/png');
  ok('"My Communities" is unchanged after the restart', (await nina2.get('/api/communities')).body.communities.filter((c) => c.isMember).map((c) => c.name).join() === 'Healthcare Professionals');
  const before = fs.readdirSync(env.PROCONNECT_UPLOADS).length;
  ok('deleting the discussion removes its files from disk (3 on the post and 2 on the reply)', (await nina2.del(`/api/posts/${postId}`)).status === 200 && before === 5 && fs.readdirSync(env.PROCONNECT_UPLOADS).length === 0, `${before} files -> ${fs.readdirSync(env.PROCONNECT_UPLOADS).length}`);

  section('Sign out');
  await nina2.post('/api/auth/logout');
  ok('after signing out, content is locked again', (await nina2.get('/api/communities')).status === 401);
} catch (err) {
  console.error('\nThe run stopped because of an error:', err);
  results.push(false);
} finally {
  server?.kill();
  fs.rmSync(tmp, { recursive: true, force: true });
}
const failed = results.filter((r) => !r).length;
console.log(`\n${failed ? `${failed} of ${results.length} checks FAILED` : `All ${results.length} checks passed`}`);
process.exit(failed ? 1 : 0);
