import { Routes, Route } from 'react-router-dom';
import Sidebar from './components/Sidebar.jsx';
import Header from './components/Header.jsx';
import { RequireAuth, GuestOnly } from './components/Guards.jsx';
import { useLayout } from './context/LayoutContext.jsx';
import Home from './pages/Home.jsx';
import SignIn from './pages/SignIn.jsx';
import SignUp from './pages/SignUp.jsx';
import Onboarding from './pages/Onboarding.jsx';
import Profile from './pages/Profile.jsx';
import Communities from './pages/Communities.jsx';
import CommunityDetail from './pages/CommunityDetail.jsx';
import PostDetail from './pages/PostDetail.jsx';
import Search from './pages/Search.jsx';
import Courses from './pages/Courses.jsx';
import CourseDetail from './pages/CourseDetail.jsx';
import Placeholder from './pages/Placeholder.jsx';

export default function App() {
  const { collapsed } = useLayout();
  return (
    <div className={`app ${collapsed ? 'collapsed' : ''}`}>
      <Sidebar />
      <div className="main">
        <Header />
        <main className="content">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/sign-in" element={<GuestOnly><SignIn /></GuestOnly>} />
            <Route path="/sign-up" element={<GuestOnly><SignUp /></GuestOnly>} />
            <Route path="/onboarding" element={<RequireAuth allowIncomplete><Onboarding /></RequireAuth>} />
            <Route path="/communities" element={<RequireAuth><Communities /></RequireAuth>} />
            <Route path="/communities/:id" element={<RequireAuth><CommunityDetail /></RequireAuth>} />
            <Route path="/courses" element={<RequireAuth><Courses /></RequireAuth>} />
            <Route path="/courses/:id" element={<RequireAuth><CourseDetail /></RequireAuth>} />
            <Route path="/search" element={<RequireAuth><Search /></RequireAuth>} />
            <Route path="/posts/:id" element={<RequireAuth><PostDetail /></RequireAuth>} />
            <Route path="/profile" element={<RequireAuth><Profile self /></RequireAuth>} />
            <Route path="/members/:id" element={<RequireAuth><Profile /></RequireAuth>} />
            <Route path="*" element={<Placeholder title="Page not found" />} />
          </Routes>
        </main>
      </div>
    </div>
  );
}
