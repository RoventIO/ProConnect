import { useEffect, useState, useCallback } from 'react';
import { api } from '../api.js';

/** Loads GET `path` and exposes { data, loading, error, reload }. Reloading keeps the old data visible. */
export function useApi(path) {
  const [state, setState] = useState({ path: null, data: null, error: null });
  const [tick, setTick] = useState(0);

  useEffect(() => {
    let alive = true;
    api(path)
      .then((data) => alive && setState({ path, data, error: null }))
      .catch((error) => alive && setState({ path, data: null, error }));
    return () => {
      alive = false;
    };
  }, [path, tick]);

  const reload = useCallback(() => setTick((t) => t + 1), []);
  const current = state.path === path;
  return { data: current ? state.data : null, error: current ? state.error : null, loading: !current, reload };
}
