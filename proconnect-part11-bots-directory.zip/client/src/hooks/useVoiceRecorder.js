import { useCallback, useEffect, useRef, useState } from 'react';

export const MAX_VOICE_SECONDS = 120;
const CANDIDATES = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus', 'audio/mp4'];

const extensionFor = (type = '') => {
  if (type.includes('webm')) return 'webm';
  if (type.includes('ogg')) return 'ogg';
  if (type.includes('mp4') || type.includes('aac')) return 'm4a';
  if (type.includes('mpeg')) return 'mp3';
  if (type.includes('wav')) return 'wav';
  return 'webm';
};

/** Records a voice message with the browser's microphone: start(), stop(), discard(). */
export function useVoiceRecorder() {
  const [status, setStatus] = useState('idle'); // idle | recording | recorded
  const [seconds, setSeconds] = useState(0);
  const [result, setResult] = useState(null); // { blob, url, duration, extension }
  const [error, setError] = useState('');
  const recorder = useRef(null);
  const stream = useRef(null);
  const chunks = useRef([]);
  const timer = useRef(null);
  const startedAt = useRef(0);
  const urlRef = useRef(null);

  const stopTracks = () => {
    stream.current?.getTracks().forEach((t) => t.stop());
    stream.current = null;
    clearInterval(timer.current);
  };

  const discard = useCallback(() => {
    if (urlRef.current) URL.revokeObjectURL(urlRef.current);
    urlRef.current = null;
    setResult(null);
    setSeconds(0);
    setError('');
    setStatus('idle');
  }, []);

  const stop = useCallback(() => {
    if (recorder.current && recorder.current.state !== 'inactive') recorder.current.stop();
  }, []);

  const start = useCallback(async () => {
    setError('');
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === 'undefined') {
      setError('Your browser cannot record audio. Try Chrome, Edge or Firefox.');
      return;
    }
    try {
      stream.current = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (err) {
      setError(
        err?.name === 'NotAllowedError'
          ? 'Microphone access was blocked. Allow it in the browser address bar and try again.'
          : 'No microphone was found.'
      );
      return;
    }
    const mimeType = CANDIDATES.find((t) => MediaRecorder.isTypeSupported?.(t));
    const rec = new MediaRecorder(stream.current, mimeType ? { mimeType } : undefined);
    chunks.current = [];
    rec.ondataavailable = (e) => e.data.size > 0 && chunks.current.push(e.data);
    rec.onstop = () => {
      const type = rec.mimeType || mimeType || 'audio/webm';
      const blob = new Blob(chunks.current, { type });
      const duration = Math.max(1, Math.round((Date.now() - startedAt.current) / 1000));
      stopTracks();
      if (urlRef.current) URL.revokeObjectURL(urlRef.current);
      urlRef.current = URL.createObjectURL(blob);
      setResult({ blob, url: urlRef.current, duration, extension: extensionFor(type) });
      setStatus('recorded');
    };
    recorder.current = rec;
    startedAt.current = Date.now();
    setSeconds(0);
    setStatus('recording');
    rec.start();
    timer.current = setInterval(() => {
      const s = Math.round((Date.now() - startedAt.current) / 1000);
      setSeconds(s);
      if (s >= MAX_VOICE_SECONDS) stop();
    }, 250);
  }, [stop]);

  useEffect(
    () => () => {
      if (recorder.current && recorder.current.state !== 'inactive') {
        recorder.current.onstop = null;
        recorder.current.stop();
      }
      stopTracks();
      if (urlRef.current) URL.revokeObjectURL(urlRef.current);
    },
    []
  );

  return { status, seconds, result, error, start, stop, discard };
}

export const formatClock = (total) => `${Math.floor(total / 60)}:${String(total % 60).padStart(2, '0')}`;
