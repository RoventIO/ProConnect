import { createContext, useContext, useEffect, useState } from 'react';

const LayoutContext = createContext(null);
const KEY = 'pc-sidebar-collapsed';

export function LayoutProvider({ children }) {
  const [collapsed, setCollapsed] = useState(() => {
    try {
      return localStorage.getItem(KEY) === '1';
    } catch {
      return false;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(KEY, collapsed ? '1' : '0');
    } catch {
      /* ignore */
    }
  }, [collapsed]);

  const toggleSidebar = () => setCollapsed((c) => !c);
  return (
    <LayoutContext.Provider value={{ collapsed, toggleSidebar }}>{children}</LayoutContext.Provider>
  );
}

export const useLayout = () => useContext(LayoutContext);
