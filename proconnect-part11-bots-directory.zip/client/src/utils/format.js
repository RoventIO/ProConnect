const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];

export function initialsOf(name = '') {
  return name.split(' ').filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join('');
}

export function timeAgo(iso) {
  if (!iso) return '';
  const diff = Date.now() - new Date(iso).getTime();
  const h = Math.floor(diff / 3600000);
  if (h < 1) return 'Just now';
  if (h < 24) return `${h} h ago`;
  const d = Math.floor(h / 24);
  if (d === 1) return 'Yesterday';
  if (d < 30) return `${d} days ago`;
  const m = new Date(iso);
  return `${MONTHS[m.getMonth()]} ${m.getFullYear()}`;
}

export function activityLabel(iso) {
  if (!iso) return 'No activity yet';
  const days = Math.floor((Date.now() - new Date(iso).getTime()) / 86400000);
  if (days < 1) return 'Active today';
  if (days === 1) return 'Active yesterday';
  return `Active ${days} days ago`;
}

export function shortDate(iso) {
  const d = new Date(iso);
  return `${MONTHS[d.getMonth()]} ${d.getDate()}`;
}

export function timeOfDay(iso) {
  const d = new Date(iso);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}

export function monthYear(iso) {
  const d = new Date(iso);
  return `${MONTHS[d.getMonth()]} ${d.getFullYear()}`;
}

/** Short chip for a course card: the start date, or the length ("6 wk") for self-paced courses. */
export function courseBadge(c) {
  if (c.startsAt) return shortDate(c.startsAt);
  const m = /(\d+)\s*weeks?/i.exec(c.duration || '');
  return m ? `${m[1]} wk` : c.type === 'course' ? 'Course' : 'Live';
}

export function courseNote(c) {
  const parts = [];
  if (c.startsAt) parts.push(timeOfDay(c.startsAt));
  if (c.duration) parts.push(c.duration);
  return parts.join(' · ');
}

const DAYS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
export function longDate(iso) {
  const d = new Date(iso);
  return `${DAYS[d.getDay()]}, ${MONTHS[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
}

/** Only real web links may be opened from listings. */
export const isWebLink = (url) => typeof url === 'string' && /^https?:\/\//i.test(url);
