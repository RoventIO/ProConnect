export const STATUS_LABELS = { student: 'Student', beginner: 'Beginner', professional: 'Professional' };

/** Student / Beginner choice. Professional is never offered here: only an Admin can grant it. */
export default function StatusPicker({ value, onChange, disabled = false, id = 'status' }) {
  return (
    <div className="field">
      <span className="field-label" id={`${id}-label`} style={{ fontSize: 12, fontWeight: 600 }}>I am a</span>
      <div className="chips" style={{ marginTop: 6 }} role="group" aria-labelledby={`${id}-label`}>
        {['student', 'beginner'].map((s) => (
          <button key={s} type="button" className={`chip-btn ${value === s ? 'active' : ''}`} aria-pressed={value === s} disabled={disabled} onClick={() => onChange(s)}>
            {STATUS_LABELS[s]}
          </button>
        ))}
      </div>
    </div>
  );
}
