import { useEffect, useRef, useState } from 'react';
import { Smile, ImagePlus, Mic, Square, X, Send } from 'lucide-react';
import EmojiPicker from './EmojiPicker.jsx';
import AudioPlayer from './AudioPlayer.jsx';
import { useVoiceRecorder, formatClock, MAX_VOICE_SECONDS } from '../hooks/useVoiceRecorder.js';

const MAX_IMAGES = 4;
const MAX_BYTES = 5 * 1024 * 1024;
const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
let imageCounter = 0; // stable keys for the preview list

/**
 * Writing box for discussions and replies: text, emoji, up to 4 images or GIFs, and a voice message.
 * `onSubmit(FormData)` should throw an ApiError on failure; its `fields` are shown next to the inputs.
 */
export default function Composer({ withTitle = false, placeholder, submitLabel = 'Post', onSubmit, onCancel, autoFocus = false }) {
  const [title, setTitle] = useState('');
  const [text, setText] = useState('');
  const [images, setImages] = useState([]); // [{ file, url }]
  const [pickerOpen, setPickerOpen] = useState(false);
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);
  const textRef = useRef(null);
  const fileInput = useRef(null);
  const voice = useVoiceRecorder();

  useEffect(() => () => images.forEach((i) => URL.revokeObjectURL(i.url)), []); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (autoFocus) textRef.current?.focus();
  }, [autoFocus]);

  const insertEmoji = (emoji) => {
    const el = textRef.current;
    const start = el?.selectionStart ?? text.length;
    const end = el?.selectionEnd ?? text.length;
    const next = text.slice(0, start) + emoji + text.slice(end);
    setText(next);
    requestAnimationFrame(() => {
      el?.focus();
      el?.setSelectionRange(start + emoji.length, start + emoji.length);
    });
  };

  const addImages = (e) => {
    const picked = [...(e.target.files || [])];
    e.target.value = '';
    const next = [...images];
    let message = '';
    for (const file of picked) {
      if (!IMAGE_TYPES.includes(file.type)) message = 'Choose JPG, PNG, WebP or GIF images.';
      else if (file.size > MAX_BYTES) message = 'Each image can be up to 5 MB.';
      else if (next.length >= MAX_IMAGES) message = `You can attach up to ${MAX_IMAGES} images.`;
      else next.push({ id: ++imageCounter, file, url: URL.createObjectURL(file) });
    }
    setImages(next);
    setErrors((er) => ({ ...er, attachments: message }));
  };

  const removeImage = (i) => {
    URL.revokeObjectURL(images[i].url);
    setImages(images.filter((_, idx) => idx !== i));
  };

  const hasAttachments = images.length > 0 || voice.status === 'recorded';

  const submit = async (e) => {
    e?.preventDefault();
    const next = {};
    if (withTitle && title.trim().length < 3) next.title = 'Give your discussion a title (at least 3 characters).';
    if (!text.trim() && !hasAttachments) next.content = withTitle ? 'Write something or attach an image or voice message.' : 'Write a reply or attach an image or voice message.';
    setErrors(next);
    setFormError('');
    if (Object.keys(next).length) return;
    if (voice.status === 'recording') voice.stop();

    const body = new FormData();
    if (withTitle) body.append('title', title.trim());
    body.append('content', text.trim());
    images.forEach((i) => body.append('images', i.file));
    if (voice.result) {
      body.append('voice', voice.result.blob, `voice.${voice.result.extension}`);
      body.append('voiceDuration', String(voice.result.duration));
    }

    setBusy(true);
    try {
      await onSubmit(body);
      images.forEach((i) => URL.revokeObjectURL(i.url));
      setTitle('');
      setText('');
      setImages([]);
      voice.discard();
    } catch (err) {
      if (err.fields) setErrors(err.fields);
      else setFormError(err.message);
    } finally {
      setBusy(false);
    }
  };

  const onKeyDown = (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') submit(e);
  };

  return (
    <form className="composer" onSubmit={submit} noValidate>
      {withTitle && (
        <div className="field">
          <label htmlFor="composer-title" className="sr-only">Title</label>
          <input id="composer-title" className="composer-title" placeholder="Title of your discussion" value={title} maxLength={150} onChange={(e) => setTitle(e.target.value)} aria-invalid={errors.title ? 'true' : 'false'} />
          {errors.title && <p className="field-error" role="alert">{errors.title}</p>}
        </div>
      )}
      <div className="field">
        <label htmlFor="composer-text" className="sr-only">Message</label>
        <textarea id="composer-text" ref={textRef} rows={withTitle ? 5 : 3} placeholder={placeholder} value={text} onChange={(e) => setText(e.target.value)} onKeyDown={onKeyDown} aria-invalid={errors.content ? 'true' : 'false'} />
        {errors.content && <p className="field-error" role="alert">{errors.content}</p>}
      </div>

      {images.length > 0 && (
        <ul className="attach-previews" aria-label="Selected images">
          {images.map((img, i) => (
            <li key={img.id}>
              <img src={img.url} alt={`Selected image ${i + 1}`} />
              <button type="button" className="attach-remove" aria-label={`Remove image ${i + 1}`} onClick={() => removeImage(i)}>
                <X size={12} />
              </button>
              {img.file.type === 'image/gif' && <span className="gif-badge">GIF</span>}
            </li>
          ))}
        </ul>
      )}

      {voice.status === 'recording' && (
        <div className="voice-recording" role="status">
          <span className="rec-dot" aria-hidden="true" /> Recording {formatClock(voice.seconds)} / {formatClock(MAX_VOICE_SECONDS)}
          <button type="button" className="btn btn-danger btn-sm" onClick={voice.stop}>
            <Square size={12} aria-hidden="true" /> Stop
          </button>
        </div>
      )}
      {voice.status === 'recorded' && voice.result && (
        <div className="voice-preview">
          <AudioPlayer src={voice.result.url} durationHint={voice.result.duration} label="Voice message preview" />
          <button type="button" className="icon-btn" aria-label="Discard voice message" onClick={voice.discard}>
            <X size={14} />
          </button>
        </div>
      )}
      {(voice.error || errors.attachments || errors.voice || errors.images) && (
        <p className="field-error" role="alert">{voice.error || errors.attachments || errors.voice || errors.images}</p>
      )}
      {formError && <p className="form-error" role="alert">{formError}</p>}

      <div className="composer-bar">
        <div className="composer-tools">
          <button type="button" className="icon-btn" data-emoji-toggle aria-label="Add emoji" aria-expanded={pickerOpen} onClick={() => setPickerOpen((o) => !o)}>
            <Smile size={16} />
          </button>
          <input ref={fileInput} type="file" hidden multiple accept="image/jpeg,image/png,image/webp,image/gif" onChange={addImages} aria-label="Choose images or GIFs" />
          <button type="button" className="icon-btn" aria-label="Attach images or GIFs" title="Images and GIFs (up to 4, 5 MB each)" onClick={() => fileInput.current.click()}>
            <ImagePlus size={16} />
          </button>
          <button type="button" className={`icon-btn ${voice.status === 'recording' ? 'is-recording' : ''}`} aria-label={voice.status === 'recording' ? 'Stop recording' : 'Record a voice message'} title="Voice message (up to 2 minutes)" disabled={voice.status === 'recorded'} onClick={voice.status === 'recording' ? voice.stop : voice.start}>
            <Mic size={16} />
          </button>
          {pickerOpen && <EmojiPicker onPick={insertEmoji} onClose={() => setPickerOpen(false)} />}
        </div>
        <div className="form-actions">
          {onCancel && <button type="button" className="btn btn-ghost btn-sm" onClick={onCancel}>Cancel</button>}
          <button type="submit" className="btn btn-primary btn-sm" disabled={busy}>
            <Send size={14} aria-hidden="true" /> {busy ? 'Sending…' : submitLabel}
          </button>
        </div>
      </div>
    </form>
  );
}
