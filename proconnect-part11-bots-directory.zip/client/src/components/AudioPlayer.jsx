import { useEffect, useRef, useState } from 'react';
import { Play, Pause } from 'lucide-react';
import { formatClock } from '../hooks/useVoiceRecorder.js';

/**
 * Voice message player in the site's own style (the browser's built-in player cannot be themed).
 * `durationHint` (seconds) is used when the file does not report a usable length, which is common for
 * recordings made in the browser.
 */
export default function AudioPlayer({ src, durationHint = 0, label = 'Voice message' }) {
  const audio = useRef(null);
  const [playing, setPlaying] = useState(false);
  const [time, setTime] = useState(0);
  const [reported, setReported] = useState(0);
  const [failed, setFailed] = useState(false);

  const total = reported > 0 ? reported : durationHint;
  const fraction = total > 0 ? Math.min(time / total, 1) : 0;

  useEffect(() => {
    setPlaying(false);
    setTime(0);
    setReported(0);
    setFailed(false);
  }, [src]);

  const onMeta = () => {
    const d = audio.current?.duration;
    if (Number.isFinite(d) && d > 0) setReported(d);
  };

  const toggle = async () => {
    const el = audio.current;
    if (!el) return;
    if (playing) {
      el.pause();
      return;
    }
    try {
      await el.play();
    } catch {
      setFailed(true);
    }
  };

  const seek = (e) => {
    const el = audio.current;
    if (!el || !(total > 0)) return;
    const t = (Number(e.target.value) / 1000) * total;
    el.currentTime = t;
    setTime(t);
  };

  return (
    <div className={`audio-player ${playing ? 'is-playing' : ''} ${failed ? 'has-error' : ''}`} role="group" aria-label={label}>
      <audio
        ref={audio}
        src={src}
        preload="metadata"
        onLoadedMetadata={onMeta}
        onDurationChange={onMeta}
        onTimeUpdate={(e) => setTime(e.currentTarget.currentTime)}
        onPlay={() => setPlaying(true)}
        onPause={() => setPlaying(false)}
        onEnded={() => {
          setPlaying(false);
          setTime(0);
        }}
        onError={() => setFailed(true)}
      />
      <button type="button" className="audio-play" aria-label={playing ? `Pause ${label}` : `Play ${label}`} onClick={toggle}>
        {playing ? <Pause size={16} aria-hidden="true" /> : <Play size={16} aria-hidden="true" />}
      </button>
      <input
        type="range"
        className="audio-seek"
        min="0"
        max="1000"
        step="1"
        value={Math.round(fraction * 1000)}
        onChange={seek}
        aria-label="Seek"
        aria-valuetext={`${formatClock(Math.floor(time))} of ${formatClock(Math.round(total))}`}
        style={{ '--p': `${fraction * 100}%` }}
        disabled={!(total > 0)}
      />
      <span className="audio-time">
        {failed ? 'Cannot play' : `${formatClock(Math.floor(time))} / ${formatClock(Math.round(total))}`}
      </span>
    </div>
  );
}
