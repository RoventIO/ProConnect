import { NavLink } from 'react-router-dom';
import {
  Home,
  Users,
  Newspaper,
  GraduationCap,
  Briefcase,
  User,
  Share2,
  PanelLeftClose,
  PanelLeftOpen,
} from 'lucide-react';
import { useLayout } from '../context/LayoutContext.jsx';
import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { UserAvatar } from './Ui.jsx';

// Required order (PRD FR-08). Only News and Jobs are "Soon".
const NAV = [
  { label: 'Home', to: '/', icon: Home, end: true },
  { label: 'Communities', to: '/communities', icon: Users },
  { label: 'News', icon: Newspaper, soon: true },
  { label: 'Courses & Webinars', to: '/courses', icon: GraduationCap },
  { label: 'Jobs', icon: Briefcase, soon: true },
  { label: 'My Profile', to: '/profile', icon: User, authOnly: true },
];

export default function Sidebar() {
  const { collapsed, toggleSidebar } = useLayout();
  const { user } = useAuth();
  const toggleLabel = collapsed ? 'Expand sidebar' : 'Collapse sidebar';
  const ToggleIcon = collapsed ? PanelLeftOpen : PanelLeftClose;

  return (
    <aside className="sidebar" aria-label="Main navigation">
      <div className="sidebar-top">
        <div className="brand">
          <span className="brand-mark" aria-hidden="true">
            <Share2 size={18} />
          </span>
          <span className="brand-text">
            <strong>ProConnect</strong>
            <small>Professional Community</small>
          </span>
        </div>
        <button
          type="button"
          className="icon-btn tip"
          data-tip={toggleLabel}
          aria-label={toggleLabel}
          onClick={toggleSidebar}
        >
          <ToggleIcon size={18} />
        </button>
      </div>

      <nav className="nav">
        {NAV.filter((item) => !item.authOnly || user).map((item) => {
          const Icon = item.icon;
          const tipText = item.soon ? `${item.label} · Soon` : item.label;
          const tipProps = collapsed ? { 'data-tip': tipText } : {};

          if (item.soon) {
            return (
              <button
                key={item.label}
                type="button"
                className={`nav-item nav-soon ${collapsed ? 'tip' : ''}`}
                aria-disabled="true"
                aria-label={`${item.label}, coming soon`}
                {...tipProps}
              >
                <span className="nav-icon"><Icon size={18} aria-hidden="true" /></span>
                <span className="nav-label">{item.label}</span>
                <span className="badge-soon nav-badge">Soon</span>
                <span className="soon-dot" aria-hidden="true" />
              </button>
            );
          }

          return (
            <NavLink
              key={item.label}
              to={item.to}
              end={item.end}
              className={({ isActive }) => `nav-item ${isActive ? 'active' : ''} ${collapsed ? 'tip' : ''}`}
              aria-label={item.label}
              {...tipProps}
            >
              <span className="nav-icon"><Icon size={18} aria-hidden="true" /></span>
              <span className="nav-label">{item.label}</span>
            </NavLink>
          );
        })}
      </nav>

      <div className="sidebar-bottom">
        {user ? (
          <div className="user-chip">
            <UserAvatar user={user} size={34} />
            <div>
              <strong>{user.name}</strong>
              <small>{user.isAdmin ? 'Administrator' : user.profession || 'New member'}</small>
            </div>
          </div>
        ) : (
          <div className="side-card">
            <strong>Build your professional profile</strong>
            <p>Join communities, ask questions and learn from experienced specialists.</p>
            <Link to="/sign-up" className="btn btn-primary btn-sm">
              Join ProConnect
            </Link>
          </div>
        )}
      </div>
    </aside>
  );
}
