import { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Link } from 'react-router-dom';
import { AlertTriangle, LogOut, X } from 'lucide-react';

const FeedbackContext = createContext(null);

/**
 * In-site replacements for the browser's confirm() and alert():
 *   const { confirm, notify } = useFeedback();
 *   if (await confirm({ title, message, confirmLabel, tone: 'danger' })) { ... }
 *   notify('You joined X.', { action: { label: 'View', to: '/communities/1' } });
 */
export function FeedbackProvider({ children }) {
  const [dialog, setDialog] = useState(null);
  const [toasts, setToasts] = useState([]);

  const confirm = useCallback((options) => new Promise((resolve) => setDialog({ options, resolve })), []);
  const closeDialog = useCallback((result) => {
    setDialog((d) => {
      d?.resolve(result);
      return null;
    });
  }, []);

  const dismiss = useCallback((id) => setToasts((t) => t.filter((x) => x.id !== id)), []);
  const notify = useCallback(
    (message, { action } = {}) => {
      const id = `${Date.now()}-${Math.random()}`;
      setToasts((t) => [...t, { id, message, action }]);
      setTimeout(() => dismiss(id), 6000);
    },
    [dismiss]
  );

  return (
    <FeedbackContext.Provider value={{ confirm, notify }}>
      {children}
      {dialog && <ConfirmDialog options={dialog.options} onClose={closeDialog} />}
      {createPortal(
        <div className="toast-stack" role="status" aria-live="polite">
          {toasts.map((t) => (
            <div className="toast" key={t.id}>
              <span>{t.message}</span>
              {t.action && (
                <Link to={t.action.to} className="toast-action" onClick={() => dismiss(t.id)}>
                  {t.action.label}
                </Link>
              )}
              <button type="button" className="toast-close" aria-label="Dismiss" onClick={() => dismiss(t.id)}>
                <X size={14} />
              </button>
            </div>
          ))}
        </div>,
        document.body
      )}
    </FeedbackContext.Provider>
  );
}

export const useFeedback = () => useContext(FeedbackContext);

function ConfirmDialog({ options, onClose }) {
  const { title, message, confirmLabel = 'Confirm', cancelLabel = 'Cancel', tone = 'default', icon } = options;
  const panel = useRef(null);
  const cancelBtn = useRef(null);

  useEffect(() => {
    const previouslyFocused = document.activeElement;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    cancelBtn.current?.focus(); // the safe choice is focused first

    const onKey = (e) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        onClose(false);
      } else if (e.key === 'Tab') {
        // keep keyboard focus inside the dialog
        const items = panel.current.querySelectorAll('button');
        const first = items[0];
        const last = items[items.length - 1];
        if (e.shiftKey && document.activeElement === first) {
          e.preventDefault();
          last.focus();
        } else if (!e.shiftKey && document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('keydown', onKey);
      document.body.style.overflow = previousOverflow;
      previouslyFocused?.focus?.();
    };
  }, [onClose]);

  const Icon = icon === 'leave' ? LogOut : AlertTriangle;

  return createPortal(
    <div className="modal-overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose(false)}>
      <div className="modal" ref={panel} role="dialog" aria-modal="true" aria-labelledby="modal-title" aria-describedby="modal-message">
        <span className={`modal-icon ${tone === 'danger' ? 'modal-icon-danger' : ''}`} aria-hidden="true">
          <Icon size={22} />
        </span>
        <h3 id="modal-title" className="serif">{title}</h3>
        <p id="modal-message" className="muted">{message}</p>
        <div className="modal-actions">
          <button type="button" ref={cancelBtn} className="btn btn-ghost" onClick={() => onClose(false)}>
            {cancelLabel}
          </button>
          <button type="button" className={`btn ${tone === 'danger' ? 'btn-danger' : 'btn-dark'}`} onClick={() => onClose(true)}>
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>,
    document.body
  );
}
