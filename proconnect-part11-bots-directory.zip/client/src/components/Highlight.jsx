/** Shows `text` with every case-insensitive occurrence of `query` marked. Plain React nodes, no raw HTML. */
export default function Highlight({ text, query }) {
  const q = (query || '').trim().toLowerCase();
  if (!text || !q) return <>{text}</>;
  const lower = text.toLowerCase();
  const parts = [];
  let i = 0;
  for (;;) {
    const j = lower.indexOf(q, i);
    if (j === -1) break;
    if (j > i) parts.push(text.slice(i, j));
    parts.push(<mark key={j}>{text.slice(j, j + q.length)}</mark>);
    i = j + q.length;
  }
  parts.push(text.slice(i));
  return <>{parts}</>;
}
