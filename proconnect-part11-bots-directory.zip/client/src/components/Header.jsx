import { useEffect, useRef, useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Moon, Sun, Search, User, LogOut } from 'lucide-react';
import { useTheme } from '../context/ThemeContext.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { UserAvatar } from './Ui.jsx';

const TITLES = {
  '/': ['Home', 'Welcome to ProConnect'],
  '/communities': ['Communities', 'Find communities in your profession'],
  '/courses': ['Courses & Webinars', 'Learn from experienced professionals'],
  '/profile': ['My Profile', 'Manage how professionals see you'],
  '/sign-in': ['Sign In', 'Access your ProConnect account'],
  '/sign-up': ['Sign Up', 'Join the professional community'],
  '/onboarding': ['Profile setup', 'Tell professionals who you are'],
  '/search': ['Search', 'Professions, communities, discussions and people'],
};

export default function Header() {
  const { pathname } = useLocation();
  const navigate = useNavigate();
  const { theme, toggleTheme } = useTheme();
  const { user, loading, logout } = useAuth();
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef(null);
  const location = useLocation();
  const [searchText, setSearchText] = useState('');

  // Keep the box in step with the address when the search page is open (back/forward, suggestions).
  useEffect(() => {
    if (location.pathname === '/search') setSearchText(new URLSearchParams(location.search).get('q') || '');
  }, [location.pathname, location.search]);

  const onSearch = (e) => {
    e.preventDefault();
    const next = new URLSearchParams(location.pathname === '/search' ? location.search : '');
    const text = searchText.trim();
    if (text) next.set('q', text);
    else next.delete('q');
    navigate(`/search${next.toString() ? `?${next}` : ''}`);
  };

  const [title, subtitle] = pathname.startsWith('/members/')
    ? ['Member profile', 'Professional background and activity']
    : pathname.startsWith('/courses/')
      ? ['Course or webinar', 'Details and registration']
    : pathname.startsWith('/posts/')
      ? ['Discussion', 'Replies and attachments']
    : pathname.startsWith('/communities/')
      ? ['Community', 'Members and discussions']
      : TITLES[pathname] || ['ProConnect', ''];
  const subtitleText = pathname === '/' && user?.profileCompleted ? `Welcome back, ${user.name.split(' ')[0]}` : subtitle;
  const themeLabel = theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode';

  useEffect(() => {
    const onClick = (e) => {
      if (menuRef.current && !menuRef.current.contains(e.target)) setMenuOpen(false);
    };
    const onKey = (e) => e.key === 'Escape' && setMenuOpen(false);
    document.addEventListener('mousedown', onClick);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onClick);
      document.removeEventListener('keydown', onKey);
    };
  }, []);

  return (
    <header className="header">
      <div className="header-title">
        <h1>{title}</h1>
        <p>{subtitleText}</p>
      </div>

      <div className="header-actions">
        <form className="search" role="search" onSubmit={onSearch}>
          <Search size={16} aria-hidden="true" />
          <input
            type="search"
            placeholder="Search professions, communities, topics, or people..."
            aria-label="Search professions, communities, topics, or people"
            value={searchText}
            onChange={(e) => setSearchText(e.target.value)}
            maxLength={100}
          />
        </form>

        <button
          type="button"
          className="icon-btn theme-btn"
          onClick={toggleTheme}
          aria-label={themeLabel}
          title={themeLabel}
        >
          {theme === 'dark' ? <Moon size={16} /> : <Sun size={16} />}
        </button>

        {loading ? null : user ? (
          <div className="avatar-menu" ref={menuRef}>
            <button
              type="button"
              className="avatar-btn"
              aria-haspopup="menu"
              aria-expanded={menuOpen}
              aria-label="Account menu"
              onClick={() => setMenuOpen((o) => !o)}
            >
              <UserAvatar user={user} size={42} />
            </button>
            {menuOpen && (
              <div className="dropdown" role="menu">
                <div className="dropdown-head">
                  <UserAvatar user={user} size={42} />
                  <div>
                    <strong>{user.name}</strong>
                    <small>{user.email}</small>
                  </div>
                </div>
                <Link role="menuitem" to="/profile" className="dropdown-item" onClick={() => setMenuOpen(false)}>
                  <User size={16} /> My Profile
                </Link>
                <button
                  role="menuitem"
                  type="button"
                  className="dropdown-item"
                  onClick={async () => {
                    setMenuOpen(false);
                    await logout();
                    navigate('/');
                  }}
                >
                  <LogOut size={16} /> Log Out
                </button>
              </div>
            )}
          </div>
        ) : (
          <>
            <Link to="/sign-in" className="btn btn-ghost">
              Sign In
            </Link>
            <Link to="/sign-up" className="btn btn-dark">
              Sign Up
            </Link>
          </>
        )}
      </div>
    </header>
  );
}
