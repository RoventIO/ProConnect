import { useEffect, useRef, useState } from 'react';

const CATEGORIES = [
  { id: 'faces', label: '😀', name: 'Faces', items: '😀 😃 😄 😁 😆 😅 😂 🤣 🙂 😉 😊 😇 🥰 😍 🤩 😘 😋 😎 🤓 🤔 🫡 🤗 😐 🙄 😏 😬 😴 🤤 😢 😭 😤 😡 🥳 🤯 😱 😳 🥺 🤝'.split(' ') },
  { id: 'hands', label: '👍', name: 'Gestures', items: '👍 👎 👏 🙌 🙏 💪 👋 ✌️ 🤞 👌 🤌 ☝️ 👀 🧠 ❤️ 🧡 💛 💚 💙 💜 🖤 💔 🔥 ✨ ⭐ 💯 🎉 🎊 🏆'.split(' ') },
  { id: 'work', label: '💼', name: 'Work', items: '💼 📈 📉 📊 💡 🎯 🚀 ✅ ❌ ⚠️ ❓ ❗ 📌 📎 📝 📚 🎓 💻 🖥️ 🛠️ ⚙️ 🔒 🔑 🗓️ ⏰ 📷 🎧 🎤 💬 📢 🔔'.split(' ') },
  { id: 'life', label: '☕', name: 'Life', items: '☕ 🍕 🍎 🌱 🌍 ☀️ 🌙 ⚡ 🌈 🎵 ⚽ 🏃 ✈️ 🚗 🏠 🐶 🐱 🦊 🐼 🎁 🎂 🥂 🍀 🔭 🧪 🩺 ⚖️ 🎨 🏗️ 🌳'.split(' ') },
];

/** Small emoji panel. `onPick(emoji)` is called for each choice; the panel stays open for several picks. */
export default function EmojiPicker({ onPick, onClose }) {
  const [active, setActive] = useState('faces');
  const ref = useRef(null);
  const current = CATEGORIES.find((c) => c.id === active);

  useEffect(() => {
    const onDown = (e) => {
      if (ref.current && !ref.current.contains(e.target) && !e.target.closest?.('[data-emoji-toggle]')) onClose();
    };
    const onKey = (e) => e.key === 'Escape' && onClose();
    document.addEventListener('mousedown', onDown);
    document.addEventListener('keydown', onKey);
    return () => {
      document.removeEventListener('mousedown', onDown);
      document.removeEventListener('keydown', onKey);
    };
  }, [onClose]);

  return (
    <div className="emoji-picker" ref={ref} role="dialog" aria-label="Choose an emoji">
      <div className="emoji-tabs" role="tablist">
        {CATEGORIES.map((c) => (
          <button key={c.id} type="button" role="tab" aria-selected={active === c.id} aria-label={c.name} className={active === c.id ? 'active' : ''} onClick={() => setActive(c.id)}>
            {c.label}
          </button>
        ))}
      </div>
      <div className="emoji-grid">
        {current.items.map((e) => (
          <button key={e} type="button" aria-label={`Insert ${e}`} onClick={() => onPick(e)}>
            {e}
          </button>
        ))}
      </div>
    </div>
  );
}
