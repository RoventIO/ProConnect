import { Mic } from 'lucide-react';
import AudioPlayer from './AudioPlayer.jsx';

/** Images, GIFs (animated automatically) and voice messages attached to a post or reply. */
export default function Attachments({ items = [] }) {
  const images = items.filter((a) => a.kind === 'image');
  const voices = items.filter((a) => a.kind === 'audio');
  if (!images.length && !voices.length) return null;
  return (
    <div className="attachments">
      {images.length > 0 && (
        <div className={`media-grid media-${Math.min(images.length, 4)}`}>
          {images.map((a) => (
            <a key={a.id} href={a.url} target="_blank" rel="noopener noreferrer" title="Open full size">
              <img src={a.url} alt="Attached to this message" loading="lazy" />
            </a>
          ))}
        </div>
      )}
      {voices.map((a) => (
        <div className="voice-msg" key={a.id}>
          <span className="voice-icon" aria-hidden="true"><Mic size={14} /></span>
          <AudioPlayer src={a.url} durationHint={a.durationSec || 0} />
        </div>
      ))}
    </div>
  );
}
