import { Navigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

function Loading() {
  return (
    <div className="card page-loading" role="status">
      Loading…
    </div>
  );
}

/**
 * Protects internal pages. Visitors are sent to Sign In with an explanation;
 * members without the minimum professional profile are sent to onboarding (PRD FR-01).
 */
export function RequireAuth({ children, allowIncomplete = false }) {
  const { user, loading } = useAuth();
  const location = useLocation();
  if (loading) return <Loading />;
  if (!user) return <Navigate to="/sign-in" replace state={{ from: location.pathname, reason: 'protected' }} />;
  if (!user.profileCompleted && !allowIncomplete) return <Navigate to="/onboarding" replace />;
  return children;
}

/** Sign In / Sign Up are only for visitors. */
export function GuestOnly({ children }) {
  const { user, loading } = useAuth();
  if (loading) return <Loading />;
  if (user) return <Navigate to={user.profileCompleted ? '/' : '/onboarding'} replace />;
  return children;
}
