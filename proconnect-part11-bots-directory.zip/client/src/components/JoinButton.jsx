import { useState } from 'react';
import { Check } from 'lucide-react';
import { api } from '../api.js';
import { useFeedback } from './Feedback.jsx';

/**
 * Join / Joined toggle for a main community. `onChange` receives { id, isMember, memberCount }.
 * Joining shows a confirmation message; leaving asks first in a styled dialog.
 */
export default function JoinButton({ community, onChange, size = 'sm', linkInMessage = true }) {
  const { confirm, notify } = useFeedback();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');

  const toggle = async () => {
    const leaving = community.isMember;
    if (leaving) {
      const ok = await confirm({
        title: `Leave ${community.name}?`,
        message: 'It will be removed from your joined communities. You can join again whenever you like.',
        confirmLabel: 'Leave community',
        cancelLabel: 'Stay',
        icon: 'leave',
      });
      if (!ok) return;
    }
    setBusy(true);
    setError('');
    try {
      const d = await api(`/communities/${community.id}/join`, { method: leaving ? 'DELETE' : 'POST' });
      onChange(d.community);
      notify(
        leaving ? `You left ${community.name}.` : `You joined ${community.name}. It now appears in your profile.`,
        !leaving && linkInMessage ? { action: { label: 'View community', to: `/communities/${community.id}` } } : undefined
      );
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="join">
      <button
        type="button"
        className={`btn ${size === 'sm' ? 'btn-sm' : ''} ${community.isMember ? 'btn-joined' : 'btn-primary'}`}
        aria-pressed={community.isMember}
        title={community.isMember ? 'Click to leave this community' : 'Join this community'}
        disabled={busy}
        onClick={toggle}
      >
        {busy ? '…' : community.isMember ? (<><Check size={14} aria-hidden="true" /> Joined</>) : 'Join Community'}
      </button>
      {error && <p className="field-error" role="alert">{error}</p>}
    </div>
  );
}
