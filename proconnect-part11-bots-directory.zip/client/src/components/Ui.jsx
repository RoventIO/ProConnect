export function Avatar({ text, src, size = 42 }) {
  return (
    <span className="avatar avatar-soft" style={{ width: size, height: size }} aria-hidden="true">
      {src ? <img src={src} alt="" /> : text}
    </span>
  );
}

/** Circle with the member's photo, or their initials when no photo is set. */
export function UserAvatar({ user, size = 42, className = '' }) {
  const initials = (user?.name || '').split(' ').filter(Boolean).slice(0, 2).map((p) => p[0].toUpperCase()).join('');
  return (
    <span className={`avatar ${className}`} style={{ width: size, height: size }} aria-hidden="true">
      {user?.avatarUrl ? <img src={user.avatarUrl} alt="" /> : initials}
    </span>
  );
}

export function PriceBadge({ price }) {
  return <span className={`pill ${price === 'Free' ? 'pill-free' : 'pill-paid'}`}>{price}</span>;
}

export function SampleTag() {
  return (
    <span className="pill pill-sample" title="Demonstration content">
      Sample data
    </span>
  );
}

export function Sparkline({ points }) {
  const w = 120;
  const h = 44;
  const pad = 3;
  const max = Math.max(...points);
  const min = Math.min(...points);
  const x = (i) => pad + (i * (w - 2 * pad)) / (points.length - 1);
  const y = (v) => h - pad - ((v - min) / (max - min || 1)) * (h - 2 * pad);
  const line = points.map((v, i) => `${i ? 'L' : 'M'}${x(i).toFixed(1)} ${y(v).toFixed(1)}`).join(' ');
  const area = `${line} L${x(points.length - 1).toFixed(1)} ${h} L${x(0).toFixed(1)} ${h} Z`;
  return (
    <svg className="spark" viewBox={`0 0 ${w} ${h}`} aria-hidden="true">
      <path className="spark-area" d={area} />
      <path className="spark-line" d={line} fill="none" />
    </svg>
  );
}

export function MetricCard({ icon: Icon, label, value, delta, points }) {
  return (
    <article className="card metric">
      <div className="metric-top">
        <span className="metric-icon">
          <Icon size={16} aria-hidden="true" />
        </span>
        <span className="pill pill-up">{delta}</span>
      </div>
      <div className="metric-bottom">
        <div>
          <strong>{value}</strong>
          <small>{label}</small>
        </div>
        <Sparkline points={points} />
      </div>
    </article>
  );
}

/** Marks automated demo accounts so nobody mistakes them for real people. */
export function BotBadge() {
  return <span className="pill" title="Automated community bot (demo content). Not a real person." style={{ marginLeft: 6 }}>Bot</span>;
}
