import { Link, useSearchParams } from 'react-router-dom';
import { Image as ImageIcon, Mic } from 'lucide-react';
import { useApi } from '../hooks/useApi.js';
import Highlight from '../components/Highlight.jsx';
import { Avatar, BotBadge, PriceBadge } from '../components/Ui.jsx';
import { initialsOf, timeAgo, courseBadge, courseNote } from '../utils/format.js';

const TABS = [
  ['all', 'All'],
  ['communities', 'Communities'],
  ['posts', 'Discussions'],
  ['people', 'People'],
  ['courses', 'Courses & Webinars'],
];
const TYPE_NAMES = { communities: 'Communities', posts: 'Discussions', people: 'People', courses: 'Courses & Webinars' };
const FILTER_NOTES = {
  profession: 'Profession applies to people and discussions.',
  topic: 'Topic applies to communities and discussions.',
  community: 'Community applies to communities, discussions and people.',
};
const SUGGESTIONS = ['Design', 'Software', 'Healthcare', 'Product', 'Webinar'];
const PER_TYPE_IN_ALL = 4;

function CommunityResult({ c, q }) {
  return (
    <li className="row result">
      <Avatar text={initialsOf(c.name)} />
      <div className="row-body">
        <strong><Link to={`/communities/${c.id}`} className="post-link"><Highlight text={c.name} query={q} /></Link></strong>
        <small className="excerpt"><Highlight text={c.description} query={q} /></small>
        <small className="muted">
          {c.category} · {c.memberCount} {c.memberCount === 1 ? 'member' : 'members'} · {c.postCount} posts
          {c.subcommunities.length > 0 && <> · {c.subcommunities.map((s) => s.name).join(', ')}</>}
        </small>
      </div>
      {c.isMember && <span className="pill pill-accent">Joined</span>}
    </li>
  );
}

function PostResult({ p, q }) {
  return (
    <li className="row result">
      <Avatar text={initialsOf(p.author.name)} src={p.author.avatarUrl} />
      <div className="row-body">
        <strong><Link to={`/posts/${p.id}`} className="post-link"><Highlight text={p.title} query={q} /></Link></strong>
        {p.excerpt && <small className="excerpt"><Highlight text={p.excerpt} query={q} /></small>}
        <small>
          <Link to={`/members/${p.author.id}`}><Highlight text={p.author.name} query={q} /></Link>{p.author.isBot && <BotBadge />}
          {p.author.profession ? ` · ${p.author.profession}` : ''} · <Link to={`/communities/${p.community.id}`}>{p.community.name}</Link>
        </small>
        <small className="muted">
          {p.replyCount} replies · {timeAgo(p.createdAt)}
          {p.imageCount > 0 && <span className="meta-icon"><ImageIcon size={12} aria-label="Has images" /> {p.imageCount}</span>}
          {p.hasVoice && <span className="meta-icon"><Mic size={12} aria-label="Has a voice message" /></span>}
        </small>
      </div>
    </li>
  );
}

function PersonResult({ u, q }) {
  return (
    <li className="row result">
      <Avatar text={initialsOf(u.name)} src={u.avatarUrl} />
      <div className="row-body">
        <strong><Link to={`/members/${u.id}`} className="post-link"><Highlight text={u.name} query={q} /></Link></strong>{u.isBot && <BotBadge />}
        <small>
          <Highlight text={[u.profession, u.location].filter(Boolean).join(' · ')} query={q} />
        </small>
        {u.headline && <small className="muted"><Highlight text={u.headline} query={q} /></small>}
        {u.skills.length > 0 && (
          <ul className="chips">
            {u.skills.slice(0, 5).map((s) => <li key={s} className="pill pill-sample"><Highlight text={s} query={q} /></li>)}
          </ul>
        )}
      </div>
    </li>
  );
}

function CourseResult({ c, q }) {
  return (
    <li className="row result">
      <span className="date-chip" aria-hidden="true">{courseBadge(c)}</span>
      <div className="row-body">
        <strong><Link to={`/courses/${c.id}`} className="post-link"><Highlight text={c.title} query={q} /></Link></strong>
        <small>{c.type === 'webinar' ? 'Webinar' : 'Course'}{c.organizer ? ` · ${c.organizer}` : ''}</small>
        <small className="muted">{courseNote(c)}{c.isPast ? ' · Ended' : ''}</small>
      </div>
      <PriceBadge price={c.priceLabel} />
    </li>
  );
}

const RENDERERS = {
  communities: (item, q) => <CommunityResult key={item.id} c={item} q={q} />,
  posts: (item, q) => <PostResult key={item.id} p={item} q={q} />,
  people: (item, q) => <PersonResult key={item.id} u={item} q={q} />,
  courses: (item, q) => <CourseResult key={item.id} c={item} q={q} />,
};

export default function Search() {
  const [params, setParams] = useSearchParams();
  const q = params.get('q') || '';
  const type = params.get('type') || 'all';
  const profession = params.get('profession') || '';
  const topic = params.get('topic') || '';
  const community = params.get('community') || '';

  const apiParams = new URLSearchParams();
  if (q) apiParams.set('q', q);
  if (profession) apiParams.set('profession', profession);
  if (topic) apiParams.set('topic', topic);
  if (community) apiParams.set('community', community);
  const { data, error, loading } = useApi(`/search?${apiParams}`);
  const { data: options } = useApi('/search/options');

  const update = (key, value) => {
    const next = new URLSearchParams(params);
    if (value) next.set(key, value);
    else next.delete(key);
    setParams(next);
  };
  const clearFilters = () => {
    const next = new URLSearchParams();
    if (q) next.set('q', q);
    setParams(next);
  };
  const hasFilters = !!(profession || topic || community);
  const excluded = data?.excluded || [];
  const total = (t) => data?.results?.[t]?.total ?? 0;
  const allTotal = data ? ['communities', 'posts', 'people', 'courses'].reduce((n, t) => n + total(t), 0) : 0;

  const section = (t, limit) => {
    const r = data.results?.[t];
    if (!r || r.items.length === 0) return null;
    const shown = limit ? r.items.slice(0, limit) : r.items;
    return (
      <section className="card" key={t} aria-labelledby={`res-${t}`}>
        <div className="card-head">
          <h3 id={`res-${t}`}>{TYPE_NAMES[t]} <span className="muted">({r.total})</span></h3>
          {limit && r.total > shown.length && (
            <button type="button" className="view-all link-btn" onClick={() => update('type', t)}>Show all {r.total}</button>
          )}
        </div>
        <ul className="list">{shown.map((item) => RENDERERS[t](item, q))}</ul>
        {!limit && r.total > r.items.length && (
          <p className="muted result-note">Showing the first {r.items.length} of {r.total}. Narrow the search with a keyword or a filter.</p>
        )}
      </section>
    );
  };

  return (
    <div className="search-page">
      <div className="card search-toolbar">
        <div className="filters" role="tablist" aria-label="Content type">
          {TABS.map(([id, label]) => {
            const disabled = id !== 'all' && excluded.includes(id);
            const count = id === 'all' ? allTotal : total(id);
            return (
              <button key={id} type="button" role="tab" aria-selected={type === id} disabled={disabled} className={`chip-btn ${type === id ? 'active' : ''}`} onClick={() => update('type', id === 'all' ? '' : id)} title={disabled ? 'Not available with the selected filters' : undefined}>
                {label}{data && !data.needsQuery && !disabled ? ` (${count})` : ''}
              </button>
            );
          })}
        </div>
        <div className="filter-row">
          <label className="filter-select">
            <span>Profession</span>
            <select value={profession} onChange={(e) => update('profession', e.target.value)}>
              <option value="">Any profession</option>
              {options?.professions.map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </label>
          <label className="filter-select">
            <span>Topic</span>
            <select value={topic} onChange={(e) => update('topic', e.target.value)}>
              <option value="">Any topic</option>
              {options?.topics.map((t) => <option key={t.id} value={t.id}>{t.name} ({t.parent.name})</option>)}
            </select>
          </label>
          <label className="filter-select">
            <span>Community</span>
            <select value={community} onChange={(e) => update('community', e.target.value)}>
              <option value="">Any community</option>
              {options?.communities.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </label>
          {hasFilters && <button type="button" className="btn btn-ghost btn-sm" onClick={clearFilters}>Clear filters</button>}
        </div>
        {hasFilters && (
          <p className="muted result-note">
            {[profession && FILTER_NOTES.profession, topic && FILTER_NOTES.topic, community && FILTER_NOTES.community].filter(Boolean).join(' ')}
            {excluded.length > 0 && <> Hidden for these filters: {excluded.map((t) => TYPE_NAMES[t]).join(', ')}.</>}
          </p>
        )}
      </div>

      {loading ? (
        <div className="card page-loading" role="status">Searching…</div>
      ) : error ? (
        <div className="card form-error" role="alert">{error.message}</div>
      ) : data.needsQuery ? (
        <div className="card empty">
          <h3>Search ProConnect</h3>
          <p className="muted">Type in the search box above to find professions, communities, discussions, people, courses and webinars. Or try one of these:</p>
          <ul className="chips">
            {SUGGESTIONS.map((s) => (
              <li key={s}><button type="button" className="chip-btn" onClick={() => update('q', s)}>{s}</button></li>
            ))}
          </ul>
        </div>
      ) : allTotal === 0 ? (
        <div className="card empty" role="status">
          <h3>{q ? `No results for "${q}"` : 'No results for these filters'}</h3>
          <p className="muted">Check the spelling, try fewer or different words{hasFilters ? ', or remove a filter' : ''}.</p>
          {hasFilters && <button type="button" className="btn btn-ghost btn-sm" onClick={clearFilters}>Clear filters</button>}
        </div>
      ) : type === 'all' ? (
        <div className="results">{['communities', 'posts', 'people', 'courses'].map((t) => section(t, PER_TYPE_IN_ALL))}</div>
      ) : total(type) === 0 ? (
        <div className="card empty" role="status">
          <h3>No {TYPE_NAMES[type].toLowerCase()} found</h3>
          <p className="muted">Other types have results. Switch to "All" to see them.</p>
          <button type="button" className="btn btn-ghost btn-sm" onClick={() => update('type', '')}>Show all types</button>
        </div>
      ) : (
        <div className="results">{section(type)}</div>
      )}
    </div>
  );
}
