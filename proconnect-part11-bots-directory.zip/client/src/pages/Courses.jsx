import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Search } from 'lucide-react';
import { useApi } from '../hooks/useApi.js';
import { PriceBadge } from '../components/Ui.jsx';
import { courseBadge, courseNote } from '../utils/format.js';

const TYPES = [['', 'All'], ['course', 'Courses'], ['webinar', 'Webinars']];
const PRICES = [['', 'Any price'], ['free', 'Free'], ['paid', 'Paid']];

export default function Courses() {
  const [type, setType] = useState('');
  const [price, setPrice] = useState('');
  const [text, setText] = useState('');
  const [q, setQ] = useState('');
  useEffect(() => {
    const t = setTimeout(() => setQ(text.trim()), 300);
    return () => clearTimeout(t);
  }, [text]);

  const params = new URLSearchParams();
  if (type) params.set('type', type);
  if (price) params.set('price', price);
  if (q) params.set('q', q);
  const { data, error, loading } = useApi(`/courses?${params}`);
  const filtered = !!(type || price || q);

  return (
    <div className="courses">
      <div className="toolbar">
        <div className="filters-group">
          <div className="filters" role="group" aria-label="Type">
            {TYPES.map(([v, label]) => (
              <button key={v || 'all'} type="button" className={`chip-btn ${type === v ? 'active' : ''}`} aria-pressed={type === v} onClick={() => setType(v)}>{label}</button>
            ))}
          </div>
          <div className="filters" role="group" aria-label="Price">
            {PRICES.map(([v, label]) => (
              <button key={v || 'any'} type="button" className={`chip-btn ${price === v ? 'active' : ''}`} aria-pressed={price === v} onClick={() => setPrice(v)}>{label}</button>
            ))}
          </div>
        </div>
        <label className="search search-inline">
          <Search size={16} aria-hidden="true" />
          <input type="search" placeholder="Filter courses" aria-label="Filter courses and webinars" value={text} onChange={(e) => setText(e.target.value)} />
        </label>
      </div>

      {loading ? (
        <div className="card page-loading" role="status">Loading…</div>
      ) : error ? (
        <div className="card form-error" role="alert">{error.message}</div>
      ) : data.courses.length === 0 ? (
        <div className="card empty" role="status">
          <h3>{filtered ? 'No courses or webinars match' : 'No courses or webinars are listed yet'}</h3>
          {filtered && (
            <>
              <p className="muted">Try a different type, price or keyword.</p>
              <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setType(''); setPrice(''); setText(''); }}>Clear filters</button>
            </>
          )}
        </div>
      ) : (
        <div className="course-grid">
          {data.courses.map((c) => (
            <article className={`card course-card ${c.isPast ? 'is-past' : ''}`} key={c.id}>
              <div className="course-top">
                <span className="pill pill-accent">{c.type === 'webinar' ? 'Webinar' : 'Course'}</span>
                <span className="course-pills">
                  {c.isSample && <span className="pill pill-sample" title="Demonstration listing">Sample</span>}
                  {c.isPast && <span className="pill pill-sample">Ended</span>}
                  <PriceBadge price={c.priceLabel} />
                </span>
              </div>
              <h3><Link to={`/courses/${c.id}`}>{c.title}</Link></h3>
              {c.organizer && <p className="muted">{c.organizer}</p>}
              <p className="course-when"><span className="date-chip" aria-hidden="true">{courseBadge(c)}</span> <small>{courseNote(c) || 'Self-paced'}</small></p>
              <Link to={`/courses/${c.id}`} className="btn btn-ghost btn-sm">View Details</Link>
            </article>
          ))}
        </div>
      )}
    </div>
  );
}
