import { useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ChevronLeft, Trash2, Image as ImageIcon, Mic, PenLine } from 'lucide-react';
import { api } from '../api.js';
import { useApi } from '../hooks/useApi.js';
import { useAuth } from '../context/AuthContext.jsx';
import JoinButton from '../components/JoinButton.jsx';
import { Avatar, BotBadge } from '../components/Ui.jsx';
import { useFeedback } from '../components/Feedback.jsx';
import Composer from '../components/Composer.jsx';
import { initialsOf, timeAgo } from '../utils/format.js';

export default function CommunityDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { data, error, loading, reload } = useApi(`/communities/${id}`);
  const { confirm, notify } = useFeedback();
  const [actionError, setActionError] = useState('');
  const [composing, setComposing] = useState(false);

  if (loading) return <div className="card page-loading" role="status">Loading…</div>;
  if (error) {
    return (
      <section className="card placeholder">
        <h2>{error.status === 404 ? 'Community not found' : 'Could not load this community'}</h2>
        <p>{error.message}</p>
        <Link to="/communities" className="btn btn-ghost">Back to Communities</Link>
      </section>
    );
  }

  const { community: c, recentPosts } = data;
  const remove = async () => {
    const extra = c.subcommunities.length ? ' and its subcommunities' : '';
    const ok = await confirm({
      title: `Delete ${c.name}?`,
      message: `This permanently removes the community${extra}, its memberships and all of its discussions. This cannot be undone.`,
      confirmLabel: 'Delete community',
      tone: 'danger',
    });
    if (!ok) return;
    try {
      await api(`/communities/${c.id}`, { method: 'DELETE' });
      notify(`${c.name} was deleted.`);
      navigate('/communities', { replace: true });
    } catch (err) {
      setActionError(err.message);
    }
  };

  return (
    <div className="community-page">
      <Link to={c.parent ? `/communities/${c.parent.id}` : '/communities'} className="back-link">
        <ChevronLeft size={16} aria-hidden="true" /> {c.parent ? c.parent.name : 'All communities'}
      </Link>

      <section className="card community-head">
        <Avatar text={initialsOf(c.name)} size={64} />
        <div className="community-info">
          <div className="community-title">
            <h2 className="serif">{c.name}</h2>
            <span className="pill pill-accent">{c.category}</span>
          </div>
          <p className="muted">{c.description}</p>
          <small className="muted">
            {c.memberCount} {c.memberCount === 1 ? 'member' : 'members'} · {c.postCount} {c.postCount === 1 ? 'post' : 'posts'}
          </small>
        </div>
        <div className="community-actions">
          {c.canJoin ? (
            <>
            <JoinButton community={c} size="md" linkInMessage={false} onChange={reload} />
              {!c.isMember && <p className="muted join-note">Join to add this community to your profile and follow its discussions.</p>}
            </>
          ) : (
            <p className="muted join-note">
              {c.isMember ? 'You are a member through ' : 'Join '}
              <Link to={`/communities/${c.parent.id}`}>{c.parent.name}</Link>
              {c.isMember ? '.' : ' to take part.'}
            </p>
          )}
          {user?.isAdmin && (
            <button type="button" className="btn btn-ghost btn-sm" onClick={remove}>
              <Trash2 size={14} aria-hidden="true" /> Delete
            </button>
          )}
        </div>
      </section>
      {actionError && <p className="form-error" role="alert">{actionError}</p>}

      {c.subcommunities.length > 0 && (
        <section className="card">
          <div className="card-head"><h3>Subcommunities</h3></div>
          <ul className="chips">
            {c.subcommunities.map((s) => (
              <li key={s.id}><Link to={`/communities/${s.id}`} className="pill pill-accent">{s.name}</Link></li>
            ))}
          </ul>
        </section>
      )}

      <section className="card">
        <div className="card-head">
          <h3>Discussions</h3>
          {c.isMember && !composing && (
            <button type="button" className="btn btn-primary btn-sm" onClick={() => setComposing(true)}>
              <PenLine size={14} aria-hidden="true" /> New discussion
            </button>
          )}
        </div>
        {!c.isMember && (
          <p className="muted join-note-block">
            {c.canJoin ? 'Join this community to start discussions and reply.' : <>Join <Link to={`/communities/${c.parent.id}`}>{c.parent.name}</Link> to start discussions and reply here.</>}
          </p>
        )}
        {composing && (
          <Composer
            withTitle
            autoFocus
            placeholder="Share your experience or ask a question…"
            submitLabel="Post discussion"
            onCancel={() => setComposing(false)}
            onSubmit={async (body) => {
              const d = await api(`/communities/${c.id}/posts`, { method: 'POST', body });
              notify('Your discussion was posted.');
              navigate(`/posts/${d.post.id}`);
            }}
          />
        )}
        {recentPosts.length === 0 ? (
          <p className="muted">No discussions yet.{c.isMember ? ' Be the first to start one.' : ''}</p>
        ) : (
          <ul className="list">
            {recentPosts.map((p) => (
              <li className="row" key={p.id}>
                <Avatar text={initialsOf(p.author.name)} src={p.author.avatarUrl} />
                <div className="row-body">
                  <strong><Link to={`/posts/${p.id}`} className="post-link">{p.title}</Link></strong>
                  {p.excerpt && <small className="excerpt">{p.excerpt}</small>}
                  <small>
                    <Link to={`/members/${p.author.id}`}>{p.author.name}</Link>
                    {p.author.isBot && <BotBadge />}
                    {p.author.profession ? ` · ${p.author.profession}` : ''}
                    {p.community.id !== c.id ? ` · ${p.community.name}` : ''}
                  </small>
                  <small className="muted">
                    {p.commentCount} replies · {timeAgo(p.createdAt)}
                    {p.imageCount > 0 && <span className="meta-icon"><ImageIcon size={12} aria-label="Has images" /> {p.imageCount}</span>}
                    {p.hasVoice && <span className="meta-icon"><Mic size={12} aria-label="Has a voice message" /></span>}
                  </small>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
