const STEPS = [
  ['01', 'Join communities', 'Find people in your profession.'],
  ['02', 'Share experience', 'Ask questions and answer with real-world practice.'],
  ['03', 'Keep learning', 'Courses and webinars from experienced professionals.'],
];

export default function AuthLayout({ heading, lead, children }) {
  return (
    <div className="auth-grid">
      <section className="auth-info">
        <div>
          <span className="pill pill-accent">ProConnect</span>
          <h2>{heading}</h2>
          <p>{lead}</p>
        </div>
        <ol className="steps">
          {STEPS.map(([n, t, d]) => (
            <li className="row" key={n}>
              <span className="date-chip" aria-hidden="true">{n}</span>
              <div className="row-body">
                <strong>{t}</strong>
                <small>{d}</small>
              </div>
            </li>
          ))}
        </ol>
      </section>
      <section className="card auth-form">{children}</section>
    </div>
  );
}
