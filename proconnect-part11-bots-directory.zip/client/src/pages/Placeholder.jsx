import { Link } from 'react-router-dom';

export default function Placeholder({ title, part }) {
  return (
    <section className="card placeholder">
      <h2>{title}</h2>
      <p>{part ? `This screen is built in ${part}.` : 'The page you are looking for does not exist.'}</p>
      <Link to="/" className="btn btn-ghost">
        Back to Home
      </Link>
    </section>
  );
}
