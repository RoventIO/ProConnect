import { Link, useParams } from 'react-router-dom';
import { ChevronLeft, ExternalLink } from 'lucide-react';
import { useApi } from '../hooks/useApi.js';
import { PriceBadge } from '../components/Ui.jsx';
import { longDate, timeOfDay, isWebLink } from '../utils/format.js';

export default function CourseDetail() {
  const { id } = useParams();
  const { data, error, loading } = useApi(`/courses/${id}`);

  if (loading) return <div className="card page-loading" role="status">Loading…</div>;
  if (error) {
    return (
      <section className="card placeholder">
        <h2>{error.status === 404 ? 'Course or webinar not found' : 'Could not load this listing'}</h2>
        <p>{error.message}</p>
        <Link to="/courses" className="btn btn-ghost">Back to Courses & Webinars</Link>
      </section>
    );
  }

  const c = data.course;
  const rows = [
    c.startsAt && ['When', `${longDate(c.startsAt)} · ${timeOfDay(c.startsAt)}`],
    c.duration && ['Format and length', c.duration],
    c.organizer && [c.type === 'webinar' ? 'Host' : 'Instructor', c.organizer],
    c.category && ['Subject', c.category],
    ['Price', c.isFree ? 'Free' : c.priceText || 'Paid'],
  ].filter(Boolean);

  return (
    <div className="community-page">
      <Link to="/courses" className="back-link"><ChevronLeft size={16} aria-hidden="true" /> Courses & Webinars</Link>

      <article className="card post-card">
        <div className="course-top">
          <span className="pill pill-accent">{c.type === 'webinar' ? 'Webinar' : 'Course'}</span>
          <span className="course-pills">
            {c.isPast && <span className="pill pill-sample">Ended</span>}
            <PriceBadge price={c.priceLabel} />
          </span>
        </div>
        <h2 className="serif post-title">{c.title}</h2>
        {c.description && <p className="post-text">{c.description}</p>}

        <dl className="facts">
          {rows.map(([k, v]) => (
            <div key={k}><dt>{k}</dt><dd>{v}</dd></div>
          ))}
        </dl>

        {c.isSample && (
          <p className="notice" role="note">
            This is a demonstration listing created for the ProConnect prototype. It is not a real course or webinar.
          </p>
        )}

        <div className="course-cta">
          {isWebLink(c.externalUrl) ? (
            <a className="btn btn-primary" href={c.externalUrl} target="_blank" rel="noopener noreferrer">
              {c.isFree ? 'Register or learn more' : 'View details and pricing'} <ExternalLink size={14} aria-hidden="true" />
            </a>
          ) : (
            <p className="muted">The organizer has not provided a registration link.</p>
          )}
          {!c.isFree && <small className="muted">Payment happens on the organizer's website. ProConnect does not process payments.</small>}
        </div>
      </article>
    </div>
  );
}
