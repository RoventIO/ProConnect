import { Link } from 'react-router-dom';
import { Sparkles, ShieldCheck, GraduationCap, Users, UserCheck, MessageCircleQuestion, Quote, Lock } from 'lucide-react';
import { useAuth } from '../context/AuthContext.jsx';
import { useApi } from '../hooks/useApi.js';
import { Avatar, BotBadge, PriceBadge, SampleTag, MetricCard } from '../components/Ui.jsx';
import { initialsOf, timeAgo, courseBadge, courseNote } from '../utils/format.js';

const fmt = (n) => (typeof n === 'number' ? n.toLocaleString('en-US') : '–');
const weekText = (n, noun) => (n > 0 ? `+${n} ${noun} this week` : `No new ${noun} this week`);

function Metrics() {
  const { data } = useApi('/stats');
  const t = data?.totals;
  const w = data?.week;
  const flat = [0, 0, 0, 0, 0, 0, 0];
  const cards = [
    { icon: Users, label: 'Communities', value: t?.communities, delta: weekText(w?.memberships.count ?? 0, 'joins'), points: w?.memberships.points ?? flat },
    { icon: UserCheck, label: 'Professionals', value: t?.professionals, delta: weekText(w?.professionals.count ?? 0, 'members'), points: w?.professionals.points ?? flat },
    { icon: MessageCircleQuestion, label: 'Discussions', value: t?.discussions, delta: weekText(w?.discussions.count ?? 0, 'posts'), points: w?.discussions.points ?? flat },
  ];
  return (
    <section aria-label="Platform at a glance">
      <div className="card-head" style={{ padding: '0 4px' }}>
        <h3>Platform at a glance</h3>
      </div>
      <div className="metrics">
        {cards.map((c) => (
          <MetricCard key={c.label} icon={c.icon} label={c.label} value={fmt(c.value)} delta={c.delta} points={c.points} />
        ))}
      </div>
    </section>
  );
}

function MemberSections() {
  const { data, error, loading } = useApi('/home');
  if (loading) return <div className="card page-loading" role="status">Loading…</div>;
  if (error) return <div className="card form-error" role="alert">{error.message}</div>;

  const maxMembers = Math.max(1, ...data.popularCommunities.map((c) => c.memberCount));
  const anySample = data.courses.some((c) => c.isSample);

  return (
    <>
      <div className="two-col">
        <section className="card">
          <div className="card-head">
            <h3>Trending Discussions</h3>
            <Link to="/communities" className="view-all">View All</Link>
          </div>
          <p className="card-sub">What professionals are talking about right now</p>
          {data.trending.length === 0 ? (
            <p className="muted">No discussions yet. Be the first to start one.</p>
          ) : (
            <ul className="list">
              {data.trending.map((t) => (
                <li className="row" key={t.id}>
                  <Avatar text={initialsOf(t.author.name)} src={t.author.avatarUrl} />
                  <div className="row-body">
                    <strong><Link to={`/posts/${t.id}`} className="post-link">{t.title}</Link></strong>
                    <small>
                      <Link to={`/members/${t.author.id}`}>{t.author.name}</Link>
                      {t.author.isBot && <BotBadge />}
                      {t.author.profession ? ` · ${t.author.profession}` : ''} · {t.community.name}
                    </small>
                    <small className="muted">{t.replyCount} replies · {timeAgo(t.createdAt)}</small>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </section>

        <section className="card">
          <div className="card-head">
            <h3>Courses & Webinars</h3>
            {anySample ? <SampleTag /> : <Link to="/courses" className="view-all">View All</Link>}
          </div>
          <p className="card-sub">Learn from experienced professionals</p>
          {data.courses.length === 0 ? (
            <p className="muted">No courses or webinars are listed yet.</p>
          ) : (
            <ul className="list">
              {data.courses.map((c) => (
                <li className="row" key={c.id}>
                  <span className="date-chip" aria-hidden="true">{courseBadge(c)}</span>
                  <div className="row-body">
                    <strong><Link to={`/courses/${c.id}`} className="post-link">{c.title}</Link></strong>
                    <small>{c.type === 'webinar' ? 'Webinar' : 'Course'}{c.organizer ? ` · ${c.organizer}` : ''}</small>
                    <small className="muted">{courseNote(c)}</small>
                  </div>
                  <PriceBadge price={c.priceLabel} />
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <section className="card">
        <div className="card-head">
          <h3>Popular Communities</h3>
          <Link to="/communities" className="view-all">View All</Link>
        </div>
        <div className="community-row">
          {data.popularCommunities.map((c) => (
            <Link to={`/communities/${c.id}`} className="row" key={c.id} style={{ textDecoration: 'none', color: 'inherit' }}>
              <Avatar text={initialsOf(c.name)} />
              <div className="row-body">
                <strong>{c.name}</strong>
                <small>{c.memberCount} {c.memberCount === 1 ? 'member' : 'members'} · {c.postCount} posts</small>
                <span className="bar" aria-hidden="true"><span style={{ width: `${(c.memberCount / maxMembers) * 100}%` }} /></span>
              </div>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}

export default function Home() {
  const { user } = useAuth();
  const member = !!user?.profileCompleted;
  const { data: stats } = useApi('/stats');

  return (
    <div className="home">
      <section className="hero">
        <span className="pill pill-accent">Professional community platform</span>
        <h2>
          Your Professional World,{' '}
          <span className="accent">Connected.</span>
        </h2>
        <p>
          Discover professional communities, exchange real-world experience, learn from industry experts, and
          build meaningful connections with people who share your interests.
        </p>
        <div className="hero-chips">
          <span className="hero-chip"><Sparkles size={14} /> Free to join</span>
          <span className="hero-chip"><ShieldCheck size={14} /> Real practitioners</span>
          <span className="hero-chip"><GraduationCap size={14} /> Courses & webinars</span>
        </div>
        <div className="hero-actions">
          <Link to="/communities" className="btn btn-primary">Explore Communities</Link>
          {!member && <Link to="/sign-up" className="btn btn-dark">Join ProConnect</Link>}
        </div>
      </section>

      <section className="tiles" aria-label="Why ProConnect">
        <article className="tile tile-sage">
          <div className="tile-chips">
            <div className="tile-chip"><span>Profession</span><span>Software Engineer</span></div>
            <div className="tile-chip"><span>Community</span><span>Backend</span></div>
            <div className="tile-chip"><span>Topic</span><span>Code reviews</span></div>
          </div>
          <h3>Every question, matched to someone who has done the work.</h3>
        </article>

        <article className="tile tile-sage">
          <span className="tile-big">{fmt(stats?.week.replies.count)}</span>
          <h3>
            <em>Replies</em> shared by members in the last 7 days.
          </h3>
        </article>

        <article className="tile tile-cream">
          <Quote size={22} aria-hidden="true" />
          <p className="tile-quote">
            I asked about moving into health informatics and got three real career paths in a day.
          </p>
          <div className="tile-cite">
            <span>Sample quote, Healthcare Professionals</span>
            <SampleTag />
          </div>
        </article>
      </section>

      <Metrics />

      {member ? (
        <MemberSections />
      ) : (
        <section className="card locked">
          <span className="locked-icon" aria-hidden="true"><Lock size={20} /></span>
          <div>
            <h3>Discussions, communities and learning are for members</h3>
            <p className="muted">
              Create your account and a short professional profile to see trending discussions, join communities
              and browse courses and webinars.
            </p>
          </div>
          <div className="hero-actions">
            <Link to="/sign-up" className="btn btn-dark">Join ProConnect</Link>
            <Link to="/sign-in" className="btn btn-ghost">Sign In</Link>
          </div>
        </section>
      )}
    </div>
  );
}
