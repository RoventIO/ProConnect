import { useRef, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { ChevronLeft, Pencil, Trash2, Smile } from 'lucide-react';
import { api } from '../api.js';
import { useApi } from '../hooks/useApi.js';
import { useFeedback } from '../components/Feedback.jsx';
import Composer from '../components/Composer.jsx';
import EmojiPicker from '../components/EmojiPicker.jsx';
import Attachments from '../components/Attachments.jsx';
import { Avatar, BotBadge } from '../components/Ui.jsx';
import { initialsOf, timeAgo } from '../utils/format.js';

/** Inline editor for the text of a discussion or reply. */
function EditForm({ withTitle, initial, onSave, onCancel }) {
  const [title, setTitle] = useState(initial.title || '');
  const [text, setText] = useState(initial.content || '');
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);
  const [picker, setPicker] = useState(false);
  const ref = useRef(null);

  const insert = (emoji) => {
    const el = ref.current;
    const s = el?.selectionStart ?? text.length;
    const e = el?.selectionEnd ?? text.length;
    setText(text.slice(0, s) + emoji + text.slice(e));
    requestAnimationFrame(() => {
      el?.focus();
      el?.setSelectionRange(s + emoji.length, s + emoji.length);
    });
  };

  const submit = async (ev) => {
    ev.preventDefault();
    setBusy(true);
    setErrors({});
    setFormError('');
    try {
      await onSave({ title, content: text });
    } catch (err) {
      if (err.fields) setErrors(err.fields);
      else setFormError(err.message);
      setBusy(false);
    }
  };

  return (
    <form className="composer" onSubmit={submit} noValidate>
      {withTitle && (
        <div className="field">
          <label htmlFor="edit-title" className="sr-only">Title</label>
          <input id="edit-title" className="composer-title" value={title} maxLength={150} onChange={(e) => setTitle(e.target.value)} />
          {errors.title && <p className="field-error" role="alert">{errors.title}</p>}
        </div>
      )}
      <div className="field">
        <label htmlFor="edit-text" className="sr-only">Text</label>
        <textarea id="edit-text" ref={ref} rows={4} value={text} onChange={(e) => setText(e.target.value)} />
        {errors.content && <p className="field-error" role="alert">{errors.content}</p>}
      </div>
      {formError && <p className="form-error" role="alert">{formError}</p>}
      <div className="composer-bar">
        <div className="composer-tools">
          <button type="button" className="icon-btn" data-emoji-toggle aria-label="Add emoji" onClick={() => setPicker((o) => !o)}>
            <Smile size={16} />
          </button>
          {picker && <EmojiPicker onPick={insert} onClose={() => setPicker(false)} />}
        </div>
        <div className="form-actions">
          <button type="button" className="btn btn-ghost btn-sm" onClick={onCancel}>Cancel</button>
          <button type="submit" className="btn btn-primary btn-sm" disabled={busy}>{busy ? 'Saving…' : 'Save'}</button>
        </div>
      </div>
    </form>
  );
}

function Actions({ item, onEdit, onDelete, label }) {
  if (!item.canEdit && !item.canDelete) return null;
  return (
    <span className="item-actions">
      {item.canEdit && (
        <button type="button" className="icon-btn" aria-label={`Edit ${label}`} onClick={onEdit}><Pencil size={14} /></button>
      )}
      {item.canDelete && (
        <button type="button" className="icon-btn" aria-label={`Delete ${label}`} onClick={onDelete}><Trash2 size={14} /></button>
      )}
    </span>
  );
}

function Byline({ author, createdAt, edited, extra }) {
  return (
    <div className="byline">
      <Avatar text={initialsOf(author.name)} src={author.avatarUrl} size={40} />
      <div>
        <strong><Link to={`/members/${author.id}`}>{author.name}</Link>{author.isBot && <BotBadge />}</strong>
        <small>
          {author.profession ? `${author.profession} · ` : ''}
          {extra}
          {timeAgo(createdAt)}
          {edited ? ' · edited' : ''}
        </small>
      </div>
    </div>
  );
}

export default function PostDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { confirm, notify } = useFeedback();
  const { data, error, loading, reload } = useApi(`/posts/${id}`);
  const [editingPost, setEditingPost] = useState(false);
  const [editingComment, setEditingComment] = useState(null);

  if (loading) return <div className="card page-loading" role="status">Loading…</div>;
  if (error) {
    return (
      <section className="card placeholder">
        <h2>{error.status === 404 ? 'Discussion not found' : 'Could not load this discussion'}</h2>
        <p>{error.message}</p>
        <Link to="/communities" className="btn btn-ghost">Back to Communities</Link>
      </section>
    );
  }

  const { post, comments } = data;
  const topCommunity = post.community.parent || post.community;

  const deletePost = async () => {
    const ok = await confirm({
      title: 'Delete this discussion?',
      message: 'The discussion, all replies and their attachments will be removed. This cannot be undone.',
      confirmLabel: 'Delete discussion',
      tone: 'danger',
    });
    if (!ok) return;
    try {
      await api(`/posts/${post.id}`, { method: 'DELETE' });
      notify('Discussion deleted.');
      navigate(`/communities/${post.community.id}`, { replace: true });
    } catch (err) {
      notify(err.message);
    }
  };

  const deleteComment = async (c) => {
    const ok = await confirm({ title: 'Delete this reply?', message: 'The reply and its attachments will be removed.', confirmLabel: 'Delete reply', tone: 'danger' });
    if (!ok) return;
    try {
      await api(`/comments/${c.id}`, { method: 'DELETE' });
      notify('Reply deleted.');
      reload();
    } catch (err) {
      notify(err.message);
    }
  };

  return (
    <div className="community-page">
      <Link to={`/communities/${post.community.id}`} className="back-link">
        <ChevronLeft size={16} aria-hidden="true" /> {post.community.name}
      </Link>

      <article className="card post-card">
        <div className="post-top">
          <Byline author={post.author} createdAt={post.createdAt} edited={post.edited} extra={<><Link to={`/communities/${post.community.id}`}>{post.community.name}</Link>{' · '}</>} />
          {!editingPost && <Actions item={post} label="discussion" onEdit={() => setEditingPost(true)} onDelete={deletePost} />}
        </div>
        {editingPost ? (
          <EditForm
            withTitle
            initial={post}
            onCancel={() => setEditingPost(false)}
            onSave={async (v) => {
              await api(`/posts/${post.id}`, { method: 'PUT', body: v });
              setEditingPost(false);
              reload();
            }}
          />
        ) : (
          <>
            <h2 className="serif post-title">{post.title}</h2>
            {post.content && <p className="post-text">{post.content}</p>}
            <Attachments items={post.attachments} />
          </>
        )}
      </article>

      <section className="card">
        <div className="card-head"><h3>Replies ({comments.length})</h3></div>
        {comments.length === 0 && <p className="muted">No replies yet.{post.canComment ? ' Start the conversation below.' : ''}</p>}
        <ul className="comment-list">
          {comments.map((c) => (
            <li key={c.id} className="comment">
              <div className="post-top">
                <Byline author={c.author} createdAt={c.createdAt} edited={c.edited} />
                {editingComment !== c.id && <Actions item={c} label="reply" onEdit={() => setEditingComment(c.id)} onDelete={() => deleteComment(c)} />}
              </div>
              {editingComment === c.id ? (
                <EditForm
                  initial={c}
                  onCancel={() => setEditingComment(null)}
                  onSave={async (v) => {
                    await api(`/comments/${c.id}`, { method: 'PUT', body: { content: v.content } });
                    setEditingComment(null);
                    reload();
                  }}
                />
              ) : (
                <>
                  {c.content && <p className="post-text">{c.content}</p>}
                  <Attachments items={c.attachments} />
                </>
              )}
            </li>
          ))}
        </ul>

        {post.canComment ? (
          <Composer
            placeholder="Write a reply…"
            submitLabel="Reply"
            onSubmit={async (body) => {
              await api(`/posts/${post.id}/comments`, { method: 'POST', body });
              reload();
            }}
          />
        ) : (
          <p className="muted join-note-block">
            <Link to={`/communities/${topCommunity.id}`}>Join {topCommunity.name}</Link> to reply to this discussion.
          </p>
        )}
      </section>
    </div>
  );
}
