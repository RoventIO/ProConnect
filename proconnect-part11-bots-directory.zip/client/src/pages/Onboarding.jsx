import { useState } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import Field from '../components/Field.jsx';
import { useAuth } from '../context/AuthContext.jsx';

const PROFESSIONS = [
  'Software Engineer', 'Product Designer', 'Product Manager', 'Data Analyst', 'Physician', 'Nurse',
  'Teacher', 'Accountant', 'Project Manager', 'Student',
];

const splitSkills = (s) => [...new Set(s.split(',').map((x) => x.trim()).filter(Boolean))];

export default function Onboarding() {
  const { user, saveProfile } = useAuth();
  const navigate = useNavigate();
  const [values, setValues] = useState({ profession: '', headline: '', bio: '', skills: '', location: '', yearsExperience: '' });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);

  if (user?.profileCompleted) return <Navigate to="/" replace />;

  const onChange = (e) => setValues((v) => ({ ...v, [e.target.name]: e.target.value }));
  const chips = splitSkills(values.skills);

  const onSubmit = async (e) => {
    e.preventDefault();
    const next = {};
    if (values.profession.trim().length < 2) next.profession = 'Enter your profession.';
    if (values.bio.trim().length < 10) next.bio = 'Write a short biography (at least 10 characters).';
    if (chips.length < 1) next.skills = 'Add at least one skill, separated by commas.';
    setErrors(next);
    setFormError('');
    if (Object.keys(next).length) return;

    setBusy(true);
    try {
      await saveProfile({ ...values, skills: chips });
      navigate('/', { replace: true });
    } catch (err) {
      if (err.fields) setErrors(err.fields);
      else setFormError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="onboarding">
      <section className="card onboarding-card">
        <span className="pill pill-accent">Step 2 of 2 · Professional profile</span>
        <h2 className="serif">Tell professionals who you are, {user?.name.split(' ')[0]}.</h2>
        <p className="muted">
          ProConnect is a community of real practitioners. A short professional profile unlocks communities,
          discussions, courses and webinars.
        </p>

        <form onSubmit={onSubmit} noValidate>
          <Field id="profession" label="Profession *" list="profession-list" placeholder="e.g. Software Engineer" value={values.profession} onChange={onChange} error={errors.profession} />
          <datalist id="profession-list">
            {PROFESSIONS.map((p) => (
              <option key={p} value={p} />
            ))}
          </datalist>
          <Field id="headline" label="Headline" placeholder="e.g. Senior Product Designer · Design & UX" value={values.headline} onChange={onChange} error={errors.headline} />
          <Field id="bio" label="Short biography *" as="textarea" rows={4} placeholder="What do you work on, and what would you like to share or learn?" value={values.bio} onChange={onChange} error={errors.bio} />
          <Field id="skills" label="Skills *" placeholder="Separate with commas, e.g. Design Systems, Prototyping" value={values.skills} onChange={onChange} error={errors.skills} />
          {chips.length > 0 && (
            <ul className="chips" aria-label="Skills preview">
              {chips.map((c) => (
                <li key={c} className="pill pill-accent">{c}</li>
              ))}
            </ul>
          )}
          <div className="field-row">
            <Field id="location" label="Location" placeholder="City, Country" value={values.location} onChange={onChange} error={errors.location} />
            <Field id="yearsExperience" label="Years of experience" type="number" min="0" max="60" placeholder="0" value={values.yearsExperience} onChange={onChange} error={errors.yearsExperience} />
          </div>
          {formError && <p className="form-error" role="alert">{formError}</p>}
          <button type="submit" className="btn btn-primary" disabled={busy}>
            {busy ? 'Saving…' : 'Save and continue'}
          </button>
        </form>
      </section>
    </div>
  );
}
