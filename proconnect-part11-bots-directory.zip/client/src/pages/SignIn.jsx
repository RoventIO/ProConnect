import { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import AuthLayout from './AuthLayout.jsx';
import Field from '../components/Field.jsx';
import { useAuth } from '../context/AuthContext.jsx';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function SignIn() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();
  const [values, setValues] = useState({ email: '', password: '' });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);

  const onChange = (e) => setValues((v) => ({ ...v, [e.target.name]: e.target.value }));

  const onSubmit = async (e) => {
    e.preventDefault();
    const next = {};
    if (!values.email.trim()) next.email = 'Enter your email address.';
    else if (!EMAIL_RE.test(values.email)) next.email = 'Enter a valid email address.';
    if (!values.password) next.password = 'Enter your password.';
    setErrors(next);
    setFormError('');
    if (Object.keys(next).length) return;

    setBusy(true);
    try {
      const user = await login(values);
      const from = location.state?.from;
      navigate(user.profileCompleted ? from || '/' : '/onboarding', { replace: true });
    } catch (err) {
      if (err.fields) setErrors(err.fields);
      else setFormError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthLayout
      heading="Welcome back to your professional world."
      lead="Pick up your discussions, communities, and learning where you left off."
    >
      {location.state?.reason === 'protected' && (
        <p className="notice" role="status">
          Sign in or create an account to continue. ProConnect content is available to members with a professional
          profile. <Link to="/sign-up">Sign Up</Link>
        </p>
      )}
      <h2>Sign In</h2>
      <p className="muted">Welcome back. Enter your details to continue.</p>
      <form onSubmit={onSubmit} noValidate>
        <Field id="email" label="Email address" type="email" placeholder="you@example.com" autoComplete="email" value={values.email} onChange={onChange} error={errors.email} />
        <Field id="password" label="Password" type="password" placeholder="Enter your password" autoComplete="current-password" value={values.password} onChange={onChange} error={errors.password} />
        {formError && <p className="form-error" role="alert">{formError}</p>}
        <button type="submit" className="btn btn-primary btn-block" disabled={busy}>
          {busy ? 'Signing in…' : 'Sign In'}
        </button>
      </form>
      <p className="auth-switch muted">
        New to ProConnect? <Link to="/sign-up">Sign Up</Link>
      </p>
    </AuthLayout>
  );
}
