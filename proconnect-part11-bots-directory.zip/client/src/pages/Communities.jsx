import { useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Search } from 'lucide-react';
import { api } from '../api.js';
import { useApi } from '../hooks/useApi.js';
import { useAuth } from '../context/AuthContext.jsx';
import Field from '../components/Field.jsx';
import JoinButton from '../components/JoinButton.jsx';
import { Avatar } from '../components/Ui.jsx';
import { initialsOf } from '../utils/format.js';

function CreateCommunityForm({ communities, categories, onCreated, onCancel }) {
  const [values, setValues] = useState({ name: '', category: '', description: '', parentId: '' });
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);
  const onChange = (e) => setValues((v) => ({ ...v, [e.target.name]: e.target.value }));
  const isSub = values.parentId !== '';

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setErrors({});
    setFormError('');
    try {
      await api('/communities', { method: 'POST', body: { ...values, parentId: values.parentId || null } });
      onCreated();
    } catch (err) {
      if (err.fields) setErrors(err.fields);
      else setFormError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="card edit-card" onSubmit={submit} noValidate>
      <h3>Create a community</h3>
      <p className="muted">Administrators only. Leave the parent empty for a main community, or choose one to add a subcommunity.</p>
      <Field id="parentId" label="Parent community" as="select" value={values.parentId} onChange={onChange} error={errors.parentId}>
        <option value="">None (main community)</option>
        {communities.map((c) => (
          <option key={c.id} value={c.id}>{c.name}</option>
        ))}
      </Field>
      <Field id="name" label="Name *" placeholder="e.g. Legal Professionals" value={values.name} onChange={onChange} error={errors.name} />
      {!isSub && (
        <>
          <Field id="category" label="Category *" list="category-list" placeholder="e.g. Legal" value={values.category} onChange={onChange} error={errors.category} />
          <datalist id="category-list">
            {categories.map((c) => <option key={c} value={c} />)}
          </datalist>
        </>
      )}
      <Field id="description" label="Description *" as="textarea" rows={3} placeholder="What is this community about?" value={values.description} onChange={onChange} error={errors.description} />
      {formError && <p className="form-error" role="alert">{formError}</p>}
      <div className="form-actions">
        <button type="submit" className="btn btn-primary" disabled={busy}>{busy ? 'Creating…' : 'Create community'}</button>
        <button type="button" className="btn btn-ghost" onClick={onCancel}>Cancel</button>
      </div>
    </form>
  );
}

function CommunityCard({ c, onMembership }) {
  return (
    <article className={`card community-card ${c.isMember ? 'is-joined' : ''}`}>
      <div className="community-top">
        <Avatar text={initialsOf(c.name)} />
        <span className="pill pill-accent">{c.category}</span>
      </div>
      <h3><Link to={`/communities/${c.id}`}>{c.name}</Link></h3>
      <p className="muted">{c.description}</p>
      {c.subcommunities.length > 0 && (
        <ul className="chips">
          {c.subcommunities.map((s) => (
            <li key={s.id}><Link to={`/communities/${s.id}`} className="pill pill-sample">{s.name}</Link></li>
          ))}
        </ul>
      )}
      <small className="muted">
        {c.memberCount} {c.memberCount === 1 ? 'member' : 'members'} · {c.postCount} {c.postCount === 1 ? 'post' : 'posts'}
      </small>
      <div className="community-actions-row">
        {c.isMember && <Link to={`/communities/${c.id}`} className="btn btn-dark btn-sm">Open</Link>}
        <JoinButton community={c} onChange={onMembership} />
      </div>
    </article>
  );
}

export default function Communities() {
  const { user } = useAuth();
  const { data, error, loading, reload } = useApi('/communities');
  const [category, setCategory] = useState('All');
  const [query, setQuery] = useState('');
  const [creating, setCreating] = useState(false);
  const [memberState, setMemberState] = useState({}); // id -> { isMember, memberCount } after join/leave

  const all = useMemo(() => (data ? data.communities.map((c) => ({ ...c, ...(memberState[c.id] || {}) })) : []), [data, memberState]);
  // Joined communities always stay on top; the filters below only narrow the "Discover" list.
  const joined = useMemo(() => all.filter((c) => c.isMember), [all]);
  const discover = useMemo(() => {
    const q = query.trim().toLowerCase();
    return all.filter(
      (c) =>
        !c.isMember &&
        (category === 'All' || c.category === category) &&
        (!q || c.name.toLowerCase().includes(q) || c.description.toLowerCase().includes(q) || c.subcommunities.some((s) => s.name.toLowerCase().includes(q)))
    );
  }, [all, category, query]);

  if (loading) return <div className="card page-loading" role="status">Loading…</div>;
  if (error) return <div className="card form-error" role="alert">{error.message}</div>;

  const onMembership = (id) => (state) => setMemberState((m) => ({ ...m, [id]: state }));
  const notJoinedCount = all.length - joined.length;

  return (
    <div className="communities">
      {user?.isAdmin && (
        <div className="toolbar">
          <span />
          {!creating && (
            <button type="button" className="btn btn-primary btn-sm" onClick={() => setCreating(true)}>
              <Plus size={14} aria-hidden="true" /> Create community
            </button>
          )}
        </div>
      )}

      {creating && (
        <CreateCommunityForm
          communities={data.communities}
          categories={data.categories}
          onCancel={() => setCreating(false)}
          onCreated={() => { setCreating(false); setMemberState({}); reload(); }}
        />
      )}

      <section aria-labelledby="your-communities">
        <div className="section-title">
          <h2 id="your-communities">My Communities</h2>
          {joined.length > 0 && <span className="pill pill-accent">{joined.length}</span>}
        </div>
        {joined.length === 0 ? (
          <div className="card empty">
            <h3>You have not joined any communities yet</h3>
            <p className="muted">Join a community from the list below. Communities you join stay here, at the top of this page, so they are always easy to open.</p>
          </div>
        ) : (
          <div className="community-grid">
            {joined.map((c) => <CommunityCard key={c.id} c={c} onMembership={onMembership(c.id)} />)}
          </div>
        )}
      </section>

      <section aria-labelledby="discover-communities">
        <div className="section-title">
          <h2 id="discover-communities">Discover Communities</h2>
          {notJoinedCount > 0 && <span className="pill pill-sample">{notJoinedCount}</span>}
        </div>
        <div className="toolbar">
          <div className="filters" role="group" aria-label="Filter by category">
            {['All', ...data.categories].map((c) => (
              <button key={c} type="button" className={`chip-btn ${category === c ? 'active' : ''}`} aria-pressed={category === c} onClick={() => setCategory(c)}>
                {c === 'All' ? 'All professions' : c}
              </button>
            ))}
          </div>
          <label className="search search-inline">
            <Search size={16} aria-hidden="true" />
            <input type="search" placeholder="Filter communities" aria-label="Filter communities" value={query} onChange={(e) => setQuery(e.target.value)} />
          </label>
        </div>

        {discover.length === 0 ? (
          <div className="card empty">
            {notJoinedCount === 0 ? (
              <>
                <h3>You have joined every community</h3>
                <p className="muted">There is nothing new to discover right now.</p>
              </>
            ) : (
              <>
                <h3>No communities match</h3>
                <p className="muted">Try a different category or clear the filter.</p>
                <button type="button" className="btn btn-ghost btn-sm" onClick={() => { setCategory('All'); setQuery(''); }}>Show all communities</button>
              </>
            )}
          </div>
        ) : (
          <div className="community-grid">
            {discover.map((c) => <CommunityCard key={c.id} c={c} onMembership={onMembership(c.id)} />)}
          </div>
        )}
      </section>
    </div>
  );
}
