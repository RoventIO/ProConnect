import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import AuthLayout from './AuthLayout.jsx';
import Field from '../components/Field.jsx';
import StatusPicker from '../components/StatusPicker.jsx';
import { useAuth } from '../context/AuthContext.jsx';

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function SignUp() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [values, setValues] = useState({ name: '', email: '', password: '', confirm: '' });
  const [status, setStatus] = useState('beginner');
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [busy, setBusy] = useState(false);

  const onChange = (e) => setValues((v) => ({ ...v, [e.target.name]: e.target.value }));

  const onSubmit = async (e) => {
    e.preventDefault();
    const next = {};
    if (values.name.trim().length < 2) next.name = 'Enter your full name.';
    if (!values.email.trim()) next.email = 'Enter your email address.';
    else if (!EMAIL_RE.test(values.email)) next.email = 'Enter a valid email address.';
    if (values.password.length < 8) next.password = 'Use at least 8 characters.';
    if (values.confirm !== values.password) next.confirm = 'Passwords do not match.';
    setErrors(next);
    setFormError('');
    if (Object.keys(next).length) return;

    setBusy(true);
    try {
      await register({ name: values.name, email: values.email, password: values.password, status });
      navigate('/onboarding', { replace: true });
    } catch (err) {
      if (err.fields) setErrors(err.fields);
      else setFormError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <AuthLayout
      heading="Build meaningful professional connections."
      lead="Create a profile, join communities in your field, and learn from people who do the work every day."
    >
      <h2>Sign Up</h2>
      <p className="muted">Create your free ProConnect account.</p>
      <form onSubmit={onSubmit} noValidate>
        <Field id="name" label="Full name" placeholder="Alex Morgan" autoComplete="name" value={values.name} onChange={onChange} error={errors.name} />
        <Field id="email" label="Email address" type="email" placeholder="you@example.com" autoComplete="email" value={values.email} onChange={onChange} error={errors.email} />
        <Field id="password" label="Password" type="password" placeholder="At least 8 characters" autoComplete="new-password" value={values.password} onChange={onChange} error={errors.password} />
        <Field id="confirm" label="Confirm password" type="password" placeholder="Re-enter your password" autoComplete="new-password" value={values.confirm} onChange={onChange} error={errors.confirm} />
        <StatusPicker value={status} onChange={setStatus} disabled={busy} id="signup-status" />
        {formError && <p className="form-error" role="alert">{formError}</p>}
        <button type="submit" className="btn btn-primary btn-block" disabled={busy}>
          {busy ? 'Creating account…' : 'Sign Up'}
        </button>
      </form>
      <p className="auth-switch muted">
        Already a member? <Link to="/sign-in">Sign In</Link>
      </p>
    </AuthLayout>
  );
}
