// Runs the browser-style UI tests: each test file is bundled with esbuild and executed in Node with a simulated
// browser (jsdom). Usage: npm test
import { build } from 'esbuild';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const outDir = path.join(here, '..', 'node_modules', '.cache', 'ui-tests');
fs.mkdirSync(outDir, { recursive: true });

const only = process.argv[2];
const files = fs.readdirSync(here).filter((f) => f.endsWith('.test.jsx') && (!only || f.includes(only))).sort();

let failedFiles = 0;
for (const file of files) {
  const outfile = path.join(outDir, file.replace('.jsx', '.mjs'));
  await build({
    entryPoints: [path.join(here, file)],
    bundle: true, platform: 'node', format: 'esm', outfile, jsx: 'automatic', logLevel: 'error',
    external: ['jsdom'], loader: { '.js': 'jsx' },
    banner: { js: "import { createRequire as __cr } from 'module'; const require = __cr(import.meta.url);" },
  });
  const lines = [];
  const code = await new Promise((resolve) => {
    const child = spawn(process.execPath, [outfile], { stdio: ['ignore', 'pipe', 'pipe'] });
    const timer = setTimeout(() => { lines.push('FAIL timed out after 120 s'); child.kill(); }, 120000);
    const collect = (d) => lines.push(...d.toString().split('\n').filter(Boolean));
    child.stdout.on('data', collect);
    child.stderr.on('data', collect);
    child.on('close', (c) => { clearTimeout(timer); resolve(c); });
  });
  const pass = lines.filter((l) => l.startsWith('PASS')).length;
  const fails = lines.filter((l) => l.startsWith('FAIL') || /Error:/.test(l));
  console.log(`${fails.length || code ? 'FAIL' : 'ok  '} ${file}: ${pass} checks passed${fails.length ? `, ${fails.length} problem(s)` : ''}`);
  fails.forEach((l) => console.log(`      ${l}`));
  if (fails.length || code) failedFiles++;
}
console.log(failedFiles ? `\n${failedFiles} test file(s) failed` : `\nAll ${files.length} test files passed`);
process.exit(failedFiles ? 1 : 0);
