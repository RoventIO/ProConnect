import './setup.js';
import React from 'react';
import { createRoot } from 'react-dom/client';
import { act } from 'react-dom/test-utils';
import { MemoryRouter, Routes, Route, useLocation } from 'react-router-dom';
import { FeedbackProvider } from '../src/components/Feedback.jsx';
import { AuthProvider } from '../src/context/AuthContext.jsx';
import { ThemeProvider } from '../src/context/ThemeContext.jsx';
import AudioPlayer from '../src/components/AudioPlayer.jsx';
import Communities from '../src/pages/Communities.jsx';
import Search from '../src/pages/Search.jsx';
import Courses from '../src/pages/Courses.jsx';
import CourseDetail from '../src/pages/CourseDetail.jsx';
import Header from '../src/components/Header.jsx';
import { RequireAuth } from '../src/components/Guards.jsx';
import SignIn from '../src/pages/SignIn.jsx';

let n = 0, failed = 0;
const check = (name, cond) => { n++; if (!cond) failed++; console.log(cond ? 'PASS' : 'FAIL', name); };
const q = (s, r = document) => r.querySelector(s);
const qa = (s, r = document) => [...r.querySelectorAll(s)];
const flush = () => act(async () => { await new Promise((r) => setTimeout(r, 0)); });
const click = (el) => act(async () => { el.dispatchEvent(new window.MouseEvent('click', { bubbles: true })); });
const byText = (t, scope = document, sel = 'button') => qa(sel, scope).find((b) => b.textContent.trim() === t || b.textContent.trim().startsWith(t));
const choose = (select, value) => act(async () => {
  Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, 'value').set.call(select, value);
  select.dispatchEvent(new window.Event('change', { bubbles: true }));
});
const typeInto = (el, value) => act(async () => {
  Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set.call(el, value);
  el.dispatchEvent(new window.Event('input', { bubbles: true }));
});
URL.createObjectURL = () => 'blob:x';

// ---------- fake server ----------
const calls = [];
let state;
const resetState = () => {
  state = {
    communities: [
      { id: 1, name: 'Alpha Tech', category: 'Technology', description: 'Alpha description', memberCount: 3, postCount: 2, isMember: true, subcommunities: [{ id: 11, name: 'Backend' }] },
      { id: 2, name: 'Beta Health', category: 'Healthcare', description: 'Beta description', memberCount: 1, postCount: 1, isMember: false, subcommunities: [] },
      { id: 3, name: 'Gamma Design', category: 'Design', description: 'Gamma description', memberCount: 2, postCount: 5, isMember: false, subcommunities: [] },
      { id: 4, name: 'Delta Finance', category: 'Finance', description: 'Delta description', memberCount: 0, postCount: 0, isMember: false, subcommunities: [] },
    ],
  };
};
resetState();
const json = (body, status = 200) => ({ ok: status < 400, status, json: async () => body });
const mkPosts = (k) => Array.from({ length: k }, (_, i) => ({ id: 100 + i, title: `Design post ${i}`, excerpt: 'about design systems', createdAt: new Date().toISOString(), replyCount: i, imageCount: i === 0 ? 2 : 0, hasVoice: i === 1, author: { id: 5, name: 'Sara', profession: 'Engineer', avatarUrl: null }, community: { id: 1, name: 'Alpha Tech' } }));
const courseList = [
  { id: 1, title: 'Free Webinar', type: 'webinar', category: 'X', organizer: 'Org A', isFree: true, priceLabel: 'Free', priceText: null, startsAt: '2026-10-22T18:00:00.000Z', duration: 'Live · 60 min', externalUrl: 'https://example.com/a', isSample: true, isPast: false, description: 'A free webinar.' },
  { id: 2, title: 'Paid Course', type: 'course', category: 'Y', organizer: 'Org B', isFree: false, priceLabel: 'Paid', priceText: null, startsAt: null, duration: '6 weeks · Self-paced', externalUrl: 'javascript:alert(1)', isSample: true, isPast: false, description: 'A paid course.' },
  { id: 3, title: 'Old Webinar', type: 'webinar', category: 'Z', organizer: null, isFree: true, priceLabel: 'Free', priceText: null, startsAt: '2020-01-01T10:00:00.000Z', duration: null, externalUrl: null, isSample: false, isPast: true, description: '' },
];
globalThis.fetch = async (input, opts = {}) => {
  const url = new URL(input, 'http://localhost');
  const key = `${opts.method || 'GET'} ${url.pathname}${url.search}`;
  calls.push(key);
  const p = url.pathname, sp = url.searchParams;
  if (p === '/api/auth/me' && globalThis.__visitor) return json({ user: null });
  if (p === '/api/auth/me') return json({ user: { id: 9, name: 'Test User', email: 't@example.com', profileCompleted: true, isAdmin: false } });
  if (p === '/api/communities') return json({ categories: ['Design', 'Finance', 'Healthcare', 'Technology'], communities: state.communities });
  const join = /^\/api\/communities\/(\d+)\/join$/.exec(p);
  if (join) { const c = state.communities.find((x) => x.id === Number(join[1])); const isMember = opts.method === 'POST'; return json({ community: { id: c.id, isMember, memberCount: c.memberCount + (isMember ? 1 : 0) } }); }
  if (p === '/api/search/options') return json({ professions: ['Engineer', 'Nurse'], topics: [{ id: 11, name: 'Backend', parent: { id: 1, name: 'Alpha Tech' } }], communities: [{ id: 1, name: 'Alpha Tech' }] });
  if (p === '/api/search') {
    const qv = sp.get('q') || '', prof = sp.get('profession'), topic = sp.get('topic'), comm = sp.get('community');
    if (!qv && !prof && !topic && !comm) { const e = { items: [], total: 0 }; return json({ query: {}, needsQuery: true, results: { communities: e, posts: e, people: e, courses: e }, excluded: [] }); }
    if (qv === 'nothing') { const e = { items: [], total: 0 }; return json({ query: { q: qv }, needsQuery: false, results: { communities: e, posts: e, people: e, courses: e }, excluded: [] }); }
    const excluded = prof ? ['communities', 'courses'] : [];
    const posts = mkPosts(6);
    return json({ query: { q: qv }, needsQuery: false, excluded, results: {
      communities: excluded.includes('communities') ? { items: [], total: 0 } : { items: [state.communities[2]], total: 1 },
      posts: { items: posts, total: 6 },
      people: { items: [{ id: 7, name: 'Laura Design', profession: 'Designer', location: 'Toronto', headline: 'Freelancer', skills: ['UI', 'Design Systems'], avatarUrl: null }], total: 1 },
      courses: excluded.includes('courses') ? { items: [], total: 0 } : { items: [courseList[0]], total: 1 },
    } });
  }
  if (p === '/api/courses') {
    let list = courseList;
    if (sp.get('type')) list = list.filter((c) => c.type === sp.get('type'));
    if (sp.get('price')) list = list.filter((c) => (sp.get('price') === 'free') === c.isFree);
    return json({ courses: list });
  }
  const one = /^\/api\/courses\/(\d+)$/.exec(p);
  if (one) { const c = courseList.find((x) => x.id === Number(one[1])); return c ? json({ course: c }) : json({ error: { message: 'Course or webinar not found.' } }, 404); }
  return json({ error: { message: 'unexpected ' + key } }, 404);
};

const root = createRoot(document.getElementById('root'));
function Where() { const l = useLocation(); window.__loc = l.pathname + l.search; return null; }
let mountId = 0;
const mount = async (ui, path) => {
  await act(async () => {
    root.render(<MemoryRouter key={++mountId} initialEntries={[path]}><ThemeProvider><AuthProvider><FeedbackProvider><Where />{ui}</FeedbackProvider></AuthProvider></ThemeProvider></MemoryRouter>);
  });
  await flush(); await flush();
};
const section = (id) => q(`[aria-labelledby="${id}"]`);
const cardNames = (sec) => qa('.community-card h3', sec).map((h) => h.textContent);

// ================= 1. AudioPlayer =================
{
  let currentTime = 0;
  Object.defineProperty(window.HTMLMediaElement.prototype, 'currentTime', { get() { return currentTime; }, set(v) { currentTime = v; }, configurable: true });
  let rejectPlay = false;
  window.HTMLMediaElement.prototype.play = function () { if (rejectPlay) return Promise.reject(new Error('blocked')); this.dispatchEvent(new window.Event('play')); return Promise.resolve(); };
  window.HTMLMediaElement.prototype.pause = function () { this.dispatchEvent(new window.Event('pause')); };
  await act(async () => { root.render(<AudioPlayer src="blob:a" durationHint={6} />); });
  const player = q('.audio-player');
  check('player shows themed play button and time from the length hint', !!q('.audio-play', player) && player.textContent.includes('0:00 / 0:06') && !q('audio[controls]'));
  await click(q('.audio-play'));
  check('play switches the button to pause', q('.audio-play').getAttribute('aria-label').startsWith('Pause'));
  await act(async () => { currentTime = 3; q('audio').dispatchEvent(new window.Event('timeupdate')); });
  check('progress and time update while playing', player.textContent.includes('0:03 / 0:06') && q('.audio-seek').value === '500');
  await click(q('.audio-play'));
  check('pause switches back to play', q('.audio-play').getAttribute('aria-label').startsWith('Play'));
  await act(async () => { Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set.call(q('.audio-seek'), '1000'); q('.audio-seek').dispatchEvent(new window.Event('input', { bubbles: true })); q('.audio-seek').dispatchEvent(new window.Event('change', { bubbles: true })); });
  check('dragging the slider seeks the audio', currentTime === 6);
  await act(async () => { q('audio').dispatchEvent(new window.Event('ended')); });
  check('playback end resets to the start', player.textContent.includes('0:00 / 0:06'));
  rejectPlay = true;
  await click(q('.audio-play'));
  check('a blocked or broken file shows a clear message', q('.audio-player').textContent.includes('Cannot play'));
  rejectPlay = false;
  await act(async () => { root.render(<AudioPlayer src="blob:b" durationHint={0} />); });
  check('slider is disabled when the length is unknown', q('.audio-seek').disabled === true);
}

// ================= 2. Communities: joined on top, discover below =================
await mount(<Communities />, '/communities');
check('a regular member does not see the Create community button (only administrators do)', !byText('Create community', document, 'button'));
check('the page has the two named sections', q('#your-communities').textContent === 'My Communities' && q('#discover-communities').textContent === 'Discover Communities');
check('joined community is under "My Communities"', cardNames(section('your-communities')).join() === 'Alpha Tech');
check('the others are under "Discover communities"', cardNames(section('discover-communities')).join() === 'Beta Health,Gamma Design,Delta Finance');
check('joined card has an Open button', !!byText('Open', section('your-communities'), 'a'));
await click(byText('Design', section('discover-communities')));
check('category filter narrows only the discover list', cardNames(section('discover-communities')).join() === 'Gamma Design' && cardNames(section('your-communities')).join() === 'Alpha Tech');
await click(byText('All professions'));
await click(byText('Join Community', qa('.community-card', section('discover-communities'))[0]));
await flush();
check('joining sends a request', calls.includes('POST /api/communities/2/join'));
check('the joined community moves to the top section', cardNames(section('your-communities')).join() === 'Alpha Tech,Beta Health');
check('and leaves the discover list', cardNames(section('discover-communities')).join() === 'Gamma Design,Delta Finance');
check('the member count in the top section is updated', section('your-communities').textContent.includes('2 members'));
check('a success message is shown', document.body.textContent.includes('You joined Beta Health'));
await click(byText('Joined', qa('.community-card', section('your-communities'))[0]));
check('leaving asks first', !!q('[role=dialog]') && q('[role=dialog]').textContent.includes('Leave Alpha Tech?'));
await click(byText('Leave community', document));
await flush();
check('after leaving, the card goes down to discover', cardNames(section('your-communities')).join() === 'Beta Health' && cardNames(section('discover-communities')).includes('Alpha Tech'));
await click(byText('Joined', qa('.community-card', section('your-communities'))[0]));
await click(byText('Leave community', document));
await flush();
check('with nothing joined an explanation is shown', section('your-communities').textContent.includes('You have not joined any communities yet') && cardNames(section('discover-communities')).length === 4);
resetState();

// ================= 3. Search page =================
await mount(<Search />, '/search?q=design');
check('search calls the API with the keyword', calls.includes('GET /api/search?q=design'));
let tabs = qa('[role=tab]').map((t) => t.textContent.trim());
check('tabs show counts per content type', tabs.join('|') === 'All (9)|Communities (1)|Discussions (6)|People (1)|Courses & Webinars (1)');
check('the All view shows up to 4 discussions with a "Show all" link', qa('.row.result', section('res-posts') || q('#res-posts').closest('section')).length === 4 && !!byText('Show all 6'));
check('the keyword is highlighted in results', qa('mark').some((m) => m.textContent.toLowerCase() === 'design'));
check('results link to their pages', !!q('a[href="/posts/100"]') && !!q('a[href="/members/7"]') && !!q('a[href="/communities/3"]') && !!q('a[href="/courses/1"]'));
await click(byText('Show all 6'));
check('"Show all" opens that type', window.__loc.includes('type=posts') && qa('.row.result').length === 6);
await click(byText('Discussions', document, '[role=tab]'));
await click(byText('All (', document, '[role=tab]'));
await choose(q('.filter-select select'), 'Engineer');
await flush(); await flush();
check('choosing a profession filters through the API', calls.includes('GET /api/search?q=design&profession=Engineer'));
check('types the filter cannot apply to are disabled and explained', byText('Communities', document, '[role=tab]').disabled && byText('Courses & Webinars', document, '[role=tab]').disabled && document.body.textContent.includes('Hidden for these filters: Communities, Courses & Webinars'));
await click(byText('Clear filters'));
await flush(); await flush();
check('clearing filters restores the keyword search', window.__loc === '/search?q=design' && !byText('Communities', document, '[role=tab]').disabled);

await mount(<Search />, '/search?q=nothing');
check('an empty result explains itself', document.body.textContent.includes('No results for "nothing"'));
await mount(<Search />, '/search');
check('an empty box shows guidance and suggestions', document.body.textContent.includes('Search ProConnect') && !!byText('Design', document, '.chip-btn'));
await click(byText('Design', document, '.chip-btn'));
await flush(); await flush();
check('a suggestion runs a search', window.__loc === '/search?q=Design' && calls.includes('GET /api/search?q=Design'));

// header search box drives the page
await mount(<><Header /><Routes><Route path="/search" element={<Search />} /><Route path="*" element={<div>other</div>} /></Routes></>, '/communities');
const box = q('form[role=search] input');
check('header has the specified placeholder', box.placeholder === 'Search professions, communities, topics, or people...');
await typeInto(box, '  design tokens ');
await act(async () => { q('form[role=search]').dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true })); });
await flush(); await flush();
check('submitting the header search opens the results page', window.__loc === '/search?q=design+tokens' && calls.includes('GET /api/search?q=design+tokens'));
check('the header box keeps the text', q('form[role=search] input').value === 'design tokens');

// ================= 4. Courses & Webinars =================
await mount(<Courses />, '/courses');
check('all listings are shown with Free/Paid labels', qa('.course-card').length === 3 && qa('.course-card .pill-free').length === 2 && qa('.course-card .pill-paid').length === 1);
check('sample and ended listings are marked', qa('.course-card')[0].textContent.includes('Sample') && qa('.course-card')[2].textContent.includes('Ended'));
check('missing optional details do not break a card', qa('.course-card')[2].querySelector('h3 a').textContent === 'Old Webinar');
await click(byText('Webinars', document, '.chip-btn'));
await flush();
check('type filter queries the API and narrows the list', calls.includes('GET /api/courses?type=webinar') && qa('.course-card').length === 2);
await click(byText('Paid', document, '.chip-btn'));
await flush();
check('price and type filters combine, with a clear empty state', calls.includes('GET /api/courses?type=webinar&price=paid') && document.body.textContent.includes('No courses or webinars match'));
await click(byText('Clear filters'));
await flush();
check('clearing restores the full list', qa('.course-card').length === 3);
check('View Details links to the listing', !!q('a[href="/courses/1"]'));

await mount(<Routes><Route path="/courses/:id" element={<CourseDetail />} /></Routes>, '/courses/1');
let link = q('.course-cta a');
check('detail shows facts and the sample notice', document.body.textContent.includes('Format and length') && document.body.textContent.includes('demonstration listing'));
check('registration link opens safely in a new tab', link?.getAttribute('href') === 'https://example.com/a' && link.getAttribute('target') === '_blank' && link.getAttribute('rel').includes('noopener'));
await mount(<Routes><Route path="/courses/:id" element={<CourseDetail />} /></Routes>, '/courses/2');
check('a paid course says payments are not processed here', document.body.textContent.includes('does not process payments'));
check('an unsafe link is not turned into a button', !q('.course-cta a') && document.body.textContent.includes('has not provided a registration link'));
await mount(<Routes><Route path="/courses/:id" element={<CourseDetail />} /></Routes>, '/courses/99');
check('unknown listing shows a clear message', document.body.textContent.includes('Course or webinar not found'));

// ================= 5. Visitors are asked to sign in before protected pages =================
globalThis.__visitor = true;
await mount(<Routes><Route path="/search" element={<RequireAuth><Search /></RequireAuth>} /><Route path="/courses" element={<RequireAuth><Courses /></RequireAuth>} /><Route path="/sign-in" element={<SignIn />} /></Routes>, '/search?q=design');
check('a visitor opening search is sent to Sign In', window.__loc === '/sign-in');
check('with a clear explanation about the professional profile', document.body.textContent.includes('Sign in or create an account to continue') && document.body.textContent.includes('professional profile'));
check('no search request was made for the visitor', !calls.some((c) => c.startsWith('GET /api/search?q=design') && calls.lastIndexOf(c) > calls.indexOf('GET /api/courses?type=webinar&price=paid')));
await mount(<Routes><Route path="/courses" element={<RequireAuth><Courses /></RequireAuth>} /><Route path="/sign-in" element={<SignIn />} /></Routes>, '/courses');
check('a visitor opening Courses & Webinars is sent to Sign In', window.__loc === '/sign-in');
globalThis.__visitor = false;

console.log(failed === 0 ? `ALL ${n} PASSED` : `${failed} of ${n} FAILED`);
process.exit(failed ? 1 : 0);
