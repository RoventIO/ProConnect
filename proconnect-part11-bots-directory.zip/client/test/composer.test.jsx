import './setup.js';
import React from 'react';
import { createRoot } from 'react-dom/client';
import { act } from 'react-dom/test-utils';
import Composer from '../src/components/Composer.jsx';

let n = 0, failed = 0;
const check = (name, cond) => { n++; if (!cond) failed++; console.log(cond ? 'PASS' : 'FAIL', name); };
const q = (s) => document.querySelector(s);
const click = (el) => act(async () => { el.dispatchEvent(new window.MouseEvent('click', { bubbles: true })); });
const byLabel = (l) => [...document.querySelectorAll('[aria-label]')].find((e) => e.getAttribute('aria-label') === l);
const type = (el, value) => act(async () => {
  const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
  el.dispatchEvent(new window.Event('input', { bubbles: true }));
});
const submit = () => act(async () => { q('form').dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true })); });
const chooseFiles = (files) => act(async () => {
  const input = q('input[type=file]');
  Object.defineProperty(input, 'files', { value: files, configurable: true });
  input.dispatchEvent(new window.Event('change', { bubbles: true }));
});

// Browser APIs that jsdom lacks
URL.createObjectURL = () => 'blob:fake';
URL.revokeObjectURL = () => {};
Object.defineProperty(globalThis.navigator, 'mediaDevices', { value: { getUserMedia: async () => ({ getTracks: () => [{ stop() {} }] }) }, configurable: true });
class FakeRecorder {
  static isTypeSupported = (t) => t === 'audio/webm;codecs=opus';
  constructor(stream, opts) { this.state = 'inactive'; this.mimeType = opts?.mimeType; }
  start() { this.state = 'recording'; }
  stop() { this.state = 'inactive'; this.ondataavailable?.({ data: new Blob([new Uint8Array(500)]) }); this.onstop?.(); }
}
globalThis.MediaRecorder = FakeRecorder;

const submitted = [];
let failNext = null;
const onSubmit = async (fd) => { if (failNext) { const e = failNext; failNext = null; throw e; } submitted.push(fd); };

const root = createRoot(document.getElementById('root'));
await act(async () => { root.render(<Composer withTitle placeholder="Share…" submitLabel="Post discussion" onSubmit={onSubmit} />); });

// 1. validation
await submit();
check('empty post shows title and content errors', document.body.textContent.includes('at least 3 characters') && document.body.textContent.includes('Write something'));
check('nothing is sent when invalid', submitted.length === 0);

// 2. emoji at the cursor
await type(q('#composer-title'), 'Hello team');
await type(q('#composer-text'), 'Great work');
const ta = q('#composer-text');
ta.setSelectionRange(5, 5);
await click(byLabel('Add emoji'));
check('emoji panel opens', !!q('.emoji-picker'));
await click(byLabel('Insert 😀'));
check('emoji inserted at the cursor', ta.value === 'Great😀 work');
await click(byLabel('Gestures'));
await click(byLabel('Insert 🙏'));
check('another category works and panel stays open', ta.value.includes('🙏') && !!q('.emoji-picker'));
await act(async () => { document.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); });
check('Escape closes the emoji panel', !q('.emoji-picker'));

// 3. images and GIFs
const png = (name) => new File([new Uint8Array(100)], name, { type: 'image/png' });
await chooseFiles([png('a.png'), new File([new Uint8Array(100)], 'b.gif', { type: 'image/gif' }), png('c.png'), png('d.png'), png('e.png')]);
check('only 4 images are accepted', document.querySelectorAll('.attach-previews li').length === 4);
check('limit message is shown', document.body.textContent.includes('up to 4 images'));
check('GIF is labelled', document.body.textContent.includes('GIF'));
await chooseFiles([new File([new Uint8Array(10)], 'x.svg', { type: 'image/svg+xml' })]);
check('unsupported type is refused', document.body.textContent.includes('JPG, PNG, WebP or GIF'));
await click(byLabel('Remove image 1'));
check('an image can be removed', document.querySelectorAll('.attach-previews li').length === 3);

// 4. voice message
await click(byLabel('Record a voice message'));
check('recording state is shown', document.body.textContent.includes('Recording'));
check('the microphone button shows the recording state', byLabel('Stop recording').className.includes('is-recording'));
check('the Stop button during recording uses the danger style', q('.voice-recording .btn-danger')?.textContent.includes('Stop'));
await click(byLabel('Stop recording'));
check('recorded voice message can be previewed in the themed player', !!q('.voice-preview .audio-player') && !q('audio[controls]') && q('.voice-preview').textContent.includes('0:00 / 0:'));
check('record button is disabled after recording', byLabel('Record a voice message').disabled === true);

// 5. successful submit
await submit();
const fd = submitted[0];
check('form was submitted once', submitted.length === 1);
check('title and text are sent', fd.get('title') === 'Hello team' && fd.get('content').includes('🙏'));
check('3 images and 1 voice file are sent', fd.getAll('images').length === 3 && fd.get('voice')?.name === 'voice.webm');
check('voice duration is sent', Number(fd.get('voiceDuration')) >= 1);
check('form resets after sending', q('#composer-title').value === '' && q('#composer-text').value === '' && document.querySelectorAll('.attach-previews li').length === 0 && !q('audio'));

// 6. server field errors are displayed
await type(q('#composer-title'), 'Another one');
await type(q('#composer-text'), 'text');
failNext = Object.assign(new Error('bad'), { fields: { title: 'Server says the title is not allowed.' } });
await submit();
check('server validation message is shown', document.body.textContent.includes('Server says the title is not allowed.'));
check('text is kept after a failed send', q('#composer-text').value === 'text');
failNext = Object.assign(new Error('Join Design & UX to take part in its discussions.'), {});
await submit();
check('general server error is shown', document.body.textContent.includes('Join Design & UX to take part'));

console.log(failed === 0 ? `ALL ${n} PASSED` : `${failed} of ${n} FAILED`);
process.exit(failed ? 1 : 0);
