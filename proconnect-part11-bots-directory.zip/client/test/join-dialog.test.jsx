import './setup.js';
import React from 'react';
import { createRoot } from 'react-dom/client';
import { act } from 'react-dom/test-utils';
import { MemoryRouter } from 'react-router-dom';
import { FeedbackProvider, useFeedback } from '../src/components/Feedback.jsx';
import JoinButton from '../src/components/JoinButton.jsx';

const results = [];
const check = (name, cond) => { results.push([cond ? 'PASS' : 'FAIL', name]); console.log(cond ? 'PASS' : 'FAIL', name); };
const click = (el) => act(async () => { el.dispatchEvent(new window.MouseEvent('click', { bubbles: true })); });
const q = (s) => document.querySelector(s);
const byText = (t) => [...document.querySelectorAll('button')].find((b) => b.textContent.trim().includes(t));

function Probe() {
  const { confirm, notify } = useFeedback();
  return (<>
    <button id="go" onClick={async () => { window.__r = await confirm({ title: 'Delete it?', message: 'msg', confirmLabel: 'Delete', tone: 'danger' }); }}>go</button>
    <button id="toast" onClick={() => notify('Hello there', { action: { label: 'View', to: '/x' } })}>t</button>
  </>);
}

let community = { id: 1, name: 'Finance & Accounting', isMember: false };
const calls = [];
globalThis.fetch = async (url, opts = {}) => {
  calls.push(`${opts.method || 'GET'} ${url}`);
  const isMember = opts.method === 'POST';
  return { ok: true, json: async () => ({ community: { id: 1, isMember, memberCount: isMember ? 3 : 2 } }) };
};
function Wrap() {
  const [c, setC] = React.useState(community);
  return <JoinButton community={c} onChange={(s) => setC((x) => ({ ...x, ...s }))} />;
}

const root = createRoot(document.getElementById('root'));
await act(async () => { root.render(<MemoryRouter><FeedbackProvider><Probe /><Wrap /></FeedbackProvider></MemoryRouter>); });

// confirm dialog
await click(q('#go'));
check('dialog opens with title', q('[role=dialog]')?.textContent.includes('Delete it?'));
check('dialog is modal and labelled', q('[role=dialog]').getAttribute('aria-modal') === 'true' && !!q('#modal-title'));
check('Cancel is focused first', document.activeElement?.textContent === 'Cancel');
check('danger button styled', byText('Delete').className.includes('btn-danger'));
await click(byText('Delete'));
check('confirm resolves true and closes', window.__r === true && !q('[role=dialog]'));

await click(q('#go'));
await act(async () => { document.dispatchEvent(new window.KeyboardEvent('keydown', { key: 'Escape', bubbles: true })); });
check('Escape resolves false and closes', window.__r === false && !q('[role=dialog]'));

await click(q('#go'));
await act(async () => { q('.modal-overlay').dispatchEvent(new window.MouseEvent('mousedown', { bubbles: true })); });
check('clicking outside cancels', window.__r === false && !q('[role=dialog]'));

await click(q('#go'));
await click(byText('Cancel'));
check('Cancel resolves false', window.__r === false);

await click(q('#toast'));
check('toast shows message and link', q('.toast')?.textContent.includes('Hello there') && q('.toast a')?.getAttribute('href') === '/x');

// join button flow
await click(byText('Join Community'));
check('join sends POST', calls.includes('POST /api/communities/1/join'));
check('button becomes Joined', !!byText('Joined'));
check('success message shown', document.body.textContent.includes('You joined Finance & Accounting'));

await click(byText('Joined'));
check('leaving asks first in styled dialog', q('[role=dialog]')?.textContent.includes('Leave Finance & Accounting?'));
check('no DELETE before confirming', !calls.some((c) => c.startsWith('DELETE')));
await click(byText('Stay'));
check('Stay keeps membership', !!byText('Joined') && !calls.some((c) => c.startsWith('DELETE')));

await click(byText('Joined'));
await click(byText('Leave community'));
check('confirming sends DELETE', calls.includes('DELETE /api/communities/1/join'));
check('button returns to Join Community', !!byText('Join Community'));
check('leave message shown', document.body.textContent.includes('You left Finance & Accounting'));


console.log(results.every(([s]) => s === 'PASS') ? 'ALL PASSED' : 'SOME FAILED');
process.exit(results.every(([s]) => s === 'PASS') ? 0 : 1);
