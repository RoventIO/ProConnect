// PRD acceptance checks for the application shell and the account flows, run against the real <App />.
import './setup.js';
import React from 'react';
import { createRoot } from 'react-dom/client';
import { act } from 'react-dom/test-utils';
import { MemoryRouter, useLocation } from 'react-router-dom';
import App from '../src/App.jsx';
import { ThemeProvider } from '../src/context/ThemeContext.jsx';
import { LayoutProvider } from '../src/context/LayoutContext.jsx';
import { AuthProvider } from '../src/context/AuthContext.jsx';
import { FeedbackProvider } from '../src/components/Feedback.jsx';

let n = 0, failed = 0;
const check = (name, cond, info) => { n++; if (!cond) failed++; console.log(cond ? 'PASS' : 'FAIL', name); if (!cond && info) console.log('   detail:', typeof info === 'function' ? info() : info); };
const q = (s, r = document) => r.querySelector(s);
const qa = (s, r = document) => [...r.querySelectorAll(s)];
const flush = async () => { for (let i = 0; i < 3; i++) await act(async () => { await new Promise((r) => setTimeout(r, 0)); }); };
const click = (el) => act(async () => { el.dispatchEvent(new window.MouseEvent('click', { bubbles: true, cancelable: true })); });
const setValue = (el, value) => act(async () => {
  const proto = el.tagName === 'TEXTAREA' ? window.HTMLTextAreaElement.prototype : window.HTMLInputElement.prototype;
  Object.getOwnPropertyDescriptor(proto, 'value').set.call(el, value);
  el.dispatchEvent(new window.Event('input', { bubbles: true }));
});
const submit = (form) => act(async () => { form.dispatchEvent(new window.Event('submit', { bubbles: true, cancelable: true })); });
const text = () => document.body.textContent;

// ---------- fake server ----------
const MEMBER = { id: 1, name: 'Alex Morgan', email: 'alex@example.com', profession: 'Designer', avatarUrl: null, profileCompleted: true, isAdmin: false };
const NEWBIE = { id: 2, name: 'Nina Park', email: 'nina@example.com', profession: null, avatarUrl: null, profileCompleted: false, isAdmin: false };
let session, hits, homeDown;
const json = (body, status = 200) => ({ ok: status < 400, status, json: async () => body });
globalThis.fetch = async (input, opts = {}) => {
  const url = new URL(input, 'http://localhost');
  const method = opts.method || 'GET';
  hits.push(`${method} ${url.pathname}`);
  const body = opts.body ? JSON.parse(opts.body) : {};
  const p = url.pathname;
  if (p === '/api/auth/me') return json({ user: session });
  if (p === '/api/auth/logout') { session = null; return json({ ok: true }); }
  if (p === '/api/auth/register') {
    if (body.email === 'taken@example.com') return json({ error: { code: 'email_taken', message: 'An account with this email already exists.', fields: { email: 'An account with this email already exists.' } } }, 409);
    session = NEWBIE; return json({ user: NEWBIE }, 201);
  }
  if (p === '/api/auth/login') {
    if (body.password === 'wrong-password') return json({ error: { code: 'invalid_credentials', message: 'Incorrect email or password.' } }, 401);
    session = MEMBER; return json({ user: MEMBER });
  }
  if (p === '/api/profile' && method === 'PUT') { session = { ...NEWBIE, ...MEMBER, name: NEWBIE.name }; return json({ user: session }); }
  if (p === '/api/stats') { const w = { count: 0, points: [0, 0, 0, 0, 0, 0, 0] }; return json({ totals: { communities: 6, professionals: 5, discussions: 6, replies: 5 }, week: { memberships: w, professionals: w, discussions: w, replies: w } }); }
  if (p === '/api/home') { if (homeDown) throw new TypeError('Failed to fetch'); return json({ trending: [{ id: 1, title: 'A trending discussion', createdAt: new Date().toISOString(), replyCount: 2, author: { id: 3, name: 'Sara Kim', profession: 'Engineer', avatarUrl: null }, community: { id: 1, name: 'Backend' } }], courses: [], popularCommunities: [{ id: 1, name: 'Software Development', memberCount: 2, postCount: 1 }] }); }
  return json({ error: { message: 'unexpected ' + p } }, 404);
};

const root = createRoot(document.getElementById('root'));
function Where() { const l = useLocation(); window.__loc = l.pathname; return null; }
let mountId = 0;
async function mount(path, { user = null, down = false } = {}) {
  localStorage.clear();
  session = user; hits = []; homeDown = down;
  await act(async () => {
    root.render(
      <MemoryRouter key={++mountId} initialEntries={[path]}>
        <ThemeProvider><LayoutProvider><AuthProvider><FeedbackProvider><Where /><App /></FeedbackProvider></AuthProvider></LayoutProvider></ThemeProvider>
      </MemoryRouter>
    );
  });
  await flush();
}
const navLabels = () => qa('.sidebar .nav-item .nav-label').map((e) => e.textContent.trim());
const field = (id) => q(`#${id}`);

// ================= Navigation and sidebar (PRD 7.1, FR-08) =================
await mount('/');
check('visitor navigation order is Home, Communities, News, Courses & Webinars, Jobs', navLabels().join('|') === 'Home|Communities|News|Courses & Webinars|Jobs');
await mount('/', { user: MEMBER });
check('member navigation adds My Profile as the last item', navLabels().join('|') === 'Home|Communities|News|Courses & Webinars|Jobs|My Profile');
const soonItems = qa('.sidebar .nav-item').filter((i) => i.querySelector('.badge-soon'));
check('only News and Jobs carry a "Soon" label, and there is no Chats item', soonItems.map((i) => i.querySelector('.nav-label').textContent).join() === 'News,Jobs' && qa('.badge-soon').length === 2 && !navLabels().includes('Chats'));
const everySoon = qa('body *').filter((e) => e.children.length === 0 && e.textContent.trim() === 'Soon');
check('the word "Soon" appears nowhere else on the page', everySoon.length === 2);
check('Soon items are inert (no link), and clicking one does not navigate', soonItems.every((i) => i.tagName === 'BUTTON' && i.getAttribute('aria-disabled') === 'true' && !i.getAttribute('href')));
await click(soonItems[0]);
check('clicking a Soon item stays on the same page', window.__loc === '/');
check('Home is highlighted as active at "/"', qa('.sidebar .nav-item.active').map((e) => e.querySelector('.nav-label').textContent).join() === 'Home');
await click(q('.sidebar a[href="/communities"]'));
await flush();
check('navigating highlights only the current section', qa('.sidebar .nav-item.active').map((e) => e.querySelector('.nav-label').textContent).join() === 'Communities');

// collapse / expand
const toggle = () => q('.sidebar-top button');
check('toggle is near the top of the sidebar with the tooltip "Collapse sidebar"', toggle().getAttribute('data-tip') === 'Collapse sidebar' && toggle().getAttribute('aria-label') === 'Collapse sidebar');
await click(toggle());
check('collapsing keeps the sidebar and changes the tooltip to "Expand sidebar"', q('.app').className.includes('collapsed') && !!q('.sidebar') && toggle().getAttribute('data-tip') === 'Expand sidebar' && navLabels().length === 6);
check('collapsed icons keep names for screen readers and tooltips, Soon items say "· Soon"', qa('.sidebar .nav-item').every((i) => i.getAttribute('aria-label')) && qa('.sidebar .nav-item').some((i) => i.getAttribute('data-tip') === 'News · Soon'));
check('the active highlight is preserved while collapsed', q('.sidebar .nav-item.active') !== null);
check('the collapsed state is remembered', localStorage.getItem('pc-sidebar-collapsed') === '1');
await click(toggle());
check('expanding restores the sidebar repeatedly', !q('.app').className.includes('collapsed') && toggle().getAttribute('data-tip') === 'Collapse sidebar');

// ================= Theme (FR-09) =================
const themeBtn = () => q('.theme-btn');
const theme = () => document.documentElement.getAttribute('data-theme');
const startTheme = theme();
const iconFor = (t) => (t === 'dark' ? 'lucide-moon' : 'lucide-sun');
check(`the starting theme is a real theme ("${startTheme}") and shows the matching icon (moon in dark, sun in light)`, ['dark', 'light'].includes(startTheme) && !!q(`.theme-btn .${iconFor(startTheme)}`));
const contentBefore = text();
await click(themeBtn());
const flipped = theme();
check('switching flips the theme and the icon', flipped !== startTheme && !!q(`.theme-btn .${iconFor(flipped)}`) && !q(`.theme-btn .${iconFor(startTheme)}`));
check('the content is unchanged by switching themes', text() === contentBefore && navLabels().length === 6, () => 'page text changed after the theme switch');
await click(toggle());
await click(themeBtn());
check('theme switching works while the sidebar is collapsed', theme() === startTheme && q('.app').className.includes('collapsed'));
check('the theme choice is remembered', localStorage.getItem('pc-theme-v2') === startTheme);

// ================= Header states (FR-10) and search field =================
await mount('/');
check('visitor header shows Sign In and Sign Up and no avatar', !!q('.header a[href="/sign-in"]') && !!q('.header a[href="/sign-up"]') && !q('.header .avatar-btn'));
const box = q('.header form[role=search] input');
check('compact search field uses the specified placeholder', box?.placeholder === 'Search professions, communities, topics, or people...');
await mount('/', { user: MEMBER });
check('member header shows a circular avatar instead of the buttons', !!q('.header .avatar-btn') && !q('.header a[href="/sign-in"]') && !q('.header a[href="/sign-up"]'));
await click(q('.avatar-btn'));
check('the avatar opens an account menu with My Profile and Log Out', !!q('[role=menu] a[href="/profile"]') && /Log Out/.test(q('[role=menu]').textContent));
await click(qa('[role=menuitem]').find((b) => b.textContent.includes('Log Out')));
await flush();
check('Log Out signs out and the header returns to Sign In / Sign Up', hits.includes('POST /api/auth/logout') && !!q('.header a[href="/sign-in"]') && window.__loc === '/');

// ================= Home (FR-07) =================
await mount('/');
const h2 = q('.hero h2').textContent.replace(/\s+/g, ' ').trim();
check('Home shows the specified headline and description', h2 === 'Your Professional World, Connected.' && text().includes('Discover professional communities, exchange real-world experience, learn from industry experts, and build meaningful connections with people who share your interests.'), () => JSON.stringify(h2));
check('Home offers Explore Communities and Join ProConnect', [...qa('.hero .hero-actions a')].map((a) => a.textContent.trim()).join() === 'Explore Communities,Join ProConnect', () => `${window.__loc} :: ${[...qa('.hero .hero-actions a')].map((a) => a.textContent.trim()).join()} :: ${text().slice(0, 200)}`);
check('a visitor does not see internal content, only a prompt to join', !text().includes('Trending Discussions') && !hits.includes('GET /api/home') && text().includes('are for members'));
await mount('/', { user: MEMBER });
check('a member sees Trending Discussions, Courses & Webinars and Popular Communities', ['Trending Discussions', 'Courses & Webinars', 'Popular Communities'].every((t) => text().includes(t)) && text().includes('A trending discussion'));
await mount('/', { user: MEMBER, down: true });
check('when the server cannot be reached the page says so instead of failing silently', text().includes('Cannot reach the server'));

// ================= Sign Up (FR-01) =================
await mount('/sign-up');
await submit(q('.content form'));
check('empty Sign Up shows clear validation messages', ['Enter your full name.', 'Enter your email address.', 'Use at least 8 characters.'].every((m) => text().includes(m)) && !hits.some((h) => h.includes('register')), () => `${window.__loc} :: ${text().slice(0, 300)}`);
await setValue(field('name'), 'Nina Park'); await setValue(field('email'), 'not-an-email'); await setValue(field('password'), 'longenough1'); await setValue(field('confirm'), 'different');
await submit(q('.content form'));
check('invalid email and mismatched passwords are explained', text().includes('Enter a valid email address.') && text().includes('Passwords do not match.'));
await setValue(field('email'), 'taken@example.com'); await setValue(field('confirm'), 'longenough1');
await submit(q('.content form')); await flush();
check('a duplicate email is rejected with a clear message', text().includes('An account with this email already exists.') && window.__loc === '/sign-up');
await setValue(field('email'), 'nina@example.com');
await submit(q('.content form')); await flush();
check('a valid registration continues to professional-profile setup', hits.includes('POST /api/auth/register') && window.__loc === '/onboarding' && text().includes('Tell professionals who you are'));

// ================= Onboarding (FR-01 minimum profile) =================
await submit(q('.content form'));
check('the minimum profile is required (profession, biography, skill)', ['Enter your profession.', 'Write a short biography', 'Add at least one skill'].every((m) => text().includes(m)) && !hits.includes('PUT /api/profile'));
await setValue(field('profession'), 'Nurse'); await setValue(field('bio'), 'Emergency nurse interested in data.'); await setValue(field('skills'), 'Triage, Patient care');
check('skills preview chips appear while typing', qa('.chips .pill').map((c) => c.textContent).join() === 'Triage,Patient care');
await submit(q('.content form')); await flush();
check('saving the profile unlocks the platform (goes to Home)', hits.includes('PUT /api/profile') && window.__loc === '/');

// ================= Sign In =================
await mount('/sign-in');
await submit(q('.content form'));
check('empty Sign In shows validation messages', text().includes('Enter your email address.') && text().includes('Enter your password.'));
await setValue(field('email'), 'alex@example.com'); await setValue(field('password'), 'wrong-password');
await submit(q('.content form')); await flush();
check('a wrong password gives a generic error and stays on the page', text().includes('Incorrect email or password.') && window.__loc === '/sign-in');
await setValue(field('password'), 'right-password');
await submit(q('.content form')); await flush();
check('a correct sign-in goes to Home and shows the member header', window.__loc === '/' && !!q('.header .avatar-btn'));
await mount('/sign-in', { user: MEMBER });
check('a signed-in member opening Sign In is sent back to Home', window.__loc === '/');

// ================= Access rules and unknown pages =================
for (const path of ['/communities', '/courses', '/profile', '/search?q=x', '/communities/1', '/posts/1']) {
  await mount(path);
  check(`visitor opening ${path} is sent to Sign In with an explanation`, window.__loc === '/sign-in' && text().includes('Sign in or create an account to continue'));
}
await mount('/onboarding', { user: NEWBIE });
await mount('/communities', { user: NEWBIE });
check('a member without the minimum profile is sent to profile setup', window.__loc === '/onboarding');
await mount('/does-not-exist', { user: MEMBER });
check('an unknown address shows a helpful "Page not found" page', text().includes('Page not found') && !!q('a[href="/"]'));

// ================= Accessibility basics =================
await mount('/', { user: MEMBER });
const unnamed = qa('button, a, input:not([type=hidden]), select, textarea').filter((el) => {
  if (el.hidden) return false;
  const label = el.id && document.querySelector(`label[for="${el.id}"]`);
  return !(el.getAttribute('aria-label') || el.getAttribute('title') || el.textContent.trim() || label || el.closest('label')?.textContent.trim());
});
check('every button, link and field on Home has an accessible name', unnamed.length === 0);
check('the page has exactly one level-1 heading', qa('h1').length === 1);
check('all user-facing text is English (no Armenian letters rendered)', !/[\u0530-\u058F]/.test(text()));

console.log(failed === 0 ? `ALL ${n} PASSED` : `${failed} of ${n} FAILED`);
process.exit(failed ? 1 : 0);
